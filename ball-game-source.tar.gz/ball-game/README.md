# Ball Game: precision ball racing on Godot + Jolt

A time-trial ball racer built around flow and momentum: roll, carve, jump and
loop through a tutorial course, The Original Track and three themed levels
against the clock.

![Banked turn](docs/screenshots/03_banked_turn.jpg)

## Run it

- **Godot 4.4 or newer** (4.6+ recommended: Jolt became the default there).
  Open `project.godot` and press F5. The first open imports the project.
- **Godot 4.3** has no built-in Jolt. Install the *Godot Jolt* add-on from the
  Asset Library, then set *Project Settings › Physics › 3D › Physics Engine* to
  `JoltPhysics3D`. Without it the game runs on Godot Physics and feels different.

| Action | Keyboard / mouse | Gamepad | Touch screen |
| --- | --- | --- | --- |
| Roll (camera-relative) | WASD / arrows | Left stick | Stick under the left thumb (touch anywhere on the left half) |
| Jump (hold for full height) | Space | A | Jump button, bottom right |
| Look | Mouse | Right stick | Drag on the right half |
| Recenter camera | C | Right stick click | Double tap on the right half |
| Restart instantly | R / Backspace | Y | Restart button, top left |
| This level's leaderboard | Tab (while held) | Back (while held) | Podium button, top left (tap again to hide) |
| Menu: levels and settings (pauses) | Esc / P | Start | Pause button, top left |

The clock starts on your first input, stops at the finish line (interpolated
inside the physics tick), and every finished run is recorded per track.

- **Ghost.** A translucent ball replays your fastest run while you race, and the
  HUD shows a live split: how far ahead (green) or behind (red) of it you are
  at the same point of the track. Both can be turned off in the menu.
- **Leaderboards.** Hold Tab (Back on a gamepad) to see the level's
  leaderboards over the running game, like a scoreboard (`LeaderboardOverlay`):
  your fastest runs on the track and how many you've finished, and, when you
  play in Möbius, the **community leaderboard** that all Ball Game players
  share, under your Möbius @handle. The finish banner shows where a run ranked,
  and your community rank. The pause menu (Esc) keeps the things that aren't
  about one level: picking a level and the settings. See the app README one
  folder up for how the community board is hosted.
- **Settings.** Camera distance and angle, field of view (and how much it widens
  at speed), mouse sensitivity (on a touch screen: look speed) and invert,
  auto-orient, volume, rolling sound, ghost and split, and graphics options for
  slower machines and browsers: lighter graphics (on by default on phones),
  render resolution (50–100%), faster edge smoothing and shadows on/off.
  They're saved between sessions; phones and tablets keep their own (see below).
- **Sound.** The rolling sound is synthesized at start-up (no audio files): its
  volume and pitch follow your speed while you're on the ground, with a thud on
  hard landings.

### In a browser

The **Ball Game** app in Möbius plays this project's web build. The *Web*
export preset is single-threaded, so it needs no special server headers;
exporting it from the editor writes `build/web/`, which you can host anywhere
(itch.io, for example). Möbius packages its own copy: run
`python3 tools/build_web.py` from the app's root (one folder up), then apply the app.
On the web, Godot uses its Compatibility (WebGL 2) renderer, which looks a
little brighter than desktop. Browsers only lock the mouse after a click, so
mouse-look starts once you click into the game.

## On phones and tablets

The same game, fitted to a touch screen. Phones and tablets (touch first, no
mouse to hover with) get it from the start; any other touch screen gets the
touch controls once it's touched, and keys, a mouse or a gamepad put them
away again.

- **Controls** (`TouchControls`) follow what phone 3D ball and platform games
  settled on, Marble It Up: Mayhem!'s analog stick and jump button above all:
  a *floating* stick appears under the left thumb wherever it lands (no
  missing a fixed one), with a small dead zone and full drive at 85% of its
  ring, and the ring follows a thumb that runs past it. Dragging on the right
  half looks around, as a mouse does on a desktop, and the camera swings
  behind the ball by itself (double tap there to swing it at once). It frames
  the ball exactly as the desktop does (*Camera distance*, *angle* and *field
  of view* are shared with the desktop's settings, and an upright phone keeps
  the desktop's angle), but faces the direction of travel firmly
  (`FollowCamera.touch_auto_yaw_sharpness`, `touch_auto_orient_min_speed`,
  `touch_auto_orient_full_speed`, `touch_auto_yaw_max_rate`): a desktop
  player has a mouse to turn the view, and an upright phone shows less than a
  third as much to the sides, so the desktop's gentle swing, trailing the
  Beach's first long right bend by up to 23°, ran the road off the phone's
  edge; on a touch screen it trails by 6° at most. With the touch controls
  up, a mouse drag doesn't look around: browsers report a finger's moves as
  the mouse's too (the first finger holding its button), which made steering
  with the stick count as turning the view by hand, so the camera stopped
  following the ball through turns; the page also keeps fingers' pointer
  moves from the engine (`keepFingersFromTheMouse` in `index.jsx`). (Earlier versions also
  tried a view that led into the stick's turns, a camera facing along the
  road, a steeper upright view and the desktop's own swing; on a phone the
  wanted one faces the direction the ball is travelling.) A touch on the look
  side only takes the view once it has dragged `look_start` (20 px) from where
  it landed, so a thumb resting there or rolling off the jump button leaves
  the camera following the ball; a dragging thumb holds the view only while it
  really moves (`look_slop`), and the camera takes over again `look_hold`
  (0.4 s) after it stops. And where a desktop camera leaves travel more than
  135° from the view alone (that's reversing), a phone's turns round to it
  once it has lasted a second (`touch_turn_round_time`): the
  ball bounced back off a
  wall, say, and that's the way it's going now. The big jump button sits under the
  right thumb: tap for a hop, hold for a full jump. Pause, restart and the
  leaderboard are small buttons top left, starting just right of Möbius's
  own exit button in that corner (`corner_offset`). Tilt steering was left out on
  purpose: it's divisive even in Super Monkey Ball, and the app frame can't
  read the motion sensors anyway.
- **The same physics.** The stick hands `PlayerInput` the same
  camera-relative intent a gamepad's left stick does, and the jump button
  presses the jump action itself, so `RollingBall` can't tell the devices
  apart: same 120 Hz Jolt, same tuning. Tests check that a full or half push
  drives exactly as keys or a gamepad stick at the same deflection, and that
  two seconds on either reach the same speed.
- **Layout** (`ScreenFit`): the UI is drawn in the browser's own pixels (a
  44 px button is thumb-sized however dense the screen; a little smaller on
  small phones, bigger on tablets), and small screens get compact layouts of
  the HUD (the speed between the stick and the jump button), the pause menu
  (title and buttons on one row, level cards to fit, numbers set with − and +
  rather than sliders a scrolling finger would drag, thumb-sized toggles) and the leaderboard. Everything stays clear of the notch, rounded
  corners and home bar the page reports. Held upright, the camera keeps the
  desktop's angle and its field of view across rather than up and down (up
  to `portrait_max_fov`, 90°), so the road ahead doesn't narrow to a slot; the
  HUD suggests turning the
  phone sideways for the wider view. Desktops keep their window's pixels and
  layout exactly as before.
- **Their own settings, the same camera.** App storage is shared by all of a
  player's devices, so phones and tablets keep their settings in
  `settings_touch.json`, apart from the desktop's `settings.json`. How the
  camera frames the ball (distance, angle, field of view and its widening at
  speed; `"shared"` in `GameSettings.SCHEMA`) is the player's own wherever
  they play, so it stays in `settings.json` and phones read and change it
  there: set it on the desktop and the phone frames the ball the same way.
- **Lighter graphics** (*Lighter graphics for phones*, on by default there,
  and phones start with *Shadows* off) trim what phones struggle with and
  leave the physics alone: the 3D view is drawn with at most about 0.8
  million pixels (a phone's screen has three or more for every desktop one;
  the edges keep their multisampling), and in a browser the whole game with
  at most 1.4 million (`LIGHT_CANVAS_PIXELS`: each frame is copied across the
  whole screen several times on its way to the display, which at a phone's
  full density was more memory traffic than the 3D view itself; the page
  reports a lower pixel ratio, so menus and text keep their size, a little
  softer), surfaces leave their relief (normal) maps off and the ground uses
  its shader's lighter version (one texture read where there were four or
  more: no anti-tiling copy, relief or roughness maps), models
  switch to their simpler versions twice as soon, scenery that fades with
  distance does so at 55% of it, set pieces seen from all over a level but
  only reached at one end of it are drawn only within 200 m
  (`GameSettings.LIGHT_RANGE_META`: the Winter Wonderland's cabin, Christmas
  tree and presents past the finish, some thirty model pieces that were a
  quarter of a phone's triangles there; their collision is always there),
  only half the purely decorative props are
  drawn (plants, grass, flowers: `GameSettings.DECORATIVE_META`, nothing the ball
  can hit; solid trees and rocks are all there), leaves are cut out in one pass
  instead of a depth pass and soft edges, there's no glow and half the
  particles, the sun's shadows (if switched on) reach 60% as far in two
  cascades at most, the screen is drawn 60 times a second (physics still step
  120 times), and the levels come from their lighter packs: the same level
  with textures at most 512 px and skies at most 2048 px, a quarter of the
  memory and a smaller download (`tools/build_web.py` makes them). Measured
  with software rendering at the same resolution, the Forest drew 110 calls
  and 127 k triangles a frame instead of 195 and 335 k, and took half the
  time; the Winter Wonderland 148 and 233 k instead of 245 and 669 k. All of
  it is in `GameSettings` (`LIGHT_*`); a level pack already downloaded stays
  until the game starts again.

## Levels

| Level | Id | What it is |
| --- | --- | --- |
| Tutorial Level | `test_track` | The original untextured grid course for learning the moves: ramps, banks, a jump and a loop (about 20 s). Its id is still `test_track`, so its records and leaderboard carry on. |
| The Original Track | `original` | The Tutorial Level's untextured grid look with more to get past: a drop into six tight wiggles (a very curvy road), four floating boxes to hop across (8 m gaps, each box a metre higher than the last, so every one takes a jump), a drop off the last box, a short 70°-banked wall ride, a giant grid sphere standing in a 30 m gap (jump onto it and roll over its top: without a jump there's no getting past), and a snaking run to the finish (about 21 s). |
| Beach Boardwalk | `beach` | A pirate bay: plank boardwalks over the sea (see-through in the shallows), a break to jump whose far side is offset sideways, an open candy-striped corkscrew channel (too slow and you drop out of the top), a jump past an anchored pirate galleon, then down onto the sand and right through a wrecked pirate ship broken in two. A wave rolls in from the sea across the beach: its face is a moving half-pipe you can ride. A steam vent in the road blasts you high into the air, then a towering cliff: climb a rise past the swinging cannonballs, drop off it to build speed, and carry it up an 80° face nearly 40 m high (nobody can drive up a wall, so it's momentum or nothing). Past two giant cannonballs swinging on chains, a long banked helix with a wall ride, another break to jump, and a choice: the palm swing and the jump between the cannons, or a raised boardwalk shortcut with its own break and rows of barrels rolling down it at you (jump them) that drops you onto the finish pier (about 41 s). |
| Forest | `jungle` | A mossy causeway between tall trees under a cloudy sky, then a choice: the very wiggly stretch and a jump between branches, or a very narrow, slippery, mossy log bridge straight over them with three breaks to jump and big stones sitting on it; the forest floor between cobblestone walls (a ball that rolled off the course can't rejoin it from the ground there, and huge boulders block the way across the open forest), a murky lily pond to cross on three big notched lily pads about 20 m apart, so each jump needs timing (fall in and the water holds you to a crawl), right through a huge fallen hollow log, past ruins, a climb past a round boulder swinging on a chain, a root break whose far side is offset, a 72°-banked wall ride, a loop, a narrow canopy bend, the final climb and a last leap before the finish, rolling a wooden ball (about 45 s hopping the pads; over a minute wading). |
| Winter Wonderland | `winter` | An ice run with candy-cane curbs between snowy, pine-covered hills, then a choice: the walled bobsled bends, or a narrow ice bridge straight across them with wide holes in the ice to weave between and a break to jump, which drops you onto a slippery black-ice bend; an open candy corkscrew channel, a jump over a frozen river, a snowman village of candy canes, reindeer and presents you can knock about, a climb past two giant baubles swinging on chains, a break to jump before the candy loop, a climb into a steep banked spiral, another break (offset sideways), then a drop into a huge ice bowl: swoop down and up its far side to be thrown onto the landing slope, and a last run-up to the finish leap, which only clears the gap with speed and a well-timed jump. The finish line stands well past where the leap lands. Beyond it, a log cabin and a giant Christmas tree in a clearing ringed by thick snowy forest (about 52 s). |

**Switching:** press Esc / P (Start) for the menu; the first tab, **Levels**,
shows every level as a picture card with your best time there, all in view
without scrolling (two across, or three across a wide desktop window once
there are more than four levels; cards get shorter where the rows wouldn't
fit). Pick one and the run restarts
on it. The game always opens on the Tutorial Level. Each level has its own
records, ghost, leaderboard and community leaderboard. In the editor, run
`scenes/main.tscn` and switch from the menu, or open a level scene
(`levels/<id>/<id>_level.tscn`) to edit it.

Most of each themed track runs raised above the ground on pillars; in places
it drops onto open ground (unpaved track pieces), where the Terrain flattens
itself under the racing line and the ball can bounce off trees, rocks,
snowmen, statues and the pillars themselves. The ground is solid everywhere
and the level is walled in at its edge. Off the track (well below or beside
it for a second, or underneath the road at once) the HUD counts down **3, 2,
1** and then puts the ball back on the start line, unless it gets back on the
track first; R / Y resets at once. A ball that drops into a gap and rolls on
under the next stretch is off the track at once: in the forest, a ball that
misses the last leap rolls on under the finish road, which isn't a finish.
A finish is going through the gate itself, between the posts and under the
banner; how the ball got there doesn't matter (a short cut off the track is
fair), since a ball that strayed for longer than the countdown was already
sent back to the start. Jumping from one part of the road onto another
carries on from where the ball lands: the Tutorial Level's quickest line
jumps across the bottom of the loop. The community leaderboard's check
follows the same rule. Track pieces can be
slippery (`grip` below 1, e.g. the winter black ice), and the ball reads the
grip of what it rolls on.

**Editing a themed level.** Its track pieces, sky, sun, materials and terrain
settings are in `tools/level_specs.py`; run `python3 tools/make_level_scene.py`
to rewrite the level scenes from it. Props, the wave, snow and sounds are
placed by each level's script (`levels/<id>/<id>_level.gd`). Useful tools:
`tools/inspect_track.gd` (where each piece ends), `tools/drive_level.gd` (an
autopilot lap; add `routes` to take the alternative routes), `tools/capture_level.gd` (screenshots along a lap, also with `routes`),
`tools/bench_level.gd` (relative render cost). When a track is redesigned,
give it a new `records` name in `scripts/levels/level_catalog.gd` so old
times aren't mixed with the new layout.

**Assets** are CC0 (see `CREDITS.md`): Poly Haven / ambientCG textures in
`Assets/Textures/<theme>/` (1K, imported as compressed WebP), Poly Haven sky
panoramas in `Assets/HDRIs/`, Quaternius and Kenney models in
`Assets/Models/<kind>/<kit>/` (Quaternius textures shared in
`Assets/Models/Quaternius/Textures`, see `tools/glb_share_textures.py`),
Freesound ambience in `Assets/Sounds/<theme>/` (Summer is the beach), and the
materials in `Assets/Materials/`. `python3 tools/fetch_assets.py` re-downloads
the textures, skies and models if you delete them to save space.

## Project layout

```
scenes/main.tscn          Game: ball, camera, input, race, HUD, menu; levels load into "Level"
scenes/ball.tscn          The ball (RigidBody3D + RollingBall)
scenes/test_track.tscn    The Tutorial Level's track: an editable list of track pieces
levels/                   One folder per level (scene + script); test/ wraps the Tutorial Level's track,
                          original/ is The Original Track (scene only)
scripts/levels/           Level, LevelCatalog, LevelLoader, LevelBounds, Terrain (hills,
                          rim), MountainRing, PropScatter, TrackSupports, RideableWave,
                          WreckedShip, HollowLog, LilyPond, Vent, Swinger, StoneWalls,
                          RollingBarrels, LevelAmbience, ModelBatch, TrackBlocks, TrackSphere
Assets/                   Themed textures, skies, models, sounds and materials
scripts/ball/             RollingBall: the controller (all feel lives here), BallAudio
scripts/camera/           FollowCamera
scripts/player/           PlayerInput: keys, gamepad or touch → camera-relative intent
scripts/track/            TrackBuilder, its pieces (Section, Loop, Corkscrew, Gap) and TrackRoute
scripts/race/             RaceManager (timer, restart, fall-out, splits), FinishLine,
                          RunRecords (runs, best, ghost), GhostRun, GhostBall,
                          CommunityBoard (the shared leaderboard, through the web host)
scripts/core/             GameSettings, GameStore (saved JSON documents)
scripts/ui/               RaceHud, PauseMenu (levels + settings), LeaderboardOverlay (Tab),
                          MenuStyle (their shared look), LoadingScreen, ScreenFit (phone
                          layout, safe area), TouchControls (stick, look, jump, buttons)
scripts/party/            PartyClient (party mode, through the web host), RemoteBall
materials/                Road, curb, ball, chequer, ground-grid, block and grid-sphere shaders
tests/                    Headless checks and the autopilot driver
tools/                    Level authoring (level_specs.py, make_level_scene.py, inspect_track,
                          drive_level, capture_level, shoot_views), export_track_outline.gd (track
                          shapes for the leaderboard's run checks), fetch_assets.py
export_presets.cfg        "Web" export (single-threaded, no special headers needed)
```

The ball doesn't read devices itself. Anything that calls
`RollingBall.drive(move, jump_held, jump_pressed)` once per physics tick can
drive it: the player, the test autopilot, or a future AI. The ghost is a
recording (30 samples a second of position and rotation) rather than a replayed
input stream, so it never drifts from the run it shows.

## Tuning guide

Everything that shapes the feel is an exported variable with a tooltip. Select
**Ball** in `main.tscn` (or open `ball.tscn`) and work through the groups:

| Group | What it controls |
| --- | --- |
| **Drive** | `drive_acceleration` and `max_drive_speed`: input adds speed only up to the cap, and slopes can take you beyond it. Above the cap, input can still steer and brake. `brake_multiplier` and `steer_multiplier` make reversing and carving stronger than straight-line acceleration. `torque_drive_share` sets whether the ball is pushed (works on any surface) or spun like a wheel (traction depends on friction). |
| **Grip and Friction** | Friction blends from `friction_at_low_speed` (crisp starts, stops and direction changes) to `friction_at_high_speed` (smooth rolling) between the two speeds. The ball's material is *rough*, so its friction wins on every surface. |
| **Damping** | `ground_linear_damp` is rolling resistance. Vertical motion is never damped in the air, so falls stay snappy. `ground_angular_damp` is the high grounded angular damping you asked for, applied to spin that **isn't rolling**: drilling spin is stopped, and wheel-spin or side-spin is traded into rolling like grippy friction. That keeps control tight without braking. For the classic heavy-ball feel (damping that brakes), raise `ground_angular_damp_on_rolling`. `air_spin_match` lines the spin up with the velocity in flight, so touchdowns keep their speed. |
| **Ground Detection** | `max_ground_angle` sets the steepest slope that counts as ground. `follow_surface` keeps loops and wall-rides counting as ground. `ground_grace_time` covers small bumps. `ground_stick_acceleration` pulls the ball onto the surface at speed (crests, loops). |
| **Jump** | `jump_speed` is the impulse. `coyote_time` and `jump_buffer_time` give grace windows. `jump_cut_gravity_multiplier`: tap for a hop, hold for full height. `jump_surface_influence` blends the jump direction from straight up to the surface normal (wall and loop jumps). |
| **Air Control** | `air_acceleration` and `air_max_speed` work like drive, but horizontal only. `fall_gravity_multiplier` is the main anti-floaty knob, together with the body's `gravity_scale` (2.0). |
| **Momentum** | `curve_energy_refund`: see the design notes below. |

**FollowCamera** groups: *Framing* (distance, pitch, look-ahead), *Follow Lag*
(separate horizontal and vertical sharpness, max lag), *Auto Orient* (how
quickly and how far it swings behind your travel; it waits `free_look_hold_time`
after you look around), *Free Look*, *Collision* (sphere sweep; pulls in
instantly, eases back out), *Surface Follow* (the camera rolls with the track
inside loops) and *Speed FOV*.

Quick recipes:

- **Less floaty:** raise `fall_gravity_multiplier` or the ball's `gravity_scale`.
- **More slide at speed:** lower `friction_at_high_speed`, `torque_drive_share` and `ground_angular_damp`.
- **Twitchier turns:** raise `steer_multiplier`. Lazier camera: lower `auto_yaw_sharpness` and `follow_sharpness`.
- **Classic "roll-a-ball":** set `ground_angular_damp_on_rolling` to 1 and `curve_energy_refund` to 0.

## Editing the track

Select **TestTrack** and edit **Segments**. The road rebuilds live in the editor.
Use *Add Element › New SectionSegment / LoopSegment / CorkscrewSegment / GapSegment*:

- **SectionSegment** covers straights, slopes, ramps and turns: `length`, `turn`
  (positive turns left), `end_pitch`, `end_bank`, and `bank_into_turn`, which
  auto-banks where the turn is tightest. Pitch and bank always ease from the
  previous piece, so joins are smooth.
- **LoopSegment**: `radius` and `side_offset`, the sideways shift so the exit
  clears the entry. `self_steer` leans the road so the ball follows that shift
  even when nobody steers.
- **CorkscrewSegment**: a roller-coaster roll around the direction of travel
  (`length`, `radius`, `turns`, `direction`, `drop`). The helix is tilted so the
  ball's own path enters in line with the track, and it is banked for
  `design_speed`, where speed presses the ball straight into the road. The
  corkscrews are open channels (`width` 0.25 with `curb` 9 and `curb_width`
  3.4: a deep U), with no casing: roughly 26–36 m/s gets through, slower falls
  out of the top, much faster flies out. While the ball is in a deep channel
  RaceManager eases it toward the middle (`channel_spring`, `channel_damping`),
  like a groove, so the ride doesn't depend on hitting the entry perfectly.
- **GapSegment**: open air for jumps (`length`, `rise`, `landing_pitch`). With
  `jump` on it is a break in level road with the far side a little higher, so
  the player has to press jump to get across (the autopilot jumps there too).
- **GapSegment** `shift` moves the far side sideways, so the jumper has to
  steer in the air.
- Every piece can have safety walls (`wall_left`, `wall_right`), a `width`
  (a share of the road's: 0.5 is a narrow plank; widths ease into each other),
  `curb` and `curb_width` (how high and wide the curbs rise: above 1 makes a
  channel; they ease in and out too, and the walls ride on the rim) and
  `tube`, which closes it over into a see-through tube the ball can't fly out
  of (no level uses it now).
- **Holes** (`TrackBuilder.holes`, also on routes): rectangles cut out of the
  road, each (start, length, centre right of the middle, width), with cut
  faces and a dark floor so they read as holes. The ball falls through.

The cross-section (road width, concave lips that guide the ball back to the
middle, rims, walls) and the spawn and finish placement live on TrackBuilder. To
add a new kind of piece, extend `TrackSegment` and implement `lay()`.

The road is one quad across per step, except where it twists (its bank
changing, as into and out of a banked turn): there it is laid in 16 columns
(`ROAD_COLUMNS`), so its surface follows the twist. One quad across a twisting
road isn't flat: it folds along its diagonal into a dip down the middle of the
road (entering a 70° wall ride, 14 cm deep with 16° sides), which threw a fast
ball into the air. Where flat road meets twisting road, the flat quad fans out
to every column's corner, so no edge is left unmatched (one would catch a
rolling ball the same way).

**Swinging weights.** `Swinger` (scripts/levels/swinger.gd) hangs a weight
on a chain from a beam on two posts and swings it across the track on the
race clock, so every run and the ghost meet it the same way. The beam is hung
just high enough that the whole swing stays `clearance` (0.2 m) above the
track, reading the track's top surface from `TrackBuilder.world_top_at()`, so a
road climbing or banking under the weight, or the curbs beside it, never cut
into it; the posts stand clear of both ends of the swing. Lap tests and
the recording tools hold them still at the top of their swing
(`Swinger.hold_still`), because the autopilot can't time its run; tests
check that they knock a ball aside and that no weight on any level dips into
the track or swings through its posts.

**Alternative routes.** Add a `TrackRoute` node as a child of the TrackBuilder.
It forks off beside the road (the lips between the two lie flat, so the road
widens and splits like a Y), follows the road at the `offsets` and `heights`
you key in, runs on its own smooth curve between its `chord` points, banks its
own bends, can have `gaps` to jump, and rejoins by ending a little above the
road so the ball drops back on. Its frames know which distance along the main
track they stand for, so progress, splits, ghosts, the camera, terrain,
scenery, supports and the leaderboard's run check all treat it as part of the
course (`TrackBuilder.network` is the whole layout; `locate()` finds the
nearest point on it). Rules that keep a route rideable: fork on a level
straight long enough for the ball to cross over (about 35 m), keep it clear
of where the main road swings, and end low over a calm stretch with no ramp
or jump just after it. The class comment in `scripts/track/track_route.gd`
explains every setting.

## In the browser

The web build runs on one thread with WebGL 2; game logic and physics take
well under a millisecond a frame, so drawing is what costs. The look is kept
as designed (full resolution, multisampled edges, glow, shadows to 100 m);
what runs in the background is trimmed instead: the level's materials are
drawn once behind the loading screen so nothing stalls mid-run when new
scenery appears (see Loading below), the camera skips its collision sweeps while it follows the
track through loops, and the party bridge is only polled four times a second
outside a party. Settings > Graphics offers faster, rougher edge smoothing
(FXAA instead of multisampling) and a lower render resolution for slow
machines; both are off by default. Phones get lighter graphics (see *On
phones and tablets*).

## Out of sight, asleep

Möbius keeps recently used apps running out of sight (closing an app's tab
only hides it), and the browser can hide the whole page. `AppSuspend`
(scripts/core/app_suspend.gd) polls the host page (`window.ballGameHost.hidden()`,
fed by Möbius's `moebius:frame-visibility` messages and the page's own
visibility) and, while hidden, pauses the game, mutes it and draws it at a
crawl; shown again it carries on as it was. In a party level it only mutes,
so the shared race clock stays fair.

## Design notes: no driving up walls

Below its top speed the drive pushes harder than gravity pulls, so on its
own it would carry a ball straight up a vertical wall. `RollingBall._limit_climb`
fades out the part of the drive that pushes up the slope while the ball heads
up it, from 45° (`climb_drive_start`) to none at 75° (`climb_drive_end`): cliffs
and the rising half of a loop are climbed on momentum alone. Riding along a
steep bank (a wall ride), steering and braking are unaffected.

## Design notes: keeping momentum on Jolt

These came out of measuring the physics headlessly, not guesswork:

- **Spin cap.** Jolt caps angular velocity at 47 rad/s by default. A 0.5 m ball
  can then only truly roll up to about 24 m/s, and friction drags it back above
  that. `project.godot` raises the cap to 250 rad/s.
- **Speculative contacts.** Jolt doesn't report the speculative contacts that
  hold a fast ball on a curved surface, so contact-only ground checks flicker in
  loops. The controller adds a short ray probe and remembers the last surface.
- **Energy loss on tight curves.** Rigid-body solvers lose energy when a ball is
  pressed hard into a tight curve. That's about a quarter of a loop's energy in
  Jolt, and more in Godot Physics, with any solver settings. On smooth ground the
  controller refunds exactly that measured shortfall, capped per tick. Wall hits
  and landings are never refunded, and tests prove it never adds energy.
- **Sinking after impacts.** After a hard landing Jolt leaves the ball sunk
  about 5 cm into the road, and Jolt's friction rolls it about the midpoint
  between the two surfaces. The controller lifts the ball back out and matches
  its spin target to that radius, so it never fights friction.
- **Loop lean.** A loop that shifts sideways needs the road to lean by
  `side_offset · sin(angle) / (2π · radius)`, or a coasting ball drifts into the
  walls.
- **Tick rate.** Physics runs at 120 Hz with physics interpolation. On 4.4+ the
  camera follows the interpolated ball for smooth motion at any refresh rate.

**Finishing.** Crossing the line ends the run: input stops counting, the
ball brakes to a stop on the run-off (`RollingBall.brake_to_stop`, about
23 m from 46 m/s) and confetti bursts from the gate's posts and showers down
just ahead of the ball, where the camera is looking (`FinishLine.celebrate`). A finish is
the ball's centre passing forward through the gate: between the posts, from
the road (`ROAD_BELOW`) up to the banner's underside (`opening_height()`).
Beside a post, over the banner or under the road doesn't count. R restarts as always. `tools/drive_level.gd`
reports where the ball came to rest after the finish.

**Drawing the scenery.** Scattered props are drawn in batches, one per kind
and area (PropScatter), and each batch uses the models' lower-detail versions
(made on import) as it gets further away, judged for the size its copies are
drawn at (`lod_bias`, the biggest copy's scale): about a fifth fewer
triangles in the forest and the winter level, with no visible change. (Until
0.11 a merge step dropped those versions, so every tree and rock was drawn in
full at any distance.)

**Fewer, bigger batches.** In a browser every batch (draw call) has a fixed
cost on top of its triangles, and the forest and winter levels drew hundreds
a frame. So the scenery is batched big: in the forest the trees along the
course in 150 m squares, the hills'
forest in 200 m ones, plants in 120 m ones (drawn to 200 m, so a batch's far
side doesn't take near plants with it), rocks in 150 m and boulders in 400 m
ones; in the winter level all its trees, rocks, snow piles and snowmen in
150–200 m squares, and the forest round the finish clearing in 200 m ones.
The hollow log's fungus and ferns and the pond's pads and flowers are one
batch each (`ModelBatch`).

**The forest** costs the most to draw, mostly its trees. Only the trees within
40 m of the track cast shadows (theirs reach the road), shadows reach 60 m
rather than 100 (`shadow_distance` in the level's spec), the forest on the
hills isn't drawn beyond 220 m, and the trees along the course aren't drawn
beyond 300 m, where the haze takes them (with no limit they were nearly half
of every frame's trees). On the web the sun's soft shadows take 5 samples a
pixel rather than 13 (`soft_shadow_filter_quality.web` in project.godot):
under the forest canopy nearly every pixel is in dappled shade, where the
13-sample filter can't stop early, and that was about a sixth of each frame.
The edges look the same.

**How smooth it runs.** The first two runs on each level in a session report,
when each run ends, how it played (`PerfReport`, through the host page's
`run_perf` signal): average frames per second, frames longer than 25 ms (a
missed refresh at 60 Hz), 1/30 s and 1/15 s, the slowest frame, which 50 m
stretches of track the long frames were on, the twenty slowest frames (where,
how long, and the engine's drawing time for each), the drawing time's median,
95th percentile and maximum, the window's size in screen pixels, the share
of it the 3D view was drawn at (`render_scale`; lighter graphics draw phones'
views smaller), whether the touch controls were up, and `cpu`: the physics
step and the scripts' time (median/max of each second's worst, in ms) and
physics steps per frame (mean/most). Physics steps 120 times a second, so a
frame that runs long has to catch up with more steps: on phones the number to
watch. The page adds how long the
engine worked on each frame (`engine_ms`, `engine_long`): a long frame the
engine wasn't busy for was waiting on the graphics card. (Signals carry flat
values only, so the lists go as text, e.g. `long_frames_at` "450:7 500:3".) For looking into lag on a player's own
machine.

**Loading.** Choosing a level puts up a loading screen (`LoadingScreen`,
owned by LevelLoader) over a picture of the level (`ui/loading/<id>.jpg`, in
the main pack so it shows during the download), with its name, the
download's progress, then "Building the level…". Building runs in one go on
the main thread, so the loader waits until the screen has been drawn before
it starts. The game always opens on the Tutorial Level (to try another
level out, `LevelLoader.first_level` opens straight on it instead, with the
tutorial as the fallback if its download fails).

Then, still behind the screen, it gets the graphics ready
(`LevelLoader._prepare_graphics`, "Getting the graphics ready… n%"): a
browser compiles each graphics program the first time something is drawn
with it, on the page's only thread, and on Windows that takes a third of a
second or more per program, which otherwise stalls the game mid-run when new
scenery comes into view. Everything in the level is drawn once, one look
(shader, drawn singly or as many copies, with or without shadows) per frame
so the screen keeps moving, with the level's particles, the ghost and a bit
of the finish confetti last. Lights other than the sun are left out of the
levels on purpose: every material near a point light needs a second program
lit by it, compiled the first time the ball gets near.

The host page (`index.jsx`, `skipUnusedShaderVariants`) also saves about half
of all compiles: Godot 4.7's web renderer compiles four "default" variants of
every material's shader up front that no render pass ever draws with (every
pass picks a variant that says how lightmaps are handled; the defaults don't),
so the page hands those a tiny stand-in program instead, and reports it if a
stand-in is ever drawn with. When a level is ready the game reports how long
the download, the build and the graphics took (`level_ready`, with the number
of programs compiled) through the host page, for looking into slow loads.

**Walls, barrels, the cabin.** `StoneWalls` stands cobblestone walls along
both sides of every open-ground stretch (a ball that left the course can't
rejoin from the ground). `RollingBarrels` rolls rows of barrels down a stretch
of road toward the player on the race clock (tests park them, like the
swinging weights). `Terrain.end_clearing` levels a clearing past the end of
the track ringed by hills (open toward the track), which the winter level
fills with a thick forest (PropScatter placements can take a `world`
position); steep ground is textured from the
sides too (triplanar), so cliffs don't streak.

**Boxes and a sphere.** In a level with no terrain, `TrackBlocks`
(scripts/levels/track_blocks.gd) stands a solid box under each open-ground
stretch of the track (pieces with `paved` off, kept straight and level): its
top is the stretch, as wide as the road with its curbs, and all the boxes
reach down to one floor. With jump gaps between them, The Original Track
hops across four. `TrackSphere` (scripts/levels/track_sphere.gd) stands a big
ball in a jump gap, by distance along the track and its top's height above the
centreline there. Both draw in the road's colours (materials/block.gdshader,
grid_sphere.gdshader).

**Lily pond, vent.** `LilyPond` (scripts/levels/lily_pond.gd) floods a stretch
of track with water that drags a wading ball down to a crawl and floats a
zigzag of lily pads (`pad_count`, `pad_bounce`) to hop along; `wade_speed` caps a
wading ball. `Vent` (scripts/levels/vent.gd) is a steam
vent in the road that launches a ball landing on it high into the air
(`RollingBall.launch`). Both are placed by distance along the track from the
level's script.

## Party mode

Several players race the same levels at the same time; each level hands out
points (10, 8, 6, 5, 4, 3, 2, 1, then 1 for any finish, 0 for none) and a
podium crowns the top three. The party itself (lobby, rounds, start times,
results, podium) lives in the web host page (`../party.jsx`), over Möbius live
rooms; `PartyClient` (scripts/party/party_client.gd) is the game's side:

- it loads the party's level and pins it (the menu can't switch away), puts
  the ball on the start line locked (`RollingBall.locked`) and reports
  "loaded";
- it starts the clock at the shared start (`RaceManager.start_now`); a start
  noticed late counts the seconds already gone, so loading slowly never helps;
- during a party level (`RaceManager.party_round`) restarting puts the ball
  back on the start line without stopping the clock, the ghost is hidden, and
  runs don't become personal records or community runs;
- it reports the finish, broadcasts the ball's position 15 times a second and
  draws the others as `RemoteBall`s with name tags, solid when the host turns
  bumping on (they sit on their own physics layer, so the camera ignores them).

On the desktop or in tests there is no web host and nothing happens; a test
hands in a stand-in host.

## Tests

```
godot --headless --path . --fixed-fps 120 --script res://tests/run_tests.gd
godot --headless --path . --fixed-fps 120 --script res://tests/run_tests.gd -- --verbose
```

That's 290 checks: speed cap, coasting, braking, carving without speed gain,
friction blend, spin damping, jump heights, tap vs hold, coyote time, no double
jump, landing speed, lossless coasting through a loop and up a climb, no energy
gain, camera behaviour, the timer starting on first input, restart, fall reset,
run records and ranking, ghost save and playback, settings, the pause menu and the Tab leaderboard, the community board (with a stand-in host),
two autopilot laps of the full Tutorial Level track (about 20.3 s; the second races
the first one's ghost), level switching with separate records, falling off (no auto-reset, solid
floor, hard border, R to reset), the ball bouncing off a jungle tree, black
ice grip, the beach wave carrying a ball along, a jump break stopping a ball
that doesn't jump, a swinging weight knocking a ball aside (without pressing it
into the road), every level's swinging weights clearing the track and their
posts, a corkscrew dropping
a slow ball and carrying a fast one, the vent's blast, the pond's drag and
lily pads, a party round (shared start, locked countdown, restart keeping the
clock, finish report, other balls drawn and solid), braking to a stop after
the finish, where a crossing of the finish line counts (through the gate only:
not beside a post, over the banner, under the road or backwards), missing the
forest's last leap showing as off the track at once rather than finishing, a hole dropping the ball through, rolling barrels shoving it, the
forest walls stopping a ball from the ground, the loading screen, the frame report going out once per run for the right level, two autopilot laps of each themed level without falling
off (one on the main road, one riding its alternative route), the game opening
on the Tutorial Level whatever was played last, a fast ball riding into a wall
ride and out again without leaving the road, The Original Track's boxes and
sphere each needing a jump (and landing one from the edge or a few metres
before it, at 22 to 33 m/s), an autopilot lap of The Original Track, the
levels menu showing every level without scrolling (tutorial first) on desktop
windows and phones, and phones: the
layout for phone and desktop screens, the touch stick driving exactly as keys
or a gamepad stick (same intent, same speed), jumping with the stick held,
looking around by dragging, the camera keeping up with bends on a touch
screen and a resting thumb not holding it, the touch buttons, phones' own settings, lighter
graphics and their lighter level packs, and the menus and controls fitting a
phone's screen sideways and upright. Tests never touch your saved runs or settings, and never send runs.
`BALL_GAME_DUMP_GHOST=<file>` saves the autopilot lap's recording, which the
leaderboard service's tests use as a known-good run. `--verbose` adds a speed table for each piece of the lap.

## Notes

- **Keeping the browser fast.** The ground is drawn in 120 m blocks with three
  levels of detail, so blocks behind the camera aren't drawn; blocks further
  than `keep_within` from every road (past the hill crests) and, on the beach,
  under the sea (`hide_below`) aren't built at all. The ground shader reads a
  texture layer only where it shows. Scattered scenery is batched per model
  and look in 60 m chunks: only trees, rocks and props near the track cast
  shadows (not small plants), and scattered scenery isn't drawn beyond 300 m.
  The sun's shadows reach 100 m. `tools/bench_level.gd` compares levels
  (frame time under software rendering, draw calls, triangles); add
  `hide=Props` or similar to see what a part costs.

- Saved data is a few JSON documents (`settings.json`, `best_times.json`,
  `runs_<track>.json`, `ghost_<track>.json`) handled by `GameStore`. On desktop
  they live in `user://store/`; older `user://best_times.cfg` bests are imported.
  In the Möbius web app they're kept in app storage instead, through
  `window.ballGameStore`, because the app frame has no IndexedDB for `user://`
  files.
- Godot 4.3 in headless mode prints three harmless "Parameter m is null"
  dummy-renderer errors for built-in box and sphere meshes. A normal editor or
  game window doesn't.
- Jolt may occasionally log "job system exceeded the maximum number of jobs"
  on many-core machines. It's internal to the engine and harmless.

| | |
| --- | --- |
| ![Start](docs/screenshots/01_start_line.jpg) | ![Loop](docs/screenshots/06_loop_entry.jpg) |
| ![Loop top](docs/screenshots/07_loop_top.jpg) | ![Finish](docs/screenshots/09_finish.jpg) |
