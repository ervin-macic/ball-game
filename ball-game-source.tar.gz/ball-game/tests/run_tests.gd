extends SceneTree
## Headless checks for the ball controller, the race flow and the test track.
##
## Run from the project folder (fixed fps keeps physics deterministic):
##   godot --headless --fixed-fps 120 --script res://tests/run_tests.gd
## Add `-- --verbose` for a per-segment speed table of the autopilot lap.
## Exits with code 1 if any check fails.

const BALL_SCENE := preload("res://scenes/ball.tscn")
const MAIN_SCENE := preload("res://scenes/main.tscn")
const Autopilot := preload("res://tests/autopilot.gd")

const TICK := 1.0 / 120.0

var _failures: Array[String] = []
var _check_count := 0
var _verbose := false


func _initialize() -> void:
	_verbose = OS.get_cmdline_user_args().has("--verbose")
	_run.call_deferred()


func _run() -> void:
	await _test_resting_ball_is_grounded_with_upward_normal()
	await _test_full_input_reaches_drive_speed_and_holds_it()
	await _test_released_input_keeps_momentum()
	await _test_opposing_input_brakes_harder_than_it_accelerates()
	await _test_steering_above_drive_speed_turns_without_adding_speed()
	await _test_friction_is_grippy_when_slow_and_slick_when_fast()
	await _test_grounded_damping_kills_drilling_spin_but_not_rolling()
	await _test_held_jump_reaches_expected_height()
	await _test_tapped_jump_is_lower_than_held_jump()
	await _test_coyote_time_allows_a_late_jump_off_a_ledge()
	await _test_jump_after_coyote_time_is_ignored()
	await _test_no_second_jump_in_the_air()
	await _test_landing_keeps_horizontal_speed()
	await _test_coasting_through_a_loop_keeps_its_momentum()
	await _test_rolling_never_climbs_higher_than_its_energy_allows()
	await _test_swinging_in_a_valley_never_gains_height()
	await _test_camera_starts_behind_the_ball_on_restart()
	await _test_camera_swings_behind_the_direction_of_travel()
	await _test_camera_pulls_in_when_a_wall_blocks_the_view()
	await _test_timer_waits_for_first_input()
	await _test_the_ball_waits_still_on_every_start_line()
	await _test_tracking_finds_the_road_after_leaving_a_loop_early()
	await _test_restart_returns_ball_to_spawn_and_clears_timer()
	await _test_leaving_the_track_counts_down_then_resets()
	await _test_autopilot_finishes_test_track_through_the_loop()
	await _test_game_store_round_trips_documents()
	await _test_run_records_rank_every_run_and_keep_the_best_ghost()
	await _test_ghost_round_trips_through_its_saved_form()
	await _test_settings_apply_to_camera_and_ghost()
	await _test_pause_menu_pauses_the_game_and_resumes_it()
	await _test_tab_shows_this_levels_leaderboard()
	await _test_community_board_is_unavailable_outside_mobius()
	await _test_community_board_sends_runs_and_shows_the_ranking()
	await _test_levels_switch_with_their_own_records_and_ball()
	await _test_props_are_solid_and_the_ball_bounces_off_them()
	await _test_black_ice_is_slippery()
	await _test_the_beach_wave_carries_the_ball()
	await _test_a_jump_break_needs_a_jump()
	await _test_a_swinging_weight_knocks_the_ball_aside()
	await _test_a_corkscrew_needs_speed()
	await _test_a_vent_blasts_the_ball_skyward()
	await _test_the_pond_slows_waders_and_the_pads_bounce()
	await _test_a_party_starts_everyone_together_and_reports_the_finish()
	await _test_the_ball_brakes_to_a_stop_after_the_finish()
	await _test_the_finish_counts_only_through_the_gate()
	await _test_missing_the_last_leap_is_off_the_track_at_once()
	await _test_a_hole_in_the_road_drops_the_ball_through()
	await _test_rolling_barrels_knock_the_ball_back()
	await _test_forest_walls_keep_ground_riders_off_the_course()
	await _test_a_loading_screen_covers_a_level_change()
	await _test_the_camera_turns_smoothly_through_the_loop()
	await _test_driving_cannot_climb_a_wall()
	await _test_the_game_sleeps_while_hidden()
	await _test_graphics_options_and_view_distance()
	for level_id in ["beach", "jungle", "winter"]:
		await _test_autopilot_finishes_level(level_id)
		await _test_autopilot_finishes_level(level_id, true)
	# After the laps: every level built before them shifts the physics they
	# run on, and the autopilot's ride over the forest's narrow log bridge is
	# sensitive to that.
	await _test_the_game_opens_on_the_tutorial()
	await _test_jumping_across_the_loop_still_finishes()
	await _test_each_run_reports_how_smoothly_it_played_once()
	await _test_a_run_left_out_of_sight_is_reported()
	await _test_swinging_weights_clear_the_track_and_their_posts()
	# The Original Track, and the road under its wall ride.
	await _test_a_ball_rolls_into_a_wall_ride_without_taking_off()
	await _test_the_original_tracks_boxes_and_sphere_need_jumps()
	await _test_autopilot_finishes_level("original")
	# Touch screens and phones.
	await _test_screens_are_fitted_for_phones_and_left_alone_on_desktops()
	await _test_the_touch_stick_drives_like_a_gamepad_stick()
	await _test_the_touch_stick_stays_where_it_is()
	await _test_the_jump_button_jumps_with_the_stick_held()
	await _test_dragging_on_the_right_looks_around()
	await _test_on_a_touch_screen_the_camera_faces_the_travel_through_turns()
	await _test_a_resting_thumb_doesnt_hold_the_camera()
	await _test_touch_buttons_restart_show_the_board_and_open_the_menu()
	await _test_phones_keep_their_own_settings()
	await _test_phones_share_the_desktops_camera_framing()
	await _test_held_upright_the_camera_keeps_the_desktop_angle()
	await _test_lighter_graphics_trim_what_phones_struggle_with()
	await _test_lighter_graphics_fetch_the_lighter_level_packs()
	await _test_the_phone_layout_fits_the_screen()
	await _test_the_levels_menu_shows_every_level()

	print("\n%d checks, %d failed" % [_check_count, _failures.size()])
	for failure in _failures:
		print("  FAIL ", failure)
	quit(1 if _failures.size() > 0 else 0)


# --- Ball controller ---------------------------------------------------------

func _test_resting_ball_is_grounded_with_upward_normal() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(60)
	_check(ball.is_grounded(), "resting ball is grounded")
	_check(ball.get_surface_up().dot(Vector3.UP) > 0.99, "ground normal points up (got %s)" % ball.get_surface_up())
	_check(absf(ball.global_position.y - ball.radius) < 0.05, "ball rests on the surface (y=%.3f)" % ball.global_position.y)
	world.free()


func _test_full_input_reaches_drive_speed_and_holds_it() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	var time_to_20 := -1.0
	for i in 600:
		ball.drive(Vector3.FORWARD, false, false)
		await physics_frame
		if time_to_20 < 0.0 and ball.linear_velocity.length() >= 20.0:
			time_to_20 = i * TICK
	var speed := ball.linear_velocity.length()
	_info("0-20 m/s in %.2f s, speed after 5 s: %.2f m/s" % [time_to_20, speed])
	_check(speed > ball.max_drive_speed * 0.9 and speed < ball.max_drive_speed * 1.03,
			"full input settles near max_drive_speed (%.2f vs %.2f)" % [speed, ball.max_drive_speed])
	world.free()


func _test_released_input_keeps_momentum() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _drive_for(ball, Vector3.FORWARD, 4.0)
	var before := ball.linear_velocity.length()
	await _ticks(240)
	var after := ball.linear_velocity.length()
	_info("coast: %.2f -> %.2f m/s over 2 s" % [before, after])
	_check(after > before * 0.85, "coasting 2 s keeps >85%% of speed (%.1f%%)" % (100.0 * after / before))
	world.free()


func _test_opposing_input_brakes_harder_than_it_accelerates() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _drive_for(ball, Vector3.FORWARD, 4.0)
	var start_speed := ball.linear_velocity.length()
	var ticks := 0
	while ball.linear_velocity.dot(Vector3.FORWARD) > 0.0 and ticks < 1200:
		ball.drive(Vector3.BACK, false, false)
		await physics_frame
		ticks += 1
	var braking := start_speed / (ticks * TICK)
	_info("braking from %.1f m/s took %.2f s (%.1f m/s²)" % [start_speed, ticks * TICK, braking])
	_check(braking > ball.drive_acceleration, "braking decelerates faster than drive accelerates (%.1f m/s²)" % braking)
	world.free()


func _test_steering_above_drive_speed_turns_without_adding_speed() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(10)
	var fast := ball.max_drive_speed * 1.3
	ball.linear_velocity = Vector3.FORWARD * fast
	ball.angular_velocity = Vector3.UP.cross(ball.linear_velocity) / ball.radius
	await _ticks(2)
	var entry := ball.linear_velocity.length()
	await _drive_for(ball, Vector3.LEFT, 1.0)
	var velocity := ball.linear_velocity
	var turned := rad_to_deg(Vector3.FORWARD.angle_to(Vector3(velocity.x, 0.0, velocity.z)))
	_info("steering at %.1f m/s: turned %.1f° in 1 s, speed now %.1f" % [entry, turned, velocity.length()])
	_check(velocity.length() < entry * 1.02, "steering above max_drive_speed adds no speed")
	_check(turned > 20.0, "steering above max_drive_speed still turns (%.1f°)" % turned)
	world.free()


func _test_friction_is_grippy_when_slow_and_slick_when_fast() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(30)
	var material := ball.physics_material_override
	_check(is_equal_approx(material.friction, ball.friction_at_low_speed) and material.rough,
			"rough, high friction at rest (%.2f)" % material.friction)
	await _drive_for(ball, Vector3.FORWARD, 5.0)
	_check(absf(material.friction - ball.friction_at_high_speed) < 0.02,
			"low friction at speed (%.2f at %.1f m/s)" % [material.friction, ball.linear_velocity.length()])
	world.free()


func _test_grounded_damping_kills_drilling_spin_but_not_rolling() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _drive_for(ball, Vector3.FORWARD, 2.0)
	var speed := ball.linear_velocity.length()
	ball.angular_velocity += Vector3.UP * 40.0
	await _ticks(60)
	var drilling := absf(ball.angular_velocity.dot(Vector3.UP))
	var rolling := ball.angular_velocity.length() * ball.radius
	_info("after 0.5 s: drilling spin %.2f rad/s, rolling %.1f m/s, speed %.1f -> %.1f" % [drilling, rolling, speed, ball.linear_velocity.length()])
	_check(drilling < 1.0, "drilling spin damped out (%.2f rad/s)" % drilling)
	_check(ball.linear_velocity.length() > speed * 0.94, "rolling speed kept while damping spin")
	world.free()


func _test_held_jump_reaches_expected_height() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(30)
	var apex := await _jump_apex(ball, 0.6)
	var g := 9.8 * ball.gravity_scale
	var expected := ball.jump_speed * ball.jump_speed / (2.0 * g)
	_info("held jump apex %.2f m (expected %.2f)" % [apex, expected])
	_check(absf(apex - expected) < expected * 0.1, "held jump apex within 10%% of v²/2g")
	world.free()


func _test_tapped_jump_is_lower_than_held_jump() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(30)
	var apex := await _jump_apex(ball, 0.05)
	var full := ball.jump_speed * ball.jump_speed / (2.0 * 9.8 * ball.gravity_scale)
	_info("tapped jump apex %.2f m (held %.2f)" % [apex, full])
	_check(apex < full * 0.75, "a tapped jump is clearly lower than a held one")
	world.free()


func _test_coyote_time_allows_a_late_jump_off_a_ledge() -> void:
	var result := await _ledge_jump(0.5)
	_check(result > 2.0, "jump pressed shortly after leaving a ledge still fires (vy=%.2f)" % result)


func _test_jump_after_coyote_time_is_ignored() -> void:
	var result := await _ledge_jump(2.5)
	_check(result < 0.0, "jump pressed well after leaving a ledge is ignored (vy=%.2f)" % result)


func _test_no_second_jump_in_the_air() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(30)
	var jumps := [0]
	ball.jumped.connect(func() -> void: jumps[0] += 1)
	ball.drive(Vector3.ZERO, true, true)
	await _ticks(30)
	ball.drive(Vector3.ZERO, true, true)
	await _ticks(10)
	_check(jumps[0] == 1, "only one jump until landing (got %d)" % jumps[0])
	world.free()


func _test_landing_keeps_horizontal_speed() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world, Vector3(0, 4, 0))
	ball.linear_velocity = Vector3.FORWARD * 20.0
	await _ticks(2)
	var before := 0.0
	while not ball.is_grounded():
		before = Vector2(ball.linear_velocity.x, ball.linear_velocity.z).length()
		await physics_frame
	await _ticks(30)
	var after := Vector2(ball.linear_velocity.x, ball.linear_velocity.z).length()
	_info("landing: horizontal %.2f -> %.2f m/s" % [before, after])
	_check(after > before * 0.95, "touchdown keeps >95%% of horizontal speed (%.1f%%)" % (100.0 * after / before))
	world.free()


func _test_coasting_through_a_loop_keeps_its_momentum() -> void:
	var loop := LoopSegment.new()
	var track := _test_track([_section(40.0), loop, _section(80.0)])
	var ball := _spawn_ball(track, _on_track(track, 30.0))
	await _ticks(1)
	_launch(ball, track, 30.0, 30.0)
	var exit_distance := 40.0 + TAU * loop.radius + 20.0
	var exit_speed := -1.0
	for i in 480:
		ball.drive(Vector3.ZERO, false, false)
		await physics_frame
		if exit_speed < 0.0 and track.path.distances[track.path.nearest_index(ball.global_position)] > exit_distance:
			exit_speed = ball.linear_velocity.length()
	var damping_only := 30.0 * exp(-ball.ground_linear_damp * 2.2)
	_info("coasting loop: in at 30.0 m/s, out at %.1f m/s (rolling resistance alone would leave %.1f)" % [exit_speed, damping_only])
	_check(exit_speed > damping_only * 0.95, "a ball coasting through the loop loses little beyond rolling resistance")
	track.get_parent().free()


func _test_rolling_never_climbs_higher_than_its_energy_allows() -> void:
	var climb := _section(30.0)
	climb.end_pitch = 25.0
	var ramp := _section(120.0)
	ramp.end_pitch = 25.0
	var track := _test_track([_section(40.0), climb, ramp])
	var ball := _spawn_ball(track, _on_track(track, 20.0))
	ball.ground_linear_damp = 0.0 # isolate the solver: no intentional rolling resistance
	await _ticks(1)
	_launch(ball, track, 20.0, 25.0)
	var start_height := ball.global_position.y
	var peak := start_height
	for i in 900: # a rolling ball needs about 4.2 s to stop on this ramp
		ball.drive(Vector3.ZERO, false, false)
		await physics_frame
		peak = maxf(peak, ball.global_position.y)
	var lossless := ROLLING_ENERGY * 25.0 * 25.0 / (9.8 * ball.gravity_scale)
	_info("coasting climb: rose %.2f m (lossless rolling %.2f m)" % [peak - start_height, lossless])
	_check(peak - start_height <= lossless + 0.05, "momentum refund never lifts the ball above its energy")
	_check(peak - start_height > lossless * 0.9, "almost all the energy turns into height on a climb")
	track.get_parent().free()


func _test_swinging_in_a_valley_never_gains_height() -> void:
	var down := _section(25.0)
	down.end_pitch = -30.0
	var bottom := _section(30.0)
	bottom.end_pitch = 30.0
	var up := _section(40.0)
	up.end_pitch = 30.0
	var track := _test_track([_section(5.0), down, _section(20.0, -30.0), bottom, up])
	var ball := _spawn_ball(track, _on_track(track, 12.0))
	var release_height := ball.global_position.y
	var highest_after_first_swing := -INF
	var crossed_bottom := false
	for i in 1200:
		ball.drive(Vector3.ZERO, false, false)
		await physics_frame
		if ball.global_position.y < release_height - 5.0:
			crossed_bottom = true
		if crossed_bottom:
			highest_after_first_swing = maxf(highest_after_first_swing, ball.global_position.y)
	_info("valley: released at %.2f m, highest later swing %.2f m" % [release_height, highest_after_first_swing])
	_check(crossed_bottom and highest_after_first_swing <= release_height + 0.05, "swinging back and forth never gains height")
	track.get_parent().free()


# --- Camera ------------------------------------------------------------------

func _test_camera_starts_behind_the_ball_on_restart() -> void:
	var main := _start_main()
	var camera: FollowCamera = main.get_node("FollowCamera")
	var ball: RollingBall = main.get_node("Ball")
	var spawn: Node3D = (main.get_node("RaceManager") as RaceManager).track.spawn_marker
	await _ticks(10)
	var to_ball := ball.global_position - camera.global_position
	var spawn_forward := -spawn.global_transform.basis.z
	_check(to_ball.dot(spawn_forward) > 0.0, "camera starts behind the ball")
	_check((-camera.global_transform.basis.z).dot(to_ball.normalized()) > 0.95, "camera looks at the ball")
	main.free()


func _test_camera_swings_behind_the_direction_of_travel() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	var camera := _follow_camera(world, ball)
	await _ticks(5)
	var turn_toward := Vector3.RIGHT
	await _drive_for(ball, turn_toward, 3.0)
	var forward := -camera.global_transform.basis.z
	forward.y = 0.0
	_info("camera forward after rolling right for 3 s: %s" % forward.normalized())
	_check(forward.normalized().dot(turn_toward) > 0.9, "camera swings behind the direction of travel")
	world.free()


func _test_camera_pulls_in_when_a_wall_blocks_the_view() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	var camera := _follow_camera(world, ball)
	var wall := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(20.0, 20.0, 0.5)
	shape.shape = box
	wall.add_child(shape)
	wall.position = Vector3(0.0, 5.0, 3.0) # between the ball and where the camera wants to be
	world.add_child(wall)
	await _ticks(30)
	var camera_z := camera.global_position.z
	_info("wall face at z=2.75, camera at z=%.2f, %.2f m from the ball" % [camera_z, camera.global_position.distance_to(ball.global_position)])
	_check(camera_z < 2.75, "camera stays on the ball's side of a wall behind it")
	world.free()


# --- Race flow ---------------------------------------------------------------

func _test_timer_waits_for_first_input() -> void:
	var main := _start_main()
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	await _ticks(90)
	_check(race.state == RaceManager.State.READY and race.race_time == 0.0, "clock waits on the start line without input")
	await _drive_for(ball, Vector3.FORWARD, 1.0)
	_check(race.state == RaceManager.State.RUNNING, "first input starts the run")
	_check(absf(race.race_time - 1.0) < 0.05, "clock counts from the first input (%.3f s)" % race.race_time)
	main.free()


func _test_the_ball_waits_still_on_every_start_line() -> void:
	var main := _start_main()
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	for entry: Dictionary in LevelCatalog.LEVELS:
		var id := str(entry["id"])
		if id != LevelCatalog.DEFAULT_ID:
			await _load_level(main, id)
		race.restart()
		await _ticks(roundi(0.5 / TICK))
		var settled := ball.global_position
		await _ticks(roundi(3.0 / TICK))
		var crept := ball.global_position.distance_to(settled)
		_check(crept < 0.01 and race.state == RaceManager.State.READY,
			"the ball waits on %s's start line without rolling (moved %.3f m)" % [id, crept])
		await _drive_for(ball, -race.track.spawn_marker.global_basis.z, 0.5)
		_check(ball.global_position.distance_to(settled) > 0.5, "the first input sets it rolling on %s" % id)
	main.free()


## Dropping off a loop part-way leaves the tracker's last frame up in the
## loop: it still has to find the road the ball carries on along, or the run
## reads as off the track and the finish never counts.
func _test_tracking_finds_the_road_after_leaving_a_loop_early() -> void:
	var main := _start_main()
	var track: TrackBuilder = (main.get_node("RaceManager") as RaceManager).track
	var path := track.path
	var top := -1
	for i in path.frames.size():
		if path.frames[i].basis.y.normalized().y < -0.95:
			top = i
			break
	_check(top >= 0, "the test track has a loop")
	if top < 0:
		main.free()
		return
	var exit := path.distances[top]
	while path.frames[path.distances.bsearch(exit)].basis.y.normalized().y < 0.999:
		exit += 1.0
	# The ball lands at the foot of the loop and rolls on down the road; the
	# tracker follows it tick by tick, starting from the loop's top.
	var hint := top
	for past in range(1, 61):
		var point := path.frame_at_distance(exit + past).origin + Vector3.UP * 0.5
		hint = track.locate(point, hint, 40.0)
	var found := track.network.distances[hint]
	_check(absf(found - (exit + 60.0)) < 3.0,
		"after dropping off the top of the loop, tracking follows the road on (found %.1f m, wanted %.1f m)" % [found, exit + 60.0])
	main.free()


func _test_restart_returns_ball_to_spawn_and_clears_timer() -> void:
	var main := _start_main()
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var track: TrackBuilder = (main.get_node("RaceManager") as RaceManager).track
	await _drive_for(ball, Vector3.FORWARD, 2.0)
	race.restart()
	await _ticks(2)
	var spawn := track.spawn_marker.global_position
	_check(race.state == RaceManager.State.READY and race.race_time == 0.0, "restart clears the clock")
	_check(ball.global_position.distance_to(spawn) < 0.1, "restart puts the ball back on the spawn point")
	_check(ball.linear_velocity.length() < 0.5, "restart stops the ball")
	main.free()


## Off the track, the HUD counts down 3, 2, 1 and then puts the ball back on
## the start line; getting back on the track first stops the countdown.
func _test_leaving_the_track_counts_down_then_resets() -> void:
	var main := _start_main()
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var track: TrackBuilder = race.track
	var hud: RaceHud = main.get_node("HUD")
	await _drive_for(ball, Vector3.FORWARD, 0.5)
	# Drop the ball well beside the track, over the test level's floor.
	var frame := track.world_frame_at(200.0)
	var beside := Transform3D(Basis.IDENTITY, frame.origin + frame.basis.x * 60.0 + Vector3.UP * 3.0)
	ball.respawn(beside)
	await _ticks(roundi((race.off_track_grace + 0.2) / TICK))
	await process_frame
	_check(race.off_track and race.reset_in > 0.0 and hud._countdown.visible and hud._countdown.text == "3", "off the track, the HUD counts down from 3")
	_check(hud._status.visible and hud._status.text.contains("Off the track"), "and says why")
	_check(ball.global_position.y > -71.0, "the floor catches a ball that falls off (no void)")
	await _ticks(roundi(race.off_track_countdown / TICK))
	await process_frame
	_check(race.state == RaceManager.State.READY and ball.global_position.distance_to(track.spawn_marker.global_position) < 0.5, "at zero the ball goes back to the start line")
	_check(not hud._countdown.visible and hud._status.visible and hud._status.text == "Move to start", "the countdown goes, and the start line's prompt shows")
	# Back on the track before zero: the countdown stops and the run goes on.
	await _drive_for(ball, Vector3.FORWARD, 0.5)
	ball.respawn(beside)
	await _ticks(roundi((race.off_track_grace + 1.0) / TICK))
	_check(race.reset_in > 0.0, "off again, it counts down again")
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
	await _ticks(roundi(0.5 / TICK))
	await process_frame
	_check(race.state == RaceManager.State.RUNNING and not race.off_track and race.reset_in < 0.0 and not hud._countdown.visible, "getting back on the track stops the countdown")
	# Fired at the edge of the world, the ball stays inside the border.
	var bounds: LevelBounds = race.track.get_parent().get_node("Bounds")
	var area := bounds._area()
	ball.respawn(Transform3D(Basis.IDENTITY, Vector3(area.end.x - 20.0, -69.0, area.get_center().z)))
	ball.linear_velocity = Vector3(60.0, 0.0, 0.0)
	await _ticks(roundi(2.0 / TICK))
	_check(ball.global_position.x < area.end.x + 1.0 and ball.global_position.y > -71.0, "a hard border keeps the ball on the map")
	Input.action_press("restart")
	await _ticks(2)
	Input.action_release("restart")
	_check(race.state == RaceManager.State.READY and ball.global_position.distance_to(track.spawn_marker.global_position) < 0.5, "R puts the ball back on the start line at once")
	main.free()


func _test_autopilot_finishes_test_track_through_the_loop() -> void:
	var main := _start_main()
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var track: TrackBuilder = (main.get_node("RaceManager") as RaceManager).track
	var pilot := Autopilot.new()
	pilot.ball = ball
	pilot.track = track
	main.add_child(pilot)

	var camera: FollowCamera = main.get_node("FollowCamera")
	var loop_range := _segment_range(track, LoopSegment)
	var loop_top_reached := false
	var camera_rolled_in_loop := false
	var loop_min_speed := INF
	var max_speed := 0.0
	var resets := [0]
	race.state_changed.connect(func(state: RaceManager.State) -> void:
		if state == RaceManager.State.READY:
			resets[0] += 1)
	var table := {}
	var ticks := 0
	while race.state != RaceManager.State.FINISHED and ticks < 120 * 120 and resets[0] == 0:
		await physics_frame
		ticks += 1
		var d := pilot.current_distance()
		var speed := ball.linear_velocity.length()
		max_speed = maxf(max_speed, speed)
		if d >= loop_range.x and d <= loop_range.y:
			loop_min_speed = minf(loop_min_speed, speed)
			var frame := track.world_frame_at(d)
			if frame.basis.y.dot(Vector3.UP) < -0.9:
				loop_top_reached = true
				camera_rolled_in_loop = camera_rolled_in_loop or camera.global_transform.basis.y.dot(Vector3.UP) < 0.0
		_record_segment_speed(table, track, d, speed)

	if _verbose or race.state != RaceManager.State.FINISHED:
		_print_segment_table(track, table)
	_info("autopilot: %s in %.3f s, progress %.0f/%.0f m, top speed %.1f m/s, slowest in loop %.1f m/s"
			% [RaceManager.State.keys()[race.state], race.race_time, pilot.progress, track.path.total_length(), max_speed, loop_min_speed])
	_check(resets[0] == 0, "autopilot never fell off")
	_check(loop_top_reached, "autopilot went over the top of the loop")
	_check(camera_rolled_in_loop, "camera rolls with the track over the top of the loop")
	_check(race.state == RaceManager.State.FINISHED, "autopilot crossed the finish line")
	_check(race.race_time > 5.0 and race.race_time < 120.0, "finish time is plausible (%.3f s)" % race.race_time)

	# The lap became the best run, with a ghost. The autopilot is deterministic, so a
	# second lap races its own ghost and the live split should stay near zero.
	var ghost := race.records.best_ghost
	_check(ghost != null and absf(ghost.duration - race.race_time) < 0.001, "the best lap is kept as a ghost")
	_check(ghost != null and ghost.pose_at(ghost.duration).origin.distance_to(ball.global_position) < 40.0, "the ghost ends at the finish")
	var dump := OS.get_environment("BALL_GAME_DUMP_GHOST") # the leaderboard service's tests replay it
	if ghost and not dump.is_empty():
		FileAccess.open(dump, FileAccess.WRITE).store_string(JSON.stringify(ghost.to_dict()))
	var first_lap := race.race_time
	race.restart()
	pilot.reset()
	var worst_split := 0.0
	var split_seen := false
	ticks = 0
	while race.state != RaceManager.State.FINISHED and ticks < 120 * 120:
		await physics_frame
		ticks += 1
		if not is_nan(race.split_delta):
			split_seen = true
			worst_split = maxf(worst_split, absf(race.split_delta))
	_info("second lap %.3f s against ghost %.3f s, largest live split %.3f s" % [race.race_time, first_lap, worst_split])
	_check(split_seen and worst_split < 0.25, "a repeat of the best lap stays level with its ghost")
	_check(race.records.runs.size() == 2 and race.last_finish.get("total") == 2, "every finished run is recorded")
	main.free()


func _test_game_store_round_trips_documents() -> void:
	var key := "test_store_document.json"
	GameStore.write(key, {"a": 1.5, "list": [1, 2, 3]})
	var back: Variant = GameStore.read(key)
	_check(back is Dictionary and back["a"] == 1.5 and back["list"].size() == 3, "stored documents read back intact")
	GameStore.remove(key)
	_check(GameStore.read(key) == null, "removed documents are gone")


func _test_run_records_rank_every_run_and_keep_the_best_ghost() -> void:
	var records := RunRecords.new("unit_test", false)
	var slow := GhostRun.new()
	var fast := GhostRun.new()
	for ghost in [slow, fast]:
		ghost.add_sample(Vector3.ZERO, Quaternion.IDENTITY, 0.0)
		ghost.add_sample(Vector3.ONE, Quaternion.IDENTITY, 1.0)
	slow.duration = 20.0
	fast.duration = 18.5
	var first := records.add_run(20.0, slow)
	var second := records.add_run(18.5, fast)
	var third := records.add_run(25.0, GhostRun.new())
	_check(first["is_best"] and second["is_best"] and not third["is_best"], "only faster runs become the best")
	_check(third["rank"] == 3 and third["total"] == 3 and records.best_time == 18.5, "runs are ranked among all runs")
	_check(records.best_ghost == fast, "the ghost of the best run is kept")
	_check(records.top(2).map(func(run: Dictionary) -> float: return run["t"]) == [18.5, 20.0], "leaderboard lists fastest first")
	var older := RunRecords.new("unit_test_legacy", false)
	older.best_time = 15.0 # a best from before ghosts were recorded
	older.add_run(19.0, slow)
	_check(older.best_ghost == slow and older.best_time == 15.0, "a slower run still becomes the ghost when the best has no recording")


func _test_ghost_round_trips_through_its_saved_form() -> void:
	var ghost := GhostRun.new()
	for i in 10:
		ghost.add_sample(Vector3(i, 0.5, -2.0 * i), Quaternion(Vector3.RIGHT, i * 0.3), i * 2.0)
	ghost.duration = 9.0 / GhostRun.SAMPLE_HZ
	var copy := GhostRun.from_dict(JSON.parse_string(JSON.stringify(ghost.to_dict())))
	var mid := ghost.duration * 0.5
	_check(copy != null and copy.pose_at(mid).origin.distance_to(ghost.pose_at(mid).origin) < 0.01, "a saved ghost replays the same path")
	_check(copy != null and absf(copy.time_at_progress(7.0) - ghost.time_at_progress(7.0)) < 0.01, "a saved ghost keeps its split points")


func _test_settings_apply_to_camera_and_ghost() -> void:
	var main := _start_main()
	var settings: GameSettings = main.get_node("Settings")
	var camera: FollowCamera = main.get_node("FollowCamera")
	var ghost: GhostBall = main.get_node("GhostBall")
	await _ticks(2)
	settings.set_value("camera_distance", 10.0)
	settings.set_value("fov", 80.0)
	settings.set_value("speed_fov", 5.0)
	settings.set_value("ghost", false)
	_check(camera.distance == 10.0 and camera.base_fov == 80.0 and camera.max_fov == 85.0, "camera settings take effect")
	_check(not ghost.enabled, "the ghost can be switched off")
	settings.reset_to_defaults()
	_check(camera.distance == 6.5 and ghost.enabled, "settings reset to defaults")
	main.free()


func _test_pause_menu_pauses_the_game_and_resumes_it() -> void:
	var main := _start_main()
	var menu: PauseMenu = main.get_node("PauseMenu")
	await _ticks(2)
	menu.open()
	_check(paused and menu.is_open(), "the menu pauses the game")
	var tabs: Array = menu._tabs.get_children().map(func(page: Node) -> String: return page.name)
	_check(tabs == ["Levels", "Settings"], "the menu holds the general things: levels and settings (%s)" % ", ".join(tabs))
	menu.close()
	_check(not paused and not menu.is_open(), "closing the menu resumes the game")
	main.free()


## Holding Tab shows the level being played's leaderboard over the running
## game, like a scoreboard; letting go hides it. Over the menu, Tab is left to
## move between the menu's controls.
func _test_tab_shows_this_levels_leaderboard() -> void:
	var main := _start_main()
	await _ticks(2)
	var board: LeaderboardOverlay = main.get_node("Leaderboard")
	var menu: PauseMenu = main.get_node("PauseMenu")
	_check(not board.is_shown(), "the leaderboard starts hidden")
	Input.action_press("leaderboard")
	await _frames(2)
	_check(board.is_shown() and not paused, "holding Tab shows the leaderboard and the game carries on")
	_check(board._title.text == "Tutorial Level", "it is the leaderboard of the level being played (%s)" % board._title.text)
	Input.action_release("leaderboard")
	await _frames(2)
	_check(not board.is_shown(), "letting go of Tab hides it")
	menu.open()
	Input.action_press("leaderboard")
	await _frames(2)
	_check(not board.is_shown() and menu.is_open(), "Tab doesn't bring it up over the menu")
	Input.action_release("leaderboard")
	menu.close()
	main.free()


func _test_community_board_is_unavailable_outside_mobius() -> void:
	var main := _start_main()
	await _ticks(2)
	var community: CommunityBoard = main.get_node("Community")
	var board: LeaderboardOverlay = main.get_node("Leaderboard")
	board.show_board()
	_check(not community.is_available() and community.status == "unavailable", "outside Möbius the community board is off")
	_check(board._community_footer.text.contains("Möbius"), "the leaderboard says where the community board works")
	board.hide_board()
	main.free()


func _test_community_board_sends_runs_and_shows_the_ranking() -> void:
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	var fake := FakeCommunityHost.new()
	main.get_node("Community").host = fake
	root.add_child(main)
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var hud: RaceHud = main.get_node("HUD")
	var board: LeaderboardOverlay = main.get_node("Leaderboard")
	# Records were already opened without saving; this only lets the run be sent (to the fake).
	race.save_records = true
	var ghost := GhostRun.new()
	ghost.add_sample(Vector3.ZERO, Quaternion.IDENTITY, 0.0)
	ghost.add_sample(Vector3.ONE, Quaternion.IDENTITY, 1.0)
	ghost.duration = 19.5
	race.last_recording = ghost
	race.state = RaceManager.State.FINISHED
	race.finished.emit(19.5, true)
	var sent: Dictionary = fake.sent[0] if fake.sent.size() == 1 else {}
	var sent_ghost: Variant = JSON.parse_string(sent.get("ghost", "null"))
	_check(sent.get("track") == "test_track" and sent.get("time") == 19.5 and sent_ghost is Dictionary
		and sent_ghost.has("p") and str(sent.get("id", "")).length() == 32, "a finished run is sent with its recording")
	fake.answer({"status": "ready", "board": {"top": [
			{"rank": 1, "player": "ana", "time": 18.2, "runs": 7},
			{"rank": 2, "player": "me", "time": 19.5, "runs": 1}],
			"runs": 8, "players": 2, "player": "me", "you": {"rank": 2, "best": 19.5, "runs": 1}},
		"submission": {"id": sent.get("id"), "status": "done", "result": {"rank": 2, "players": 2}}})
	await _frames(40)
	_check(hud._status.text.contains("Community  #2 of 2 players"), "the finish banner shows the community ranking")
	board.show_board()
	await _frames(2)
	_check(board._community_rows.get_child_count() == 2 and board._community_footer.text.contains("#2"),
		"the leaderboard lists the community's fastest players")
	board.hide_board()
	main.free()


func _load_level(main: Node, id: String) -> LevelLoader:
	var loader: LevelLoader = main.get_node("LevelLoader")
	loader.load_level(id)
	while loader.level_id != id:
		await process_frame
	await _ticks(2)
	return loader


func _test_levels_switch_with_their_own_records_and_ball() -> void:
	var main := _start_main()
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var loader: LevelLoader = main.get_node("LevelLoader")
	_check(loader.level_id == "test_track" and race.track_id == "test_track", "the game starts on the test track")
	var ids := LevelCatalog.available().map(func(entry: Dictionary) -> String: return entry["id"])
	_check(ids == ["test_track", "original", "beach", "jungle", "winter"],
		"the menu lists the tutorial, The Original Track, then the three themed levels (%s)" % ", ".join(ids))
	race.records.add_run(30.0, null)
	await _load_level(main, "winter")
	_check(race.track_id == LevelCatalog.records_id("winter") and race.records.runs.is_empty() and not is_finite(race.best_time), "a level has its own records")
	_check(race.state == RaceManager.State.READY and race.ball.global_position.distance_to(race.track.spawn_marker.global_position) < 0.5, "switching level puts the ball on its start line")
	var ball_mesh: MeshInstance3D = race.ball.find_children("*", "MeshInstance3D", true, false)[0]
	_check(ball_mesh.material_override == loader.level.ball_material, "the level dresses the ball")
	await _load_level(main, "test_track")
	# Tests never save, so records can't survive a switch here; the game reloads them from storage.
	_check(race.records.track_id == "test_track" and race.track_id == "test_track", "switching back uses the test track's records")
	main.free()


func _test_props_are_solid_and_the_ball_bounces_off_them() -> void:
	var main := _start_main()
	await _load_level(main, "jungle")
	var race: RaceManager = main.get_node("RaceManager")
	var ball := race.ball
	# A tree stands 6 m right of the fern run at 1087 m (jungle_level.gd: FERNS_FROM + 42).
	var frame := race.track.world_frame_at(1087.0)
	var right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
	ball.respawn(Transform3D(Basis.IDENTITY, frame.origin + right * 2.0 + Vector3.UP * 0.6))
	ball.start_control() # mid-run: not waiting on the start line
	await _ticks(10)
	ball.linear_velocity = right * 12.0
	var bounced := false
	for i in 90:
		await physics_frame
		if ball.linear_velocity.dot(right) < -1.0:
			bounced = true
			break
	_check(bounced, "the ball bounces off a tree trunk")
	main.free()


func _test_the_beach_wave_carries_the_ball() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "beach")
	var race: RaceManager = main.get_node("RaceManager")
	var wave: RideableWave = loader.level.get_node("Wave")
	var ball := race.ball
	var start := race.track.world_frame_at((wave.from_distance + wave.to_distance) * 0.5)
	ball.respawn(Transform3D(Basis.IDENTITY, start.origin + Vector3.UP * 0.6))
	ball.control_started.emit() # the race clock (and so the waves) start now
	var highest := 0.0
	var inland := 0.0
	for i in roundi(wave.period / TICK):
		await physics_frame
		highest = maxf(highest, ball.global_position.y - start.origin.y)
		inland = maxf(inland, (ball.global_position - start.origin).dot(wave._inland))
	_info("a wave lifted a resting ball %.1f m and carried it %.1f m inland" % [highest, inland])
	_check(highest > 1.5 and inland > 3.0, "a wave rolls in across the beach and scoops the ball up its face")
	main.free()


func _test_black_ice_is_slippery() -> void:
	var main := _start_main()
	await _load_level(main, "winter")
	var race: RaceManager = main.get_node("RaceManager")
	var ball := race.ball
	var grips := []
	for d in [120.0, 290.0]: # ordinary ice run, then the black ice bend
		var frame := race.track.world_frame_at(d)
		ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
		await _ticks(10)
		var forward := -frame.basis.z
		var start_speed := ball.linear_velocity.dot(forward)
		for i in roundi(1.0 / TICK):
			ball.drive(forward, false, false)
			await physics_frame
		grips.append([ball.surface_grip, ball.linear_velocity.dot(forward) - start_speed])
	_info("grip %.2f gains %.1f m/s in 1 s; black ice grip %.2f gains %.1f m/s" % [grips[0][0], grips[0][1], grips[1][0], grips[1][1]])
	_check(grips[0][0] == 1.0 and grips[1][0] < 0.5, "the black ice bend is slippery underfoot")
	_check(grips[1][1] < grips[0][1] * 0.6, "on black ice the ball can't push off as hard")
	main.free()


func _test_autopilot_finishes_level(level_id: String, take_routes := false) -> void:
	Swinger.hold_still = true
	RollingBarrels.hold_still = true
	var main := _start_main()
	await _load_level(main, level_id)
	var race: RaceManager = main.get_node("RaceManager")
	var pilot := Autopilot.new()
	pilot.ball = race.ball
	pilot.track = race.track
	pilot.take_routes = take_routes
	main.add_child(pilot)
	var restarts := [0]
	race.state_changed.connect(func(state: RaceManager.State) -> void:
		if state == RaceManager.State.READY:
			restarts[0] += 1)
	var ticks := 0
	var left_track := -1.0
	while race.state != RaceManager.State.FINISHED and ticks < 120 * 120 and restarts[0] == 0:
		await physics_frame
		ticks += 1
		if race.off_track and left_track < 0.0:
			left_track = race.progress
	var line := "its alternative routes" if take_routes else "the main road"
	_info("%s autopilot on %s: %s in %.3f s" % [level_id, line, RaceManager.State.keys()[race.state], race.race_time])
	_check(race.state == RaceManager.State.FINISHED and restarts[0] == 0 and left_track < 0.0,
		"the autopilot finishes %s on %s without leaving the track%s" % [level_id, line, "" if left_track < 0.0 else " (left it at %.0f m)" % left_track])
	if take_routes:
		var routes := race.track.routes()
		_check(not routes.is_empty(), "%s has an alternative route" % level_id)
		for route in routes:
			var rode: float = pilot.ridden.get(route.name, 0.0)
			_check(rode >= route.length() * 0.4,
				"the autopilot rides %s's %s rather than the road beside it (%.0f of %.0f m)" % [level_id, route.name, rode, route.length()])
	main.free()
	Swinger.hold_still = false
	RollingBarrels.hold_still = false


## The beach corkscrew carries a ball through at racing speed but drops one
## that comes in too slow (there's nothing to hold it on at the top).
func _test_a_corkscrew_needs_speed() -> void:
	for speed in [16.0, 30.0]:
		Swinger.hold_still = true
		RollingBarrels.hold_still = true
		var main := _start_main()
		await _load_level(main, "beach")
		var race: RaceManager = main.get_node("RaceManager")
		var track := race.track
		var path := track.path
		var channel := -1
		for i in path.frames.size():
			if path.lips[i].x > 5.0:
				channel = i
				break
		var start := path.distances[channel] - 8.0
		var end := start
		for i in range(channel, path.frames.size()):
			if path.lips[i].x < 1.2:
				end = path.distances[i]
				break
		var frame := track.world_frame_at(start)
		var ball := race.ball
		ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.55))
		ball.control_started.emit()
		await physics_frame
		ball.linear_velocity = -frame.basis.z.normalized() * speed
		ball.angular_velocity = frame.basis.x.normalized() * (-speed / ball.radius)
		var hint := -1
		var through := false
		for i in roundi(4.0 / TICK):
			await physics_frame
			hint = path.nearest_index(track.to_local(ball.global_position), hint, 60)
			var at := track.global_transform * path.frames[hint]
			if (ball.global_position - at.origin).length() > 8.0:
				break
			if path.distances[hint] >= end:
				through = true
				break
		if speed < 20.0:
			_check(not through, "a ball entering the corkscrew at %.0f m/s falls off it" % speed)
		else:
			_check(through, "a ball entering the corkscrew at %.0f m/s rides through it" % speed)
		main.free()
		Swinger.hold_still = false
		RollingBarrels.hold_still = false


## Rolling onto the beach's steam vent throws the ball high into the air.
func _test_a_vent_blasts_the_ball_skyward() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "beach")
	var race: RaceManager = main.get_node("RaceManager")
	var vent: Vent = loader.level.get_node("Vent")
	var frame := race.track.world_frame_at(vent.at_distance - 8.0)
	var ball := race.ball
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
	ball.control_started.emit()
	await physics_frame
	ball.linear_velocity = -frame.basis.z.normalized() * 12.0
	var highest := 0.0
	for i in roundi(2.5 / TICK):
		await physics_frame
		highest = maxf(highest, ball.global_position.y - vent.global_position.y)
	_info("the vent threw a ball %.1f m up" % highest)
	_check(highest > 15.0, "the steam vent blasts the ball into the sky")
	main.free()


## In the forest's lily pond a ball wading through the water is dragged to a
## crawl, and a ball dropped onto a lily pad bounces back up.
func _test_the_pond_slows_waders_and_the_pads_bounce() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "jungle")
	var race: RaceManager = main.get_node("RaceManager")
	var pond: LilyPond = loader.level.get_node("LilyPond")
	var ball := race.ball
	# Wading: off to the side of the pads, at speed.
	var frame := race.track.world_frame_at((pond.from_distance + pond.to_distance) * 0.5 - 8.0)
	var aside := frame.basis.x.normalized() * 6.5
	ball.respawn(Transform3D(frame.basis, frame.origin + aside + Vector3.UP * 0.6))
	ball.control_started.emit()
	await physics_frame
	ball.linear_velocity = -frame.basis.z.normalized() * 25.0
	for i in roundi(1.0 / TICK):
		ball.drive(-frame.basis.z.normalized(), false, false)
		await physics_frame
	var wading := Vector2(ball.linear_velocity.x, ball.linear_velocity.z).length()
	_info("after a second in the pond a ball at 25 m/s (still driving) is down to %.1f m/s" % wading)
	_check(wading < 4.5, "the pond's water drags a wading ball to a crawl, even while it drives")
	_check(pond.has_node("Pad_2") and not pond.has_node("Pad_3"), "there are three lily pads")
	# Landing: drop it onto the first pad; it settles rather than springing off.
	var pad: Node3D = pond.get_node("Pad_0")
	ball.respawn(Transform3D(Basis.IDENTITY, pad.global_position + Vector3.UP * 4.0))
	var landed := false
	var rebound := 0.0
	for i in roundi(2.0 / TICK):
		await physics_frame
		var height := ball.global_position.y - pad.global_position.y
		if not landed and ball.linear_velocity.y > 0.5 and height < 1.5:
			landed = true
		if landed:
			rebound = maxf(rebound, height)
	_info("a ball dropped 4 m onto a lily pad bounced back %.1f m up" % rebound)
	_check(rebound < 1.5, "lily pads are not bouncy")
	_check(absf(ball.global_position.y - pad.global_position.y - 0.57) < 0.25, "a ball landing on a pad stays on it")
	main.free()


## A swinging weight across the track is solid and strong: a ball resting in
## its path is knocked well aside within one swing.
func _test_a_swinging_weight_knocks_the_ball_aside() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "winter")
	var race: RaceManager = main.get_node("RaceManager")
	var swingers := loader.level.find_children("Swinger_*", "Node3D", false, false)
	_check(swingers.size() >= 2, "winter has swinging weights across the track")
	if swingers.is_empty():
		main.free()
		return
	var swinger: Swinger = swingers[0]
	var frame := race.track.world_frame_at(swinger.at_distance)
	var ball := race.ball
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
	ball.control_started.emit() # the race (and the swinging) starts now
	var furthest := 0.0
	var lowest := INF
	for i in roundi(swinger.period * 1.2 / TICK):
		await physics_frame
		var aside := (ball.global_position - frame.origin).dot(frame.basis.x)
		furthest = maxf(furthest, absf(aside))
		lowest = minf(lowest, (ball.global_position - frame.origin).dot(frame.basis.y))
	_info("a swinging bauble pushed a resting ball %.1f m aside (its centre never lower than %.2f m above the road)" % [furthest, lowest])
	_check(furthest > 2.0, "a swinging weight knocks a resting ball aside")
	_check(lowest > ball.radius * 0.5, "a swinging weight never presses the ball into the road")
	main.free()


## Over its whole swing a weight never dips into the track (not even where the
## road climbs under it) or swings through the posts holding it up, on every
## level. At the bottom of the swing it still skims just over the road, low
## enough to sweep a ball away.
func _test_swinging_weights_clear_the_track_and_their_posts() -> void:
	var main := _start_main()
	var probe := SphereShape3D.new()
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = probe
	var checked := 0
	var skimming := 0
	var touching: Array[String] = []
	for id: String in ["beach", "jungle", "winter"]:
		var loader := await _load_level(main, id)
		var level := loader.level
		var space := level.get_world_3d().direct_space_state
		for swinger: Swinger in level.find_children("Swinger_*", "Node3D", false, false):
			checked += 1
			query.exclude = [(swinger.get_node("Weight") as CollisionObject3D).get_rid()]
			# A ball just inside the clearance meets nothing anywhere along the swing...
			probe.radius = swinger.weight_radius + swinger.clearance - 0.01
			for step in 111:
				var angle := deg_to_rad(lerpf(-swinger.amplitude, swinger.amplitude, step / 110.0))
				query.transform = swinger.weight_transform(angle)
				var hits := space.intersect_shape(query)
				if not hits.is_empty():
					touching.append("%s %s at %.0f° (%s)" % [id, swinger.name, rad_to_deg(angle), hits[0]["collider"].name])
					break
			# ...and one just past it reaches the road at the bottom of the swing.
			probe.radius = swinger.weight_radius + swinger.clearance + 0.03
			query.transform = swinger.weight_transform(0.0)
			for hit in space.intersect_shape(query):
				if level.track.is_ancestor_of(hit["collider"]):
					skimming += 1
					break
	_info("swinging weights checked: %d, skimming the road: %d %s" % [checked, skimming, ", ".join(touching)])
	_check(checked >= 5 and touching.is_empty(), "swinging weights never dip into the track or swing through their posts")
	_check(skimming == checked, "at the bottom of its swing each weight skims just over the road")
	main.free()


## A jump break is a real break: a ball that rolls at it without jumping drops
## in and can't carry on, and the same ball jumping gets across.
func _test_a_jump_break_needs_a_jump() -> void:
	for jumping in [false, true]:
		var main := _start_main()
		await _load_level(main, "beach")
		var race: RaceManager = main.get_node("RaceManager")
		var gap := race.track.path.jumps[0]
		var pilot := Autopilot.new()
		pilot.ball = race.ball
		pilot.track = race.track
		pilot.jumps = jumping
		main.add_child(pilot)
		var ticks := 0
		while race.progress < gap.y + 20.0 and not race.off_track and ticks < 120 * 30:
			await physics_frame
			ticks += 1
		if jumping:
			_check(race.progress >= gap.y + 20.0 and not race.off_track, "jumping carries the ball over the beach's first break (%.0f to %.0f m)" % [gap.x, gap.y])
		else:
			_check(race.off_track and race.progress < gap.y + 20.0, "without a jump the ball drops into the beach's first break (and can't carry on)")
		main.free()


## Where the road twists into a steep bank its surface still runs straight down
## the middle, so a fast ball rolls into a wall ride and out again without
## being thrown into the air. (Laid as one quad across, the road folded there
## into dips with sides as steep as 16°.)
func _test_a_ball_rolls_into_a_wall_ride_without_taking_off() -> void:
	var ride := SectionSegment.new()
	ride.length = 66.0
	ride.turn = -110.0
	ride.bank_into_turn = 70.0
	ride.wall_right = 1.4
	var track := _test_track([_section(40.0), ride, _section(40.0)])
	await _ticks(1)
	var space := track.get_world_3d().direct_space_state
	var worst := 0.0
	for k in 760:
		var frame := track.world_frame_at(35.0 + k * 0.1)
		var up := frame.basis.y.normalized()
		var hit := space.intersect_ray(PhysicsRayQueryParameters3D.create(frame.origin + up, frame.origin - up))
		worst = maxf(worst, absf(((hit.get("position", frame.origin + up) as Vector3) - frame.origin).dot(up)))
	_check(worst < 0.01, "a twisting road runs straight down its middle (off by %.3f m at most)" % worst)
	var ball := _spawn_ball(track, _on_track(track, 10.0))
	await _ticks(1)
	_launch(ball, track, 10.0, 32.0)
	var pilot := Autopilot.new()
	pilot.ball = ball
	pilot.track = track
	track.get_parent().add_child(pilot)
	var airborne := 0
	var fastest := 0.0
	while pilot.current_distance() < 140.0 and pilot.progress < 140.0:
		await physics_frame
		var here := pilot.current_distance()
		if here > 40.0 and here < 106.0:
			fastest = maxf(fastest, ball.linear_velocity.length())
			if not ball.is_grounded():
				airborne += 1
	_info("wall ride at up to %.1f m/s: %d ticks in the air" % [fastest, airborne])
	_check(airborne == 0, "a fast ball rides into a wall ride and out again without leaving the road (%d ticks in the air)" % airborne)
	track.get_parent().free()


## The Original Track's box hops and its giant sphere need a jump each: rolled
## at without one, the ball drops into the gap; with one, from the edge or a
## few metres before it, it lands on the next box or on the sphere and carries
## on. The boxes stand flush under the track's open stretches.
func _test_the_original_tracks_boxes_and_sphere_need_jumps() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "original")
	var race: RaceManager = main.get_node("RaceManager")
	var track := race.track
	var blocks: TrackBlocks = loader.level.get_node("Blocks")
	var sphere: TrackSphere = loader.level.get_node("Sphere")
	var tops := blocks.stretches()
	_check(tops.size() == 4 and blocks.get_child_count() == 4, "the Original Track hops across four boxes")
	var space := track.get_world_3d().direct_space_state
	var flush := 0
	for top in tops:
		var middle: Vector3 = ((top[0] as Transform3D).origin + (top[1] as Transform3D).origin) * 0.5
		var hit := space.intersect_ray(PhysicsRayQueryParameters3D.create(middle + Vector3.UP, middle + Vector3.DOWN))
		if not hit.is_empty() and (hit["collider"] as Node).get_parent() == blocks and absf((hit["position"] as Vector3).y - middle.y) < 0.01:
			flush += 1
	_check(flush == tops.size(), "every box stands solid and flush under its stretch of track (%d of %d)" % [flush, tops.size()])
	var gaps := track.path.jumps
	_check(gaps.size() == 5 and sphere.distance > gaps[4].x and sphere.distance < gaps[4].y, "the sphere stands in the last jump gap")
	# Box hops: the first from the run-up, the last from the third box.
	for k in [0, 3]:
		var back := 20.0 if k == 0 else 12.0
		var rolled: Dictionary = await _roll_at_gap(race, gaps[k], back, 30.0, NAN)
		_check(not rolled["across"], "without a jump the ball drops into box gap %d" % (k + 1))
		for trial in [[30.0, 3.0], [22.0, 0.5], [33.0, 9.0]]:
			var hopped: Dictionary = await _roll_at_gap(race, gaps[k], back, trial[0], trial[1])
			_check(hopped["across"], "jumping %.1f m before box gap %d at %.0f m/s lands on the next box" % [trial[1], k + 1, trial[0]])
	var dropped: Dictionary = await _roll_at_gap(race, gaps[4], 20.0, 30.0, NAN, sphere)
	_check(not dropped["across"], "without a jump the ball can't get past the sphere")
	for trial in [[30.0, 3.0], [22.0, 0.5], [33.0, 6.0]]:
		var bounced: Dictionary = await _roll_at_gap(race, gaps[4], 20.0, trial[0], trial[1], sphere)
		_check(bounced["across"] and bounced["touched"], "jumping %.1f m before the sphere gap at %.0f m/s lands on the sphere and carries the ball across" % [trial[1], trial[0]])
	main.free()


## Rolls the ball at [param gap] (a jump gap: takeoff and landing distances)
## from [param back] metres before it at [param speed], jumping [param lead]
## metres before its edge (NAN: no jump). Returns whether it got across, and
## whether it touched [param sphere] on the way.
func _roll_at_gap(race: RaceManager, gap: Vector2, back: float, speed: float, lead: float, sphere: TrackSphere = null) -> Dictionary:
	var track := race.track
	var ball := race.ball
	var frame := track.world_frame_at(gap.x - back)
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.55))
	ball.control_started.emit()
	await physics_frame
	ball.linear_velocity = -frame.basis.z.normalized() * speed
	ball.angular_velocity = frame.basis.y.cross(ball.linear_velocity) / ball.radius
	var jumped := is_nan(lead)
	var hold := 0.0
	var touched := false
	var hint := -1
	var lowest := minf(track.world_frame_at(gap.x).origin.y, track.world_frame_at(gap.y).origin.y) - 5.0
	for i in roundi(3.0 / TICK):
		hint = track.path.nearest_index(track.to_local(ball.global_position), hint, 60)
		var here := track.path.distances[hint]
		var press := false
		if not jumped and gap.x - here <= lead:
			jumped = true
			press = true
			hold = 0.5
		hold = maxf(hold - TICK, 0.0)
		var ahead := track.world_frame_at(here + 12.0).origin - ball.global_position
		ball.drive(Vector3(ahead.x, 0.0, ahead.z).normalized(), hold > 0.0, press)
		await physics_frame
		if sphere and ball.global_position.distance_to(sphere.centre()) < sphere.radius + ball.radius + 0.1:
			touched = true
		if ball.global_position.y < lowest:
			break
		if here > gap.y + 10.0:
			return {"across": true, "touched": touched}
	return {"across": false, "touched": touched}


## Stands in for the web page's window.ballGameCommunity.
class FakeCommunityHost:
	extends RefCounted
	var sent: Array[Dictionary] = []
	var _state := {"version": 0, "status": "idle"}

	func submit(track: String, time: float, ghost_json: String, request_id: String) -> void:
		sent.append({"track": track, "time": time, "ghost": ghost_json, "id": request_id})

	func refresh(_track: String) -> void:
		pass

	func state(_track: String) -> String:
		return JSON.stringify(_state)

	func answer(state: Dictionary) -> void:
		state["version"] = int(_state["version"]) + 1
		_state = state


# --- Helpers -----------------------------------------------------------------

func _frames(count: int) -> void:
	for i in count:
		await process_frame


## Kinetic energy of a rolling solid sphere is 0.7 m v², so a coasting climb can rise 0.7 v² / g.
const ROLLING_ENERGY := 0.7


func _section(length: float, pitch := 0.0) -> SectionSegment:
	var segment := SectionSegment.new()
	segment.length = length
	segment.end_pitch = pitch
	return segment


## A TrackBuilder with [param segments], inside a fresh world node.
func _test_track(segments: Array) -> TrackBuilder:
	var world := Node3D.new()
	root.add_child(world)
	var track := TrackBuilder.new()
	track.segments.assign(segments)
	world.add_child(track)
	return track


## Ball spawn point resting on the track centreline at [param distance].
func _on_track(track: TrackBuilder, distance: float) -> Vector3:
	var frame := track.world_frame_at(distance)
	return frame.origin + frame.basis.y * 0.5


## Sets the ball rolling along the track at [param speed] from [param distance].
func _launch(ball: RollingBall, track: TrackBuilder, distance: float, speed: float) -> void:
	var frame := track.world_frame_at(distance)
	ball.global_position = frame.origin + frame.basis.y * 0.5
	ball.linear_velocity = -frame.basis.z * speed
	ball.angular_velocity = frame.basis.y.cross(ball.linear_velocity) / ball.radius


func _flat_world(friction := 1.0) -> Node3D:
	var world := Node3D.new()
	root.add_child(world)
	var ground := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(600.0, 2.0, 600.0)
	shape.shape = box
	ground.add_child(shape)
	ground.position = Vector3(0.0, -1.0, 0.0)
	var material := PhysicsMaterial.new()
	material.friction = friction
	ground.physics_material_override = material
	world.add_child(ground)
	return world


func _spawn_ball(world: Node3D, at := Vector3(0.0, 0.5, 0.0)) -> RollingBall:
	var ball: RollingBall = BALL_SCENE.instantiate()
	world.add_child(ball)
	ball.respawn(Transform3D(Basis.IDENTITY, at))
	return ball


func _follow_camera(world: Node3D, ball: RollingBall) -> FollowCamera:
	var camera := FollowCamera.new()
	camera.ball = ball
	camera.capture_mouse_on_start = false
	world.add_child(camera)
	camera.snap_behind(ball.global_transform)
	return camera


func _start_main() -> Node:
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false # never touch the player's records
	main.get_node("Settings").persist = false
	root.add_child(main)
	return main


func _ticks(count: int) -> void:
	for i in count:
		await physics_frame


func _drive_for(ball: RollingBall, direction: Vector3, seconds: float) -> void:
	for i in roundi(seconds / TICK):
		ball.drive(direction, false, false)
		await physics_frame


## Jumps from rest, holding the button for [param hold] seconds; returns the apex height gain.
func _jump_apex(ball: RollingBall, hold: float) -> float:
	var start_y := ball.global_position.y
	var apex := start_y
	for i in 240:
		var held := i * TICK < hold
		ball.drive(Vector3.ZERO, held, i == 0)
		await physics_frame
		apex = maxf(apex, ball.global_position.y)
	return apex - start_y


## Rolls off a ledge and presses jump [param coyote_fraction] × coyote_time after
## losing contact. Returns the vertical speed shortly after (positive = jumped).
func _ledge_jump(coyote_fraction: float) -> float:
	var world := Node3D.new()
	root.add_child(world)
	var ledge := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(20.0, 2.0, 20.0)
	shape.shape = box
	ledge.add_child(shape)
	ledge.position = Vector3(0.0, -1.0, 0.0) # top at y=0, edge at z=-10
	world.add_child(ledge)
	var ball := _spawn_ball(world, Vector3(0.0, 0.5, 5.0))
	await _ticks(20)
	ball.linear_velocity = Vector3.FORWARD * 5.0
	ball.angular_velocity = Vector3.UP.cross(ball.linear_velocity) / ball.radius
	var left_ground_at := -1
	var tick := 0
	while tick < 600:
		var since := (tick - left_ground_at) * TICK if left_ground_at >= 0 else 0.0
		var press := left_ground_at >= 0 and since >= ball.coyote_time * coyote_fraction
		ball.drive(Vector3.ZERO, press, press)
		await physics_frame
		tick += 1
		if left_ground_at < 0 and ball.global_position.z < -10.0:
			# Contact is lost once the centre passes the edge; measure from there.
			left_ground_at = tick
		if press:
			break
	await _ticks(3)
	var vertical := ball.linear_velocity.y
	world.free()
	return vertical


func _segment_range(track: TrackBuilder, kind: Script) -> Vector2:
	var ends := _segment_end_distances(track)
	var start := 0.0
	for i in track.segments.size():
		if track.segments[i] and track.segments[i].get_script() == kind:
			return Vector2(start, ends[i])
		start = ends[i]
	return Vector2(-1.0, -1.0)


func _segment_end_distances(track: TrackBuilder) -> PackedFloat32Array:
	var cursor := TrackCursor.new()
	var scratch := TrackPath.new()
	var ends := PackedFloat32Array()
	for segment in track.segments:
		if segment:
			segment.lay(cursor, scratch, track.max_spacing, deg_to_rad(track.max_step_angle))
		ends.append(cursor.distance)
	return ends


func _record_segment_speed(table: Dictionary, track: TrackBuilder, distance: float, speed: float) -> void:
	if not table.has("_ends"):
		table["_ends"] = _segment_end_distances(track)
	var ends: PackedFloat32Array = table["_ends"]
	var index: int = ends.bsearch(distance)
	if not table.has(index):
		table[index] = Vector3(speed, speed, speed) # entry, min, max
	var row: Vector3 = table[index]
	table[index] = Vector3(row.x, minf(row.y, speed), maxf(row.z, speed))


func _print_segment_table(track: TrackBuilder, table: Dictionary) -> void:
	print("   segment               entry    min    max  (m/s)")
	for i in track.segments.size():
		var name: String = track.segments[i].resource_name if track.segments[i] else "?"
		if table.has(i):
			var row: Vector3 = table[i]
			print("   %-20s %6.1f %6.1f %6.1f" % [name, row.x, row.y, row.z])
		else:
			print("   %-20s   (not reached)" % name)


func _check(condition: bool, description: String) -> void:
	_check_count += 1
	if condition:
		print("  ok   ", description)
	else:
		print("  FAIL ", description)
		_failures.append(description)


func _info(message: String) -> void:
	print("       ", message)


# --- Party -------------------------------------------------------------------

func _test_a_party_starts_everyone_together_and_reports_the_finish() -> void:
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	var fake := FakePartyHost.new()
	main.get_node("Party").host = fake
	root.add_child(main)
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var party: PartyClient = main.get_node("Party")
	var hud: RaceHud = main.get_node("HUD")
	var loader: LevelLoader = main.get_node("LevelLoader")
	var spawn := race.track.spawn_marker.global_position

	# The lobby: another player's ball shows up, solid because bumping is on.
	fake.remote = {"pid": "maja", "name": "Maja", "color": "#2ec4b6", "p": [spawn.x + 3.0, spawn.y, spawn.z], "q": [0, 0, 0, 1], "v": [0, 0, 0], "age": 0.05}
	fake.current = {"active": true, "phase": "lobby", "round": -1, "level": "", "collisions": true, "entrant": false}
	await _frames(40) # outside a party the host is only asked four times a second
	var others := party.get_node("PartyBalls").get_children()
	_check(others.size() == 1 and (others[0] as RemoteBall).player_name == "Maja", "another player's ball is drawn")
	_check(ball.collision_mask & RemoteBall.LAYER != 0 and (others[0] as RemoteBall).collision_layer == RemoteBall.LAYER, "with bumping on, the balls collide")
	await _frames(10)
	_check(not fake.pose_calls.is_empty() and JSON.parse_string(fake.pose_calls[-1]).get("lv") == "test_track", "this ball's position is broadcast")

	# A level: back on the start line, locked, and reported as loaded.
	fake.current = {"active": true, "phase": "loading", "round": 0, "level": "test_track", "collisions": true, "entrant": true}
	await _frames(3)
	_check(fake.loaded_calls == [["test_track", 0]], "the level is reported as loaded once")
	_check(race.party_round and ball.locked and race.state == RaceManager.State.READY, "the ball waits on the start line")
	_check(hud._status.text == "Get ready…", "the HUD says to get ready")
	loader.load_level("beach")
	_check(loader.level_id == "test_track" and not loader.busy, "the menu can't switch away from the party's level")
	for i in 10:
		ball.drive(Vector3.FORWARD, false, true)
		await physics_frame
	_check(race.state == RaceManager.State.READY, "input can't jump the start")

	# The countdown, then the shared start; a late start counts the time already gone.
	fake.current = {"active": true, "phase": "racing", "round": 0, "level": "test_track", "collisions": true, "entrant": true, "go_in": 2.0}
	await _frames(3)
	_check(race.state == RaceManager.State.READY, "nothing moves during the countdown")
	fake.current["go_in"] = -0.5
	await _frames(1)
	_check(race.state == RaceManager.State.RUNNING and race.race_time >= 0.5 and not ball.locked, "the clock starts at the shared start, counting a late start")
	await _ticks(30)
	var before := race.race_time
	race.restart()
	_check(race.state == RaceManager.State.RUNNING and race.race_time >= before, "restarting mid-level keeps the clock running")
	_check(ball.global_position.distance_to(spawn) < 1.0, "restarting puts the ball back on the start line")

	# The finish is reported to the party, and no personal record comes of it.
	var runs_before := race.records.runs.size()
	race._finish(race.race_time)
	await _frames(2)
	_check(fake.finish_calls.size() == 1 and fake.finish_calls[0][1] == 0 and absf(fake.finish_calls[0][0] - race.race_time) < 0.01, "the finish time is reported once")
	_check(race.records.runs.size() == runs_before, "party runs don't become personal records")
	_check(hud._status.text.begins_with("FINISH"), "the HUD shows the finish")

	# Results: the party's rules are off again; leaving clears the other balls.
	fake.current = {"active": true, "phase": "results", "round": 0, "level": "test_track", "collisions": true, "entrant": true}
	await _frames(2)
	_check(not race.party_round and not ball.locked and loader.party_level == "", "between levels the ball is free")
	fake.current = {"active": false}
	await _frames(2)
	_check(not party.active and ball.collision_mask & RemoteBall.LAYER == 0, "leaving the party stops the bumping")
	await _frames(2)
	_check(party.get_node("PartyBalls").get_child_count() == 0, "leaving the party clears the other balls")
	main.queue_free()
	await _frames(2)


class FakePartyHost:
	extends RefCounted
	var current := {"active": false}
	var remote := {}
	var pose_calls: Array[String] = []
	var loaded_calls: Array = []
	var finish_calls: Array = []

	func state() -> String:
		return JSON.stringify(current)

	func remotes(level: String) -> String:
		return JSON.stringify([remote] if not remote.is_empty() and current.get("active", false) and level == "test_track" else [])

	func pose(text: String) -> void:
		pose_calls.append(text)

	func loaded(level: String, round_index: int) -> void:
		loaded_calls.append([level, round_index])

	func finish(time: float, round_index: int) -> void:
		finish_calls.append([time, round_index])


# --- Round 7 ------------------------------------------------------------------

## Crossing the finish ends the run: input stops counting and the ball brakes
## to a stop on the run-off, before the end of the track.
func _test_the_ball_brakes_to_a_stop_after_the_finish() -> void:
	var main := _start_main()
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var ball := race.ball
	var track := race.track
	var finish_at := track.path.total_length() - track.finish_distance_from_end
	var frame := track.world_frame_at(finish_at - 6.0)
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
	ball.control_started.emit()
	race._furthest = finish_at
	await physics_frame
	ball.linear_velocity = -frame.basis.z.normalized() * 46.0
	var stopped_at := INF
	for i in roundi(5.0 / TICK):
		ball.drive(-frame.basis.z.normalized(), false, false)
		await physics_frame
		if race.state == RaceManager.State.FINISHED and ball.linear_velocity.length() < 0.3:
			stopped_at = track.locate(track.to_local(ball.global_position), -1, 40)
			break
	_check(race.state == RaceManager.State.FINISHED, "the run finished")
	var stop_distance: float = track.path.distances[stopped_at] if stopped_at != INF else INF
	_info("a ball crossing the line at 46 m/s stopped %.1f m past it" % (stop_distance - finish_at))
	_check(stop_distance < track.path.total_length() - 1.0, "the ball brakes to a stop on the run-off, still driving")
	race.restart()
	_check(not ball.brake_to_stop, "restarting lets go of the brakes")
	main.free()


## A finish is a pass through the gate: between the posts, from the road up
## to the banner. Rolling past beside a post, flying over the banner, passing
## under the road or crossing backwards isn't.
func _test_the_finish_counts_only_through_the_gate() -> void:
	var main := _start_main()
	await _ticks(2)
	var line := (main.get_node("RaceManager") as RaceManager).track.finish_line
	var half := line.gate_width * 0.5
	var top := line.opening_height()
	var crosses := func(x: float, y: float) -> bool:
		return line.crossing_fraction(line.global_transform * Vector3(x, y, 0.5), line.global_transform * Vector3(x, y, -0.5)) >= 0.0
	_check(crosses.call(0.0, 0.5) and crosses.call(half - 0.5, 0.5), "rolling through the gate on the road counts, right up by a post")
	_check(crosses.call(0.0, top - 0.3), "jumping through just under the banner counts")
	_check(not crosses.call(half + 1.0, 0.5) and not crosses.call(-half - 1.0, 0.5), "rolling past beside a post doesn't")
	_check(not crosses.call(0.0, top + 0.6) and not crosses.call(0.0, line.gate_height + 3.0), "flying over the banner doesn't")
	_check(not crosses.call(0.0, -1.6), "passing under the road doesn't")
	var back := line.crossing_fraction(line.global_transform * Vector3(0.0, 0.5, -0.5), line.global_transform * Vector3(0.0, 0.5, 0.5))
	_check(back < 0.0, "crossing backwards doesn't")
	main.free()


## Stands in for the host page's frame-report interface (index.jsx).
class PerfPage extends RefCounted:
	var started := 0
	var reports: Array = []

	func run_started() -> void:
		started += 1

	func run_perf(json: String) -> void:
		reports.append(JSON.parse_string(json))


## How smoothly a run played is reported once, when the run ends, for the level
## it was played on, with where its long frames were (it used to go out again
## on every later restart, and named the level being switched to).
func _test_each_run_reports_how_smoothly_it_played_once() -> void:
	var main := _start_main()
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var perf: PerfReport = main.get_node("PerfReport")
	var page := PerfPage.new()
	perf.listen(page)
	race.ball.start_control()
	perf.set_process(false) # the frames below are made up
	for i in 300:
		perf._process(1.0 / 60.0)
	perf._process(0.05)
	race.restart()
	race.restart()
	_check(page.started == 1 and page.reports.size() == 1, "a run is reported once, when it ends (%d reports)" % page.reports.size())
	if page.reports.size() == 1:
		var report: Dictionary = page.reports[0]
		_check(report["level"] == "test_track" and not report["finished"], "for the level it was played on, unfinished")
		_check(report["long_frames"] == 1 and report["slow_frames"] == 1 and report["worst_ms"] == 50
			and report["long_frames_at"] == "0:1" and report["slowest"] == "0:50/0.0",
			"with its long frame and where it was")
		var flat := true
		for key in report:
			flat = flat and report[key] is not Dictionary and report[key] is not Array
		# The page adds three more (engine_ms, engine_long, browser); signals take at most 20.
		_check(flat and report.size() <= 17, "as flat values, few enough for a signal (%d)" % report.size())
		_check(absf(report["seconds"] - 5.0) < 0.11 and report["fps"] > 59.0, "and its frame rate")
		_check(String(report.get("camera", "")).begins_with("held 0% · off travel"),
			"and how the camera followed the ball (%s)" % report.get("camera", "none"))
	main.free()


## A run the player leaves by putting the game out of sight (on a phone:
## another app, the home screen, closing it) is reported then, as far as it
## went: on phones most runs end that way. Back in sight, the rest of it is
## measured as a run of its own.
func _test_a_run_left_out_of_sight_is_reported() -> void:
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	var fake := FakeVisibilityHost.new()
	main.get_node("AppSuspend").host = fake
	root.add_child(main)
	await _frames(3)
	var race: RaceManager = main.get_node("RaceManager")
	var perf: PerfReport = main.get_node("PerfReport")
	var page := PerfPage.new()
	perf.listen(page)
	race.ball.start_control()
	perf.set_process(false) # the frames below are made up
	for i in 300:
		perf._process(1.0 / 60.0)
	fake.is_hidden = true
	await _frames(40)
	_check(page.reports.size() == 1 and not page.reports[0]["finished"] and absf(page.reports[0]["seconds"] - 5.0) < 0.11,
		"a run left out of sight is reported then, as far as it went (%d reports)" % page.reports.size())
	fake.is_hidden = false
	await _frames(3)
	_check(page.started == 2 and perf.is_processing(), "back in sight, the rest of it is measured as a run of its own")
	main.free()
	paused = false


## The forest's last leap ends just before the finish line: a ball that rolls
## into the gap instead of jumping it carries on under the finish road. That
## isn't a finish, and the player is told they're off the track straight away
## (not seconds later, which looked like the line had failed to count).
func _test_missing_the_last_leap_is_off_the_track_at_once() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "jungle")
	var race: RaceManager = main.get_node("RaceManager")
	var ball := race.ball
	var track := loader.level.track
	var finish_at := track.path.total_length() - track.finish_distance_from_end
	var leap := Vector2.ZERO
	for gap in track.path.jumps:
		if gap.y <= finish_at and gap.y > leap.y:
			leap = gap
	_check(leap != Vector2.ZERO and finish_at - leap.y < 5.0, "the forest's last leap ends just before the finish line (%.1f m)" % (finish_at - leap.y))
	# A little off the middle, clear of the pillar under the landing's edge.
	var frame := track.world_frame_at(leap.x - 5.0)
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.55 + frame.basis.x.normalized() * 1.6))
	ball.start_control()
	# Already rolling at 31 m/s (not sliding), as a player arrives at the lip.
	ball.linear_velocity = -frame.basis.z.normalized() * 31.0
	ball.angular_velocity = frame.basis.y.normalized().cross(ball.linear_velocity) / ball.radius
	var to_line := track.finish_line.global_transform.affine_inverse()
	var passed_at := -1
	var off_at := -1
	for i in roundi(4.0 / TICK):
		ball.drive(Vector3.ZERO, false, false)
		await physics_frame
		if passed_at < 0 and (to_line * ball.global_position).z < 0.0:
			passed_at = i
		if off_at < 0 and race.off_track:
			off_at = i
		if passed_at >= 0 and i > passed_at + roundi(1.0 / TICK):
			break
	_check(passed_at >= 0 and race.state == RaceManager.State.RUNNING, "rolling under the finish road after missing the leap isn't a finish")
	_check(off_at >= 0 and off_at <= passed_at + roundi(0.5 / TICK),
		"it shows as off the track straight away (%.2f s after passing under the line)" % ((off_at - passed_at) * TICK))
	_check(race.progress <= leap.y + 1.0, "progress stops counting underneath the road (%.0f m, the leap ends at %.0f m)" % [race.progress, leap.y])
	main.free()


## Holes in the ice bridge: a ball rolling over one falls through; beside it,
## it rolls on.
func _test_a_hole_in_the_road_drops_the_ball_through() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "winter")
	var route := loader.level.track.get_node("IceBridge") as TrackRoute
	_check(route != null and route.holes.size() >= 4, "the ice bridge has holes")
	var ball: RollingBall = main.get_node("Ball")
	var hole: Vector4 = route.holes[0]
	var results := []
	for x in [hole.z, -hole.z]:
		var frame := route.world_frame_at(hole.x + hole.y * 0.5)
		ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.x.normalized() * x + frame.basis.y * 1.2))
		ball.control_started.emit()
		for i in roundi(1.0 / TICK):
			await physics_frame
		results.append(frame.origin.y - ball.global_position.y)
	_info("dropped over a hole the ball fell %.1f m; beside it %.1f m" % [results[0], results[1]])
	_check(results[0] > 2.0, "a ball over a hole falls through it")
	_check(results[1] < 0.5, "beside the hole the road holds the ball")
	main.free()


## Barrels roll down the beach's raised shortcut toward the player, and are
## solid: a ball resting in their way is shoved back.
func _test_rolling_barrels_knock_the_ball_back() -> void:
	RollingBarrels.hold_still = false
	var main := _start_main()
	var loader := await _load_level(main, "beach")
	var barrels := loader.level.get_node_or_null("RollingBarrels") as RollingBarrels
	_check(barrels != null, "the beach shortcut has rolling barrels")
	if barrels == null:
		main.free()
		return
	var row: Node3D = barrels.get_node("Barrels_0")
	var before := row.global_position
	await _ticks(30)
	_check(row.global_position.distance_to(before) > 1.0, "the barrels roll")
	# Put a ball a little way down the road from the first row, at rest.
	var route := barrels.track
	var here: int = route.path.nearest_index(route.to_local(row.global_position), -1, 400)
	var ahead := route.path.distances[here] - 6.0
	var frame := route.world_frame_at(ahead)
	var ball: RollingBall = main.get_node("Ball")
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
	ball.control_started.emit()
	var start := ball.global_position
	var shoved := 0.0
	for i in roundi(2.5 / TICK):
		await physics_frame
		shoved = maxf(shoved, ball.global_position.distance_to(start))
	_info("a barrel row shoved a resting ball %.1f m" % shoved)
	_check(shoved > 3.0, "a barrel row shoves a ball in its way")
	RollingBarrels.hold_still = true
	main.free()


## Along the forest floor cobblestone walls stand on both sides: a ball rolling
## across the ground toward the course is stopped by them.
func _test_forest_walls_keep_ground_riders_off_the_course() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "jungle")
	var walls := loader.level.get_node_or_null("StoneWalls") as StoneWalls
	_check(walls != null, "the forest has cobblestone walls")
	if walls == null:
		main.free()
		return
	var track := loader.level.track
	var terrain: Terrain = loader.level.get_node("Terrain")
	var frame := track.world_frame_at(580.0)
	var right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
	var outside := frame.origin + right * (walls.offset + 6.0)
	outside.y = terrain.height_at(outside) + 0.6
	var ball: RollingBall = main.get_node("Ball")
	ball.respawn(Transform3D(Basis.IDENTITY, outside))
	ball.control_started.emit()
	await physics_frame
	ball.linear_velocity = -right * 25.0
	var closest := INF
	for i in roundi(1.5 / TICK):
		ball.drive(-right, false, false)
		await physics_frame
		var offset := (ball.global_position - frame.origin).dot(right)
		closest = minf(closest, offset)
	_info("a ball rolling at the course from outside the wall got to %.1f m from the centreline" % closest)
	_check(closest > walls.offset - 1.0, "the wall stops a ball rolling in from the ground")
	main.free()


## Changing level puts up a loading screen with the level's name, and takes
## it down once the level is in.
## The tutorial's quickest line jumps from the loop's way in straight across
## to its way out, skipping the loop. Landing on the road there, the race
## carries on from where the ball is, so the finish counts (the community
## leaderboard's check already accepts such a run), and the camera follows.
func _test_jumping_across_the_loop_still_finishes() -> void:
	var main := _start_main()
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var ball := race.ball
	var track := race.track
	var path := track.path
	var top := -1
	for i in path.frames.size():
		if path.frames[i].basis.y.normalized().y < -0.95:
			top = i
			break
	var loop_top := path.distances[top]
	# Followed the track up to just before the loop, then landed well past it,
	# where the quickest line comes down.
	var entry := loop_top - 30.0
	var landing := loop_top + 44.0
	ball.start_control()
	await physics_frame
	race._track_hint = clampi(path.distances.bsearch(entry), 0, path.frames.size() - 1)
	race._furthest = entry
	var frame := track.world_frame_at(landing)
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.55))
	ball.linear_velocity = -frame.basis.z.normalized() * 30.0
	ball.angular_velocity = frame.basis.y.normalized().cross(ball.linear_velocity) / ball.radius
	race._previous_ball_position = ball.global_position
	for i in roundi(5.0 / TICK):
		await physics_frame
		if race.state == RaceManager.State.FINISHED:
			break
	_check(race.state == RaceManager.State.FINISHED, "a run that jumps across the tutorial's loop finishes at the line")
	var camera: FollowCamera = main.get_node("FollowCamera")
	_check(camera._track_frame(ball.global_position) != null, "the camera follows the road again after the jump")
	main.free()


## The game opens on the level played last time without building the
## tutorial first (its graphics would only add to the wait).
func _test_the_game_opens_on_the_tutorial() -> void:
	# Whatever was played last time, the game opens on the tutorial.
	var main := _start_main()
	await _load_level(main, "winter")
	main.free()
	main = _start_main()
	await _ticks(2)
	var loader: LevelLoader = main.get_node("LevelLoader")
	var race: RaceManager = main.get_node("RaceManager")
	_check(loader.level_id == LevelCatalog.DEFAULT_ID and not loader.busy and race.track_id == LevelCatalog.DEFAULT_ID,
		"the game opens on the tutorial, whatever was played last")
	main.free()
	# A level being tried out (first_level) opens straight away instead.
	main = MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	loader = main.get_node("LevelLoader")
	loader.first_level = "jungle"
	var installed: Array[String] = []
	loader.changed.connect(func(level: Level) -> void: installed.append(level.level_id))
	root.add_child(main)
	_check(loader.busy and loader.screen.visible and loader.screen._title.text == "Forest", "first_level opens on that level's loading screen")
	while loader.busy:
		await process_frame
	await _ticks(2)
	race = main.get_node("RaceManager")
	_check(installed == ["jungle"], "the tutorial isn't built first (%s)" % ", ".join(installed))
	_check(race.track_id == LevelCatalog.records_id("jungle") and race.state == RaceManager.State.READY, "the race is ready on that level")
	main.free()


func _test_a_loading_screen_covers_a_level_change() -> void:
	var main := _start_main()
	await _ticks(2)
	var loader: LevelLoader = main.get_node("LevelLoader")
	loader.load_level("winter")
	_check(loader.screen.visible and loader.screen._title.text == "Winter Wonderland", "a loading screen shows the level being loaded")
	while loader.level_id != "winter":
		await process_frame
	for i in 90:
		await process_frame
	_check(not loader.screen.visible, "the loading screen goes once the level is in")
	main.free()


## Round the loop the camera hands over between orbiting the ball and
## chasing along the track; that hand-over must never jump.
func _test_the_camera_turns_smoothly_through_the_loop() -> void:
	var main := _start_main()
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var camera: FollowCamera = main.get_node("FollowCamera")
	var pilot := Autopilot.new()
	pilot.ball = race.ball
	pilot.track = race.track
	main.add_child(pilot)
	var previous := camera.global_transform
	var worst_turn := 0.0
	var worst_jump := 0.0
	var chased := false
	for i in roundi(40.0 / TICK):
		await physics_frame
		if race.state == RaceManager.State.FINISHED:
			break
		var now := camera.global_transform
		worst_turn = maxf(worst_turn, rad_to_deg(previous.basis.get_rotation_quaternion().angle_to(now.basis.get_rotation_quaternion())))
		var expected := race.ball.linear_velocity.length() * TICK
		worst_jump = maxf(worst_jump, previous.origin.distance_to(now.origin) - expected)
		chased = chased or camera._chase > 0.9
		previous = now
	_info("through a lap the camera turned at most %.1f° and jumped at most %.2f m in one tick" % [worst_turn, worst_jump])
	_check(chased, "the camera chased along the track in the loop")
	_check(worst_turn < 10.0 and worst_jump < 0.8, "the camera never snaps through the loop")
	main.free()


## Nobody drives up a wall: full throttle still speeds a ball up a moderate
## slope, but on a near-vertical face it only slows down (climbs are momentum).
func _test_driving_cannot_climb_a_wall() -> void:
	var curve := _section(18.0)
	curve.end_pitch = 80.0
	var track := _test_track([_section(60.0), _section(30.0, 25.0), _section(40.0, 25.0), _section(20.0, 0.0), curve, _section(60.0, 80.0)])
	var ball := _spawn_ball(track, _on_track(track, 10.0))
	await _ticks(1)
	ball.control_started.emit()
	var forward := -track.world_frame_at(10.0).basis.z
	# On the 25° ramp from 10 m/s, full drive gains speed.
	_launch(ball, track, 95.0, 10.0)
	for i in 30:
		ball.drive(forward, false, false)
		await physics_frame
	var on_ramp := ball.linear_velocity.length()
	_check(on_ramp > 10.5, "full drive still speeds a ball up a 25° slope (%.1f m/s)" % on_ramp)
	# On the wall from 20 m/s, full throttle does no better than coasting.
	var ends := []
	for driving in [true, false]:
		_launch(ball, track, 175.0, 20.0)
		for i in 36:
			ball.drive(forward if driving else Vector3.ZERO, false, false)
			await physics_frame
		ends.append(ball.linear_velocity.length())
	_info("up the 80° face from 20 m/s, after 0.3 s: %.1f m/s driving, %.1f m/s coasting" % ends)
	_check(ends[0] < 17.0 and absf(ends[0] - ends[1]) < 0.3, "driving up a near-vertical wall is no better than coasting")
	track.get_parent().free()


## Hidden (its Möbius tab closed, the page minimised) the game pauses and goes
## silent; shown again it carries on as it was. In a party level it only goes
## silent, so the shared race clock keeps running.
func _test_the_game_sleeps_while_hidden() -> void:
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	var fake := FakeVisibilityHost.new()
	main.get_node("AppSuspend").host = fake
	root.add_child(main)
	await _frames(3)
	var race: RaceManager = main.get_node("RaceManager")
	var suspend: AppSuspend = main.get_node("AppSuspend")
	fake.is_hidden = true
	await _frames(40)
	_check(suspend.asleep and paused and AudioServer.is_bus_mute(0), "hidden, the game is paused and silent")
	fake.is_hidden = false
	await _frames(3)
	_check(not suspend.asleep and not paused and not AudioServer.is_bus_mute(0), "shown again, it carries on with its sound")
	var menu: PauseMenu = main.get_node("PauseMenu")
	menu.open()
	fake.is_hidden = true
	await _frames(40)
	fake.is_hidden = false
	await _frames(3)
	_check(paused and menu.is_open(), "left on the menu, it stays paused when shown again")
	menu.close()
	race.party_round = true
	fake.is_hidden = true
	await _frames(40)
	_check(suspend.asleep and not paused and AudioServer.is_bus_mute(0), "in a party level it only goes silent")
	fake.is_hidden = false
	await _frames(3)
	race.party_round = false
	main.free()
	paused = false


class FakeVisibilityHost:
	extends RefCounted
	var is_hidden := false

	func hidden() -> bool:
		return is_hidden


## Edge smoothing stays the project's own multisampling unless the player
## picks the faster, rougher screen-space option.
func _test_graphics_options_and_view_distance() -> void:
	var main := _start_main()
	await _ticks(2)
	var settings: GameSettings = main.get_node("Settings")
	var viewport := main.get_viewport()
	var project_msaa := int(ProjectSettings.get_setting("rendering/anti_aliasing/quality/msaa_3d"))
	_check(viewport.msaa_3d == project_msaa and viewport.screen_space_aa == Viewport.SCREEN_SPACE_AA_DISABLED,
		"edge smoothing is the project's own multisampling by default")
	settings.set_value("fast_antialiasing", true)
	_check(viewport.msaa_3d == Viewport.MSAA_DISABLED and viewport.screen_space_aa == Viewport.SCREEN_SPACE_AA_FXAA,
		"the fast option swaps multisampling for a screen-space pass")
	settings.set_value("fast_antialiasing", false)
	_check(viewport.msaa_3d == project_msaa, "switching it off restores the multisampling")
	main.free()


# --- Touch screens and phones ------------------------------------------------

## The game as a player has it (PlayerInput kept), never saving anything.
## [param touch_first] 1 makes it a phone's; the window itself is left alone
## (tests try screens out through ScreenFit.apply_layout).
func _start_main_with_input(touch_first := -1) -> Node:
	var main := MAIN_SCENE.instantiate()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	var fit: ScreenFit = main.get_node("ScreenFit")
	fit.force_touch_first = touch_first
	fit.follow_window = false
	root.add_child(main)
	return main


func _touch(index: int, at: Vector2, pressed := true) -> void:
	var event := InputEventScreenTouch.new()
	event.index = index
	event.position = at
	event.pressed = pressed
	Input.parse_input_event(event)
	# Input waits to be flushed at the end of a frame; hand it over now.
	Input.flush_buffered_events()


func _touch_drag(index: int, at: Vector2, relative: Vector2) -> void:
	var event := InputEventScreenDrag.new()
	event.index = index
	event.position = at
	event.relative = relative
	Input.parse_input_event(event)
	Input.flush_buffered_events()


func _tap(at: Vector2) -> void:
	_touch(0, at)
	await _frames(1)
	_touch(0, at, false)
	await _frames(1)


## Phones lay their UI out in the browser's pixels (a little smaller on small
## phones), compact, clear of the notch; desktops keep their window's pixels.
func _test_screens_are_fitted_for_phones_and_left_alone_on_desktops() -> void:
	var desktop := ScreenFit.layout(Vector2(1920, 1080), 1.0, false)
	_check(desktop["scale"] == 1.0 and desktop["size"] == Vector2(1920, 1080) and not desktop["compact"],
		"a desktop window keeps its pixels and the full layout")
	var phone := ScreenFit.layout(Vector2(2532, 1170), 3.0, true, {"left": 47.0, "right": 47.0, "bottom": 21.0})
	var size: Vector2 = phone["size"]
	_check(absf(size.y - 430.0) < 1.0 and phone["compact"] and not phone["portrait"],
		"a phone held sideways gets the compact layout, 430 UI pixels high (%s)" % size)
	_check(absf(phone["safe"]["left"] - 47.0 * 3.0 / phone["scale"]) < 0.01 and phone["safe"]["top"] == 0.0,
		"the margin its notch needs comes along in UI pixels")
	var upright := ScreenFit.layout(Vector2(1170, 2532), 3.0, true)
	_check(upright["portrait"] and upright["compact"], "held upright it is portrait, and compact")
	var small := ScreenFit.layout(Vector2(1334, 750), 2.0, true)
	_check(small["scale"] < 2.0 * 0.9, "a small phone's UI is drawn a little smaller (%.2f screen pixels each)" % small["scale"])
	_check(is_equal_approx(FollowCamera.portrait_fov(72.0, 16.0 / 9.0, 90.0), 72.0)
		and is_equal_approx(FollowCamera.portrait_fov(72.0, 0.46, 90.0), 90.0)
		and absf(FollowCamera.portrait_fov(72.0, 0.75, 90.0) - 88.2) < 0.5,
		"held upright, the camera keeps its field of view across, opening up and down to at most 90°")


## The touch stick hands the ball the intent a gamepad's stick (or the keys)
## would, so the ball handles the same: all the way over is full drive, half
## way the same push as a gamepad stick half way over, and a run on either
## reaches the same speed.
func _test_the_touch_stick_drives_like_a_gamepad_stick() -> void:
	var main := _start_main_with_input()
	var touch: TouchControls = main.get_node("TouchControls")
	var ball: RollingBall = main.get_node("Ball")
	var camera: FollowCamera = main.get_node("FollowCamera")
	var race: RaceManager = main.get_node("RaceManager")
	await _ticks(2)
	var thumb := touch.stick_centre()
	_touch(0, thumb)
	await _frames(1)
	_check(touch.active and touch.is_steering() and touch.stick == Vector2.ZERO, "a thumb on the stick takes it, resting in its dead zone")
	var player: PlayerInput = main.get_node("PlayerInput")
	var reach := touch.stick_radius
	_touch_drag(0, thumb + Vector2(0, -reach), Vector2(0, -reach))
	await _frames(1)
	# What PlayerInput hands the ball this tick (the ball uses it up each step).
	player._physics_process(TICK)
	var full := camera.get_flat_basis().inverse() * ball._move_intent
	_check(touch.stick.is_equal_approx(Vector2(0, -1)) and full.is_equal_approx(Vector3.FORWARD),
		"pushed all the way up it drives straight ahead at full strength (%s)" % full)
	_touch_drag(0, thumb + Vector2(0, -reach * 0.5), Vector2(0, reach * 0.5))
	await _frames(1)
	player._physics_process(TICK)
	var half := (camera.get_flat_basis().inverse() * ball._move_intent).length()
	_touch(0, thumb + Vector2(0, -reach * 0.5), false)
	await _frames(1)
	var deflection := inverse_lerp(touch.dead_zone, touch.full_at, 0.5)
	Input.action_press("move_forward", 0.2 + 0.8 * deflection)
	player._physics_process(TICK)
	var gamepad := (camera.get_flat_basis().inverse() * ball._move_intent).length()
	Input.action_release("move_forward")
	_check(absf(half - deflection) < 0.001 and absf(half - gamepad) < 0.001,
		"half way over it pushes as hard as a gamepad stick at the same deflection (%.3f, %.3f)" % [half, gamepad])
	player._physics_process(TICK)
	_check(not touch.is_steering() and ball._move_intent == Vector3.ZERO, "letting go stops driving")
	await _ticks(2)
	race.restart()
	await _ticks(2)
	_touch(0, thumb)
	_touch_drag(0, thumb + Vector2(0, -reach), Vector2(0, -reach))
	await _ticks(240)
	var touch_speed := ball.linear_velocity.length()
	_touch(0, thumb + Vector2(0, -reach), false)
	race.restart()
	await _ticks(2)
	Input.action_press("move_forward")
	await _ticks(240)
	var key_speed := ball.linear_velocity.length()
	Input.action_release("move_forward")
	_check(key_speed > 5.0 and absf(touch_speed - key_speed) < 0.01 * key_speed,
		"two seconds on the touch stick reach the speed two seconds on the keys do (%.2f, %.2f m/s)" % [touch_speed, key_speed])
	main.free()


## The stick is fixed: a thumb landing on it, or a little wide of it, takes it,
## and only its knob follows the thumb, to the rim at most; the stick itself
## never moves, so the thumb always finds it in the same place. It sits further
## in from the screen's edges than the other controls, leaving the thumb room
## to push it all the way over in every direction. A touch well away from it
## doesn't take it.
func _test_the_touch_stick_stays_where_it_is() -> void:
	var main := _start_main_with_input()
	var touch: TouchControls = main.get_node("TouchControls")
	await _ticks(2)
	var centre := touch.stick_centre()
	var area := touch._usable()
	_check(centre.x - touch.stick_radius - area.position.x >= touch.stick_inset.x - 0.5
		and area.end.y - (centre.y + touch.stick_radius) >= touch.stick_inset.y - 0.5
		and touch.stick_inset.x > touch.margin and touch.stick_inset.y > touch.margin,
		"the stick sits further in from the left and bottom edges than the other controls (%s)" % touch.stick_inset)
	var r := touch.stick_radius
	_touch(0, centre + Vector2(r * 1.5, 0))
	await _frames(1)
	_check(touch.is_steering() and touch.stick.is_equal_approx(Vector2(1, 0)),
		"a thumb landing just wide of the stick takes it, pushed toward the thumb (%s)" % touch.stick)
	_touch_drag(0, centre + Vector2(0, -r * 3.0), Vector2(-r * 1.5, -r * 3.0))
	await _frames(1)
	_check(touch.stick.is_equal_approx(Vector2(0, -1)) and touch.stick_centre() == centre,
		"run past the rim, the knob stays at the rim and the stick doesn't move (%s)" % touch.stick)
	_touch_drag(0, centre + Vector2(0, r * 0.5), Vector2(0, r * 3.5))
	await _frames(1)
	var back := inverse_lerp(touch.dead_zone, touch.full_at, 0.5)
	_check(touch.stick.is_equal_approx(Vector2(0, back)) and touch.stick_centre() == centre,
		"and turning back reads from the same centre at once (%s)" % touch.stick)
	_touch(0, centre + Vector2(0, r * 0.5), false)
	await _frames(1)
	_touch(1, centre + Vector2(0, -r * (touch.stick_reach + 0.5)))
	await _frames(1)
	_check(not touch.is_steering(), "a touch well away from the stick doesn't take it")
	_touch(1, centre + Vector2(0, -r * (touch.stick_reach + 0.5)), false)
	await _frames(1)
	main.free()


## The jump button presses jump just as Space does, while the other thumb
## keeps steering.
func _test_the_jump_button_jumps_with_the_stick_held() -> void:
	var main := _start_main_with_input()
	var touch: TouchControls = main.get_node("TouchControls")
	var ball: RollingBall = main.get_node("Ball")
	await _ticks(30)
	var start_y := ball.global_position.y
	var thumb := touch.stick_centre()
	_touch(0, thumb)
	_touch_drag(0, thumb + Vector2(0, -20), Vector2(0, -20))
	_touch(1, touch.jump_centre() + Vector2(touch.jump_radius * 1.2, 0))
	await _frames(1)
	_check(Input.is_action_pressed("jump") and touch.is_steering(), "a thumb on (or just beside) the jump button holds jump while the other steers")
	var apex := start_y
	for i in 90:
		await physics_frame
		apex = maxf(apex, ball.global_position.y)
	_check(apex - start_y > 1.0, "and the ball jumps (%.2f m)" % (apex - start_y))
	_touch(1, touch.jump_centre(), false)
	await _frames(1)
	_check(not Input.is_action_pressed("jump") and touch.is_steering(), "letting go releases jump; the stick keeps steering")
	_touch(0, thumb, false)
	await _frames(1)
	main.free()


## Dragging on the right turns the view as the mouse does, and holds it a
## moment before the camera swings back behind the ball; the touch's stand-in
## mouse doesn't turn it a second time; a double tap swings it behind the ball.
func _test_dragging_on_the_right_looks_around() -> void:
	var main := _start_main_with_input()
	var touch: TouchControls = main.get_node("TouchControls")
	var camera: FollowCamera = main.get_node("FollowCamera")
	await _ticks(2)
	var yaw := camera._yaw
	var at := Vector2(1200, 400)
	_touch(0, at)
	_touch_drag(0, at + Vector2(100, 0), Vector2(100, 0))
	await _frames(1)
	var turned := rad_to_deg(yaw - camera._yaw)
	_check(absf(turned - 100.0 * touch.look_sensitivity) < 0.01, "a drag turns the view by its length times the look speed (%.2f°)" % turned)
	_check(camera._free_look_left > 0.0, "and the camera leaves it there a moment")
	var stand_in := InputEventMouseMotion.new()
	stand_in.device = InputEvent.DEVICE_ID_EMULATION
	stand_in.relative = Vector2(200, 0)
	stand_in.button_mask = MOUSE_BUTTON_MASK_LEFT
	var before := camera._yaw
	camera._unhandled_input(stand_in)
	_check(camera._yaw == before, "the stand-in mouse a touch also sends doesn't turn it again")
	_touch(0, at + Vector2(100, 0), false)
	await _frames(1)
	_touch(0, at)
	_touch(0, at, false)
	_touch(0, at)
	_touch(0, at, false)
	await _frames(1)
	_check(camera._free_look_left == 0.0, "a double tap there swings the camera back behind the ball")
	main.free()


## The buttons top left: restart, the leaderboard (tap again to hide it) and
## the menu, which pauses the game while the touch controls make way.
func _test_touch_buttons_restart_show_the_board_and_open_the_menu() -> void:
	var main := _start_main_with_input()
	var touch: TouchControls = main.get_node("TouchControls")
	var race: RaceManager = main.get_node("RaceManager")
	var board: LeaderboardOverlay = main.get_node("Leaderboard")
	var menu: PauseMenu = main.get_node("PauseMenu")
	await _ticks(2)
	Input.action_press("move_forward")
	await _ticks(60)
	Input.action_release("move_forward")
	_check(race.state == RaceManager.State.RUNNING, "the run is on")
	await _tap(touch.button_rect("restart").get_center())
	await _ticks(1)
	_check(race.state == RaceManager.State.READY and race.race_time == 0.0, "the restart button puts the ball back on the start line")
	await _tap(touch.button_rect("board").get_center())
	await _frames(1)
	_check(board.is_shown() and not paused, "the podium button shows the leaderboard over the running game")
	await _tap(touch.button_rect("board").get_center())
	await _frames(1)
	_check(not board.is_shown(), "tapped again, it goes")
	await _tap(touch.button_rect("menu").get_center())
	await _frames(1)
	_check(menu.is_open() and paused and not touch.active, "the menu button opens the menu, pausing the game; the touch controls make way")
	menu.close()
	await _frames(2)
	_check(touch.active and not paused, "they come back when it closes")
	main.free()


## Phones keep their own settings, apart from the desktop's (app storage is
## shared by a player's devices): lighter graphics on, and the touch look
## speed where a desktop has the mouse's.
func _test_phones_keep_their_own_settings() -> void:
	_check(GameSettings.defaults_for(true)["phone_graphics"] and not GameSettings.defaults_for(false)["phone_graphics"],
		"lighter graphics are on by default on phones only")
	_check(not GameSettings.defaults_for(true)["shadows"] and GameSettings.defaults_for(false)["shadows"],
		"phones start without shadows; desktops keep them")
	var mouse := {}
	var look := {}
	for entry in GameSettings.SCHEMA:
		if entry["key"] == "mouse_sensitivity":
			mouse = entry
		elif entry["key"] == "touch_look_sensitivity":
			look = entry
	_check(GameSettings.shown(mouse, false) and not GameSettings.shown(mouse, true) and GameSettings.shown(look, true) and not GameSettings.shown(look, false),
		"phones show the touch look speed, desktops the mouse sensitivity")
	var main := _start_main_with_input(1)
	var settings: GameSettings = main.get_node("Settings")
	await _ticks(2)
	_check(settings.store_key() == GameSettings.TOUCH_STORE_KEY and settings.values["phone_graphics"],
		"a phone keeps them in %s, lighter graphics on" % settings.store_key())
	settings.set_value("phone_graphics", false)
	main.free()


## How the camera frames the ball is the player's own on every device: a phone
## takes the desktop's camera distance, angle and fields of view (app storage
## is shared by a player's devices), and changing them on the phone changes
## them there too, while the phone's other settings stay its own and the
## desktop's own (mouse, shadows) stay as they were.
func _test_phones_share_the_desktops_camera_framing() -> void:
	var saved := {}
	for key in [GameSettings.STORE_KEY, GameSettings.TOUCH_STORE_KEY]:
		saved[key] = GameStore.read(key)
	GameStore.write(GameSettings.STORE_KEY, {"camera_distance": 5.0, "camera_pitch": -15.0, "fov": 62.0, "speed_fov": 9.0,
		"mouse_sensitivity": 0.05, "shadows": true})
	GameStore.remove(GameSettings.TOUCH_STORE_KEY)
	var main := MAIN_SCENE.instantiate()
	main.get_node("RaceManager").save_records = false
	var fit: ScreenFit = main.get_node("ScreenFit")
	fit.force_touch_first = 1
	fit.follow_window = false
	root.add_child(main)
	await _ticks(2)
	var settings: GameSettings = main.get_node("Settings")
	var camera: FollowCamera = main.get_node("FollowCamera")
	_check(is_equal_approx(camera.distance, 5.0) and is_equal_approx(camera.base_fov, 62.0) and is_equal_approx(camera.max_fov, 71.0),
		"a phone frames the ball as the desktop does (%.1f m, %.0f° to %.0f°)" % [camera.distance, camera.base_fov, camera.max_fov])
	_check(not settings.values["shadows"] and settings.values["phone_graphics"], "and keeps its own graphics: no shadows, lighter")
	settings.set_value("camera_distance", 6.0)
	settings.set_value("volume", 40.0)
	settings.save()
	var desktop: Variant = GameStore.read(GameSettings.STORE_KEY)
	var phone: Variant = GameStore.read(GameSettings.TOUCH_STORE_KEY)
	_check(desktop is Dictionary and is_equal_approx(desktop["camera_distance"], 6.0) and is_equal_approx(desktop["mouse_sensitivity"], 0.05)
		and desktop["shadows"] == true and not desktop.has("volume"),
		"moving the camera on the phone moves it on the desktop too; the desktop's own settings stay")
	_check(phone is Dictionary and is_equal_approx(phone["volume"], 40.0) and not phone.has("camera_distance"),
		"the phone's own settings stay its own")
	main.free()
	for key: String in saved:
		if saved[key] == null:
			GameStore.remove(key)
		else:
			GameStore.write(key, saved[key])


## Held upright, a phone keeps the desktop's camera angle: the same height
## behind the ball and the same pitch as a wide screen; only the field of view
## is kept across (FollowCamera.portrait_fov), so the road doesn't narrow to a
## slot.
func _test_held_upright_the_camera_keeps_the_desktop_angle() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	var placed := {}
	for shape in [Vector2i(1600, 762), Vector2i(540, 978)]:
		var view := SubViewport.new()
		view.size = shape
		world.add_child(view)
		var camera := FollowCamera.new()
		camera.ball = ball
		camera.capture_mouse_on_start = false
		camera.distance = 5.0
		camera.default_pitch = -13.0
		camera.base_fov = 62.0
		camera.max_fov = 62.0
		view.add_child(camera)
		camera.make_current()
		camera.snap_behind(ball.global_transform)
		await _frames(3)
		placed[shape.x > shape.y] = [camera.global_position - ball.global_position, rad_to_deg(camera.global_transform.basis.get_euler().x), camera.fov]
		view.queue_free()
	var wide: Array = placed[true]
	var tall: Array = placed[false]
	_check((wide[0] as Vector3).is_equal_approx(tall[0]) and is_equal_approx(wide[1], tall[1]),
		"upright, the camera sits where a wide screen's does and looks down as far (%.1f° pitch, %.1f m up)" % [tall[1], (tall[0] as Vector3).y])
	_check(tall[2] > wide[2], "with the field of view kept across (%.0f° up and down, where a wide screen has %.0f°)" % [tall[2], wide[2]])
	world.free()


## Lighter graphics: the 3D view drawn with fewer pixels on dense screens,
## simpler models sooner, scenery and shadows not as far, 60 frames a second
## and the levels' lighter packs. Switching them off puts it all back. The
## physics are untouched.
func _test_lighter_graphics_trim_what_phones_struggle_with() -> void:
	_check(is_equal_approx(GameSettings.light_resolution_scale(Vector2(1024, 600)), 1.0)
		and absf(GameSettings.light_resolution_scale(Vector2(2532, 1170)) - 0.52) < 0.01,
		"a phone's dense screen is drawn at about half its pixels each way; a small one in full")
	var main := _start_main()
	await _ticks(2)
	var settings: GameSettings = main.get_node("Settings")
	var levels: LevelLoader = main.get_node("LevelLoader")
	var viewport := main.get_viewport()
	var sun: DirectionalLight3D = levels.level.find_children("*", "DirectionalLight3D", true, false)[0]
	var full_mode := sun.directional_shadow_mode
	var full_reach := sun.directional_shadow_max_distance
	var prop := MeshInstance3D.new()
	prop.visibility_range_end = 300.0
	prop.visibility_range_end_margin = 20.0
	levels.level.add_child(prop)
	# A set piece seen from all over the level (the winter cabin).
	var cabin := MeshInstance3D.new()
	cabin.set_meta(GameSettings.LIGHT_RANGE_META, 200.0)
	levels.level.add_child(cabin)
	# Plants (nothing the ball can hit), a leafy material, glow and a particle effect.
	var plants := MultiMeshInstance3D.new()
	plants.multimesh = MultiMesh.new()
	plants.multimesh.transform_format = MultiMesh.TRANSFORM_3D
	plants.multimesh.mesh = BoxMesh.new()
	plants.multimesh.instance_count = 10
	plants.set_meta(GameSettings.DECORATIVE_META, true)
	levels.level.add_child(plants)
	var leaves := StandardMaterial3D.new()
	leaves.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_DEPTH_PRE_PASS
	var tree := MeshInstance3D.new()
	tree.mesh = BoxMesh.new()
	tree.material_override = leaves
	levels.level.add_child(tree)
	var spray := CPUParticles3D.new()
	spray.amount = 40
	levels.level.add_child(spray)
	# A surface with a relief map, and a shader with a lighter version of its own.
	var bumpy := StandardMaterial3D.new()
	bumpy.normal_enabled = true
	var rock := MeshInstance3D.new()
	rock.mesh = BoxMesh.new()
	rock.material_override = bumpy
	levels.level.add_child(rock)
	var ground_shader := Shader.new()
	ground_shader.code = "shader_type spatial;\nuniform bool lighter = false;\nvoid fragment() { ALBEDO = lighter ? vec3(1.0) : vec3(0.5); }\n"
	var ground := ShaderMaterial.new()
	ground.shader = ground_shader
	var floor := MeshInstance3D.new()
	floor.mesh = BoxMesh.new()
	floor.material_override = ground
	levels.level.add_child(floor)
	var world: WorldEnvironment = levels.level.find_children("*", "WorldEnvironment", true, false)[0]
	var glow := world.environment.glow_enabled
	var threshold := float(ProjectSettings.get_setting("rendering/mesh_lod/lod_change/threshold_pixels"))
	settings.set_value("phone_graphics", true)
	_check(is_equal_approx(viewport.mesh_lod_threshold, threshold * GameSettings.LIGHT_LOD_THRESHOLD) and Engine.max_fps == 60 and levels.light_textures,
		"simpler models sooner, 60 frames a second, lighter level packs")
	_check(sun.directional_shadow_mode == DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
		and is_equal_approx(sun.directional_shadow_max_distance, maxf(full_reach * GameSettings.LIGHT_SHADOW_DISTANCE, GameSettings.LIGHT_MIN_SHADOW_DISTANCE)),
		"shadows reach %d m in two cascades (from %d m)" % [sun.directional_shadow_max_distance, full_reach])
	_check(is_equal_approx(prop.visibility_range_end, 300.0 * GameSettings.LIGHT_VIEW_DISTANCE) and is_equal_approx(prop.visibility_range_end_margin, 20.0 * GameSettings.LIGHT_VIEW_DISTANCE),
		"scenery that fades with distance fades sooner (%d m rather than 300)" % prop.visibility_range_end)
	_check(plants.multimesh.visible_instance_count == 5, "half the decorative plants are drawn (%d of 10)" % plants.multimesh.visible_instance_count)
	_check(is_equal_approx(cabin.visibility_range_end, 200.0), "a set piece seen from all over the level is drawn only within 200 m")
	_check(leaves.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR, "leaves are cut out in one pass")
	_check(not world.environment.glow_enabled and spray.amount == 20, "no glow, half the particles")
	_check(not bumpy.normal_enabled and ground.get_shader_parameter("lighter") == true,
		"surfaces leave their relief maps off, and shaders with a lighter version use it")
	_check(Engine.physics_ticks_per_second == 120 and ProjectSettings.get_setting("physics/3d/physics_engine") == "Jolt Physics",
		"the physics are untouched: Jolt, 120 steps a second")
	settings.set_value("phone_graphics", false)
	_check(plants.multimesh.visible_instance_count == -1 and leaves.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_DEPTH_PRE_PASS
		and spray.amount == 40 and world.environment.glow_enabled == glow and bumpy.normal_enabled and ground.get_shader_parameter("lighter") == false
		and cabin.visibility_range_end == 0.0,
		"switched off, all the plants, soft leaves, particles, glow, relief and far set pieces are back")
	settings.set_value("phone_graphics", true)
	levels.load_level(levels.level_id)
	var new_sun: DirectionalLight3D = levels.level.find_children("*", "DirectionalLight3D", true, false)[0]
	_check(new_sun != sun and new_sun.directional_shadow_max_distance < full_reach, "a level loaded meanwhile gets them too")
	settings.set_value("phone_graphics", false)
	_check(new_sun.directional_shadow_mode == full_mode and new_sun.directional_shadow_max_distance == full_reach
		and Engine.max_fps == 0 and is_equal_approx(viewport.mesh_lod_threshold, threshold) and not levels.light_textures,
		"switching them off puts it all back")
	main.free()


func _test_lighter_graphics_fetch_the_lighter_level_packs() -> void:
	var loader := LevelLoader.new()
	var entry := LevelCatalog.find("beach")
	var host := FakePackHost.new()
	host.packs = ["level_beach.pck", "level_beach.mobile.pck"]
	_check(loader.pack_for(entry, host) == "level_beach.pck", "full graphics download a level's full pack")
	loader.light_textures = true
	_check(loader.pack_for(entry, host) == "level_beach.mobile.pck", "lighter graphics download its lighter pack (smaller textures)")
	host.packs = ["level_beach.pck"]
	_check(loader.pack_for(entry, host) == "level_beach.pck", "or the full one, where the page has no lighter one")
	loader.free()


class FakePackHost:
	extends RefCounted
	var packs: Array = []

	func has_pack(name: String) -> bool:
		return packs.has(name)


## On a phone, sideways and upright, the menu and the leaderboard fit inside
## the screen's safe area, and so do the touch controls.
func _test_the_phone_layout_fits_the_screen() -> void:
	var main := _start_main_with_input(1)
	var fit: ScreenFit = main.get_node("ScreenFit")
	var menu: PauseMenu = main.get_node("PauseMenu")
	var board: LeaderboardOverlay = main.get_node("Leaderboard")
	var touch: TouchControls = main.get_node("TouchControls")
	await _ticks(2)
	for screen: Array in [[Vector2(2532, 1170), {"left": 47.0, "right": 47.0, "bottom": 21.0}, "sideways"],
			[Vector2(1170, 2532), {"top": 47.0, "bottom": 34.0}, "upright"]]:
		fit.apply_layout(ScreenFit.layout(screen[0], 3.0, true, screen[1]))
		await _frames(2)
		var area := fit.usable_rect()
		menu.open()
		await _frames(2)
		var menu_size := (menu._panel_root.find_children("*", "PanelContainer", true, false)[0] as Control).get_combined_minimum_size()
		_check(menu_size.x <= area.size.x + 0.5 and menu_size.y <= area.size.y + 0.5, "%s, the menu fits the screen (%s in %s)" % [screen[2], menu_size, area.size])
		# Sideways the menu fills the screen's height, up beside Möbius's exit
		# button; upright it sits well below it.
		_check((menu._m["title_indent"] > 0.0) == (screen[2] == "sideways"),
			"%s, the menu's title starts clear of Möbius's exit button (indent %.0f)" % [screen[2], menu._m["title_indent"]])
		menu._tabs.current_tab = 1
		await _frames(2)
		menu_size = (menu._panel_root.find_children("*", "PanelContainer", true, false)[0] as Control).get_combined_minimum_size()
		_check(menu_size.x <= area.size.x + 0.5, "%s, its settings fit across (%s)" % [screen[2], menu_size])
		var settings: GameSettings = main.get_node("Settings")
		var volume: float = settings.values["volume"]
		var more := menu._panel_root.find_child("More_volume", true, false) as Button
		_check(more != null and menu._panel_root.find_children("*", "HSlider", true, false).is_empty(),
			"%s, numbers step with − and + rather than sliders a scrolling finger would drag" % screen[2])
		if more:
			more.pressed.emit()
			_check(is_equal_approx(settings.values["volume"], minf(volume + 10.0, 100.0)) and (menu._value_labels["volume"] as Label).text == "%d%%" % settings.values["volume"],
				"%s, + turns the volume up a step (%s)" % [screen[2], (menu._value_labels["volume"] as Label).text])
			settings.set_value("volume", volume)
		menu._tabs.current_tab = 0
		menu.close()
		board.show_board()
		await _frames(2)
		var board_size := (board._root.find_children("*", "PanelContainer", true, false)[0] as Control).get_combined_minimum_size()
		_check(board_size.x <= area.size.x + 0.5 and board_size.y <= area.size.y + 0.5, "%s, the leaderboard fits (%s)" % [screen[2], board_size])
		board.hide_board()
		var inside := area.encloses(Rect2(touch.jump_centre() - Vector2.ONE * touch.jump_radius, Vector2.ONE * touch.jump_radius * 2.0)) \
			and area.encloses(Rect2(touch.stick_centre() - Vector2.ONE * touch.stick_radius, Vector2.ONE * touch.stick_radius * 2.0))
		for name in TouchControls.BUTTONS:
			inside = inside and area.encloses(touch.button_rect(name))
		_check(inside, "%s, the touch controls sit inside the safe area" % screen[2])
		# Möbius's own exit button: 10 px in from the corner, 40 px across (browser pixels).
		var exit_edge := area.position.x + 50.0 * 3.0 / fit.ui_scale
		_check(touch.button_rect("menu").position.x > exit_edge + 4.0,
			"%s, the small buttons start right of Möbius's exit button (%.0f > %.0f UI px)" % [screen[2], touch.button_rect("menu").position.x, exit_edge])
	main.get_node("Settings").set_value("phone_graphics", false)
	main.free()


## The levels menu shows every level without scrolling, the tutorial first and
## The Original Track next to it: on a wide desktop window (three across), a
## narrower one (two across, shorter cards) and a phone either way up.
func _test_the_levels_menu_shows_every_level() -> void:
	for screen: Array in [[Vector2(1600, 760), 1.0, false, "a wide desktop window"],
			[Vector2(1100, 760), 1.0, false, "a narrower desktop window"],
			[Vector2(2532, 1170), 3.0, true, "a phone held sideways"],
			[Vector2(1170, 2532), 3.0, true, "a phone held upright"]]:
		var main := _start_main_with_input(1 if screen[2] else 0)
		var fit: ScreenFit = main.get_node("ScreenFit")
		var menu: PauseMenu = main.get_node("PauseMenu")
		await _ticks(2)
		fit.apply_layout(ScreenFit.layout(screen[0], screen[1], screen[2]))
		await _frames(2)
		menu.open()
		await _frames(3)
		var grid := menu._level_rows
		var page := grid.get_parent() as Control
		var needed := grid.get_combined_minimum_size()
		var ids: Array = grid.get_children().map(func(card: Node) -> String: return str(card.name).trim_prefix("Level_"))
		_check(ids.size() == LevelCatalog.available().size() and needed.x <= page.size.x + 0.5 and needed.y <= page.size.y + 0.5,
			"on %s every level shows without scrolling (%s on a %s page)" % [screen[3], needed, page.size])
		_check(ids.slice(0, 2) == ["test_track", "original"], "on %s the tutorial comes first, then The Original Track (%s)" % [screen[3], ", ".join(ids)])
		menu.close()
		main.get_node("Settings").set_value("phone_graphics", false)
		main.free()


## A touch screen frames the ball as the desktop does but faces the direction
## of travel firmly (there's no mouse to turn the view, and an upright phone
## shows less than a third as much to the sides): through a long bend taken
## at speed it stays within a few degrees of the travel, where the desktop's
## swing (unchanged) trails by about 20°, and keeps up with a slow, tight
## turn. Rolling back the way it came for a second, it turns round to it.
func _test_on_a_touch_screen_the_camera_faces_the_travel_through_turns() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	var camera := _follow_camera(world, ball)
	var lags: Array[float] = []
	for touch_mode in [false, true]:
		camera.touch_mode = touch_mode
		camera._yaw = 0.0
		camera._free_look_left = 0.0
		var heading := 0.0
		var step := 1.0 / 60.0
		for i in 180:
			heading += deg_to_rad(45.0) * step
			# Travelling along the heading (yaw 0 looks down -z) at 30 m/s.
			camera._auto_orient(Vector3(-sin(heading), 0.0, -cos(heading)) * 30.0, step)
		lags.append(rad_to_deg(absf(wrapf(heading - camera._yaw, -PI, PI))))
	_info("trailing a 45°/s bend at 30 m/s: desktop %.1f°, touch %.1f°" % [lags[0], lags[1]])
	_check(lags[1] < 7.0 and lags[0] > 15.0,
		"on a touch screen the camera stays within 7° of a long bend (%.1f°); the desktop's swing is unchanged (%.1f°)" % [lags[1], lags[0]])
	camera.touch_mode = true
	camera._yaw = 0.0
	camera._free_look_left = 0.0
	var turning := 0.0
	for i in 120:
		turning += deg_to_rad(180.0) / 60.0
		camera._auto_orient(Vector3(-sin(turning), 0.0, -cos(turning)) * 4.0, 1.0 / 60.0)
	var slow_lag := rad_to_deg(absf(wrapf(turning - camera._yaw, -PI, PI)))
	_check(slow_lag < 30.0, "and within 30° of a slow, tight turn (%.0f°)" % slow_lag)
	var behind: Array[float] = []
	for touch_mode in [false, true]:
		camera.touch_mode = touch_mode
		camera._yaw = 0.0
		camera._away_for = 0.0
		camera._free_look_left = 0.0
		for i in 150:
			camera._auto_orient(Vector3(0.0, 0.0, 20.0), 1.0 / 60.0)
		behind.append(rad_to_deg(absf(wrapf(PI - camera._yaw, -PI, PI))))
	_check(behind[0] > 170.0 and behind[1] < 20.0,
		"rolling back the way it came, the touch camera turns round to it within 2.5 s (%.0f° off; desktop %.0f°, as before)" % [behind[1], behind[0]])
	world.free()


## A thumb resting on the look side (on the jump button's edge, say) trembles
## a pixel or two: that turns nothing that matters and doesn't stop the camera
## swinging behind the ball. A real drag does take the view, and hands it back
## shortly after the thumb stops.
func _test_a_resting_thumb_doesnt_hold_the_camera() -> void:
	var main := _start_main_with_input()
	var touch: TouchControls = main.get_node("TouchControls")
	var camera: FollowCamera = main.get_node("FollowCamera")
	await _ticks(2)
	var at := Vector2(1200, 400)
	_touch(0, at)
	await _frames(1)
	_check(camera.touch_mode, "with the touch controls up the camera follows the travel the touch way")
	var yaw := camera._yaw
	for i in 30:
		var wobble := 1.0 if i % 2 == 0 else -1.0
		_touch_drag(0, at + Vector2(1.0 if i % 2 == 0 else 0.0, 0.0), Vector2(wobble, 0.0))
		await _frames(1)
	_check(camera._free_look_left == 0.0 and absf(rad_to_deg(camera._yaw - yaw)) < 0.5,
		"a resting thumb's tremor neither holds the view nor turns it (%.2f°)" % rad_to_deg(camera._yaw - yaw))
	_touch_drag(0, at + Vector2(60, 0), Vector2(59, 0))
	await _frames(1)
	_check(absf(rad_to_deg(yaw - camera._yaw)) > 10.0 and camera._free_look_left > 0.0 and camera._free_look_left <= touch.look_hold,
		"a real drag turns it, and holds it %.1f s at most once the thumb stops" % touch.look_hold)
	_touch(0, at + Vector2(60, 0), false)
	await _frames(1)
	# A thumb landing on the look side and shifting a little (rolling off the
	# jump button, say) isn't a drag yet: the view stays the camera's.
	camera._free_look_left = 0.0
	var landed := Vector2(1100, 450)
	var before := camera._yaw
	_touch(1, landed)
	_touch_drag(1, landed + Vector2(15, 0), Vector2(15, 0))
	await _frames(1)
	_check(camera._yaw == before and camera._free_look_left == 0.0,
		"a thumb shifting less than %d px on the look side doesn't take the view" % touch.look_start)
	_touch(1, landed + Vector2(15, 0), false)
	await _frames(1)
	# A browser also reports a finger's moves as the mouse's, the first finger
	# holding its button: steering with the stick then looked like a mouse
	# dragging the view, and the camera stopped following the ball through
	# turns. With the touch controls up, a mouse drag doesn't take the view.
	var finger_as_mouse := InputEventMouseMotion.new()
	finger_as_mouse.relative = Vector2(40, 0)
	finger_as_mouse.button_mask = MOUSE_BUTTON_MASK_LEFT
	camera._free_look_left = 0.0
	var steady := camera._yaw
	camera._unhandled_input(finger_as_mouse)
	_check(camera._yaw == steady and camera._free_look_left == 0.0,
		"with the touch controls up, a finger reported as a mouse drag neither turns nor holds the view")
	camera.touch_mode = false
	camera._unhandled_input(finger_as_mouse)
	_check(camera._yaw != steady and camera._free_look_left > 0.0, "a real mouse drag on a desktop still looks around")
	camera.touch_mode = true
	main.free()

