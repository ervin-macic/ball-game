extends SceneTree
## Headless checks for the ball controller, the race flow and the test track.
##
## Run from the project folder (fixed fps keeps physics deterministic):
##   godot --headless --fixed-fps 120 --script res://tests/run_tests.gd
## Add `-- --verbose` for a per-segment speed table of the autopilot lap.
## Exits with code 1 if any check fails.

const BALL_SCENE := preload("res://scenes/ball.tscn")
const MAIN_SCENE := preload("res://scenes/main.tscn")
const Autopilot := preload("res://tests/autopilot.gd")

const TICK := 1.0 / 120.0

var _failures: Array[String] = []
var _check_count := 0
var _verbose := false


func _initialize() -> void:
	_verbose = OS.get_cmdline_user_args().has("--verbose")
	_run.call_deferred()


func _run() -> void:
	await _test_resting_ball_is_grounded_with_upward_normal()
	await _test_full_input_reaches_drive_speed_and_holds_it()
	await _test_released_input_keeps_momentum()
	await _test_opposing_input_brakes_harder_than_it_accelerates()
	await _test_steering_above_drive_speed_turns_without_adding_speed()
	await _test_friction_is_grippy_when_slow_and_slick_when_fast()
	await _test_grounded_damping_kills_drilling_spin_but_not_rolling()
	await _test_held_jump_reaches_expected_height()
	await _test_tapped_jump_is_lower_than_held_jump()
	await _test_coyote_time_allows_a_late_jump_off_a_ledge()
	await _test_jump_after_coyote_time_is_ignored()
	await _test_no_second_jump_in_the_air()
	await _test_landing_keeps_horizontal_speed()
	await _test_coasting_through_a_loop_keeps_its_momentum()
	await _test_rolling_never_climbs_higher_than_its_energy_allows()
	await _test_swinging_in_a_valley_never_gains_height()
	await _test_camera_starts_behind_the_ball_on_restart()
	await _test_camera_swings_behind_the_direction_of_travel()
	await _test_camera_pulls_in_when_a_wall_blocks_the_view()
	await _test_timer_waits_for_first_input()
	await _test_restart_returns_ball_to_spawn_and_clears_timer()
	await _test_falling_off_the_track_waits_for_restart()
	await _test_autopilot_finishes_test_track_through_the_loop()
	await _test_game_store_round_trips_documents()
	await _test_run_records_rank_every_run_and_keep_the_best_ghost()
	await _test_ghost_round_trips_through_its_saved_form()
	await _test_settings_apply_to_camera_and_ghost()
	await _test_pause_menu_pauses_the_game_and_resumes_it()
	await _test_community_board_is_unavailable_outside_mobius()
	await _test_community_board_sends_runs_and_shows_the_ranking()
	await _test_levels_switch_with_their_own_records_and_ball()
	await _test_props_are_solid_and_the_ball_bounces_off_them()
	await _test_black_ice_is_slippery()
	await _test_the_beach_wave_carries_the_ball()
	await _test_a_jump_break_needs_a_jump()
	await _test_a_swinging_weight_knocks_the_ball_aside()
	await _test_a_corkscrew_needs_speed()
	await _test_a_vent_blasts_the_ball_skyward()
	await _test_the_pond_slows_waders_and_the_pads_bounce()
	await _test_a_party_starts_everyone_together_and_reports_the_finish()
	await _test_the_ball_brakes_to_a_stop_after_the_finish()
	await _test_a_hole_in_the_road_drops_the_ball_through()
	await _test_rolling_barrels_knock_the_ball_back()
	await _test_forest_walls_keep_ground_riders_off_the_course()
	await _test_a_loading_screen_covers_a_level_change()
	await _test_the_camera_turns_smoothly_through_the_loop()
	await _test_driving_cannot_climb_a_wall()
	await _test_the_game_sleeps_while_hidden()
	for level_id in ["beach", "jungle", "winter"]:
		await _test_autopilot_finishes_level(level_id)
		await _test_autopilot_finishes_level(level_id, true)

	print("\n%d checks, %d failed" % [_check_count, _failures.size()])
	for failure in _failures:
		print("  FAIL ", failure)
	quit(1 if _failures.size() > 0 else 0)


# --- Ball controller ---------------------------------------------------------

func _test_resting_ball_is_grounded_with_upward_normal() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(60)
	_check(ball.is_grounded(), "resting ball is grounded")
	_check(ball.get_surface_up().dot(Vector3.UP) > 0.99, "ground normal points up (got %s)" % ball.get_surface_up())
	_check(absf(ball.global_position.y - ball.radius) < 0.05, "ball rests on the surface (y=%.3f)" % ball.global_position.y)
	world.free()


func _test_full_input_reaches_drive_speed_and_holds_it() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	var time_to_20 := -1.0
	for i in 600:
		ball.drive(Vector3.FORWARD, false, false)
		await physics_frame
		if time_to_20 < 0.0 and ball.linear_velocity.length() >= 20.0:
			time_to_20 = i * TICK
	var speed := ball.linear_velocity.length()
	_info("0-20 m/s in %.2f s, speed after 5 s: %.2f m/s" % [time_to_20, speed])
	_check(speed > ball.max_drive_speed * 0.9 and speed < ball.max_drive_speed * 1.03,
			"full input settles near max_drive_speed (%.2f vs %.2f)" % [speed, ball.max_drive_speed])
	world.free()


func _test_released_input_keeps_momentum() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _drive_for(ball, Vector3.FORWARD, 4.0)
	var before := ball.linear_velocity.length()
	await _ticks(240)
	var after := ball.linear_velocity.length()
	_info("coast: %.2f -> %.2f m/s over 2 s" % [before, after])
	_check(after > before * 0.85, "coasting 2 s keeps >85%% of speed (%.1f%%)" % (100.0 * after / before))
	world.free()


func _test_opposing_input_brakes_harder_than_it_accelerates() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _drive_for(ball, Vector3.FORWARD, 4.0)
	var start_speed := ball.linear_velocity.length()
	var ticks := 0
	while ball.linear_velocity.dot(Vector3.FORWARD) > 0.0 and ticks < 1200:
		ball.drive(Vector3.BACK, false, false)
		await physics_frame
		ticks += 1
	var braking := start_speed / (ticks * TICK)
	_info("braking from %.1f m/s took %.2f s (%.1f m/s²)" % [start_speed, ticks * TICK, braking])
	_check(braking > ball.drive_acceleration, "braking decelerates faster than drive accelerates (%.1f m/s²)" % braking)
	world.free()


func _test_steering_above_drive_speed_turns_without_adding_speed() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(10)
	var fast := ball.max_drive_speed * 1.3
	ball.linear_velocity = Vector3.FORWARD * fast
	ball.angular_velocity = Vector3.UP.cross(ball.linear_velocity) / ball.radius
	await _ticks(2)
	var entry := ball.linear_velocity.length()
	await _drive_for(ball, Vector3.LEFT, 1.0)
	var velocity := ball.linear_velocity
	var turned := rad_to_deg(Vector3.FORWARD.angle_to(Vector3(velocity.x, 0.0, velocity.z)))
	_info("steering at %.1f m/s: turned %.1f° in 1 s, speed now %.1f" % [entry, turned, velocity.length()])
	_check(velocity.length() < entry * 1.02, "steering above max_drive_speed adds no speed")
	_check(turned > 20.0, "steering above max_drive_speed still turns (%.1f°)" % turned)
	world.free()


func _test_friction_is_grippy_when_slow_and_slick_when_fast() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(30)
	var material := ball.physics_material_override
	_check(is_equal_approx(material.friction, ball.friction_at_low_speed) and material.rough,
			"rough, high friction at rest (%.2f)" % material.friction)
	await _drive_for(ball, Vector3.FORWARD, 5.0)
	_check(absf(material.friction - ball.friction_at_high_speed) < 0.02,
			"low friction at speed (%.2f at %.1f m/s)" % [material.friction, ball.linear_velocity.length()])
	world.free()


func _test_grounded_damping_kills_drilling_spin_but_not_rolling() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _drive_for(ball, Vector3.FORWARD, 2.0)
	var speed := ball.linear_velocity.length()
	ball.angular_velocity += Vector3.UP * 40.0
	await _ticks(60)
	var drilling := absf(ball.angular_velocity.dot(Vector3.UP))
	var rolling := ball.angular_velocity.length() * ball.radius
	_info("after 0.5 s: drilling spin %.2f rad/s, rolling %.1f m/s, speed %.1f -> %.1f" % [drilling, rolling, speed, ball.linear_velocity.length()])
	_check(drilling < 1.0, "drilling spin damped out (%.2f rad/s)" % drilling)
	_check(ball.linear_velocity.length() > speed * 0.94, "rolling speed kept while damping spin")
	world.free()


func _test_held_jump_reaches_expected_height() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(30)
	var apex := await _jump_apex(ball, 0.6)
	var g := 9.8 * ball.gravity_scale
	var expected := ball.jump_speed * ball.jump_speed / (2.0 * g)
	_info("held jump apex %.2f m (expected %.2f)" % [apex, expected])
	_check(absf(apex - expected) < expected * 0.1, "held jump apex within 10%% of v²/2g")
	world.free()


func _test_tapped_jump_is_lower_than_held_jump() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(30)
	var apex := await _jump_apex(ball, 0.05)
	var full := ball.jump_speed * ball.jump_speed / (2.0 * 9.8 * ball.gravity_scale)
	_info("tapped jump apex %.2f m (held %.2f)" % [apex, full])
	_check(apex < full * 0.75, "a tapped jump is clearly lower than a held one")
	world.free()


func _test_coyote_time_allows_a_late_jump_off_a_ledge() -> void:
	var result := await _ledge_jump(0.5)
	_check(result > 2.0, "jump pressed shortly after leaving a ledge still fires (vy=%.2f)" % result)


func _test_jump_after_coyote_time_is_ignored() -> void:
	var result := await _ledge_jump(2.5)
	_check(result < 0.0, "jump pressed well after leaving a ledge is ignored (vy=%.2f)" % result)


func _test_no_second_jump_in_the_air() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	await _ticks(30)
	var jumps := [0]
	ball.jumped.connect(func() -> void: jumps[0] += 1)
	ball.drive(Vector3.ZERO, true, true)
	await _ticks(30)
	ball.drive(Vector3.ZERO, true, true)
	await _ticks(10)
	_check(jumps[0] == 1, "only one jump until landing (got %d)" % jumps[0])
	world.free()


func _test_landing_keeps_horizontal_speed() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world, Vector3(0, 4, 0))
	ball.linear_velocity = Vector3.FORWARD * 20.0
	await _ticks(2)
	var before := 0.0
	while not ball.is_grounded():
		before = Vector2(ball.linear_velocity.x, ball.linear_velocity.z).length()
		await physics_frame
	await _ticks(30)
	var after := Vector2(ball.linear_velocity.x, ball.linear_velocity.z).length()
	_info("landing: horizontal %.2f -> %.2f m/s" % [before, after])
	_check(after > before * 0.95, "touchdown keeps >95%% of horizontal speed (%.1f%%)" % (100.0 * after / before))
	world.free()


func _test_coasting_through_a_loop_keeps_its_momentum() -> void:
	var loop := LoopSegment.new()
	var track := _test_track([_section(40.0), loop, _section(80.0)])
	var ball := _spawn_ball(track, _on_track(track, 30.0))
	await _ticks(1)
	_launch(ball, track, 30.0, 30.0)
	var exit_distance := 40.0 + TAU * loop.radius + 20.0
	var exit_speed := -1.0
	for i in 480:
		ball.drive(Vector3.ZERO, false, false)
		await physics_frame
		if exit_speed < 0.0 and track.path.distances[track.path.nearest_index(ball.global_position)] > exit_distance:
			exit_speed = ball.linear_velocity.length()
	var damping_only := 30.0 * exp(-ball.ground_linear_damp * 2.2)
	_info("coasting loop: in at 30.0 m/s, out at %.1f m/s (rolling resistance alone would leave %.1f)" % [exit_speed, damping_only])
	_check(exit_speed > damping_only * 0.95, "a ball coasting through the loop loses little beyond rolling resistance")
	track.get_parent().free()


func _test_rolling_never_climbs_higher_than_its_energy_allows() -> void:
	var climb := _section(30.0)
	climb.end_pitch = 25.0
	var ramp := _section(120.0)
	ramp.end_pitch = 25.0
	var track := _test_track([_section(40.0), climb, ramp])
	var ball := _spawn_ball(track, _on_track(track, 20.0))
	ball.ground_linear_damp = 0.0 # isolate the solver: no intentional rolling resistance
	await _ticks(1)
	_launch(ball, track, 20.0, 25.0)
	var start_height := ball.global_position.y
	var peak := start_height
	for i in 900: # a rolling ball needs about 4.2 s to stop on this ramp
		ball.drive(Vector3.ZERO, false, false)
		await physics_frame
		peak = maxf(peak, ball.global_position.y)
	var lossless := ROLLING_ENERGY * 25.0 * 25.0 / (9.8 * ball.gravity_scale)
	_info("coasting climb: rose %.2f m (lossless rolling %.2f m)" % [peak - start_height, lossless])
	_check(peak - start_height <= lossless + 0.05, "momentum refund never lifts the ball above its energy")
	_check(peak - start_height > lossless * 0.9, "almost all the energy turns into height on a climb")
	track.get_parent().free()


func _test_swinging_in_a_valley_never_gains_height() -> void:
	var down := _section(25.0)
	down.end_pitch = -30.0
	var bottom := _section(30.0)
	bottom.end_pitch = 30.0
	var up := _section(40.0)
	up.end_pitch = 30.0
	var track := _test_track([_section(5.0), down, _section(20.0, -30.0), bottom, up])
	var ball := _spawn_ball(track, _on_track(track, 12.0))
	var release_height := ball.global_position.y
	var highest_after_first_swing := -INF
	var crossed_bottom := false
	for i in 1200:
		ball.drive(Vector3.ZERO, false, false)
		await physics_frame
		if ball.global_position.y < release_height - 5.0:
			crossed_bottom = true
		if crossed_bottom:
			highest_after_first_swing = maxf(highest_after_first_swing, ball.global_position.y)
	_info("valley: released at %.2f m, highest later swing %.2f m" % [release_height, highest_after_first_swing])
	_check(crossed_bottom and highest_after_first_swing <= release_height + 0.05, "swinging back and forth never gains height")
	track.get_parent().free()


# --- Camera ------------------------------------------------------------------

func _test_camera_starts_behind_the_ball_on_restart() -> void:
	var main := _start_main()
	var camera: FollowCamera = main.get_node("FollowCamera")
	var ball: RollingBall = main.get_node("Ball")
	var spawn: Node3D = (main.get_node("RaceManager") as RaceManager).track.spawn_marker
	await _ticks(10)
	var to_ball := ball.global_position - camera.global_position
	var spawn_forward := -spawn.global_transform.basis.z
	_check(to_ball.dot(spawn_forward) > 0.0, "camera starts behind the ball")
	_check((-camera.global_transform.basis.z).dot(to_ball.normalized()) > 0.95, "camera looks at the ball")
	main.free()


func _test_camera_swings_behind_the_direction_of_travel() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	var camera := _follow_camera(world, ball)
	await _ticks(5)
	var turn_toward := Vector3.RIGHT
	await _drive_for(ball, turn_toward, 3.0)
	var forward := -camera.global_transform.basis.z
	forward.y = 0.0
	_info("camera forward after rolling right for 3 s: %s" % forward.normalized())
	_check(forward.normalized().dot(turn_toward) > 0.9, "camera swings behind the direction of travel")
	world.free()


func _test_camera_pulls_in_when_a_wall_blocks_the_view() -> void:
	var world := _flat_world()
	var ball := _spawn_ball(world)
	var camera := _follow_camera(world, ball)
	var wall := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(20.0, 20.0, 0.5)
	shape.shape = box
	wall.add_child(shape)
	wall.position = Vector3(0.0, 5.0, 3.0) # between the ball and where the camera wants to be
	world.add_child(wall)
	await _ticks(30)
	var camera_z := camera.global_position.z
	_info("wall face at z=2.75, camera at z=%.2f, %.2f m from the ball" % [camera_z, camera.global_position.distance_to(ball.global_position)])
	_check(camera_z < 2.75, "camera stays on the ball's side of a wall behind it")
	world.free()


# --- Race flow ---------------------------------------------------------------

func _test_timer_waits_for_first_input() -> void:
	var main := _start_main()
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	await _ticks(90)
	_check(race.state == RaceManager.State.READY and race.race_time == 0.0, "clock waits on the start line without input")
	await _drive_for(ball, Vector3.FORWARD, 1.0)
	_check(race.state == RaceManager.State.RUNNING, "first input starts the run")
	_check(absf(race.race_time - 1.0) < 0.05, "clock counts from the first input (%.3f s)" % race.race_time)
	main.free()


func _test_restart_returns_ball_to_spawn_and_clears_timer() -> void:
	var main := _start_main()
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var track: TrackBuilder = (main.get_node("RaceManager") as RaceManager).track
	await _drive_for(ball, Vector3.FORWARD, 2.0)
	race.restart()
	await _ticks(2)
	var spawn := track.spawn_marker.global_position
	_check(race.state == RaceManager.State.READY and race.race_time == 0.0, "restart clears the clock")
	_check(ball.global_position.distance_to(spawn) < 0.1, "restart puts the ball back on the spawn point")
	_check(ball.linear_velocity.length() < 0.5, "restart stops the ball")
	main.free()


func _test_falling_off_the_track_waits_for_restart() -> void:
	var main := _start_main()
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var track: TrackBuilder = race.track
	var hud: RaceHud = main.get_node("HUD")
	await _drive_for(ball, Vector3.FORWARD, 0.5)
	# Drop the ball well beside the track, over the test level's floor.
	var frame := track.world_frame_at(200.0)
	ball.respawn(Transform3D(Basis.IDENTITY, frame.origin + frame.basis.x * 60.0 + Vector3.UP * 3.0))
	await _ticks(roundi(4.0 / TICK))
	_check(race.state == RaceManager.State.RUNNING, "falling off the track does not restart the run by itself")
	_check(ball.global_position.y > -71.0, "the floor catches a ball that falls off (no void)")
	_check(race.off_track and hud._status.visible and hud._status.text.contains("reset"), "the HUD offers a reset when off the track")
	# Fired at the edge of the world, the ball stays inside the border.
	var bounds: LevelBounds = race.track.get_parent().get_node("Bounds")
	var area := bounds._area()
	ball.respawn(Transform3D(Basis.IDENTITY, Vector3(area.end.x - 20.0, -69.0, area.get_center().z)))
	ball.linear_velocity = Vector3(60.0, 0.0, 0.0)
	await _ticks(roundi(2.0 / TICK))
	_check(ball.global_position.x < area.end.x + 1.0 and ball.global_position.y > -71.0, "a hard border keeps the ball on the map")
	Input.action_press("restart")
	await _ticks(2)
	Input.action_release("restart")
	_check(race.state == RaceManager.State.READY and ball.global_position.distance_to(track.spawn_marker.global_position) < 0.5, "restart puts the ball back on the start line")
	main.free()


func _test_autopilot_finishes_test_track_through_the_loop() -> void:
	var main := _start_main()
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var track: TrackBuilder = (main.get_node("RaceManager") as RaceManager).track
	var pilot := Autopilot.new()
	pilot.ball = ball
	pilot.track = track
	main.add_child(pilot)

	var camera: FollowCamera = main.get_node("FollowCamera")
	var loop_range := _segment_range(track, LoopSegment)
	var loop_top_reached := false
	var camera_rolled_in_loop := false
	var loop_min_speed := INF
	var max_speed := 0.0
	var resets := [0]
	race.state_changed.connect(func(state: RaceManager.State) -> void:
		if state == RaceManager.State.READY:
			resets[0] += 1)
	var table := {}
	var ticks := 0
	while race.state != RaceManager.State.FINISHED and ticks < 120 * 120 and resets[0] == 0:
		await physics_frame
		ticks += 1
		var d := pilot.current_distance()
		var speed := ball.linear_velocity.length()
		max_speed = maxf(max_speed, speed)
		if d >= loop_range.x and d <= loop_range.y:
			loop_min_speed = minf(loop_min_speed, speed)
			var frame := track.world_frame_at(d)
			if frame.basis.y.dot(Vector3.UP) < -0.9:
				loop_top_reached = true
				camera_rolled_in_loop = camera_rolled_in_loop or camera.global_transform.basis.y.dot(Vector3.UP) < 0.0
		_record_segment_speed(table, track, d, speed)

	if _verbose or race.state != RaceManager.State.FINISHED:
		_print_segment_table(track, table)
	_info("autopilot: %s in %.3f s, progress %.0f/%.0f m, top speed %.1f m/s, slowest in loop %.1f m/s"
			% [RaceManager.State.keys()[race.state], race.race_time, pilot.progress, track.path.total_length(), max_speed, loop_min_speed])
	_check(resets[0] == 0, "autopilot never fell off")
	_check(loop_top_reached, "autopilot went over the top of the loop")
	_check(camera_rolled_in_loop, "camera rolls with the track over the top of the loop")
	_check(race.state == RaceManager.State.FINISHED, "autopilot crossed the finish line")
	_check(race.race_time > 5.0 and race.race_time < 120.0, "finish time is plausible (%.3f s)" % race.race_time)

	# The lap became the best run, with a ghost. The autopilot is deterministic, so a
	# second lap races its own ghost and the live split should stay near zero.
	var ghost := race.records.best_ghost
	_check(ghost != null and absf(ghost.duration - race.race_time) < 0.001, "the best lap is kept as a ghost")
	_check(ghost != null and ghost.pose_at(ghost.duration).origin.distance_to(ball.global_position) < 40.0, "the ghost ends at the finish")
	var dump := OS.get_environment("BALL_GAME_DUMP_GHOST") # the leaderboard service's tests replay it
	if ghost and not dump.is_empty():
		FileAccess.open(dump, FileAccess.WRITE).store_string(JSON.stringify(ghost.to_dict()))
	var first_lap := race.race_time
	race.restart()
	pilot.reset()
	var worst_split := 0.0
	var split_seen := false
	ticks = 0
	while race.state != RaceManager.State.FINISHED and ticks < 120 * 120:
		await physics_frame
		ticks += 1
		if not is_nan(race.split_delta):
			split_seen = true
			worst_split = maxf(worst_split, absf(race.split_delta))
	_info("second lap %.3f s against ghost %.3f s, largest live split %.3f s" % [race.race_time, first_lap, worst_split])
	_check(split_seen and worst_split < 0.25, "a repeat of the best lap stays level with its ghost")
	_check(race.records.runs.size() == 2 and race.last_finish.get("total") == 2, "every finished run is recorded")
	main.free()


func _test_game_store_round_trips_documents() -> void:
	var key := "test_store_document.json"
	GameStore.write(key, {"a": 1.5, "list": [1, 2, 3]})
	var back: Variant = GameStore.read(key)
	_check(back is Dictionary and back["a"] == 1.5 and back["list"].size() == 3, "stored documents read back intact")
	GameStore.remove(key)
	_check(GameStore.read(key) == null, "removed documents are gone")


func _test_run_records_rank_every_run_and_keep_the_best_ghost() -> void:
	var records := RunRecords.new("unit_test", false)
	var slow := GhostRun.new()
	var fast := GhostRun.new()
	for ghost in [slow, fast]:
		ghost.add_sample(Vector3.ZERO, Quaternion.IDENTITY, 0.0)
		ghost.add_sample(Vector3.ONE, Quaternion.IDENTITY, 1.0)
	slow.duration = 20.0
	fast.duration = 18.5
	var first := records.add_run(20.0, slow)
	var second := records.add_run(18.5, fast)
	var third := records.add_run(25.0, GhostRun.new())
	_check(first["is_best"] and second["is_best"] and not third["is_best"], "only faster runs become the best")
	_check(third["rank"] == 3 and third["total"] == 3 and records.best_time == 18.5, "runs are ranked among all runs")
	_check(records.best_ghost == fast, "the ghost of the best run is kept")
	_check(records.top(2).map(func(run: Dictionary) -> float: return run["t"]) == [18.5, 20.0], "leaderboard lists fastest first")
	var older := RunRecords.new("unit_test_legacy", false)
	older.best_time = 15.0 # a best from before ghosts were recorded
	older.add_run(19.0, slow)
	_check(older.best_ghost == slow and older.best_time == 15.0, "a slower run still becomes the ghost when the best has no recording")


func _test_ghost_round_trips_through_its_saved_form() -> void:
	var ghost := GhostRun.new()
	for i in 10:
		ghost.add_sample(Vector3(i, 0.5, -2.0 * i), Quaternion(Vector3.RIGHT, i * 0.3), i * 2.0)
	ghost.duration = 9.0 / GhostRun.SAMPLE_HZ
	var copy := GhostRun.from_dict(JSON.parse_string(JSON.stringify(ghost.to_dict())))
	var mid := ghost.duration * 0.5
	_check(copy != null and copy.pose_at(mid).origin.distance_to(ghost.pose_at(mid).origin) < 0.01, "a saved ghost replays the same path")
	_check(copy != null and absf(copy.time_at_progress(7.0) - ghost.time_at_progress(7.0)) < 0.01, "a saved ghost keeps its split points")


func _test_settings_apply_to_camera_and_ghost() -> void:
	var main := _start_main()
	var settings: GameSettings = main.get_node("Settings")
	var camera: FollowCamera = main.get_node("FollowCamera")
	var ghost: GhostBall = main.get_node("GhostBall")
	await _ticks(2)
	settings.set_value("camera_distance", 10.0)
	settings.set_value("fov", 80.0)
	settings.set_value("speed_fov", 5.0)
	settings.set_value("ghost", false)
	_check(camera.distance == 10.0 and camera.base_fov == 80.0 and camera.max_fov == 85.0, "camera settings take effect")
	_check(not ghost.enabled, "the ghost can be switched off")
	settings.reset_to_defaults()
	_check(camera.distance == 6.5 and ghost.enabled, "settings reset to defaults")
	main.free()


func _test_pause_menu_pauses_the_game_and_resumes_it() -> void:
	var main := _start_main()
	var menu: PauseMenu = main.get_node("PauseMenu")
	await _ticks(2)
	menu.open()
	_check(paused and menu.is_open(), "the menu pauses the game")
	menu.close()
	_check(not paused and not menu.is_open(), "closing the menu resumes the game")
	main.free()


func _test_community_board_is_unavailable_outside_mobius() -> void:
	var main := _start_main()
	await _ticks(2)
	var community: CommunityBoard = main.get_node("Community")
	var menu: PauseMenu = main.get_node("PauseMenu")
	menu.open()
	_check(not community.is_available() and community.status == "unavailable", "outside Möbius the community board is off")
	_check(menu._community_footer.text.contains("Möbius"), "the menu says where the community board works")
	menu.close()
	main.free()


func _test_community_board_sends_runs_and_shows_the_ranking() -> void:
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	var fake := FakeCommunityHost.new()
	main.get_node("Community").host = fake
	root.add_child(main)
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var hud: RaceHud = main.get_node("HUD")
	var menu: PauseMenu = main.get_node("PauseMenu")
	# Records were already opened without saving; this only lets the run be sent (to the fake).
	race.save_records = true
	var ghost := GhostRun.new()
	ghost.add_sample(Vector3.ZERO, Quaternion.IDENTITY, 0.0)
	ghost.add_sample(Vector3.ONE, Quaternion.IDENTITY, 1.0)
	ghost.duration = 19.5
	race.last_recording = ghost
	race.state = RaceManager.State.FINISHED
	race.finished.emit(19.5, true)
	var sent: Dictionary = fake.sent[0] if fake.sent.size() == 1 else {}
	var sent_ghost: Variant = JSON.parse_string(sent.get("ghost", "null"))
	_check(sent.get("track") == "test_track" and sent.get("time") == 19.5 and sent_ghost is Dictionary
		and sent_ghost.has("p") and str(sent.get("id", "")).length() == 32, "a finished run is sent with its recording")
	fake.answer({"status": "ready", "board": {"top": [
			{"rank": 1, "player": "ana", "time": 18.2, "runs": 7},
			{"rank": 2, "player": "me", "time": 19.5, "runs": 1}],
			"runs": 8, "players": 2, "player": "me", "you": {"rank": 2, "best": 19.5, "runs": 1}},
		"submission": {"id": sent.get("id"), "status": "done", "result": {"rank": 2, "players": 2}}})
	await _frames(40)
	_check(hud._status.text.contains("Community  #2 of 2 players"), "the finish banner shows the community ranking")
	menu.open()
	await _frames(2)
	_check(menu._community_rows.get_child_count() == 2 and menu._community_footer.text.contains("#2"),
		"the menu lists the community's fastest players")
	menu.close()
	main.free()


func _load_level(main: Node, id: String) -> LevelLoader:
	var loader: LevelLoader = main.get_node("LevelLoader")
	loader.load_level(id)
	while loader.level_id != id:
		await process_frame
	await _ticks(2)
	return loader


func _test_levels_switch_with_their_own_records_and_ball() -> void:
	var main := _start_main()
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var loader: LevelLoader = main.get_node("LevelLoader")
	_check(loader.level_id == "test_track" and race.track_id == "test_track", "the game starts on the test track")
	var ids := LevelCatalog.available().map(func(entry: Dictionary) -> String: return entry["id"])
	_check(ids == ["test_track", "beach", "jungle", "winter"], "the menu lists the test track and three themed levels")
	race.records.add_run(30.0, null)
	await _load_level(main, "winter")
	_check(race.track_id == LevelCatalog.records_id("winter") and race.records.runs.is_empty() and not is_finite(race.best_time), "a level has its own records")
	_check(race.state == RaceManager.State.READY and race.ball.global_position.distance_to(race.track.spawn_marker.global_position) < 0.5, "switching level puts the ball on its start line")
	var ball_mesh: MeshInstance3D = race.ball.find_children("*", "MeshInstance3D", true, false)[0]
	_check(ball_mesh.material_override == loader.level.ball_material, "the level dresses the ball")
	await _load_level(main, "test_track")
	# Tests never save, so records can't survive a switch here; the game reloads them from storage.
	_check(race.records.track_id == "test_track" and race.track_id == "test_track", "switching back uses the test track's records")
	main.free()


func _test_props_are_solid_and_the_ball_bounces_off_them() -> void:
	var main := _start_main()
	await _load_level(main, "jungle")
	var race: RaceManager = main.get_node("RaceManager")
	var ball := race.ball
	# A tree stands 6 m right of the fern run at 1087 m (jungle_level.gd: FERNS_FROM + 42).
	var frame := race.track.world_frame_at(1087.0)
	var right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
	ball.respawn(Transform3D(Basis.IDENTITY, frame.origin + right * 2.0 + Vector3.UP * 0.6))
	await _ticks(10)
	ball.linear_velocity = right * 12.0
	var bounced := false
	for i in 90:
		await physics_frame
		if ball.linear_velocity.dot(right) < -1.0:
			bounced = true
			break
	_check(bounced, "the ball bounces off a tree trunk")
	main.free()


func _test_the_beach_wave_carries_the_ball() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "beach")
	var race: RaceManager = main.get_node("RaceManager")
	var wave: RideableWave = loader.level.get_node("Wave")
	var ball := race.ball
	var start := race.track.world_frame_at((wave.from_distance + wave.to_distance) * 0.5)
	ball.respawn(Transform3D(Basis.IDENTITY, start.origin + Vector3.UP * 0.6))
	ball.control_started.emit() # the race clock (and so the waves) start now
	var highest := 0.0
	var inland := 0.0
	for i in roundi(wave.period / TICK):
		await physics_frame
		highest = maxf(highest, ball.global_position.y - start.origin.y)
		inland = maxf(inland, (ball.global_position - start.origin).dot(wave._inland))
	_info("a wave lifted a resting ball %.1f m and carried it %.1f m inland" % [highest, inland])
	_check(highest > 1.5 and inland > 3.0, "a wave rolls in across the beach and scoops the ball up its face")
	main.free()


func _test_black_ice_is_slippery() -> void:
	var main := _start_main()
	await _load_level(main, "winter")
	var race: RaceManager = main.get_node("RaceManager")
	var ball := race.ball
	var grips := []
	for d in [120.0, 290.0]: # ordinary ice run, then the black ice bend
		var frame := race.track.world_frame_at(d)
		ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
		await _ticks(10)
		var forward := -frame.basis.z
		var start_speed := ball.linear_velocity.dot(forward)
		for i in roundi(1.0 / TICK):
			ball.drive(forward, false, false)
			await physics_frame
		grips.append([ball.surface_grip, ball.linear_velocity.dot(forward) - start_speed])
	_info("grip %.2f gains %.1f m/s in 1 s; black ice grip %.2f gains %.1f m/s" % [grips[0][0], grips[0][1], grips[1][0], grips[1][1]])
	_check(grips[0][0] == 1.0 and grips[1][0] < 0.5, "the black ice bend is slippery underfoot")
	_check(grips[1][1] < grips[0][1] * 0.6, "on black ice the ball can't push off as hard")
	main.free()


func _test_autopilot_finishes_level(level_id: String, take_routes := false) -> void:
	Swinger.hold_still = true
	RollingBarrels.hold_still = true
	var main := _start_main()
	await _load_level(main, level_id)
	var race: RaceManager = main.get_node("RaceManager")
	var pilot := Autopilot.new()
	pilot.ball = race.ball
	pilot.track = race.track
	pilot.take_routes = take_routes
	main.add_child(pilot)
	var restarts := [0]
	race.state_changed.connect(func(state: RaceManager.State) -> void:
		if state == RaceManager.State.READY:
			restarts[0] += 1)
	var ticks := 0
	var left_track := -1.0
	while race.state != RaceManager.State.FINISHED and ticks < 120 * 120 and restarts[0] == 0:
		await physics_frame
		ticks += 1
		if race.off_track and left_track < 0.0:
			left_track = race.progress
	var line := "its alternative routes" if take_routes else "the main road"
	_info("%s autopilot on %s: %s in %.3f s" % [level_id, line, RaceManager.State.keys()[race.state], race.race_time])
	_check(race.state == RaceManager.State.FINISHED and restarts[0] == 0 and left_track < 0.0,
		"the autopilot finishes %s on %s without leaving the track%s" % [level_id, line, "" if left_track < 0.0 else " (left it at %.0f m)" % left_track])
	if take_routes:
		var routes := race.track.routes()
		_check(not routes.is_empty(), "%s has an alternative route" % level_id)
		for route in routes:
			var rode: float = pilot.ridden.get(route.name, 0.0)
			_check(rode >= route.length() * 0.4,
				"the autopilot rides %s's %s rather than the road beside it (%.0f of %.0f m)" % [level_id, route.name, rode, route.length()])
	main.free()
	Swinger.hold_still = false
	RollingBarrels.hold_still = false


## The beach corkscrew carries a ball through at racing speed but drops one
## that comes in too slow (there's nothing to hold it on at the top).
func _test_a_corkscrew_needs_speed() -> void:
	for speed in [16.0, 30.0]:
		Swinger.hold_still = true
		RollingBarrels.hold_still = true
		var main := _start_main()
		await _load_level(main, "beach")
		var race: RaceManager = main.get_node("RaceManager")
		var track := race.track
		var path := track.path
		var channel := -1
		for i in path.frames.size():
			if path.lips[i].x > 5.0:
				channel = i
				break
		var start := path.distances[channel] - 8.0
		var end := start
		for i in range(channel, path.frames.size()):
			if path.lips[i].x < 1.2:
				end = path.distances[i]
				break
		var frame := track.world_frame_at(start)
		var ball := race.ball
		ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.55))
		ball.control_started.emit()
		await physics_frame
		ball.linear_velocity = -frame.basis.z.normalized() * speed
		ball.angular_velocity = frame.basis.x.normalized() * (-speed / ball.radius)
		var hint := -1
		var through := false
		for i in roundi(4.0 / TICK):
			await physics_frame
			hint = path.nearest_index(track.to_local(ball.global_position), hint, 60)
			var at := track.global_transform * path.frames[hint]
			if (ball.global_position - at.origin).length() > 8.0:
				break
			if path.distances[hint] >= end:
				through = true
				break
		if speed < 20.0:
			_check(not through, "a ball entering the corkscrew at %.0f m/s falls off it" % speed)
		else:
			_check(through, "a ball entering the corkscrew at %.0f m/s rides through it" % speed)
		main.free()
		Swinger.hold_still = false
		RollingBarrels.hold_still = false


## Rolling onto the beach's steam vent throws the ball high into the air.
func _test_a_vent_blasts_the_ball_skyward() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "beach")
	var race: RaceManager = main.get_node("RaceManager")
	var vent: Vent = loader.level.get_node("Vent")
	var frame := race.track.world_frame_at(vent.at_distance - 8.0)
	var ball := race.ball
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
	ball.control_started.emit()
	await physics_frame
	ball.linear_velocity = -frame.basis.z.normalized() * 12.0
	var highest := 0.0
	for i in roundi(2.5 / TICK):
		await physics_frame
		highest = maxf(highest, ball.global_position.y - vent.global_position.y)
	_info("the vent threw a ball %.1f m up" % highest)
	_check(highest > 15.0, "the steam vent blasts the ball into the sky")
	main.free()


## In the forest's lily pond a ball wading through the water is dragged to a
## crawl, and a ball dropped onto a lily pad bounces back up.
func _test_the_pond_slows_waders_and_the_pads_bounce() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "jungle")
	var race: RaceManager = main.get_node("RaceManager")
	var pond: LilyPond = loader.level.get_node("LilyPond")
	var ball := race.ball
	# Wading: off to the side of the pads, at speed.
	var frame := race.track.world_frame_at((pond.from_distance + pond.to_distance) * 0.5 - 8.0)
	var aside := frame.basis.x.normalized() * 6.5
	ball.respawn(Transform3D(frame.basis, frame.origin + aside + Vector3.UP * 0.6))
	ball.control_started.emit()
	await physics_frame
	ball.linear_velocity = -frame.basis.z.normalized() * 25.0
	for i in roundi(1.0 / TICK):
		ball.drive(-frame.basis.z.normalized(), false, false)
		await physics_frame
	var wading := Vector2(ball.linear_velocity.x, ball.linear_velocity.z).length()
	_info("after a second in the pond a ball at 25 m/s (still driving) is down to %.1f m/s" % wading)
	_check(wading < 4.5, "the pond's water drags a wading ball to a crawl, even while it drives")
	_check(pond.has_node("Pad_2") and not pond.has_node("Pad_3"), "there are three lily pads")
	# Landing: drop it onto the first pad; it settles rather than springing off.
	var pad: Node3D = pond.get_node("Pad_0")
	ball.respawn(Transform3D(Basis.IDENTITY, pad.global_position + Vector3.UP * 4.0))
	var landed := false
	var rebound := 0.0
	for i in roundi(2.0 / TICK):
		await physics_frame
		var height := ball.global_position.y - pad.global_position.y
		if not landed and ball.linear_velocity.y > 0.5 and height < 1.5:
			landed = true
		if landed:
			rebound = maxf(rebound, height)
	_info("a ball dropped 4 m onto a lily pad bounced back %.1f m up" % rebound)
	_check(rebound < 1.5, "lily pads are not bouncy")
	_check(absf(ball.global_position.y - pad.global_position.y - 0.57) < 0.25, "a ball landing on a pad stays on it")
	main.free()


## A swinging weight across the track is solid and strong: a ball resting in
## its path is knocked well aside within one swing.
func _test_a_swinging_weight_knocks_the_ball_aside() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "winter")
	var race: RaceManager = main.get_node("RaceManager")
	var swingers := loader.level.find_children("Swinger_*", "Node3D", false, false)
	_check(swingers.size() >= 2, "winter has swinging weights across the track")
	if swingers.is_empty():
		main.free()
		return
	var swinger: Swinger = swingers[0]
	var frame := race.track.world_frame_at(swinger.at_distance)
	var ball := race.ball
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
	ball.control_started.emit() # the race (and the swinging) starts now
	var furthest := 0.0
	for i in roundi(swinger.period * 1.2 / TICK):
		await physics_frame
		var aside := (ball.global_position - frame.origin).dot(frame.basis.x)
		furthest = maxf(furthest, absf(aside))
	_info("a swinging bauble pushed a resting ball %.1f m aside" % furthest)
	_check(furthest > 2.0, "a swinging weight knocks a resting ball aside")
	main.free()


## A jump break is a real break: a ball that rolls at it without jumping drops
## in and can't carry on, and the same ball jumping gets across.
func _test_a_jump_break_needs_a_jump() -> void:
	for jumping in [false, true]:
		var main := _start_main()
		await _load_level(main, "beach")
		var race: RaceManager = main.get_node("RaceManager")
		var gap := race.track.path.jumps[0]
		var pilot := Autopilot.new()
		pilot.ball = race.ball
		pilot.track = race.track
		pilot.jumps = jumping
		main.add_child(pilot)
		var ticks := 0
		while race.progress < gap.y + 20.0 and not race.off_track and ticks < 120 * 30:
			await physics_frame
			ticks += 1
		if jumping:
			_check(race.progress >= gap.y + 20.0 and not race.off_track, "jumping carries the ball over the beach's first break (%.0f to %.0f m)" % [gap.x, gap.y])
		else:
			_check(race.off_track and race.progress < gap.y + 20.0, "without a jump the ball drops into the beach's first break (and can't carry on)")
		main.free()


## Stands in for the web page's window.ballGameCommunity.
class FakeCommunityHost:
	extends RefCounted
	var sent: Array[Dictionary] = []
	var _state := {"version": 0, "status": "idle"}

	func submit(track: String, time: float, ghost_json: String, request_id: String) -> void:
		sent.append({"track": track, "time": time, "ghost": ghost_json, "id": request_id})

	func refresh(_track: String) -> void:
		pass

	func state(_track: String) -> String:
		return JSON.stringify(_state)

	func answer(state: Dictionary) -> void:
		state["version"] = int(_state["version"]) + 1
		_state = state


# --- Helpers -----------------------------------------------------------------

func _frames(count: int) -> void:
	for i in count:
		await process_frame


## Kinetic energy of a rolling solid sphere is 0.7 m v², so a coasting climb can rise 0.7 v² / g.
const ROLLING_ENERGY := 0.7


func _section(length: float, pitch := 0.0) -> SectionSegment:
	var segment := SectionSegment.new()
	segment.length = length
	segment.end_pitch = pitch
	return segment


## A TrackBuilder with [param segments], inside a fresh world node.
func _test_track(segments: Array) -> TrackBuilder:
	var world := Node3D.new()
	root.add_child(world)
	var track := TrackBuilder.new()
	track.segments.assign(segments)
	world.add_child(track)
	return track


## Ball spawn point resting on the track centreline at [param distance].
func _on_track(track: TrackBuilder, distance: float) -> Vector3:
	var frame := track.world_frame_at(distance)
	return frame.origin + frame.basis.y * 0.5


## Sets the ball rolling along the track at [param speed] from [param distance].
func _launch(ball: RollingBall, track: TrackBuilder, distance: float, speed: float) -> void:
	var frame := track.world_frame_at(distance)
	ball.global_position = frame.origin + frame.basis.y * 0.5
	ball.linear_velocity = -frame.basis.z * speed
	ball.angular_velocity = frame.basis.y.cross(ball.linear_velocity) / ball.radius


func _flat_world(friction := 1.0) -> Node3D:
	var world := Node3D.new()
	root.add_child(world)
	var ground := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(600.0, 2.0, 600.0)
	shape.shape = box
	ground.add_child(shape)
	ground.position = Vector3(0.0, -1.0, 0.0)
	var material := PhysicsMaterial.new()
	material.friction = friction
	ground.physics_material_override = material
	world.add_child(ground)
	return world


func _spawn_ball(world: Node3D, at := Vector3(0.0, 0.5, 0.0)) -> RollingBall:
	var ball: RollingBall = BALL_SCENE.instantiate()
	world.add_child(ball)
	ball.respawn(Transform3D(Basis.IDENTITY, at))
	return ball


func _follow_camera(world: Node3D, ball: RollingBall) -> FollowCamera:
	var camera := FollowCamera.new()
	camera.ball = ball
	camera.capture_mouse_on_start = false
	world.add_child(camera)
	camera.snap_behind(ball.global_transform)
	return camera


func _start_main() -> Node:
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false # never touch the player's records
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	root.add_child(main)
	return main


func _ticks(count: int) -> void:
	for i in count:
		await physics_frame


func _drive_for(ball: RollingBall, direction: Vector3, seconds: float) -> void:
	for i in roundi(seconds / TICK):
		ball.drive(direction, false, false)
		await physics_frame


## Jumps from rest, holding the button for [param hold] seconds; returns the apex height gain.
func _jump_apex(ball: RollingBall, hold: float) -> float:
	var start_y := ball.global_position.y
	var apex := start_y
	for i in 240:
		var held := i * TICK < hold
		ball.drive(Vector3.ZERO, held, i == 0)
		await physics_frame
		apex = maxf(apex, ball.global_position.y)
	return apex - start_y


## Rolls off a ledge and presses jump [param coyote_fraction] × coyote_time after
## losing contact. Returns the vertical speed shortly after (positive = jumped).
func _ledge_jump(coyote_fraction: float) -> float:
	var world := Node3D.new()
	root.add_child(world)
	var ledge := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(20.0, 2.0, 20.0)
	shape.shape = box
	ledge.add_child(shape)
	ledge.position = Vector3(0.0, -1.0, 0.0) # top at y=0, edge at z=-10
	world.add_child(ledge)
	var ball := _spawn_ball(world, Vector3(0.0, 0.5, 5.0))
	await _ticks(20)
	ball.linear_velocity = Vector3.FORWARD * 5.0
	ball.angular_velocity = Vector3.UP.cross(ball.linear_velocity) / ball.radius
	var left_ground_at := -1
	var tick := 0
	while tick < 600:
		var since := (tick - left_ground_at) * TICK if left_ground_at >= 0 else 0.0
		var press := left_ground_at >= 0 and since >= ball.coyote_time * coyote_fraction
		ball.drive(Vector3.ZERO, press, press)
		await physics_frame
		tick += 1
		if left_ground_at < 0 and ball.global_position.z < -10.0:
			# Contact is lost once the centre passes the edge; measure from there.
			left_ground_at = tick
		if press:
			break
	await _ticks(3)
	var vertical := ball.linear_velocity.y
	world.free()
	return vertical


func _segment_range(track: TrackBuilder, kind: Script) -> Vector2:
	var ends := _segment_end_distances(track)
	var start := 0.0
	for i in track.segments.size():
		if track.segments[i] and track.segments[i].get_script() == kind:
			return Vector2(start, ends[i])
		start = ends[i]
	return Vector2(-1.0, -1.0)


func _segment_end_distances(track: TrackBuilder) -> PackedFloat32Array:
	var cursor := TrackCursor.new()
	var scratch := TrackPath.new()
	var ends := PackedFloat32Array()
	for segment in track.segments:
		if segment:
			segment.lay(cursor, scratch, track.max_spacing, deg_to_rad(track.max_step_angle))
		ends.append(cursor.distance)
	return ends


func _record_segment_speed(table: Dictionary, track: TrackBuilder, distance: float, speed: float) -> void:
	if not table.has("_ends"):
		table["_ends"] = _segment_end_distances(track)
	var ends: PackedFloat32Array = table["_ends"]
	var index: int = ends.bsearch(distance)
	if not table.has(index):
		table[index] = Vector3(speed, speed, speed) # entry, min, max
	var row: Vector3 = table[index]
	table[index] = Vector3(row.x, minf(row.y, speed), maxf(row.z, speed))


func _print_segment_table(track: TrackBuilder, table: Dictionary) -> void:
	print("   segment               entry    min    max  (m/s)")
	for i in track.segments.size():
		var name: String = track.segments[i].resource_name if track.segments[i] else "?"
		if table.has(i):
			var row: Vector3 = table[i]
			print("   %-20s %6.1f %6.1f %6.1f" % [name, row.x, row.y, row.z])
		else:
			print("   %-20s   (not reached)" % name)


func _check(condition: bool, description: String) -> void:
	_check_count += 1
	if condition:
		print("  ok   ", description)
	else:
		print("  FAIL ", description)
		_failures.append(description)


func _info(message: String) -> void:
	print("       ", message)


# --- Party -------------------------------------------------------------------

func _test_a_party_starts_everyone_together_and_reports_the_finish() -> void:
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	var fake := FakePartyHost.new()
	main.get_node("Party").host = fake
	root.add_child(main)
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var party: PartyClient = main.get_node("Party")
	var hud: RaceHud = main.get_node("HUD")
	var loader: LevelLoader = main.get_node("LevelLoader")
	var spawn := race.track.spawn_marker.global_position

	# The lobby: another player's ball shows up, solid because bumping is on.
	fake.remote = {"pid": "maja", "name": "Maja", "color": "#2ec4b6", "p": [spawn.x + 3.0, spawn.y, spawn.z], "q": [0, 0, 0, 1], "v": [0, 0, 0], "age": 0.05}
	fake.current = {"active": true, "phase": "lobby", "round": -1, "level": "", "collisions": true, "entrant": false}
	await _frames(3)
	var others := party.get_node("PartyBalls").get_children()
	_check(others.size() == 1 and (others[0] as RemoteBall).player_name == "Maja", "another player's ball is drawn")
	_check(ball.collision_mask & RemoteBall.LAYER != 0 and (others[0] as RemoteBall).collision_layer == RemoteBall.LAYER, "with bumping on, the balls collide")
	await _frames(10)
	_check(not fake.pose_calls.is_empty() and JSON.parse_string(fake.pose_calls[-1]).get("lv") == "test_track", "this ball's position is broadcast")

	# A level: back on the start line, locked, and reported as loaded.
	fake.current = {"active": true, "phase": "loading", "round": 0, "level": "test_track", "collisions": true, "entrant": true}
	await _frames(3)
	_check(fake.loaded_calls == [["test_track", 0]], "the level is reported as loaded once")
	_check(race.party_round and ball.locked and race.state == RaceManager.State.READY, "the ball waits on the start line")
	_check(hud._status.text == "Get ready…", "the HUD says to get ready")
	loader.load_level("beach")
	_check(loader.level_id == "test_track" and not loader.busy, "the menu can't switch away from the party's level")
	for i in 10:
		ball.drive(Vector3.FORWARD, false, true)
		await physics_frame
	_check(race.state == RaceManager.State.READY, "input can't jump the start")

	# The countdown, then the shared start; a late start counts the time already gone.
	fake.current = {"active": true, "phase": "racing", "round": 0, "level": "test_track", "collisions": true, "entrant": true, "go_in": 2.0}
	await _frames(3)
	_check(race.state == RaceManager.State.READY, "nothing moves during the countdown")
	fake.current["go_in"] = -0.5
	await _frames(1)
	_check(race.state == RaceManager.State.RUNNING and race.race_time >= 0.5 and not ball.locked, "the clock starts at the shared start, counting a late start")
	await _ticks(30)
	var before := race.race_time
	race.restart()
	_check(race.state == RaceManager.State.RUNNING and race.race_time >= before, "restarting mid-level keeps the clock running")
	_check(ball.global_position.distance_to(spawn) < 1.0, "restarting puts the ball back on the start line")

	# The finish is reported to the party, and no personal record comes of it.
	var runs_before := race.records.runs.size()
	race._finish(race.race_time)
	await _frames(2)
	_check(fake.finish_calls.size() == 1 and fake.finish_calls[0][1] == 0 and absf(fake.finish_calls[0][0] - race.race_time) < 0.01, "the finish time is reported once")
	_check(race.records.runs.size() == runs_before, "party runs don't become personal records")
	_check(hud._status.text.begins_with("FINISH"), "the HUD shows the finish")

	# Results: the party's rules are off again; leaving clears the other balls.
	fake.current = {"active": true, "phase": "results", "round": 0, "level": "test_track", "collisions": true, "entrant": true}
	await _frames(2)
	_check(not race.party_round and not ball.locked and loader.party_level == "", "between levels the ball is free")
	fake.current = {"active": false}
	await _frames(2)
	_check(not party.active and ball.collision_mask & RemoteBall.LAYER == 0, "leaving the party stops the bumping")
	await _frames(2)
	_check(party.get_node("PartyBalls").get_child_count() == 0, "leaving the party clears the other balls")
	main.queue_free()
	await _frames(2)


class FakePartyHost:
	extends RefCounted
	var current := {"active": false}
	var remote := {}
	var pose_calls: Array[String] = []
	var loaded_calls: Array = []
	var finish_calls: Array = []

	func state() -> String:
		return JSON.stringify(current)

	func remotes(level: String) -> String:
		return JSON.stringify([remote] if not remote.is_empty() and current.get("active", false) and level == "test_track" else [])

	func pose(text: String) -> void:
		pose_calls.append(text)

	func loaded(level: String, round_index: int) -> void:
		loaded_calls.append([level, round_index])

	func finish(time: float, round_index: int) -> void:
		finish_calls.append([time, round_index])


# --- Round 7 ------------------------------------------------------------------

## Crossing the finish ends the run: input stops counting and the ball brakes
## to a stop on the run-off, before the end of the track.
func _test_the_ball_brakes_to_a_stop_after_the_finish() -> void:
	var main := _start_main()
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var ball := race.ball
	var track := race.track
	var finish_at := track.path.total_length() - track.finish_distance_from_end
	var frame := track.world_frame_at(finish_at - 6.0)
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
	ball.control_started.emit()
	race._furthest = finish_at
	await physics_frame
	ball.linear_velocity = -frame.basis.z.normalized() * 46.0
	var stopped_at := INF
	for i in roundi(5.0 / TICK):
		ball.drive(-frame.basis.z.normalized(), false, false)
		await physics_frame
		if race.state == RaceManager.State.FINISHED and ball.linear_velocity.length() < 0.3:
			stopped_at = track.locate(track.to_local(ball.global_position), -1, 40)
			break
	_check(race.state == RaceManager.State.FINISHED, "the run finished")
	var stop_distance: float = track.path.distances[stopped_at] if stopped_at != INF else INF
	_info("a ball crossing the line at 46 m/s stopped %.1f m past it" % (stop_distance - finish_at))
	_check(stop_distance < track.path.total_length() - 1.0, "the ball brakes to a stop on the run-off, still driving")
	race.restart()
	_check(not ball.brake_to_stop, "restarting lets go of the brakes")
	# Sailing over the top of the gate off a jump still finishes.
	var line := track.finish_line
	var before := line.global_transform * Vector3(0.0, 12.0, 0.5)
	var after := line.global_transform * Vector3(0.0, 12.0, -0.5)
	_check(line.crossing_fraction(before, after) >= 0.0, "flying over the finish gate counts as crossing it")
	_check(line.crossing_fraction(after, before) < 0.0, "crossing backwards doesn't")
	main.free()


## Holes in the ice bridge: a ball rolling over one falls through; beside it,
## it rolls on.
func _test_a_hole_in_the_road_drops_the_ball_through() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "winter")
	var route := loader.level.track.get_node("IceBridge") as TrackRoute
	_check(route != null and route.holes.size() >= 4, "the ice bridge has holes")
	var ball: RollingBall = main.get_node("Ball")
	var hole: Vector4 = route.holes[0]
	var results := []
	for x in [hole.z, -hole.z]:
		var frame := route.world_frame_at(hole.x + hole.y * 0.5)
		ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.x.normalized() * x + frame.basis.y * 1.2))
		ball.control_started.emit()
		for i in roundi(1.0 / TICK):
			await physics_frame
		results.append(frame.origin.y - ball.global_position.y)
	_info("dropped over a hole the ball fell %.1f m; beside it %.1f m" % [results[0], results[1]])
	_check(results[0] > 2.0, "a ball over a hole falls through it")
	_check(results[1] < 0.5, "beside the hole the road holds the ball")
	main.free()


## Barrels roll down the beach's raised shortcut toward the player, and are
## solid: a ball resting in their way is shoved back.
func _test_rolling_barrels_knock_the_ball_back() -> void:
	RollingBarrels.hold_still = false
	var main := _start_main()
	var loader := await _load_level(main, "beach")
	var barrels := loader.level.get_node_or_null("RollingBarrels") as RollingBarrels
	_check(barrels != null, "the beach shortcut has rolling barrels")
	if barrels == null:
		main.free()
		return
	var row: Node3D = barrels.get_node("Barrels_0")
	var before := row.global_position
	await _ticks(30)
	_check(row.global_position.distance_to(before) > 1.0, "the barrels roll")
	# Put a ball a little way down the road from the first row, at rest.
	var route := barrels.track
	var here: int = route.path.nearest_index(route.to_local(row.global_position), -1, 400)
	var ahead := route.path.distances[here] - 6.0
	var frame := route.world_frame_at(ahead)
	var ball: RollingBall = main.get_node("Ball")
	ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
	ball.control_started.emit()
	var start := ball.global_position
	var shoved := 0.0
	for i in roundi(2.5 / TICK):
		await physics_frame
		shoved = maxf(shoved, ball.global_position.distance_to(start))
	_info("a barrel row shoved a resting ball %.1f m" % shoved)
	_check(shoved > 3.0, "a barrel row shoves a ball in its way")
	RollingBarrels.hold_still = true
	main.free()


## Along the forest floor cobblestone walls stand on both sides: a ball rolling
## across the ground toward the course is stopped by them.
func _test_forest_walls_keep_ground_riders_off_the_course() -> void:
	var main := _start_main()
	var loader := await _load_level(main, "jungle")
	var walls := loader.level.get_node_or_null("StoneWalls") as StoneWalls
	_check(walls != null, "the forest has cobblestone walls")
	if walls == null:
		main.free()
		return
	var track := loader.level.track
	var terrain: Terrain = loader.level.get_node("Terrain")
	var frame := track.world_frame_at(580.0)
	var right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
	var outside := frame.origin + right * (walls.offset + 6.0)
	outside.y = terrain.height_at(outside) + 0.6
	var ball: RollingBall = main.get_node("Ball")
	ball.respawn(Transform3D(Basis.IDENTITY, outside))
	ball.control_started.emit()
	await physics_frame
	ball.linear_velocity = -right * 25.0
	var closest := INF
	for i in roundi(1.5 / TICK):
		ball.drive(-right, false, false)
		await physics_frame
		var offset := (ball.global_position - frame.origin).dot(right)
		closest = minf(closest, offset)
	_info("a ball rolling at the course from outside the wall got to %.1f m from the centreline" % closest)
	_check(closest > walls.offset - 1.0, "the wall stops a ball rolling in from the ground")
	main.free()


## Changing level puts up a loading screen with the level's name, and takes
## it down once the level is in.
func _test_a_loading_screen_covers_a_level_change() -> void:
	var main := _start_main()
	await _ticks(2)
	var loader: LevelLoader = main.get_node("LevelLoader")
	loader.load_level("winter")
	_check(loader.screen.visible and loader.screen._title.text == "Winter Wonderland", "a loading screen shows the level being loaded")
	while loader.level_id != "winter":
		await process_frame
	for i in 90:
		await process_frame
	_check(not loader.screen.visible, "the loading screen goes once the level is in")
	main.free()


## Round the loop the camera hands over between orbiting the ball and
## chasing along the track; that hand-over must never jump.
func _test_the_camera_turns_smoothly_through_the_loop() -> void:
	var main := _start_main()
	await _ticks(2)
	var race: RaceManager = main.get_node("RaceManager")
	var camera: FollowCamera = main.get_node("FollowCamera")
	var pilot := Autopilot.new()
	pilot.ball = race.ball
	pilot.track = race.track
	main.add_child(pilot)
	var previous := camera.global_transform
	var worst_turn := 0.0
	var worst_jump := 0.0
	var chased := false
	for i in roundi(40.0 / TICK):
		await physics_frame
		if race.state == RaceManager.State.FINISHED:
			break
		var now := camera.global_transform
		worst_turn = maxf(worst_turn, rad_to_deg(previous.basis.get_rotation_quaternion().angle_to(now.basis.get_rotation_quaternion())))
		var expected := race.ball.linear_velocity.length() * TICK
		worst_jump = maxf(worst_jump, previous.origin.distance_to(now.origin) - expected)
		chased = chased or camera._chase > 0.9
		previous = now
	_info("through a lap the camera turned at most %.1f° and jumped at most %.2f m in one tick" % [worst_turn, worst_jump])
	_check(chased, "the camera chased along the track in the loop")
	_check(worst_turn < 10.0 and worst_jump < 0.8, "the camera never snaps through the loop")
	main.free()


## Nobody drives up a wall: full throttle still speeds a ball up a moderate
## slope, but on a near-vertical face it only slows down (climbs are momentum).
func _test_driving_cannot_climb_a_wall() -> void:
	var curve := _section(18.0)
	curve.end_pitch = 80.0
	var track := _test_track([_section(60.0), _section(30.0, 25.0), _section(40.0, 25.0), _section(20.0, 0.0), curve, _section(60.0, 80.0)])
	var ball := _spawn_ball(track, _on_track(track, 10.0))
	await _ticks(1)
	ball.control_started.emit()
	var forward := -track.world_frame_at(10.0).basis.z
	# On the 25° ramp from 10 m/s, full drive gains speed.
	_launch(ball, track, 95.0, 10.0)
	for i in 30:
		ball.drive(forward, false, false)
		await physics_frame
	var on_ramp := ball.linear_velocity.length()
	_check(on_ramp > 10.5, "full drive still speeds a ball up a 25° slope (%.1f m/s)" % on_ramp)
	# On the wall from 20 m/s, full throttle does no better than coasting.
	var ends := []
	for driving in [true, false]:
		_launch(ball, track, 175.0, 20.0)
		for i in 36:
			ball.drive(forward if driving else Vector3.ZERO, false, false)
			await physics_frame
		ends.append(ball.linear_velocity.length())
	_info("up the 80° face from 20 m/s, after 0.3 s: %.1f m/s driving, %.1f m/s coasting" % ends)
	_check(ends[0] < 17.0 and absf(ends[0] - ends[1]) < 0.3, "driving up a near-vertical wall is no better than coasting")
	track.get_parent().free()


## Hidden (its Möbius tab closed, the page minimised) the game pauses and goes
## silent; shown again it carries on as it was. In a party level it only goes
## silent, so the shared race clock keeps running.
func _test_the_game_sleeps_while_hidden() -> void:
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	var fake := FakeVisibilityHost.new()
	main.get_node("AppSuspend").host = fake
	root.add_child(main)
	await _frames(3)
	var race: RaceManager = main.get_node("RaceManager")
	var suspend: AppSuspend = main.get_node("AppSuspend")
	fake.is_hidden = true
	await _frames(40)
	_check(suspend.asleep and paused and AudioServer.is_bus_mute(0), "hidden, the game is paused and silent")
	fake.is_hidden = false
	await _frames(3)
	_check(not suspend.asleep and not paused and not AudioServer.is_bus_mute(0), "shown again, it carries on with its sound")
	var menu: PauseMenu = main.get_node("PauseMenu")
	menu.open()
	fake.is_hidden = true
	await _frames(40)
	fake.is_hidden = false
	await _frames(3)
	_check(paused and menu.is_open(), "left on the menu, it stays paused when shown again")
	menu.close()
	race.party_round = true
	fake.is_hidden = true
	await _frames(40)
	_check(suspend.asleep and not paused and AudioServer.is_bus_mute(0), "in a party level it only goes silent")
	fake.is_hidden = false
	await _frames(3)
	race.party_round = false
	main.free()
	paused = false


class FakeVisibilityHost:
	extends RefCounted
	var is_hidden := false

	func hidden() -> bool:
		return is_hidden
