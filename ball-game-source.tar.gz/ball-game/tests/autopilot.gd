extends Node
## Test driver: steers a RollingBall along a TrackBuilder centreline at full
## throttle through the same drive() call the player uses. Used by the headless
## tests to prove a track is completable with the current tuning. It jumps the
## gaps that need a jump, and with [member take_routes] it takes every
## alternative route instead of the main road.

var ball: RollingBall
var track: TrackBuilder
## Aim this many seconds of travel ahead along the centreline...
var look_ahead_time := 0.4
## ...but never closer than this.
var min_look_ahead := 6.0
## Furthest distance along the track reached so far.
var progress := 0.0
## Take each alternative route (TrackRoute) rather than staying on the main road.
var take_routes := false
## Jump the gaps that need a jump (off: roll straight at them).
var jumps := true
## Start jumping this many seconds of travel before a jump gap...
var jump_lead_time := 0.08
## ...and hold the button this long for a full jump.
var jump_hold_time := 0.5
## Routes taken this lap.
var routes_taken: Array[TrackRoute] = []
## Metres actually rolled on each route (by name): the ball on its surface.
var ridden := {}

var _index := -1
## The road being followed: the track itself or one of its routes.
var _lane: TrackBuilder
var _lane_index := -1
var _jumped := Vector2(-1.0, -1.0)
var _jump_left := 0.0


func _physics_process(delta: float) -> void:
	if ball == null or track == null:
		return
	if _lane == null:
		_lane = track
	var local := track.to_local(ball.global_position)
	_index = track.locate(local, _index, 40)
	progress = maxf(progress, track.network.distances[_index])
	_choose_lane()
	var lane_path := _lane.path
	_lane_index = lane_path.nearest_index(local, _lane_index, 40)
	var here := lane_path.distances[_lane_index]
	var speed := ball.linear_velocity.length()
	if _lane != track:
		var surface := _lane.global_transform * lane_path.frames[_lane_index]
		# Riding includes flying its breaks: anywhere just over the route counts.
		if surface.origin.distance_to(ball.global_position) < ball.radius + 2.5:
			ridden[_lane.name] = ridden.get(_lane.name, 0.0) + speed * delta
	var jump_pressed := false
	var gap := lane_path.jump_ahead(here, speed * jump_lead_time + 1.0)
	if jumps and gap != Vector2.ZERO and gap != _jumped:
		_jumped = gap
		_jump_left = jump_hold_time
		jump_pressed = true
	_jump_left = maxf(_jump_left - delta, 0.0)
	var reach := maxf(min_look_ahead, speed * look_ahead_time)
	# In a corkscrew's deep channel, or wherever the road is rolled steeply,
	# steering only fights the twist: let the ball's speed carry it round.
	var under := _lane.world_frame_at(here)
	var in_channel := lane_path.lips[_lane_index].x > 1.5
	if (in_channel or under.basis.y.normalized().y < 0.55) and _jump_left <= 0.0:
		ball.drive(Vector3.ZERO, false, jump_pressed)
		return
	# Passing an obstacle: aim at the free side of the obstacle itself, so the
	# ball is already on that line when it gets there.
	var dodge := _dodge(here)
	var aim_at := here + reach
	if dodge != Vector2.ZERO and dodge.x > here + 4.0:
		aim_at = minf(aim_at, dodge.x)
	var target := _lane.world_frame_at(aim_at)
	var aim := target.origin + target.basis.y * 0.5 + target.basis.x.normalized() * dodge.y - ball.global_position
	# Steer on velocity error (want: toward the aim point, a bit faster than now)
	# rather than straight at the point, which damps side-to-side overshoot.
	var aim_flat := ball.surface_to_intent(aim)
	var velocity_flat := ball.surface_to_intent(ball.linear_velocity)
	aim_flat.y = 0.0
	velocity_flat.y = 0.0
	if aim_flat.length() < 0.01:
		ball.drive(Vector3.ZERO, _jump_left > 0.0, jump_pressed)
		return
	var wanted := aim_flat.normalized() * (speed + 10.0)
	ball.drive((wanted - velocity_flat).normalized(), _jump_left > 0.0, jump_pressed)


## The next obstacle or hole on the lane, if any: (its distance, the sideways
## aim in metres right that passes it), or zero.
func _dodge(here: float) -> Vector2:
	if not (_lane is TrackRoute):
		return Vector2.ZERO
	var best := Vector2.ZERO
	var nearest := INF
	for spot in (_lane as TrackRoute).obstacles:
		if spot.x > here - 3.0 and spot.x < here + 22.0 and spot.x < nearest:
			nearest = spot.x
			best = Vector2(spot.x, -signf(spot.y if spot.y != 0.0 else 1.0) * 1.15)
	for hole in _lane.holes:
		var middle := hole.x + hole.y * 0.5
		if hole.x + hole.y > here - 1.0 and hole.x < here + 22.0 and middle < nearest:
			nearest = middle
			# Pass on the wider side, clear of the edge.
			var aim := hole.z - hole.w * 0.5 - 0.75 if hole.z > 0.3 else hole.z + hole.w * 0.5 + 0.75
			best = Vector2(middle, aim)
	return best


## Onto a route shortly before its fork; back to the main road at its end.
func _choose_lane() -> void:
	if _lane == track:
		if not take_routes:
			return
		var here := track.network.distances[_index]
		for route in track.routes():
			if not routes_taken.has(route) and here >= route.from_distance - 10.0 and here < route.from_distance + 5.0:
				routes_taken.append(route)
				_lane = route
				_lane_index = -1
				return
	elif _lane_index >= 0 and _lane.path.distances[_lane_index] >= _lane.path.total_length() - 0.5:
		_lane = track
		_lane_index = -1


## Forget the tracked position, e.g. after the run restarts at the spawn.
func reset() -> void:
	_index = -1
	_lane = track
	_lane_index = -1
	_jumped = Vector2(-1.0, -1.0)
	routes_taken.clear()
	ridden.clear()
	progress = 0.0


func current_distance() -> float:
	return track.network.distances[maxi(_index, 0)]
