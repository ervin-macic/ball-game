class_name RollingBall
extends RigidBody3D
## Player sphere tuned for flow and momentum.
##
## A driver (PlayerInput, the test Autopilot, a future replay or AI) calls
## [method drive] once per physics tick with a world-space move intent. All
## forces are applied in [method _integrate_forces], where the contacts Jolt
## reported for the last step are available.
##
## Four rules shape the feel:
## [br]- Input never fights momentum. It adds speed only up to
##   [member max_drive_speed]; above that it can still steer and brake, while
##   slopes and jumps can carry the ball faster.
## [br]- Grounded angular damping acts on spin that is [i]not[/i] rolling:
##   drilling spin is stopped, wheel-spin and side-spin are traded into rolling.
##   Control stays tight without braking.
## [br]- In the air, spin is matched to velocity, so landings keep their speed
##   instead of scrubbing it off through friction.
## [br]- On smooth ground, energy the physics solver loses on tight curves is
##   refunded (see [member curve_energy_refund]); a coasting ball climbs exactly
##   as high as its energy allows, never higher.

## First move or jump input since the last respawn. The race timer starts here.
signal control_started
signal jumped
## Emitted on touchdown. [param impact_speed] is the speed into the surface.
signal landed(impact_speed: float)
signal respawned

## Solid sphere: I = 0.4 m r². Rolling therefore needs 1.4× the force of sliding.
const ROLLING_INERTIA_FACTOR := 1.4
## A ball that lands hard sinks into the ground by up to its fall speed × one tick,
## and Jolt leaves it there (measured: 4.8 cm, indefinitely). Sinking beyond this
## is lifted back out, at most MAX_LIFT_PER_TICK per tick so the correction never pops.
const SINK_TOLERANCE := 0.005
const MAX_LIFT_PER_TICK := 0.04

@export_group("Body")
## Applied to the collision sphere and the visual sphere when the ball enters the tree.
@export_range(0.1, 3.0, 0.01, "suffix:m") var radius := 0.5

@export_group("Drive")
## Acceleration from full input on flat ground while rolling.
@export_range(0.0, 150.0, 0.1, "suffix:m/s²") var drive_acceleration := 24.0
## Input adds speed up to here. Slopes, jumps and boosts can still exceed it.
@export_range(1.0, 200.0, 0.1, "suffix:m/s") var max_drive_speed := 32.0
## Fraction of [member max_drive_speed] over which input acceleration fades to zero. 0 is a hard cut-off.
@export_range(0.0, 1.0, 0.01) var drive_fade_band := 0.3
## Multiplier on input that opposes the current motion (braking and reversing).
@export_range(0.0, 6.0, 0.05) var brake_multiplier := 1.7
## Multiplier on input perpendicular to the motion. Above 1, turns carve harder than straight-line acceleration.
@export_range(0.0, 4.0, 0.05) var steer_multiplier := 1.4
## How the drive is delivered. 0: push the centre (works on any friction). 1: spin the ball (traction then depends on friction, like a wheel).
@export_range(0.0, 1.0, 0.01) var torque_drive_share := 0.5

## Driving up steep ground: full drive up to this slope...
@export_range(0.0, 90.0, 0.5, "suffix:°") var climb_drive_start := 45.0
## ...and none up the slope from this one (see _limit_climb).
@export_range(0.0, 90.0, 0.5, "suffix:°") var climb_drive_end := 75.0

@export_group("Grip and Friction")
## Contact friction when slow: crisp starts, stops and direction changes.
@export_range(0.0, 3.0, 0.01) var friction_at_low_speed := 1.1
## Contact friction when fast: smooth rolling that carries momentum through turns.
@export_range(0.0, 3.0, 0.01) var friction_at_high_speed := 0.35
## At or below this speed the low-speed friction applies.
@export_range(0.0, 100.0, 0.1, "suffix:m/s") var low_friction_speed := 3.0
## At or above this speed the high-speed friction applies. Between them the change is smooth.
@export_range(0.0, 200.0, 0.1, "suffix:m/s") var high_friction_speed := 22.0

@export_group("Damping")
## Damping of velocity along the surface while grounded (rolling resistance).
@export_range(0.0, 5.0, 0.001, "suffix:1/s") var ground_linear_damp := 0.06
## Damping of horizontal velocity in the air. Vertical motion is never damped, so falls stay snappy.
@export_range(0.0, 5.0, 0.001, "suffix:1/s") var air_linear_damp := 0.02
## Grounded angular damping of spin that is not rolling. Drilling spin is stopped; wheel-spin and side-spin are traded into rolling like grippy friction, so control stays tight without deleting momentum.
@export_range(0.0, 60.0, 0.1, "suffix:1/s") var ground_angular_damp := 10.0
## Share of the grounded angular damping also applied to the rolling itself. 0 keeps momentum. 1 is classic full angular damping, which brakes the ball.
@export_range(0.0, 1.0, 0.01) var ground_angular_damp_on_rolling := 0.0
## Angular damping in the air.
@export_range(0.0, 20.0, 0.01, "suffix:1/s") var air_angular_damp := 0.3
## In the air, how quickly spin turns toward "rolling at the current velocity" so touchdowns keep their speed. 0 disables it.
@export_range(0.0, 30.0, 0.1, "suffix:1/s") var air_spin_match := 8.0

@export_group("Ground Detection")
## Steepest contact, measured from up, that counts as ground.
@export_range(0.0, 89.0, 0.5, "suffix:°") var max_ground_angle := 55.0
## Also accept contacts within [member max_ground_angle] of the previous ground normal, so the ball keeps "ground" through loops, pipes and wall-rides.
@export var follow_surface := true
## Ground behaviour persists this long after contact is lost (smooths small bumps).
@export_range(0.0, 0.3, 0.005, "suffix:s") var ground_grace_time := 0.06
## How long the last ground normal is remembered for following steep surfaces and probing toward them.
@export_range(0.0, 2.0, 0.01, "suffix:s") var surface_memory_time := 0.25
## When no contact is reported, a ray this far beyond the ball's surface still finds the ground.
## Jolt holds a ball on speculative contacts a hair above fast curved surfaces (loops) without
## reporting them, so contacts alone flicker exactly where ground matters most.
@export_range(0.0, 1.0, 0.005, "suffix:m") var ground_probe_distance := 0.12
## Extra pull into the surface while touching it at speed. Helps loops and crests.
@export_range(0.0, 100.0, 0.1, "suffix:m/s²") var ground_stick_acceleration := 8.0
## Speed at which the stick force starts. It reaches full strength at twice this speed.
@export_range(0.0, 100.0, 0.1, "suffix:m/s") var stick_min_speed := 6.0

@export_group("Jump")
## Velocity added along the jump direction by the jump impulse.
@export_range(0.0, 50.0, 0.1, "suffix:m/s") var jump_speed := 8.5
## Jump direction. 0: straight up. 1: along the surface normal (wall and loop jumps).
@export_range(0.0, 1.0, 0.01) var jump_surface_influence := 0.6
## Grace period after leaving the ground during which a jump still works.
@export_range(0.0, 0.5, 0.005, "suffix:s") var coyote_time := 0.12
## A jump pressed this long before landing still fires on touchdown.
@export_range(0.0, 0.5, 0.005, "suffix:s") var jump_buffer_time := 0.12
## Gravity multiplier while rising with jump released. Tap for a hop, hold for full height.
@export_range(1.0, 6.0, 0.05) var jump_cut_gravity_multiplier := 2.2
## After a jump, ground contacts are ignored this long so the ball cleanly leaves the surface.
@export_range(0.0, 0.5, 0.005, "suffix:s") var jump_ground_ignore_time := 0.1

@export_group("Air Control")
## Acceleration from full input in the air.
@export_range(0.0, 100.0, 0.1, "suffix:m/s²") var air_acceleration := 14.0
## Air input adds horizontal speed up to here; above it, input can only steer and brake.
@export_range(1.0, 200.0, 0.1, "suffix:m/s") var air_max_speed := 30.0
## Multiplier on air input that opposes horizontal motion.
@export_range(0.0, 6.0, 0.05) var air_brake_multiplier := 1.3
## Gravity multiplier while falling. Above 1, arcs feel weighty rather than floaty.
@export_range(1.0, 6.0, 0.05) var fall_gravity_multiplier := 1.35
## Terminal falling speed.
@export_range(1.0, 300.0, 0.5, "suffix:m/s") var max_fall_speed := 60.0

@export_group("Momentum")
## Rigid-body solvers bleed energy when a ball is pressed hard into a tight curve
## (loops, pipes, sharp dips): about a quarter of a loop's energy in Jolt, more in
## Godot Physics, whatever the solver settings. While the ball rolls on continuous
## ground, this refunds that share of the loss (1 = all of it). The controller's own
## damping and braking still count; wall hits and landings are never refunded.
@export_range(0.0, 1.0, 0.01) var curve_energy_refund := 1.0
## Largest refund per physics tick, as a fraction of kinetic energy. Real impacts lose more than this and stay lost.
@export_range(0.0, 0.2, 0.001) var max_refund_per_tick := 0.02

@export_group("Safety")
## Hard cap on total speed.
@export_range(1.0, 500.0, 1.0, "suffix:m/s") var max_speed := 120.0

var _material: PhysicsMaterial

# Intent from the driver, consumed by _integrate_forces.
var _move_intent := Vector3.ZERO
var _jump_held := false
var _jump_queued := false
var _has_control := false
## While locked (a party countdown), input is ignored and can't start the run.
var locked := false
## Turn the ball's spin with the road where it rolls about the direction of
## travel. RaceManager turns this on in a corkscrew's deep channel; elsewhere
## the contact alone handles the spin.
var spin_follows_roll := false
## After the finish: input is ignored and the ball brakes smoothly to a stop.
var brake_to_stop := false
## How hard it brakes then (m/s², on top of a gentle exponential slow-down).
const FINISH_BRAKE := 14.0

# Ground state.
var _touching_ground := false
var _ground_normal := Vector3.UP
## Surface normal the spin was last lined up with (zero: none yet).
var _spin_normal := Vector3.ZERO
## A launch (vents, catapults) waiting for the next physics step, or NAN.
var _launch := Vector3(NAN, NAN, NAN)
## Grip of the surface under the ball (1 = normal). A collider can lower it with
## a "grip" metadata value (TrackBuilder does for slippery ice pieces).
var surface_grip := 1.0
var _time_since_ground := INF
var _ground_ignore_left := 0.0
var _surface_axis := Vector3.RIGHT
var _surface_basis := Basis.IDENTITY
var _probe_query := PhysicsRayQueryParameters3D.new()
## Radius friction actually rolls the ball about. Jolt anchors friction midway
## between the ball's surface and the ground's, so a sunk ball rolls on a shorter
## radius; spin targets must match it or they fight friction and bleed speed.
var _rolling_radius := 0.5
## How far the ball's centre sits inside its nominal radius from the ground.
var _sink_depth := 0.0

# Jump state.
var _jump_buffer_left := 0.0
var _jump_spent := false
var _rising_from_jump := false

var _prev_velocity := Vector3.ZERO

# Momentum bookkeeping (energies are per kilogram).
var _touching_other := false
var _expected_energy := NAN
var _applied_force := Vector3.ZERO
var _applied_torque := Vector3.ZERO


func _ready() -> void:
	_apply_radius()
	# The controller owns damping, sleeping and friction; these are invariants it
	# relies on rather than tunables. Engine damping would double up with ours,
	# and a sleeping ball would ignore input.
	linear_damp_mode = RigidBody3D.DAMP_MODE_REPLACE
	linear_damp = 0.0
	angular_damp_mode = RigidBody3D.DAMP_MODE_REPLACE
	angular_damp = 0.0
	can_sleep = false
	continuous_cd = true
	contact_monitor = true
	max_contacts_reported = maxi(max_contacts_reported, 8)
	_material = physics_material_override.duplicate() if physics_material_override else PhysicsMaterial.new()
	# Rough: the ball's friction wins over the surface's when Jolt combines them,
	# so the speed-based grip below is what the player feels on every surface.
	_material.rough = true
	_material.friction = friction_at_low_speed
	physics_material_override = _material


## Feeds one physics tick of control. [param move] is a world-space direction,
## normally horizontal, with length 0..1 (analog magnitude). Intent lasts one tick:
## a driver that stops calling leaves the ball coasting, never stuck on old input.
func drive(move: Vector3, jump_held: bool, jump_pressed: bool) -> void:
	if locked or brake_to_stop:
		move = Vector3.ZERO
		jump_held = false
		jump_pressed = false
	_move_intent = move.limit_length(1.0)
	_jump_held = jump_held
	if jump_pressed:
		_jump_queued = true
	if not _has_control and (_move_intent.length_squared() > 1e-4 or jump_pressed):
		_has_control = true
		control_started.emit()


## Hands control over without waiting for input (a party start signal).
func start_control() -> void:
	if not _has_control:
		_has_control = true
		control_started.emit()


## Teleports to [param at] with all motion and control state cleared.
func respawn(at: Transform3D) -> void:
	global_transform = at
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	_move_intent = Vector3.ZERO
	_jump_held = false
	_jump_queued = false
	_has_control = false
	_spin_normal = Vector3.ZERO
	spin_follows_roll = false
	brake_to_stop = false
	_launch = Vector3(NAN, NAN, NAN)
	_touching_ground = false
	_ground_normal = at.basis.y.normalized()
	surface_grip = 1.0
	_time_since_ground = INF
	_ground_ignore_left = 0.0
	_surface_basis = Basis.IDENTITY
	_jump_buffer_left = 0.0
	_jump_spent = false
	_rising_from_jump = false
	_prev_velocity = Vector3.ZERO
	_expected_energy = NAN
	_rolling_radius = radius
	_sink_depth = 0.0
	_set_friction(friction_at_low_speed)
	reset_physics_interpolation()
	respawned.emit()


func is_grounded() -> bool:
	return _time_since_ground <= ground_grace_time


## The ground normal while grounded, world up otherwise.
func get_surface_up() -> Vector3:
	return _ground_normal if is_grounded() else Vector3.UP


## Inverse of how [method drive] intent is laid onto the surface (identity on level
## ground, a half turn at the top of a loop): turns a direction along the surface
## back into the flat frame the driver steers in.
func surface_to_intent(direction: Vector3) -> Vector3:
	return _surface_basis.inverse() * direction


## Throws the ball off whatever it's on with [param velocity] (applied on the
## next physics step, so the controller doesn't fight it).
func launch(velocity: Vector3) -> void:
	_launch = velocity


func _integrate_forces(state: PhysicsDirectBodyState3D) -> void:
	var dt := state.step
	var gravity := state.total_gravity
	var up := -gravity.normalized() if gravity.length_squared() > 1e-8 else Vector3.UP

	if not is_nan(_launch.x):
		# Thrown off the ground: the new velocity stands, and the ground lets go.
		state.linear_velocity = _launch
		_launch = Vector3(NAN, NAN, NAN)
		_ground_ignore_left = jump_ground_ignore_time
		_touching_ground = false
		_time_since_ground = INF
	_ground_ignore_left = maxf(_ground_ignore_left - dt, 0.0)
	_jump_buffer_left = maxf(_jump_buffer_left - dt, 0.0)
	if _jump_queued:
		_jump_buffer_left = jump_buffer_time
		_jump_queued = false

	_read_ground_contacts(state, up)
	_resolve_sinking(state)
	_refund_solver_energy_loss(state, gravity)
	_applied_force = Vector3.ZERO
	_applied_torque = Vector3.ZERO
	_update_surface_basis(up)
	_set_friction(_friction_for_speed(state.linear_velocity.length()) * (surface_grip if is_grounded() else 1.0))
	_try_jump(state, up)

	if is_grounded():
		_apply_ground_control(state, dt)
	else:
		_spin_normal = Vector3.ZERO
		_apply_air_control(state, dt, up, gravity)

	if state.linear_velocity.length() > max_speed:
		state.linear_velocity = state.linear_velocity.limit_length(max_speed)
	# After the finish: brake, after everything else, so the energy refund below
	# counts the braking as intended rather than giving the speed back.
	if brake_to_stop:
		var v := state.linear_velocity
		var speed := v.length()
		if speed > 1e-3:
			var slower := maxf(speed * exp(-1.2 * dt) - FINISH_BRAKE * dt, 0.0)
			state.linear_velocity = v * (slower / speed)
			state.angular_velocity *= slower / speed
		_expected_energy = NAN
		_prev_velocity = state.linear_velocity
		_move_intent = Vector3.ZERO
		_jump_held = false
		return
	_prev_velocity = state.linear_velocity
	# Energy the coming step should end with if contacts only redirect the ball:
	# what it has now plus the work of the forces just applied.
	if _touching_ground and is_grounded():
		var work := (_applied_force.dot(state.linear_velocity) + _applied_torque.dot(state.angular_velocity)) / mass * dt
		_expected_energy = _energy(state, gravity) + work
	else:
		_expected_energy = NAN
	_move_intent = Vector3.ZERO
	_jump_held = false


func _read_ground_contacts(state: PhysicsDirectBodyState3D, up: Vector3) -> void:
	var cos_limit := cos(deg_to_rad(max_ground_angle))
	var remembers_surface := follow_surface and _time_since_ground <= surface_memory_time
	var centre := state.transform.origin
	var normal_sum := Vector3.ZERO
	var nearest := radius
	_touching_other = false
	if _ground_ignore_left <= 0.0:
		var grip := 1.0
		for i in state.get_contact_count():
			var n := state.get_contact_local_normal(i)
			if _counts_as_ground(n, up, cos_limit, remembers_surface):
				normal_sum += n
				var collider := state.get_contact_collider_object(i)
				if collider and collider.has_meta("grip"):
					grip = minf(grip, float(collider.get_meta("grip")))
				nearest = minf(nearest, (centre - state.get_contact_collider_position(i)).dot(n))
			else:
				_touching_other = true
		if normal_sum.length_squared() < 1e-8 and ground_probe_distance > 0.0:
			var probe_direction := -_ground_normal if remembers_surface else -up
			var hit := _probe_ground(state, probe_direction)
			if not hit.is_empty() and _counts_as_ground(hit["normal"], up, cos_limit, remembers_surface):
				normal_sum = hit["normal"]
				nearest = minf(nearest, (centre - (hit["position"] as Vector3)).dot(hit["normal"]))

		if normal_sum.length_squared() > 1e-8:
			surface_grip = grip
	var was_grounded := is_grounded()
	_touching_ground = normal_sum.length_squared() > 1e-8
	if _touching_ground:
		var n := normal_sum.normalized()
		if not was_grounded:
			landed.emit(maxf(-_prev_velocity.dot(n), 0.0))
		_ground_normal = n
		_sink_depth = clampf(radius - nearest, 0.0, radius * 0.5)
		_time_since_ground = 0.0
		_jump_spent = false
		_rising_from_jump = false
	else:
		_sink_depth = 0.0
		_time_since_ground += state.step


## Lifts a sunk ball back onto the surface and updates the radius it rolls on.
func _resolve_sinking(state: PhysicsDirectBodyState3D) -> void:
	var lift := clampf(_sink_depth - SINK_TOLERANCE, 0.0, MAX_LIFT_PER_TICK)
	if lift > 0.0:
		state.transform = Transform3D(state.transform.basis, state.transform.origin + _ground_normal * lift)
		_sink_depth -= lift
	_rolling_radius = radius - _sink_depth * 0.5


## Puts back energy the physics step lost while the ball rolled on smooth ground.
## Only a shortfall against the last tick's expectation is refunded, never a gain.
func _refund_solver_energy_loss(state: PhysicsDirectBodyState3D, gravity: Vector3) -> void:
	var expected := _expected_energy
	_expected_energy = NAN
	if is_nan(expected) or curve_energy_refund <= 0.0 or not _touching_ground or _touching_other:
		return
	var kinetic := _kinetic_energy(state)
	var shortfall := expected - (kinetic + _potential_energy(state, gravity))
	if shortfall <= 0.0 or kinetic < 1e-3:
		return
	var refund := minf(shortfall * curve_energy_refund, kinetic * max_refund_per_tick)
	var scale := sqrt((kinetic + refund) / kinetic)
	state.linear_velocity *= scale
	state.angular_velocity *= scale


func _energy(state: PhysicsDirectBodyState3D, gravity: Vector3) -> float:
	return _kinetic_energy(state) + _potential_energy(state, gravity)


func _kinetic_energy(state: PhysicsDirectBodyState3D) -> float:
	var inertia_per_mass := (ROLLING_INERTIA_FACTOR - 1.0) * radius * radius
	return 0.5 * state.linear_velocity.length_squared() + 0.5 * inertia_per_mass * state.angular_velocity.length_squared()


func _potential_energy(state: PhysicsDirectBodyState3D, gravity: Vector3) -> float:
	return -gravity.dot(state.transform.origin)


## Applies a central force for the coming step and records it for the energy bookkeeping.
func _push(state: PhysicsDirectBodyState3D, force: Vector3) -> void:
	state.apply_central_force(force)
	_applied_force += force


func _twist(state: PhysicsDirectBodyState3D, torque: Vector3) -> void:
	state.apply_torque(torque)
	_applied_torque += torque


## Level enough to stand on, or (while the last surface is remembered) close
## enough to it that the ball is still riding the same surface, e.g. in a loop.
func _counts_as_ground(n: Vector3, up: Vector3, cos_limit: float, remembers_surface: bool) -> bool:
	return n.dot(up) >= cos_limit or (remembers_surface and n.dot(_ground_normal) >= cos_limit)


## Ray hit (position, normal, ...) a short way beyond the ball's surface, or empty.
func _probe_ground(state: PhysicsDirectBodyState3D, direction: Vector3) -> Dictionary:
	var origin := state.transform.origin
	_probe_query.from = origin
	_probe_query.to = origin + direction * (radius + ground_probe_distance)
	_probe_query.collision_mask = collision_mask
	_probe_query.exclude = [get_rid()]
	return state.get_space_state().intersect_ray(_probe_query)


func _update_surface_basis(up: Vector3) -> void:
	if not is_grounded():
		_surface_basis = Basis.IDENTITY
		return
	var axis := up.cross(_ground_normal)
	var axis_length := axis.length()
	# Keep the last good axis through the singular point at the top of a loop,
	# where up and the ground normal are exactly opposite.
	if axis_length > 1e-3:
		_surface_axis = axis / axis_length
	var angle := acos(clampf(up.dot(_ground_normal), -1.0, 1.0))
	_surface_basis = Basis(_surface_axis, angle) if angle > 1e-4 else Basis.IDENTITY


func _friction_for_speed(speed: float) -> float:
	var t := smoothstep(low_friction_speed, high_friction_speed, speed)
	return lerpf(friction_at_low_speed, friction_at_high_speed, t)


func _set_friction(value: float) -> void:
	# Each change is pushed to the physics server, so skip imperceptible ones.
	if _material and absf(_material.friction - value) > 0.002:
		_material.friction = value


func _try_jump(state: PhysicsDirectBodyState3D, up: Vector3) -> void:
	if _jump_buffer_left <= 0.0 or _jump_spent or _time_since_ground > coyote_time:
		return
	var direction := up.lerp(_ground_normal, jump_surface_influence)
	direction = direction.normalized() if direction.length_squared() > 1e-4 else _ground_normal
	var velocity := state.linear_velocity
	var into_surface := velocity.dot(direction)
	if into_surface < 0.0:
		# Going downhill or landing: cancel the inward motion so every jump gets full height.
		velocity -= direction * into_surface
	state.linear_velocity = velocity
	state.apply_central_impulse(direction * jump_speed * mass)
	_jump_buffer_left = 0.0
	_jump_spent = true
	_rising_from_jump = true
	_ground_ignore_left = jump_ground_ignore_time
	_touching_ground = false
	_time_since_ground = INF
	jumped.emit()


func _apply_ground_control(state: PhysicsDirectBodyState3D, dt: float) -> void:
	var n := _ground_normal
	var velocity := state.linear_velocity
	var tangent_velocity := velocity - n * velocity.dot(n)

	velocity -= tangent_velocity * (1.0 - exp(-ground_linear_damp * surface_grip * dt))
	state.linear_velocity = velocity
	tangent_velocity = velocity - n * velocity.dot(n)
	var speed := tangent_velocity.length()

	var intent := _intent_on_surface(n)
	if intent.length_squared() > 1e-6:
		# On slippery ground the same input pushes, steers and brakes far less.
		var accel := _shape_acceleration(intent * drive_acceleration * surface_grip, tangent_velocity,
				max_drive_speed, drive_fade_band, brake_multiplier, steer_multiplier)
		accel = _limit_climb(accel, n, tangent_velocity)
		_push(state, accel * (mass * ROLLING_INERTIA_FACTOR * (1.0 - torque_drive_share)))
		_twist(state, n.cross(accel) * (mass * ROLLING_INERTIA_FACTOR * radius * torque_drive_share))

	if _touching_ground and ground_stick_acceleration > 0.0:
		var strength := clampf((speed - stick_min_speed) / maxf(stick_min_speed, 0.1), 0.0, 1.0)
		_push(state, -n * (ground_stick_acceleration * strength * mass))

	_damp_ground_spin(state, n, dt)


## A ball can't drive itself up a wall: on steep ground the part of the
## drive that pushes up the slope, while heading up it, fades away (fully
## from [member climb_drive_start] to [member climb_drive_end]), so cliffs and
## the rising half of a loop are climbed on momentum alone. Riding along a
## steep bank (a wall ride), steering and braking are unaffected.
func _limit_climb(accel: Vector3, n: Vector3, tangent_velocity: Vector3) -> Vector3:
	var uphill := Vector3.UP - n * n.y
	if uphill.length_squared() < 1e-6:
		return accel
	uphill = uphill.normalized()
	var push_up := accel.dot(uphill)
	if push_up <= 0.0:
		return accel
	var steep := 1.0 - smoothstep(cos(deg_to_rad(climb_drive_end)), cos(deg_to_rad(climb_drive_start)), n.y)
	var heading_up := 1.0
	if tangent_velocity.length_squared() > 0.25:
		heading_up = clampf(tangent_velocity.normalized().dot(uphill), 0.0, 1.0)
	return accel - uphill * push_up * steep * heading_up


func _apply_air_control(state: PhysicsDirectBodyState3D, dt: float, up: Vector3, gravity: Vector3) -> void:
	var velocity := state.linear_velocity
	var horizontal := velocity - up * velocity.dot(up)
	velocity -= horizontal * (1.0 - exp(-air_linear_damp * dt))
	state.linear_velocity = velocity
	horizontal = velocity - up * velocity.dot(up)

	var intent := _move_intent - up * _move_intent.dot(up)
	if intent.length_squared() > 1e-6:
		intent = intent.normalized() * _move_intent.length()
		var accel := _shape_acceleration(intent * air_acceleration, horizontal,
				air_max_speed, drive_fade_band, air_brake_multiplier, 1.0)
		_push(state, accel * mass)

	var vertical_speed := velocity.dot(up)
	if _rising_from_jump and vertical_speed <= 0.0:
		_rising_from_jump = false
	var extra_gravity := 0.0
	if vertical_speed < 0.0:
		extra_gravity = fall_gravity_multiplier - 1.0
	elif _rising_from_jump and not _jump_held:
		extra_gravity = jump_cut_gravity_multiplier - 1.0
	if extra_gravity > 0.0:
		_push(state, gravity * (extra_gravity * mass))
	if vertical_speed < -max_fall_speed:
		state.linear_velocity += up * (-max_fall_speed - vertical_speed)

	var spin := state.angular_velocity * exp(-air_angular_damp * dt)
	if air_spin_match > 0.0:
		spin = spin.lerp(up.cross(horizontal) / radius, 1.0 - exp(-air_spin_match * dt))
	state.angular_velocity = spin


## Grounded angular damping. Drilling spin (about the normal) is simply stopped.
## Wheel-spin and side-spin are traded toward rolling the way grippy friction
## would, by an impulse at the contact point: excess spin turns into motion and
## missing spin is taken from it, so damping never deletes rolling momentum.
func _damp_ground_spin(state: PhysicsDirectBodyState3D, n: Vector3, dt: float) -> void:
	var rate := 1.0 - exp(-ground_angular_damp * dt)
	var spin := state.angular_velocity
	# Where the surface rolls under the ball about the direction of travel (a
	# corkscrew), turn the spin with it, so rolling spin stays rolling instead
	# of turning into "drilling" spin that the damping below would delete with
	# its energy. Only that roll, and only where asked (spin_follows_roll):
	# elsewhere (loops, crests, banks) it costs speed and repeatability.
	var travel := state.linear_velocity
	if spin_follows_roll and _spin_normal != Vector3.ZERO and travel.length_squared() > 1e-4:
		var along := travel.normalized()
		var roll := atan2(_spin_normal.cross(n).dot(along), _spin_normal.dot(n))
		if absf(roll) > 1e-6:
			spin = spin.rotated(along, roll)
	_spin_normal = n
	spin -= n * spin.dot(n) * rate
	var velocity := state.linear_velocity
	var slip := velocity - _rolling_radius * spin.cross(n)
	slip -= n * slip.dot(n)
	var inertia_per_mass := (ROLLING_INERTIA_FACTOR - 1.0) * radius * radius
	var impulse := -slip * rate / (1.0 + _rolling_radius * _rolling_radius / inertia_per_mass)
	velocity += impulse
	spin += (-n * _rolling_radius).cross(impulse) / inertia_per_mass
	if ground_angular_damp_on_rolling > 0.0:
		# Classic angular damping of the rolling itself: brakes the ball through the
		# contact on the next tick. Off by default because it bleeds momentum.
		spin *= exp(-ground_angular_damp * ground_angular_damp_on_rolling * dt)
	state.linear_velocity = velocity
	state.angular_velocity = spin


## Lays the flat intent onto the surface, keeping its analog magnitude.
func _intent_on_surface(n: Vector3) -> Vector3:
	var on_surface := _surface_basis * _move_intent
	on_surface -= n * on_surface.dot(n)
	if on_surface.length_squared() < 1e-8:
		return Vector3.ZERO
	return on_surface.normalized() * _move_intent.length()


## Splits raw input acceleration into the part along the current motion and the
## part across it, then applies the momentum rules: no pushing past the speed
## limit, stronger braking, stronger steering.
static func _shape_acceleration(accel: Vector3, velocity: Vector3, speed_limit: float,
		fade_band: float, brake: float, steer: float) -> Vector3:
	var speed := velocity.length()
	if speed < 0.1:
		return accel
	var direction := velocity / speed
	var along := accel.dot(direction)
	var across := accel - direction * along
	if along < 0.0:
		along *= brake
	else:
		along *= _drive_fade(speed, speed_limit, fade_band)
	return direction * along + across * steer


static func _drive_fade(speed: float, limit: float, band: float) -> float:
	if speed >= limit:
		return 0.0
	var fade_start := limit * (1.0 - band)
	if speed <= fade_start:
		return 1.0
	return (limit - speed) / maxf(limit - fade_start, 1e-3)


func _apply_radius() -> void:
	for child in get_children():
		if child is CollisionShape3D and child.shape is SphereShape3D:
			var shape := (child.shape as SphereShape3D).duplicate() as SphereShape3D
			shape.radius = radius
			child.shape = shape
		elif child is MeshInstance3D and child.mesh is SphereMesh:
			var sphere := (child.mesh as SphereMesh).duplicate() as SphereMesh
			sphere.radius = radius
			sphere.height = radius * 2.0
			child.mesh = sphere
