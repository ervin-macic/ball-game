class_name BallAudio
extends Node
## Rolling rumble that follows speed while the ball is on the ground, and a thud
## on hard landings. Both sounds are synthesised at start-up, so the game ships
## no audio files.

@export var ball: RollingBall
@export var enabled := true
@export_range(-60.0, 12.0, 0.5, "suffix:dB") var max_volume_db := -4.0
## Below this speed the ball is silent; at full_speed the rumble is loudest.
@export_range(0.0, 10.0, 0.1, "suffix:m/s") var silent_speed := 0.4
@export_range(1.0, 100.0, 0.5, "suffix:m/s") var full_speed := 30.0
@export_range(0.1, 2.0, 0.01) var min_pitch := 0.55
@export_range(0.5, 4.0, 0.01) var max_pitch := 1.7
## How quickly the rumble fades in and out (on take-off and landing).
@export_range(1.0, 60.0, 0.5) var fade_sharpness := 14.0

const MIX_RATE := 22050

var _roll: AudioStreamPlayer
var _thud: AudioStreamPlayer
var _level := 0.0


func _ready() -> void:
	_roll = AudioStreamPlayer.new()
	_roll.stream = _rolling_loop()
	_roll.volume_db = -80.0
	add_child(_roll)
	_roll.play()
	_thud = AudioStreamPlayer.new()
	_thud.stream = _thud_sound()
	add_child(_thud)
	ball.landed.connect(_on_landed)


func _process(delta: float) -> void:
	var speed := ball.linear_velocity.length()
	var target := 0.0
	if enabled and ball.is_grounded():
		target = clampf(inverse_lerp(silent_speed, full_speed, speed), 0.0, 1.0)
	_level = lerpf(_level, target, 1.0 - exp(-fade_sharpness * delta))
	_roll.volume_db = linear_to_db(maxf(_level, 0.0001)) + max_volume_db
	_roll.pitch_scale = lerpf(min_pitch, max_pitch, clampf(speed / full_speed, 0.0, 1.25))


func _on_landed(impact_speed: float) -> void:
	if not enabled or impact_speed < 3.0:
		return
	_thud.volume_db = linear_to_db(clampf(impact_speed / 16.0, 0.15, 1.0)) + max_volume_db
	_thud.play()


## A seamless low rumble: brown noise with a slow "surface texture" wobble.
## The loop has no seam at all: the noise filters run twice around the buffer
## (the second lap starts from the state the first one ended in, so the end
## flows into the start exactly), and the wobble completes whole cycles per loop.
## No crossfade, so no dip in level at the loop point.
static func _rolling_loop() -> AudioStreamWAV:
	var seconds := 3.0
	var length := int(MIX_RATE * seconds)
	var rng := RandomNumberGenerator.new()
	rng.seed = 1789
	var white := PackedFloat32Array()
	white.resize(length)
	for i in length:
		white[i] = rng.randf_range(-1.0, 1.0)
	var raw := PackedFloat32Array()
	raw.resize(length)
	var brown := 0.0
	var smooth := 0.0
	for lap in 2:
		for i in length:
			brown = (brown + white[i] * 0.06) * 0.995
			smooth += (brown - smooth) * 0.18
			raw[i] = smooth
	var mean := 0.0
	for value in raw:
		mean += value
	mean /= length
	# 7 and 2.33... Hz rounded to whole cycles over the loop.
	var fast := roundf(7.0 * seconds) / seconds
	var slow := roundf(2.3 * seconds) / seconds
	for i in length:
		var t := float(i) / MIX_RATE
		raw[i] = (raw[i] - mean) * (0.75 + 0.25 * sin(TAU * fast * t) * sin(TAU * slow * t))
	return _to_wav(raw, true)


static func _thud_sound() -> AudioStreamWAV:
	var length := int(MIX_RATE * 0.28)
	var rng := RandomNumberGenerator.new()
	rng.seed = 42
	var raw := PackedFloat32Array()
	raw.resize(length)
	for i in length:
		var t := float(i) / MIX_RATE
		var envelope := exp(-t * 18.0)
		raw[i] = (sin(TAU * 62.0 * t) * 0.8 + rng.randf_range(-1.0, 1.0) * 0.25 * exp(-t * 60.0)) * envelope
	return _to_wav(raw, false)


static func _to_wav(samples: PackedFloat32Array, looping: bool) -> AudioStreamWAV:
	var peak := 0.0001
	for value in samples:
		peak = maxf(peak, absf(value))
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		bytes.encode_s16(i * 2, int(clampf(samples[i] / peak, -1.0, 1.0) * 30000.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = MIX_RATE
	wav.stereo = false
	wav.data = bytes
	if looping:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = samples.size()
	return wav
