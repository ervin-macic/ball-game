class_name AppSuspend
extends Node
## Puts the game to sleep while nobody can see it. Möbius keeps recently used
## apps running out of sight (closing an app's tab only hides it), and the
## browser can hide the whole page; either way the game would carry on
## playing sounds. While hidden it is paused, silent and drawn at a crawl;
## shown again, it picks up exactly where it was (still paused if the menu was
## open). In a party level only the sound goes: the shared race clock can't
## wait, and pausing would stop this player's clock while the others' ran on.
##
## The host page (index.jsx) knows whether the game is showing and offers it
## as `window.ballGameHost.hidden()`. Elsewhere (desktop, tests) [member host]
## is null and the game never sleeps, unless a test hands in its own host.

const WEB_HOST_INTERFACE := "ballGameHost"
## Frames per second drawn while hidden.
const HIDDEN_FPS := 4

@export var race: RaceManager
@export_range(0.05, 2.0, 0.05, "suffix:s") var poll_interval := 0.25

var host: Variant = null
var asleep := false

var _since_poll := 0.0
var _was_paused := false
var _was_muted := false
var _paused_it := false
var _max_fps := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if host == null and OS.has_feature("web"):
		host = JavaScriptBridge.get_interface(WEB_HOST_INTERFACE)
	if host == null:
		set_process(false)


func _process(delta: float) -> void:
	_since_poll += delta
	if _since_poll < poll_interval and not asleep:
		return
	_since_poll = 0.0
	var hidden := bool(host.hidden())
	if hidden and not asleep:
		sleep()
	elif not hidden and asleep:
		wake()


func sleep() -> void:
	asleep = true
	var tree := get_tree()
	_was_paused = tree.paused
	_paused_it = not tree.paused and not (race and race.party_round)
	if _paused_it:
		tree.paused = true
	_was_muted = AudioServer.is_bus_mute(0)
	AudioServer.set_bus_mute(0, true)
	_max_fps = Engine.max_fps
	Engine.max_fps = HIDDEN_FPS


func wake() -> void:
	asleep = false
	if _paused_it:
		get_tree().paused = _was_paused
	_paused_it = false
	AudioServer.set_bus_mute(0, _was_muted)
	Engine.max_fps = _max_fps
