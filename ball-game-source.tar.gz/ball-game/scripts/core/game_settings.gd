class_name GameSettings
extends Node
## Player preferences: edited in the pause menu, saved between sessions, and
## applied to the camera, audio, ghost and HUD.

signal changed

const STORE_KEY := "settings.json"
## Every setting the menu shows, in order. Numbers carry min, max, step and unit.
const SCHEMA := [
	{"key": "camera_distance", "label": "Camera distance", "default": 6.5, "min": 3.0, "max": 14.0, "step": 0.1, "unit": " m"},
	{"key": "camera_pitch", "label": "Camera angle", "default": -13.0, "min": -40.0, "max": 10.0, "step": 1.0, "unit": "°"},
	{"key": "fov", "label": "Field of view", "default": 72.0, "min": 55.0, "max": 100.0, "step": 1.0, "unit": "°"},
	{"key": "speed_fov", "label": "Extra field of view at speed", "default": 16.0, "min": 0.0, "max": 30.0, "step": 1.0, "unit": "°"},
	{"key": "mouse_sensitivity", "label": "Mouse sensitivity", "default": 0.12, "min": 0.02, "max": 0.5, "step": 0.01, "unit": ""},
	{"key": "invert_y", "label": "Invert mouse up/down", "default": false},
	{"key": "auto_orient", "label": "Camera swings behind your travel", "default": true},
	{"key": "volume", "label": "Volume", "default": 70.0, "min": 0.0, "max": 100.0, "step": 1.0, "unit": "%"},
	{"key": "rolling_sound", "label": "Rolling sound", "default": true},
	{"key": "ghost", "label": "Ghost of your best run", "default": true},
	{"key": "split", "label": "Split time against your best", "default": true},
	{"key": "render_scale", "label": "Render resolution", "default": 100.0, "min": 50.0, "max": 100.0, "step": 5.0, "unit": "%"},
	{"key": "adaptive_resolution", "label": "Lower resolution when the game slows", "default": true},
	{"key": "shadows", "label": "Shadows", "default": true},
]

@export var camera: FollowCamera
@export var ball_audio: BallAudio
@export var ghost: GhostBall
@export var hud: RaceHud
## Turn off to keep tests from touching saved settings.
@export var persist := true

var values := {}
var _dirty := false

## Adaptive resolution: while frames take longer than SLOW_FRAME on average,
## the 3D view is drawn at a lower resolution (in steps, down to MIN_SCALE);
## once frames are quick again it climbs back to the Render resolution setting.
## The interface stays sharp either way.
const SLOW_FRAME := 1.0 / 50.0
const QUICK_FRAME := 1.0 / 57.0
const MIN_SCALE := 0.6
const WEB_SHADOW_DISTANCE := 70.0
var _scale := 1.0
var _frame_time := 0.0
var _frames := 0
var _quick_for := 0.0


func _ready() -> void:
	values = defaults()
	if persist:
		var stored: Variant = GameStore.read(STORE_KEY)
		if stored is Dictionary:
			for entry in SCHEMA:
				var key: String = entry["key"]
				if stored.has(key) and typeof(stored[key]) == typeof(entry["default"]):
					values[key] = clampf(stored[key], entry["min"], entry["max"]) if entry.has("min") else stored[key]
	# A level loaded later brings its own sun: give it the shadow setting too.
	# (A method connection goes away with this node; a lambda would outlive it.)
	get_tree().node_added.connect(_on_node_added)
	apply()


func _on_node_added(node: Node) -> void:
	if node is DirectionalLight3D:
		_shade(node as DirectionalLight3D)
	elif node is WorldEnvironment and OS.has_feature("web") and (node as WorldEnvironment).environment:
		# Glow is a multi-pass blur over the whole screen: in the browser its
		# subtle bloom isn't worth the frame time.
		(node as WorldEnvironment).environment.glow_enabled = false


static func defaults() -> Dictionary:
	var result := {}
	for entry in SCHEMA:
		result[entry["key"]] = entry["default"]
	return result


func set_value(key: String, value: Variant) -> void:
	values[key] = value
	_dirty = true
	apply()
	changed.emit()


func reset_to_defaults() -> void:
	values = defaults()
	_dirty = true
	apply()
	changed.emit()


## Writes pending changes. The menu calls this when it closes, so dragging a
## slider doesn't write storage on every step.
func save() -> void:
	if persist and _dirty:
		GameStore.write(STORE_KEY, values)
	_dirty = false


func _process(delta: float) -> void:
	if not values.get("adaptive_resolution", false) or get_tree().paused:
		return
	_frame_time += delta
	_frames += 1
	if _frame_time < 0.5:
		return
	var average := _frame_time / _frames
	var window := _frame_time
	_frame_time = 0.0
	_frames = 0
	var ceiling: float = values["render_scale"] / 100.0
	var target := _scale
	if average > SLOW_FRAME:
		_quick_for = 0.0
		target = maxf(_scale - 0.08, minf(MIN_SCALE, ceiling))
	elif average < QUICK_FRAME:
		_quick_for += window
		if _quick_for >= 2.0:
			_quick_for = 0.0
			target = minf(_scale + 0.05, ceiling)
	else:
		_quick_for = 0.0
	if not is_equal_approx(target, _scale):
		_scale = target
		get_viewport().scaling_3d_scale = _scale


func apply() -> void:
	if camera:
		camera.distance = values["camera_distance"]
		camera.default_pitch = values["camera_pitch"]
		camera.base_fov = values["fov"]
		camera.max_fov = values["fov"] + values["speed_fov"]
		camera.mouse_sensitivity = values["mouse_sensitivity"]
		camera.invert_y = values["invert_y"]
		camera.auto_orient = values["auto_orient"]
	var volume: float = values["volume"] / 100.0
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.0001)))
	AudioServer.set_bus_mute(0, volume <= 0.0)
	if ball_audio:
		ball_audio.enabled = values["rolling_sound"]
	if ghost:
		ghost.enabled = values["ghost"]
	if hud:
		hud.show_split = values["split"]
	# Graphics: fewer pixels and no shadow pass are the two big savings on
	# slower machines and in the browser.
	var viewport := get_viewport()
	if viewport:
		viewport.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
		viewport.scaling_3d_scale = values["render_scale"] / 100.0
		_scale = viewport.scaling_3d_scale
	for light in get_tree().root.find_children("*", "DirectionalLight3D", true, false):
		_shade(light as DirectionalLight3D)


## Shadows on or off; in the browser they reach a little less far (the shadow
## pass redraws everything near the camera, and the fog softens the far end).
func _shade(light: DirectionalLight3D) -> void:
	light.shadow_enabled = values["shadows"]
	if OS.has_feature("web"):
		light.directional_shadow_max_distance = minf(light.directional_shadow_max_distance, WEB_SHADOW_DISTANCE)
