class_name GameSettings
extends Node
## Player preferences: edited in the pause menu, saved between sessions, and
## applied to the camera, audio, ghost and HUD.

signal changed

const STORE_KEY := "settings.json"
## Every setting the menu shows, in order. Numbers carry min, max, step and unit.
const SCHEMA := [
	{"key": "camera_distance", "label": "Camera distance", "default": 6.5, "min": 3.0, "max": 14.0, "step": 0.1, "unit": " m"},
	{"key": "camera_pitch", "label": "Camera angle", "default": -13.0, "min": -40.0, "max": 10.0, "step": 1.0, "unit": "°"},
	{"key": "fov", "label": "Field of view", "default": 72.0, "min": 55.0, "max": 100.0, "step": 1.0, "unit": "°"},
	{"key": "speed_fov", "label": "Extra field of view at speed", "default": 16.0, "min": 0.0, "max": 30.0, "step": 1.0, "unit": "°"},
	{"key": "mouse_sensitivity", "label": "Mouse sensitivity", "default": 0.12, "min": 0.02, "max": 0.5, "step": 0.01, "unit": ""},
	{"key": "invert_y", "label": "Invert mouse up/down", "default": false},
	{"key": "auto_orient", "label": "Camera swings behind your travel", "default": true},
	{"key": "volume", "label": "Volume", "default": 70.0, "min": 0.0, "max": 100.0, "step": 1.0, "unit": "%"},
	{"key": "rolling_sound", "label": "Rolling sound", "default": true},
	{"key": "ghost", "label": "Ghost of your best run", "default": true},
	{"key": "split", "label": "Split time against your best", "default": true},
	{"key": "render_scale", "label": "Render resolution", "default": 100.0, "min": 50.0, "max": 100.0, "step": 5.0, "unit": "%"},
	{"key": "fast_antialiasing", "label": "Faster, rougher edge smoothing", "default": false},
	{"key": "shadows", "label": "Shadows", "default": true},
]

@export var camera: FollowCamera
@export var ball_audio: BallAudio
@export var ghost: GhostBall
@export var hud: RaceHud
## Turn off to keep tests from touching saved settings.
@export var persist := true

var values := {}
var _dirty := false


func _ready() -> void:
	values = defaults()
	if persist:
		var stored: Variant = GameStore.read(STORE_KEY)
		if stored is Dictionary:
			for entry in SCHEMA:
				var key: String = entry["key"]
				if stored.has(key) and typeof(stored[key]) == typeof(entry["default"]):
					values[key] = clampf(stored[key], entry["min"], entry["max"]) if entry.has("min") else stored[key]
	# A level loaded later brings its own sun: give it the shadow setting too.
	# (A method connection goes away with this node; a lambda would outlive it.)
	get_tree().node_added.connect(_on_node_added)
	apply()


func _on_node_added(node: Node) -> void:
	if node is DirectionalLight3D:
		(node as DirectionalLight3D).shadow_enabled = values["shadows"]


static func defaults() -> Dictionary:
	var result := {}
	for entry in SCHEMA:
		result[entry["key"]] = entry["default"]
	return result


func set_value(key: String, value: Variant) -> void:
	values[key] = value
	_dirty = true
	apply()
	changed.emit()


func reset_to_defaults() -> void:
	values = defaults()
	_dirty = true
	apply()
	changed.emit()


## Writes pending changes. The menu calls this when it closes, so dragging a
## slider doesn't write storage on every step.
func save() -> void:
	if persist and _dirty:
		GameStore.write(STORE_KEY, values)
	_dirty = false


func apply() -> void:
	if camera:
		camera.distance = values["camera_distance"]
		camera.default_pitch = values["camera_pitch"]
		camera.base_fov = values["fov"]
		camera.max_fov = values["fov"] + values["speed_fov"]
		camera.mouse_sensitivity = values["mouse_sensitivity"]
		camera.invert_y = values["invert_y"]
		camera.auto_orient = values["auto_orient"]
	var volume: float = values["volume"] / 100.0
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.0001)))
	AudioServer.set_bus_mute(0, volume <= 0.0)
	if ball_audio:
		ball_audio.enabled = values["rolling_sound"]
	if ghost:
		ghost.enabled = values["ghost"]
	if hud:
		hud.show_split = values["split"]
	# Graphics: fewer pixels and no shadow pass are the two big savings on
	# slower machines and in the browser.
	var viewport := get_viewport()
	if viewport:
		viewport.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
		viewport.scaling_3d_scale = values["render_scale"] / 100.0
		# Off (the default): the project's own multisampling, untouched. On: a
		# cheaper screen-space pass instead, rougher but quicker on slow machines.
		if values["fast_antialiasing"]:
			viewport.msaa_3d = Viewport.MSAA_DISABLED
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
		else:
			viewport.msaa_3d = int(ProjectSettings.get_setting("rendering/anti_aliasing/quality/msaa_3d", Viewport.MSAA_DISABLED)) as Viewport.MSAA
			viewport.screen_space_aa = int(ProjectSettings.get_setting("rendering/anti_aliasing/quality/screen_space_aa", Viewport.SCREEN_SPACE_AA_DISABLED)) as Viewport.ScreenSpaceAA
	for light in get_tree().root.find_children("*", "DirectionalLight3D", true, false):
		(light as DirectionalLight3D).shadow_enabled = values["shadows"]
