class_name GameSettings
extends Node
## Player preferences: edited in the pause menu, saved between sessions, and
## applied to the camera, touch controls, audio, ghost, HUD and graphics.
##
## Phones and tablets keep their own copy (TOUCH_STORE_KEY): app storage is
## shared by all of a player's devices, and a phone's lighter graphics or
## touch look speed shouldn't follow them back to their desktop. How the
## camera frames the ball ("shared" in SCHEMA) is the player's own wherever
## they play, though: it stays with the desktop's settings (STORE_KEY), and
## phones read and change it there.

signal changed

const STORE_KEY := "settings.json"
const TOUCH_STORE_KEY := "settings_touch.json"
## Every setting the menu shows, in order. Numbers carry min, max, step and
## unit, and "touch_step", what one tap of − or + changes them by on a touch
## screen. "only" shows a setting on touch-first devices or desktops alone,
## "touch_label" renames it on touch-first ones, and "touch_default" is its
## default there. "shared" ones are the same on every device (STORE_KEY).
const SCHEMA := [
	{"key": "camera_distance", "label": "Camera distance", "default": 6.5, "min": 3.0, "max": 14.0, "step": 0.1, "touch_step": 0.5, "unit": " m", "shared": true},
	{"key": "camera_pitch", "label": "Camera angle", "default": -13.0, "min": -40.0, "max": 10.0, "step": 1.0, "touch_step": 2.0, "unit": "°", "shared": true},
	{"key": "fov", "label": "Field of view", "default": 72.0, "min": 55.0, "max": 100.0, "step": 1.0, "touch_step": 2.0, "unit": "°", "shared": true},
	{"key": "speed_fov", "label": "Extra field of view at speed", "default": 16.0, "min": 0.0, "max": 30.0, "step": 1.0, "touch_step": 2.0, "unit": "°", "shared": true},
	{"key": "mouse_sensitivity", "label": "Mouse sensitivity", "default": 0.12, "min": 0.02, "max": 0.5, "step": 0.01, "unit": "", "only": "desktop"},
	{"key": "touch_look_sensitivity", "label": "Look speed when dragging", "default": 0.3, "min": 0.05, "max": 1.0, "step": 0.01, "touch_step": 0.05, "unit": "", "only": "touch"},
	{"key": "invert_y", "label": "Invert mouse up/down", "touch_label": "Invert look up/down", "default": false},
	{"key": "auto_orient", "label": "Camera swings behind your travel", "default": true},
	{"key": "volume", "label": "Volume", "default": 70.0, "min": 0.0, "max": 100.0, "step": 1.0, "touch_step": 10.0, "unit": "%"},
	{"key": "rolling_sound", "label": "Rolling sound", "default": true},
	{"key": "ghost", "label": "Ghost of your best run", "default": true},
	{"key": "split", "label": "Split time against your best", "default": true},
	{"key": "render_scale", "label": "Render resolution", "default": 100.0, "min": 50.0, "max": 100.0, "step": 5.0, "touch_step": 5.0, "unit": "%"},
	{"key": "fast_antialiasing", "label": "Faster, rougher edge smoothing", "default": false},
	{"key": "shadows", "label": "Shadows", "default": true, "touch_default": false},
	{"key": "phone_graphics", "label": "Lighter graphics for phones", "default": false, "touch_default": true},
]

## Lighter graphics (phone_graphics) draw the 3D view with at most this many
## pixels: a phone's screen has three or more for every one of a desktop's,
## and filling them all is what costs.
const LIGHT_PIXELS := 800000.0
## ...and in a browser the whole game with at most this many (ScreenFit.
## limit_pixels): each frame is copied across the whole screen several times
## on its way to the display, at a phone's full density more memory traffic
## than the 3D view itself. Menus and text stay as big, a little softer.
const LIGHT_CANVAS_PIXELS := 1400000.0
## Scenery that fades out with distance does so at this share of its usual
## distance. Nothing the ball can reach is ever left out: whatever is near the
## camera, and so near the ball, is drawn.
const LIGHT_VIEW_DISTANCE := 0.55
## Share of the purely decorative props (plants, grass, flowers: nothing the
## ball can hit; PropScatter marks their batches DECORATIVE_META) drawn.
const LIGHT_DECORATION_SHARE := 0.5
## (Here rather than on PropScatter: this script is compiled at start-up, and
## PropScatter needs a shader that only the levels' downloads carry.)
const DECORATIVE_META := &"decorative"
## Share of each particle effect's particles (spray, snow, smoke).
const LIGHT_PARTICLE_SHARE := 0.5
## Shadows reach this share of the level's usual distance (at least
## LIGHT_MIN_SHADOW_DISTANCE m), in two cascades at most.
const LIGHT_SHADOW_DISTANCE := 0.6
const LIGHT_MIN_SHADOW_DISTANCE := 36.0
## Models switch to their simpler versions this many times sooner.
const LIGHT_LOD_THRESHOLD := 2.0
## Phones with fast screens draw 60 frames a second rather than 90 or 120.
## Physics still steps 120 times a second either way.
const LIGHT_MAX_FPS := 60
const FULL_RANGE_META := &"full_view_range"
## Set pieces seen from all over a level but only ever reached at one end of
## it (the winter cabin past the finish) carry this meta, a distance in
## metres: full graphics draw them from anywhere, lighter graphics only within
## that distance. Their collision is always there, and they are drawn well
## before the ball can get near.
const LIGHT_RANGE_META := &"light_view_range"
const FULL_SUN_META := &"full_shadow_reach"
const FULL_TRANSPARENCY_META := &"full_transparency"
const FULL_NORMAL_META := &"full_normal_map"
## Shaders with a bool uniform of this name have a lighter version of their
## own (the ground's: one texture read where there are four or more).
const LIGHTER_UNIFORM := &"lighter"
const FULL_GLOW_META := &"full_glow"
const FULL_AMOUNT_META := &"full_amount"

@export var camera: FollowCamera
@export var ball_audio: BallAudio
@export var ghost: GhostBall
@export var hud: RaceHud
## Takes the touch look speed.
@export var touch: TouchControls
## Says whether this is a phone or tablet (its own settings and defaults).
@export var fit: ScreenFit
## Lighter graphics also download the levels' lighter packs (smaller
## textures); levels it loads get the shorter view and shadow distances.
@export var levels: LevelLoader
## Turn off to keep tests from touching saved settings.
@export var persist := true

var values := {}
var _dirty := false
var _scene_light := false


func _ready() -> void:
	values = defaults()
	if persist:
		var own: Variant = GameStore.read(store_key())
		var shared: Variant = GameStore.read(STORE_KEY)
		for entry in SCHEMA:
			var stored: Variant = shared if entry.get("shared", false) else own
			var key: String = entry["key"]
			if stored is Dictionary and stored.has(key) and typeof(stored[key]) == typeof(entry["default"]):
				values[key] = clampf(stored[key], entry["min"], entry["max"]) if entry.has("min") else stored[key]
	# A level loaded later brings its own sun: give it the shadow setting too.
	# (A method connection goes away with this node; a lambda would outlive it.)
	get_tree().node_added.connect(_on_node_added)
	if levels:
		levels.changed.connect(_on_level_changed)
	get_viewport().size_changed.connect(_fit_resolution)
	apply()


func _on_node_added(node: Node) -> void:
	if node is DirectionalLight3D:
		(node as DirectionalLight3D).shadow_enabled = values["shadows"]


func _on_level_changed(level: Level) -> void:
	fit_scene(level, values["phone_graphics"])


func is_touch_first() -> bool:
	return fit != null and fit.is_touch_first()


func store_key() -> String:
	return TOUCH_STORE_KEY if is_touch_first() else STORE_KEY


func defaults() -> Dictionary:
	return defaults_for(is_touch_first())


static func defaults_for(touch_first: bool) -> Dictionary:
	var result := {}
	for entry in SCHEMA:
		result[entry["key"]] = entry.get("touch_default", entry["default"]) if touch_first else entry["default"]
	return result


## Whether the menu shows [param entry] on this kind of device.
static func shown(entry: Dictionary, touch_first: bool) -> bool:
	var only := str(entry.get("only", ""))
	return only.is_empty() or only == ("touch" if touch_first else "desktop")


static func label_for(entry: Dictionary, touch_first: bool) -> String:
	return str(entry.get("touch_label", entry["label"])) if touch_first else str(entry["label"])


func set_value(key: String, value: Variant) -> void:
	values[key] = value
	_dirty = true
	apply()
	changed.emit()


func reset_to_defaults() -> void:
	values = defaults()
	_dirty = true
	apply()
	changed.emit()


## Writes pending changes. The menu calls this when it closes, so dragging a
## slider doesn't write storage on every step.
func save() -> void:
	if persist and _dirty:
		if store_key() == STORE_KEY:
			GameStore.write(STORE_KEY, values)
		else:
			# The phone's own settings, and the shared ones in with the
			# desktop's (whose own settings stay as they are).
			var own := {}
			var stored: Variant = GameStore.read(STORE_KEY)
			var shared: Dictionary = stored if stored is Dictionary else {}
			for entry in SCHEMA:
				var key: String = entry["key"]
				if entry.get("shared", false):
					shared[key] = values[key]
				else:
					own[key] = values[key]
			GameStore.write(store_key(), own)
			GameStore.write(STORE_KEY, shared)
	_dirty = false


func apply() -> void:
	if camera:
		camera.distance = values["camera_distance"]
		camera.default_pitch = values["camera_pitch"]
		camera.base_fov = values["fov"]
		camera.max_fov = values["fov"] + values["speed_fov"]
		camera.mouse_sensitivity = values["mouse_sensitivity"]
		camera.invert_y = values["invert_y"]
		camera.auto_orient = values["auto_orient"]
	if touch:
		touch.look_sensitivity = values["touch_look_sensitivity"]
	var volume: float = values["volume"] / 100.0
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.0001)))
	AudioServer.set_bus_mute(0, volume <= 0.0)
	if ball_audio:
		ball_audio.enabled = values["rolling_sound"]
	if ghost:
		ghost.enabled = values["ghost"]
	if hud:
		hud.show_split = values["split"]
	# Graphics: fewer pixels and no shadow pass are the two big savings on
	# slower machines and in the browser.
	var light: bool = values["phone_graphics"]
	_fit_resolution()
	var viewport := get_viewport()
	if viewport:
		var lod_threshold := float(ProjectSettings.get_setting("rendering/mesh_lod/lod_change/threshold_pixels", 1.0))
		viewport.mesh_lod_threshold = lod_threshold * (LIGHT_LOD_THRESHOLD if light else 1.0)
		# Off (the default): the project's own multisampling, untouched. On: a
		# cheaper screen-space pass instead, rougher but quicker on slow machines.
		if values["fast_antialiasing"]:
			viewport.msaa_3d = Viewport.MSAA_DISABLED
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
		else:
			viewport.msaa_3d = int(ProjectSettings.get_setting("rendering/anti_aliasing/quality/msaa_3d", Viewport.MSAA_DISABLED)) as Viewport.MSAA
			viewport.screen_space_aa = int(ProjectSettings.get_setting("rendering/anti_aliasing/quality/screen_space_aa", Viewport.SCREEN_SPACE_AA_DISABLED)) as Viewport.ScreenSpaceAA
	Engine.max_fps = LIGHT_MAX_FPS if light else int(ProjectSettings.get_setting("application/run/max_fps", 0))
	if levels:
		levels.light_textures = light
	if light != _scene_light:
		fit_scene(get_tree().root, light)
	for sun in get_tree().root.find_children("*", "DirectionalLight3D", true, false):
		(sun as DirectionalLight3D).shadow_enabled = values["shadows"]


## The 3D view's resolution: the render resolution setting, and with lighter
## graphics no more than LIGHT_PIXELS (again whenever the window resizes).
func _fit_resolution() -> void:
	var viewport := get_viewport()
	if viewport == null or values.is_empty():
		return
	if fit:
		fit.limit_pixels(LIGHT_CANVAS_PIXELS if values["phone_graphics"] else 0.0)
	var scale: float = values["render_scale"] / 100.0
	if values["phone_graphics"]:
		scale = minf(scale, light_resolution_scale(Vector2(get_tree().root.size)))
	viewport.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
	viewport.scaling_3d_scale = scale


## The share of [param pixels] (a screen's size) lighter graphics draw the
## 3D view at, each way.
static func light_resolution_scale(pixels: Vector2) -> float:
	var count := pixels.x * pixels.y
	if count <= LIGHT_PIXELS:
		return 1.0
	return clampf(sqrt(LIGHT_PIXELS / count), 0.35, 1.0)


## Gives everything under [param root] lighter graphics ([param light]) or
## the full ones, which it remembers: view and shadow distances, how many of
## the decorative props are drawn, leaves drawn in one pass (cut out rather than
## soft-edged after a depth pass), surfaces without their relief maps and
## shaders' own lighter versions, no glow, fewer particles.
func fit_scene(root: Node, light: bool) -> void:
	if root == get_tree().root:
		_scene_light = light
	var materials := {}
	for node in root.find_children("*", "GeometryInstance3D", true, false):
		var geometry := node as GeometryInstance3D
		_fit_view_range(geometry, light)
		var view := geometry as MultiMeshInstance3D
		if view and view.multimesh and view.has_meta(DECORATIVE_META):
			view.multimesh.visible_instance_count = ceili(view.multimesh.instance_count * LIGHT_DECORATION_SHARE) if light else -1
		var particles := geometry as CPUParticles3D
		if particles:
			_fit_particles(particles, light)
		for material in _materials_of(geometry):
			materials[material] = true
	for material: Material in materials:
		_fit_material(material, light)
	for sun in root.find_children("*", "DirectionalLight3D", true, false):
		_fit_sun(sun as DirectionalLight3D, light)
	for world in root.find_children("*", "WorldEnvironment", true, false):
		var environment := (world as WorldEnvironment).environment
		if environment:
			if not environment.has_meta(FULL_GLOW_META):
				environment.set_meta(FULL_GLOW_META, environment.glow_enabled)
			environment.glow_enabled = bool(environment.get_meta(FULL_GLOW_META)) and not light


static func _materials_of(geometry: GeometryInstance3D) -> Array[Material]:
	var found: Array[Material] = []
	if geometry.material_override:
		found.append(geometry.material_override)
	var mesh: Mesh = null
	if geometry is MeshInstance3D:
		var instance := geometry as MeshInstance3D
		mesh = instance.mesh
		if mesh:
			for i in mesh.get_surface_count():
				if instance.get_surface_override_material(i):
					found.append(instance.get_surface_override_material(i))
	elif geometry is MultiMeshInstance3D and (geometry as MultiMeshInstance3D).multimesh:
		mesh = (geometry as MultiMeshInstance3D).multimesh.mesh
	if mesh:
		for i in mesh.get_surface_count():
			if mesh.surface_get_material(i):
				found.append(mesh.surface_get_material(i))
	return found


## Leaves and other soft-edged cut-outs are drawn twice (a depth pass, then
## soft edges); lighter graphics cut them out in one. Relief (normal) maps
## cost every pixel another texture read and more lighting maths, for detail a
## phone's small screen hardly shows: lighter graphics leave them off. Shaders
## with a lighter version of their own (LIGHTER_UNIFORM) switch to it.
static func _fit_material(material: Material, light: bool) -> void:
	var shader_material := material as ShaderMaterial
	if shader_material:
		if shader_material.shader and _has_uniform(shader_material.shader, LIGHTER_UNIFORM):
			shader_material.set_shader_parameter(LIGHTER_UNIFORM, light)
		return
	var base := material as BaseMaterial3D
	if base == null:
		return
	if not base.has_meta(FULL_NORMAL_META):
		base.set_meta(FULL_NORMAL_META, base.normal_enabled)
	var normal_map: bool = bool(base.get_meta(FULL_NORMAL_META)) and not light
	if base.normal_enabled != normal_map:
		base.normal_enabled = normal_map
	if not base.has_meta(FULL_TRANSPARENCY_META):
		if base.transparency != BaseMaterial3D.TRANSPARENCY_ALPHA_DEPTH_PRE_PASS:
			return
		base.set_meta(FULL_TRANSPARENCY_META, base.transparency)
	base.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR if light else int(base.get_meta(FULL_TRANSPARENCY_META)) as BaseMaterial3D.Transparency


static func _has_uniform(shader: Shader, uniform: StringName) -> bool:
	for entry: Dictionary in shader.get_shader_uniform_list():
		if StringName(entry["name"]) == uniform:
			return true
	return false


static func _fit_particles(particles: CPUParticles3D, light: bool) -> void:
	if not particles.has_meta(FULL_AMOUNT_META):
		particles.set_meta(FULL_AMOUNT_META, particles.amount)
	var full: int = particles.get_meta(FULL_AMOUNT_META)
	var wanted := maxi(1, roundi(full * LIGHT_PARTICLE_SHARE)) if light else full
	if particles.amount != wanted:
		particles.amount = wanted


static func _fit_view_range(geometry: GeometryInstance3D, light: bool) -> void:
	if geometry.has_meta(LIGHT_RANGE_META):
		var reach: float = geometry.get_meta(LIGHT_RANGE_META)
		geometry.visibility_range_end = reach if light else 0.0
		geometry.visibility_range_end_margin = reach * 0.1 if light else 0.0
		return
	if not geometry.has_meta(FULL_RANGE_META):
		if geometry.visibility_range_begin <= 0.0 and geometry.visibility_range_end <= 0.0:
			return
		geometry.set_meta(FULL_RANGE_META, PackedFloat32Array([geometry.visibility_range_begin, geometry.visibility_range_begin_margin,
			geometry.visibility_range_end, geometry.visibility_range_end_margin]))
	var full: PackedFloat32Array = geometry.get_meta(FULL_RANGE_META)
	var share := LIGHT_VIEW_DISTANCE if light else 1.0
	geometry.visibility_range_begin = full[0] * share
	geometry.visibility_range_begin_margin = full[1] * share
	geometry.visibility_range_end = full[2] * share
	geometry.visibility_range_end_margin = full[3] * share


static func _fit_sun(sun: DirectionalLight3D, light: bool) -> void:
	if not sun.has_meta(FULL_SUN_META):
		sun.set_meta(FULL_SUN_META, [sun.directional_shadow_mode, sun.directional_shadow_max_distance])
	var full: Array = sun.get_meta(FULL_SUN_META)
	if light:
		sun.directional_shadow_mode = mini(full[0], DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS) as DirectionalLight3D.ShadowMode
		sun.directional_shadow_max_distance = minf(full[1], maxf(full[1] * LIGHT_SHADOW_DISTANCE, LIGHT_MIN_SHADOW_DISTANCE))
	else:
		sun.directional_shadow_mode = full[0]
		sun.directional_shadow_max_distance = full[1]
