class_name PerfReport
extends Node
## How smoothly runs play on a player's own machine, for looking into lag: the
## first two runs of each level in a session (the first may still meet new
## scenery; the second shows the settled frame rate) report through the host
## page (index.jsx, window.ballGameHost.run_perf) once each run ends: the frame
## rate, how many frames ran long, where along the track they were, and how
## long the engine spent drawing each frame. The page adds how long the engine
## worked on each frame in all (engine_ms, engine_long), so frames that ran
## long while the engine wasn't busy point at the graphics card.

const PAGE_INTERFACE := "ballGameHost"
const RUNS_PER_LEVEL := 2
## Shorter runs (a quick restart off the line) say little.
const MIN_SECONDS := 3.0
## A frame this long missed at least one refresh of a 60 Hz screen.
const LONG_FRAME := 0.025
## Long frames are counted per stretch of track this long.
const STRETCH := 50
## The slowest frames listed individually (where, how long, drawing time).
const LISTED := 20

@export var race: RaceManager
@export var levels: LevelLoader

## The host page's interface (index.jsx, window.ballGameHost): none outside a
## browser, unless a test hands in its own through listen().
var _page: Variant = null
var _viewport: RID
var _reported := {}
var _running := false
var _level := ""
var _frames := 0
var _seconds := 0.0
var _long := 0
var _slow := 0
var _very_slow := 0
var _worst := 0.0
var _drawing := PackedFloat32Array()
var _long_at := {}
var _slowest: Array = []


func _ready() -> void:
	set_process(false)
	if OS.has_feature("web"):
		var page: Variant = JavaScriptBridge.get_interface(PAGE_INTERFACE)
		if page != null:
			listen(page)


## Starts reporting runs to [param page] (run_started(), run_perf(json)).
func listen(page: Variant) -> void:
	_page = page
	_viewport = get_viewport().get_viewport_rid()
	RenderingServer.viewport_set_measure_render_time(_viewport, true)
	if not race.state_changed.is_connected(_on_state_changed):
		race.state_changed.connect(_on_state_changed)


func _process(delta: float) -> void:
	_frames += 1
	_seconds += delta
	_worst = maxf(_worst, delta)
	# The engine's time drawing the last frame: finding what's in view and
	# handing it to the graphics card (milliseconds).
	var drawing := RenderingServer.viewport_get_measured_render_time_cpu(_viewport) + RenderingServer.get_frame_setup_time_cpu()
	_drawing.append(drawing)
	if delta <= LONG_FRAME:
		return
	_long += 1
	if delta > 1.0 / 30.0:
		_slow += 1
	if delta > 1.0 / 15.0:
		_very_slow += 1
	var stretch := int(race.progress) / STRETCH * STRETCH
	_long_at[stretch] = _long_at.get(stretch, 0) + 1
	_slowest.append([roundi(race.progress), roundi(delta * 1000.0), snappedf(drawing, 0.1)])
	if _slowest.size() > LISTED * 4:
		_keep_slowest()


func _keep_slowest() -> void:
	_slowest.sort_custom(func(a: Array, b: Array) -> bool: return a[1] > b[1])
	_slowest.resize(mini(_slowest.size(), LISTED))


func _on_state_changed(state: RaceManager.State) -> void:
	if state == RaceManager.State.RUNNING:
		_start()
	elif _running:
		# The run is over: finished, restarted, sent back to the start or
		# left for another level.
		_running = false
		set_process(false)
		_report(state == RaceManager.State.FINISHED)


func _start() -> void:
	_running = true
	_level = levels.level_id if levels else race.track_id
	_frames = 0
	_seconds = 0.0
	_long = 0
	_slow = 0
	_very_slow = 0
	_worst = 0.0
	_drawing.clear()
	_long_at.clear()
	_slowest.clear()
	_page.run_started()
	set_process(true)


## Signals carry flat values only (text, numbers, true/false; at most 20), so
## the lists go as text: drawing_ms "median/95th percentile/max",
## long_frames_at "metres along the track:long frames there" by stretch, and
## slowest "metres:frame ms/drawing ms" for each of the slowest frames.
func _report(finished: bool) -> void:
	var count: int = _reported.get(_level, 0)
	if _seconds < MIN_SECONDS or count >= RUNS_PER_LEVEL:
		return
	_reported[_level] = count + 1
	_keep_slowest()
	var drawing := _drawing.duplicate()
	drawing.sort()
	var stretches := _long_at.keys()
	stretches.sort_custom(func(a: int, b: int) -> bool: return _long_at[a] > _long_at[b])
	var long_at := PackedStringArray()
	for stretch in stretches.slice(0, 12):
		long_at.append("%d:%d" % [stretch, _long_at[stretch]])
	var slowest := PackedStringArray()
	for frame: Array in _slowest:
		slowest.append("%d:%d/%.1f" % frame)
	var size := get_viewport().get_visible_rect().size
	_page.run_perf(JSON.stringify({
		"level": _level, "run": count + 1, "finished": finished,
		"seconds": snappedf(_seconds, 0.1), "fps": snappedf(_frames / _seconds, 0.1),
		"long_frames": _long, "slow_frames": _slow, "very_slow_frames": _very_slow,
		"worst_ms": roundi(_worst * 1000.0),
		"drawing_ms": "%.1f/%.1f/%.1f" % [_at(drawing, 0.5), _at(drawing, 0.95), _at(drawing, 1.0)],
		"long_frames_at": " ".join(long_at), "slowest": " ".join(slowest),
		"size": "%dx%d" % [size.x, size.y],
	}))


static func _at(sorted: PackedFloat32Array, share: float) -> float:
	if sorted.is_empty():
		return 0.0
	return snappedf(sorted[mini(int(sorted.size() * share), sorted.size() - 1)], 0.1)
