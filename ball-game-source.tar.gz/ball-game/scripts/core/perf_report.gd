class_name PerfReport
extends Node
## How smoothly runs play on a player's own machine, for looking into lag: the
## first two runs of each level in a session (the first may still meet new
## scenery; the second shows the settled frame rate) report through the host
## page (index.jsx, window.ballGameHost.run_perf) once each run ends: the frame
## rate, how many frames ran long, where along the track they were, and how
## long the engine spent drawing each frame. The page adds how long the engine
## worked on each frame in all (engine_ms, engine_long), so frames that ran
## long while the engine wasn't busy point at the graphics card. Each report
## also says how big the window was in screen pixels, the share of that the 3D
## view was drawn at (lighter graphics draw phones' views smaller) and whether
## the touch controls were up, and where the engine's own time went ("cpu"):
## the longest physics step and the scripts' frame in each second (the
## engine keeps the worst of each second), and physics steps per frame. Physics
## steps 120 times a second, so a frame that takes long has to catch up with
## more of them: the number to watch on phones. A run the player leaves by
## putting the game out of sight (another app, the phone's home screen, or
## closing it) is reported then, as far as it went: on phones that is how most
## runs end. Back in sight, the rest of the run counts as a new one. (Möbius
## hiding the app says so through AppSuspend; the browser hiding the whole page
## stops the game outright, so the page tells it: on_visibility.)

const PAGE_INTERFACE := "ballGameHost"
const RUNS_PER_LEVEL := 2
## Shorter runs (a quick restart off the line) say little.
const MIN_SECONDS := 3.0
## A frame this long missed at least one refresh of a 60 Hz screen.
const LONG_FRAME := 0.025
## Long frames are counted per stretch of track this long.
const STRETCH := 50
## The slowest frames listed individually (where, how long, drawing time).
const LISTED := 20

@export var race: RaceManager
@export var levels: LevelLoader
@export var touch: TouchControls
## Says when the game goes out of sight and comes back.
@export var suspend: AppSuspend
## How the camera followed the ball through the run ("camera"): the share of
## the time the player's own look input held the view, and how far the view
## was turned from the ball's travel.
@export var camera: FollowCamera

## The host page's interface (index.jsx, window.ballGameHost): none outside a
## browser, unless a test hands in its own through listen().
var _page: Variant = null
var _viewport: RID
var _reported := {}
var _running := false
var _level := ""
var _frames := 0
var _seconds := 0.0
var _long := 0
var _slow := 0
var _very_slow := 0
var _worst := 0.0
var _drawing := PackedFloat32Array()
var _long_at := {}
var _slowest: Array = []
var _physics := PackedFloat32Array()
var _scripts := PackedFloat32Array()
var _steps := PackedInt32Array()
var _physics_frames := 0
var _visibility_callback: JavaScriptObject
var _held := 0
var _off_travel := PackedFloat32Array()


func _ready() -> void:
	set_process(false)
	if OS.has_feature("web"):
		var page: Variant = JavaScriptBridge.get_interface(PAGE_INTERFACE)
		if page != null:
			listen(page)
			# A browser stops drawing a page it hides (a phone's home screen,
			# another app), so nothing in the game runs to notice: the page
			# says so itself.
			if page.on_visibility != null:
				_visibility_callback = JavaScriptBridge.create_callback(_on_page_visibility)
				page.on_visibility(_visibility_callback)


## Starts reporting runs to [param page] (run_started(), run_perf(json)).
func listen(page: Variant) -> void:
	_page = page
	_viewport = get_viewport().get_viewport_rid()
	RenderingServer.viewport_set_measure_render_time(_viewport, true)
	if not race.state_changed.is_connected(_on_state_changed):
		race.state_changed.connect(_on_state_changed)
	if suspend and not suspend.slept.is_connected(_on_slept):
		suspend.slept.connect(_on_slept)
		suspend.woke.connect(_on_woke)


func _process(delta: float) -> void:
	_frames += 1
	_seconds += delta
	_worst = maxf(_worst, delta)
	# The engine's time drawing the last frame: finding what's in view and
	# handing it to the graphics card (milliseconds).
	var drawing := RenderingServer.viewport_get_measured_render_time_cpu(_viewport) + RenderingServer.get_frame_setup_time_cpu()
	_drawing.append(drawing)
	_physics.append(Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0)
	_scripts.append(Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0)
	var physics_frames := Engine.get_physics_frames()
	_steps.append(physics_frames - _physics_frames)
	_physics_frames = physics_frames
	if camera:
		if camera.is_holding_view():
			_held += 1
		var off := camera.off_travel()
		if off >= 0.0:
			_off_travel.append(off)
	if delta <= LONG_FRAME:
		return
	_long += 1
	if delta > 1.0 / 30.0:
		_slow += 1
	if delta > 1.0 / 15.0:
		_very_slow += 1
	var stretch := int(race.progress) / STRETCH * STRETCH
	_long_at[stretch] = _long_at.get(stretch, 0) + 1
	_slowest.append([roundi(race.progress), roundi(delta * 1000.0), snappedf(drawing, 0.1)])
	if _slowest.size() > LISTED * 4:
		_keep_slowest()


func _keep_slowest() -> void:
	_slowest.sort_custom(func(a: Array, b: Array) -> bool: return a[1] > b[1])
	_slowest.resize(mini(_slowest.size(), LISTED))


func _on_state_changed(state: RaceManager.State) -> void:
	if state == RaceManager.State.RUNNING:
		_start()
	elif _running:
		# The run is over: finished, restarted, sent back to the start or
		# left for another level.
		_running = false
		set_process(false)
		_report(state == RaceManager.State.FINISHED)


## Out of sight: the run so far is reported (the player may never come back),
## and nothing is measured while hidden.
func _on_slept() -> void:
	if _running:
		_running = false
		set_process(false)
		_report(false)


## Back in sight mid-run: the rest of it is measured as a run of its own.
func _on_woke() -> void:
	if not _running and race.state == RaceManager.State.RUNNING:
		_start()


## The page went out of sight ([param args][0] true) or came back.
func _on_page_visibility(args: Array) -> void:
	if args.is_empty():
		return
	if bool(args[0]):
		_on_slept()
	else:
		_on_woke()


func _start() -> void:
	_running = true
	_level = levels.level_id if levels else race.track_id
	_frames = 0
	_seconds = 0.0
	_long = 0
	_slow = 0
	_very_slow = 0
	_worst = 0.0
	_drawing.clear()
	_physics.clear()
	_scripts.clear()
	_steps.clear()
	_held = 0
	_off_travel.clear()
	_physics_frames = Engine.get_physics_frames()
	_long_at.clear()
	_slowest.clear()
	_page.run_started()
	set_process(true)


## Signals carry flat values only (text, numbers, true/false; at most 20), so
## the lists go as text: drawing_ms "median/95th percentile/max",
## long_frames_at "metres along the track:long frames there" by stretch, and
## slowest "metres:frame ms/drawing ms" for each of the slowest frames.
func _report(finished: bool) -> void:
	var count: int = _reported.get(_level, 0)
	if _seconds < MIN_SECONDS or count >= RUNS_PER_LEVEL:
		return
	_reported[_level] = count + 1
	_keep_slowest()
	var drawing := _drawing.duplicate()
	drawing.sort()
	var stretches := _long_at.keys()
	stretches.sort_custom(func(a: int, b: int) -> bool: return _long_at[a] > _long_at[b])
	var long_at := PackedStringArray()
	for stretch in stretches.slice(0, 12):
		long_at.append("%d:%d" % [stretch, _long_at[stretch]])
	var slowest := PackedStringArray()
	for frame: Array in _slowest:
		slowest.append("%d:%d/%.1f" % frame)
	var size := get_tree().root.size
	_page.run_perf(JSON.stringify({
		"level": _level, "run": count + 1, "finished": finished,
		"seconds": snappedf(_seconds, 0.1), "fps": snappedf(_frames / _seconds, 0.1),
		"long_frames": _long, "slow_frames": _slow, "very_slow_frames": _very_slow,
		"worst_ms": roundi(_worst * 1000.0),
		"drawing_ms": "%.1f/%.1f/%.1f" % [_at(drawing, 0.5), _at(drawing, 0.95), _at(drawing, 1.0)],
		"long_frames_at": " ".join(long_at), "slowest": " ".join(slowest),
		"size": "%dx%d" % [size.x, size.y],
		"render_scale": snappedf(get_viewport().scaling_3d_scale, 0.01),
		"touch": touch != null and touch.active,
		"cpu": cpu_summary(_physics, _scripts, _steps),
		"camera": camera_summary(_held, _frames, _off_travel),
	}))


## "held 3% · off travel 4/12°": the share of frames the player's look input
## held the view, and how far the view was turned from the ball's travel
## (median/95th percentile, where the ball was moving and not on a loop).
static func camera_summary(held: int, frames: int, off_travel: PackedFloat32Array) -> String:
	var sorted := off_travel.duplicate()
	sorted.sort()
	return "held %d%% · off travel %.0f/%.0f°" % [roundi(100.0 * held / maxi(frames, 1)), _at(sorted, 0.5), _at(sorted, 0.95)]


## "physics 4.1/6.3 · steps 2.0/4 · scripts 1.2/2.0": the physics step and
## scripts milliseconds (median/max of the per-second worst), and physics steps
## per frame (mean/most).
static func cpu_summary(physics: PackedFloat32Array, scripts: PackedFloat32Array, steps: PackedInt32Array) -> String:
	var physics_sorted := physics.duplicate()
	physics_sorted.sort()
	var scripts_sorted := scripts.duplicate()
	scripts_sorted.sort()
	var total := 0
	var most := 0
	for n in steps:
		total += n
		most = maxi(most, n)
	return "physics %.1f/%.1f · steps %.1f/%d · scripts %.1f/%.1f" % [_at(physics_sorted, 0.5), _at(physics_sorted, 1.0),
		float(total) / maxi(steps.size(), 1), most, _at(scripts_sorted, 0.5), _at(scripts_sorted, 1.0)]


static func _at(sorted: PackedFloat32Array, share: float) -> float:
	if sorted.is_empty():
		return 0.0
	return snappedf(sorted[mini(int(sorted.size() * share), sorted.size() - 1)], 0.1)
