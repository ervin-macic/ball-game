class_name GameStore
extends RefCounted
## Small JSON documents that outlive the session, keyed by file name ("settings.json").
##
## Desktop builds write them under user://store/. A web build hosted in a Möbius
## app runs in a sandboxed frame with no IndexedDB, so user:// would vanish on
## reload; when the host page provides `window.ballGameStore` (read_doc,
## write_doc and remove_doc on JSON text), documents live in the app's storage.

const WEB_HOST_INTERFACE := "ballGameStore"
const DESKTOP_DIR := "user://store"

static var _host: JavaScriptObject
static var _host_checked := false


## The stored value (Dictionary, Array, number...) or null when absent or unreadable.
static func read(key: String) -> Variant:
	var text := _read_text(key)
	return JSON.parse_string(text) if not text.is_empty() else null


static func write(key: String, value: Variant) -> void:
	var text := JSON.stringify(value)
	var host := _web_host()
	if host:
		host.write_doc(key, text)
		return
	DirAccess.make_dir_recursive_absolute(DESKTOP_DIR)
	var file := FileAccess.open(_desktop_path(key), FileAccess.WRITE)
	if file:
		file.store_string(text)


static func remove(key: String) -> void:
	var host := _web_host()
	if host:
		host.remove_doc(key)
	elif FileAccess.file_exists(_desktop_path(key)):
		DirAccess.remove_absolute(_desktop_path(key))


static func _read_text(key: String) -> String:
	var host := _web_host()
	if host:
		var stored: Variant = host.read_doc(key)
		return str(stored) if stored != null else ""
	var path := _desktop_path(key)
	return FileAccess.get_file_as_string(path) if FileAccess.file_exists(path) else ""


static func _web_host() -> JavaScriptObject:
	if not _host_checked:
		_host_checked = true
		if OS.has_feature("web"):
			_host = JavaScriptBridge.get_interface(WEB_HOST_INTERFACE)
	return _host


static func _desktop_path(key: String) -> String:
	return DESKTOP_DIR.path_join(key.validate_filename())
