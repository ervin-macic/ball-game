@tool
class_name LoopSegment
extends TrackSegment
## A full vertical loop. It enters and exits along the cursor's heading; the exit
## is shifted sideways by [member side_offset] so the road clears itself.

@export_range(2.0, 200.0, 0.1, "suffix:m") var radius := 8.0:
	set(value):
		radius = value
		emit_changed()
## Sideways shift between entry and exit. Must exceed the full road width. Positive shifts right.
@export_range(-200.0, 200.0, 0.1, "suffix:m") var side_offset := 12.5:
	set(value):
		side_offset = value
		emit_changed()
## How far the road leans sideways to carry the ball across the offset by itself.
## 1 suits a ball that is not steering; 0 is a flat road the player must steer across.
@export_range(0.0, 2.0, 0.01) var self_steer := 1.0:
	set(value):
		self_steer = value
		emit_changed()


func lay(cursor: TrackCursor, path: TrackPath, max_spacing: float, max_turn: float) -> void:
	var start := cursor.frame()
	var right := start.basis.x
	var up := start.basis.y
	var forward := -start.basis.z
	var steps := maxi(ceili(TAU * radius / max_spacing), ceili(TAU / max_turn))
	var previous := start.origin
	for i in range(1, steps + 1):
		var angle := TAU * float(i) / steps
		# Circle in the forward/up plane, drifting sideways along a curve whose
		# slope is zero at both ends, so entry and exit stay straight.
		var drift := side_offset * (angle - sin(angle)) / TAU
		var drift_rate := side_offset * (1.0 - cos(angle)) / TAU
		var point := start.origin + forward * (radius * sin(angle)) + up * (radius * (1.0 - cos(angle))) + right * drift
		var tangent := (forward * (radius * cos(angle)) + up * (radius * sin(angle)) + right * drift_rate).normalized()
		# The ball needs sideways acceleration side_offset/TAU * w² * sin(angle) to
		# follow the drift, while the road pushes it inward with about w² * radius.
		# Leaning the road by their ratio lets that inward push do the steering.
		var lean := self_steer * side_offset * sin(angle) / (TAU * radius)
		var toward_centre := up * cos(angle) - forward * sin(angle) + right * lean
		var road_up := (toward_centre - tangent * toward_centre.dot(tangent)).normalized()
		cursor.distance += point.distance_to(previous)
		previous = point
		path.add_frame(Transform3D(Basis(tangent.cross(road_up), road_up, -tangent), point), cursor.distance)
	cursor.position = start.origin + right * side_offset
