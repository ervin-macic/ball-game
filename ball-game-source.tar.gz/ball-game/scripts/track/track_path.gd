@tool
class_name TrackPath
extends RefCounted
## The sampled centreline of a built track, in the TrackBuilder's local space.
##
## Frames are ordered by distance and grouped into continuous runs; a GapSegment
## starts a new run. Each frame's basis is right (x), road-up (y), backward (z).

var frames: Array[Transform3D] = []
var distances := PackedFloat32Array()
## Safety-wall heights (left, right) of the segment that laid each frame.
var walls := PackedVector2Array()
## Whether each frame is built road (1) or open ground the ball rolls on (0).
var paved := PackedByteArray()
## Index of the first frame of each run.
var run_starts := PackedInt32Array()
## Wall heights stamped on frames added from now on. The builder sets this per segment.
var current_walls := Vector2.ZERO
## Road grip of the segment that laid each frame.
var grips := PackedFloat32Array()
## Grip stamped on frames added from now on. The builder sets this per segment.
var current_grip := 1.0
## Paved flag stamped on frames added from now on. The builder sets this per segment.
var current_paved := true
## Height of the left and right lips at each frame, as a share of the full lip
## (0 lays them flat, where a route forks off beside the road).
var lips := PackedVector2Array()
## Distance ranges (x to y) of gaps the player has to jump to get across.
var jumps := PackedVector2Array()
## In a track network: 0 for frames of the main track, n for frames of its nth route.
var owners := PackedInt32Array()
## Road width at each frame, as a share of the builder's road width.
var widths := PackedFloat32Array()
## Width share stamped on frames added from now on. The builder sets this per segment.
var current_width := 1.0
## Whether each frame is closed over into a tube (1) or open (0).
var tubes := PackedByteArray()
## Tube flag stamped on frames added from now on. The builder sets this per segment.
var current_tube := false
## Curb height share stamped on frames added from now on (see lips).
var current_curb := 1.0
## Curb width share of each frame, and the one stamped on frames added from now on.
var curb_widths := PackedFloat32Array()
var current_curb_width := 1.0

var _new_run_pending := true


func add_frame(frame: Transform3D, distance: float) -> void:
	if _new_run_pending:
		run_starts.append(frames.size())
		_new_run_pending = false
	frames.append(frame)
	distances.append(distance)
	walls.append(current_walls)
	paved.append(1 if current_paved else 0)
	grips.append(current_grip)
	lips.append(Vector2(current_curb, current_curb))
	owners.append(0)
	widths.append(current_width)
	tubes.append(1 if current_tube else 0)
	curb_widths.append(current_curb_width)


## The next frame added starts a new continuous run.
func break_run() -> void:
	_new_run_pending = true


## Appends every frame of [param other] as new runs, owned by [param owner] and
## placed at [param at_distances] (one per frame) instead of its own distances.
func append_path(other: TrackPath, owner: int, at_distances: PackedFloat32Array) -> void:
	for i in other.frames.size():
		if other.run_starts.has(i):
			break_run()
		current_walls = other.walls[i]
		current_paved = other.paved[i] == 1
		current_grip = other.grips[i]
		current_width = other.widths[i]
		current_tube = other.tubes[i] == 1
		current_curb_width = other.curb_widths[i]
		add_frame(other.frames[i], at_distances[i])
		lips[lips.size() - 1] = other.lips[i]
		owners[owners.size() - 1] = owner


## Whether frames [param a] and [param b] lie on the same continuous run of
## the same track (so the centreline runs straight from one to the other).
func connected(a: int, b: int) -> bool:
	if a < 0 or b < 0 or a >= frames.size() or b >= frames.size() or owners[a] != owners[b]:
		return false
	var low := mini(a, b)
	var high := maxi(a, b)
	for start in run_starts:
		if start > low and start <= high:
			return false
	return true


## The jump gap that starts within [param reach] metres after [param distance], or Vector2.ZERO.
func jump_ahead(distance: float, reach: float) -> Vector2:
	for gap in jumps:
		if gap.x >= distance - 0.5 and gap.x <= distance + reach:
			return gap
	return Vector2.ZERO


func run_count() -> int:
	return run_starts.size()


## Frame index range [x, y) of one run.
func run_range(run: int) -> Vector2i:
	var end := run_starts[run + 1] if run + 1 < run_starts.size() else frames.size()
	return Vector2i(run_starts[run], end)


## Frame index ranges [x, y) of built road: each run split where it meets
## open ground. A piece's first frame is the previous piece's last one, so a
## paved stretch starts on the last ground frame and the two surfaces meet.
func paved_ranges() -> Array[Vector2i]:
	var ranges: Array[Vector2i] = []
	for run in run_count():
		var span := run_range(run)
		var i := span.x
		while i < span.y:
			if not paved[i]:
				i += 1
				continue
			var start := maxi(i - 1, span.x) if i > span.x and (not paved[i - 1] or not is_equal_approx(grips[i - 1], grips[i])) else i
			var end := i + 1
			while end < span.y and paved[end] and is_equal_approx(grips[end], grips[i]):
				end += 1
			ranges.append(Vector2i(start, end))
			i = end
	return ranges


## Frame index ranges [x, y) of open ground, the stretches a terrain must carry.
func ground_ranges() -> Array[Vector2i]:
	var ranges: Array[Vector2i] = []
	var i := 0
	while i < frames.size():
		if paved[i]:
			i += 1
			continue
		var start := maxi(i - 1, 0)
		var end := i
		while end < frames.size() and not paved[end]:
			end += 1
		ranges.append(Vector2i(start, mini(end + 1, frames.size())))
		i = end
	return ranges


func total_length() -> float:
	return distances[distances.size() - 1] if distances.size() > 0 else 0.0


## Frame interpolated at [param distance] along the centreline, clamped to the ends.
func frame_at_distance(distance: float) -> Transform3D:
	if frames.size() < 2:
		return frames[0] if frames.size() == 1 else Transform3D.IDENTITY
	var i := clampi(distances.bsearch(distance), 1, frames.size() - 1)
	var span := maxf(distances[i] - distances[i - 1], 1e-6)
	var t := clampf((distance - distances[i - 1]) / span, 0.0, 1.0)
	return frames[i - 1].interpolate_with(frames[i], t)


## Index of the frame nearest [param point]. With a [param hint], only frames
## within [param window] metres along the track of it are searched (cheap
## per-tick tracking). The window is a distance, not a frame count: loops and
## corkscrews are sampled far more densely than straights, and a frame-count
## window there spans so little track that a ball leaving one early (dropping
## off the top of a loop) is never found again.
func nearest_index(point: Vector3, hint := -1, window := 80.0) -> int:
	var from := 0
	var to := frames.size()
	if hint >= 0 and hint < frames.size():
		var span := window_around(hint, window)
		from = span.x
		to = span.y
	var best := from
	var best_distance := INF
	for i in range(from, to):
		var d := frames[i].origin.distance_squared_to(point)
		if d < best_distance:
			best_distance = d
			best = i
	return best


## The frames (from x up to, not including, y) within [param window] metres
## along the track of frame [param hint], stopping where distances stop
## running on (the end of a route appended to a network).
func window_around(hint: int, window: float) -> Vector2i:
	var at := distances[hint]
	var from := hint
	while from > 0 and distances[from - 1] <= distances[from] and at - distances[from - 1] <= window:
		from -= 1
	var to := hint + 1
	while to < frames.size() and distances[to] >= distances[to - 1] and distances[to] - at <= window:
		to += 1
	return Vector2i(from, to)
