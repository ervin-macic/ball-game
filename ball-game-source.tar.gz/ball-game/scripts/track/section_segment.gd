@tool
class_name SectionSegment
extends TrackSegment
## A road piece: straight, slope, ramp, turn or banked turn. Pitch and bank ease
## from wherever the previous piece left them to the targets set here, so pieces
## always join smoothly.

## Centreline length.
@export_range(0.5, 2000.0, 0.1, "suffix:m") var length := 20.0:
	set(value):
		length = value
		emit_changed()
## Heading change over the piece. Positive turns left.
@export_range(-720.0, 720.0, 0.5, "suffix:°") var turn := 0.0:
	set(value):
		turn = value
		emit_changed()
## 0 keeps a constant radius. 1 eases the curvature in and out, tightest mid-turn, with no jolt at entry or exit.
@export_range(0.0, 1.0, 0.01) var turn_easing := 1.0:
	set(value):
		turn_easing = value
		emit_changed()
## Slope at the end of the piece. Positive climbs.
@export_range(-89.0, 89.0, 0.5, "suffix:°") var end_pitch := 0.0:
	set(value):
		end_pitch = value
		emit_changed()
## Base roll at the end of the piece. Positive raises the right edge.
@export_range(-89.0, 89.0, 0.5, "suffix:°") var end_bank := 0.0:
	set(value):
		end_bank = value
		emit_changed()
## Extra roll toward the inside of the turn, strongest where the turn is tightest.
@export_range(0.0, 85.0, 0.5, "suffix:°") var bank_into_turn := 0.0:
	set(value):
		bank_into_turn = value
		emit_changed()

## Steepest slope of the smoothstep easing curve.
const EASE_PEAK_RATE := 1.5


func lay(cursor: TrackCursor, path: TrackPath, max_spacing: float, max_turn: float) -> void:
	var start_heading := cursor.heading
	var start_pitch := cursor.pitch
	var start_bank := cursor.bank
	var turn_rad := deg_to_rad(turn)
	var pitch_rad := deg_to_rad(end_pitch)
	var bank_rad := deg_to_rad(end_bank)
	var into_turn := deg_to_rad(bank_into_turn) * signf(turn_rad)

	var roll_change := absf(bank_rad - start_bank) + absf(into_turn)
	var largest_angle := maxf(absf(turn_rad), maxf(absf(pitch_rad - start_pitch), roll_change)) * EASE_PEAK_RATE
	var steps := maxi(maxi(ceili(length / max_spacing), ceili(largest_angle / max_turn)), 1)
	var step_length := length / steps

	for i in range(1, steps + 1):
		var t := float(i) / steps
		var mid := (float(i) - 0.5) / steps
		var mid_heading := start_heading + turn_rad * _turn_progress(mid)
		var mid_pitch := lerpf(start_pitch, pitch_rad, _ease(mid))
		cursor.position += TrackCursor.direction(mid_heading, mid_pitch) * step_length
		cursor.distance += step_length
		cursor.heading = start_heading + turn_rad * _turn_progress(t)
		cursor.pitch = lerpf(start_pitch, pitch_rad, _ease(t))
		cursor.bank = lerpf(start_bank, bank_rad, _ease(t)) + into_turn * _turn_tightness(t)
		path.add_frame(cursor.frame(), cursor.distance)


func _turn_progress(t: float) -> float:
	return lerpf(t, _ease(t), turn_easing)


## Turn rate at [param t] relative to its peak: 1 where the turn is tightest.
## A turn that isn't fully eased starts and ends at a non-zero rate; its lean
## into the turn still fades in and out over the ends, or the road would twist
## abruptly where the piece begins (a wall the ball runs into).
func _turn_tightness(t: float) -> float:
	var rate := lerpf(1.0, 6.0 * t * (1.0 - t), turn_easing)
	var ends := smoothstep(0.0, 0.15, t) * smoothstep(1.0, 0.85, t)
	return rate / lerpf(1.0, EASE_PEAK_RATE, turn_easing) * lerpf(ends, 1.0, turn_easing)


static func _ease(t: float) -> float:
	return t * t * (3.0 - 2.0 * t)
