@tool
class_name TrackCursor
extends RefCounted
## Where the next track segment begins: a position plus heading, pitch and bank.

var position := Vector3.ZERO
## Radians about world up. 0 faces -Z; positive turns left.
var heading := 0.0
## Radians. Positive climbs.
var pitch := 0.0
## Radians. Positive raises the right edge (the bank for a left turn).
var bank := 0.0
## Metres of centreline laid so far.
var distance := 0.0


## Road frame here: x is right, y is road-up, -z is the direction of travel.
func frame() -> Transform3D:
	return Transform3D(Basis.from_euler(Vector3(pitch, heading, bank)), position)


## Unit direction of travel for a heading and pitch.
static func direction(heading_rad: float, pitch_rad: float) -> Vector3:
	return Basis.from_euler(Vector3(pitch_rad, heading_rad, 0.0)) * Vector3.FORWARD
