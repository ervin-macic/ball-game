@tool
class_name GapSegment
extends TrackSegment
## Open air to jump across. The road resumes [member length] metres further on
## (measured level along the heading), [member rise] metres higher, starting at
## [member landing_pitch]. A gap after a ramp carries the ball over by itself;
## a [member jump] gap is a break in level road that a ball only crosses by
## jumping: either 14 m or longer, or shorter with the far side a little higher
## (land it on a gentle down-slope to give the height back, so the rest of the
## level stays where it was).

@export_range(0.0, 500.0, 0.1, "suffix:m") var length := 12.0:
	set(value):
		length = value
		emit_changed()
@export_range(-200.0, 200.0, 0.1, "suffix:m") var rise := -2.0:
	set(value):
		rise = value
		emit_changed()
## Slope the landing road starts at. Matching the expected arc makes landings soft.
@export_range(-89.0, 89.0, 0.5, "suffix:°") var landing_pitch := -10.0:
	set(value):
		landing_pitch = value
		emit_changed()

## Sideways step of the far side (metres, + to the right): the jumper has to
## steer in the air.
@export_range(-20.0, 20.0, 0.1, "suffix:m") var shift := 0.0:
	set(value):
		shift = value
		emit_changed()
## The player has to jump to cross (the test autopilot jumps here too).
@export var jump := false:
	set(value):
		jump = value
		emit_changed()


func lay(cursor: TrackCursor, path: TrackPath, _max_spacing: float, _max_turn: float) -> void:
	var takeoff := cursor.distance
	var right := Basis(Vector3.UP, cursor.heading) * Vector3.RIGHT
	cursor.position += TrackCursor.direction(cursor.heading, 0.0) * length + Vector3.UP * rise + right * shift
	cursor.distance += Vector3(length, rise, shift).length()
	if jump:
		path.jumps.append(Vector2(takeoff, cursor.distance))
	cursor.pitch = deg_to_rad(landing_pitch)
	path.break_run()
	path.add_frame(cursor.frame(), cursor.distance)
