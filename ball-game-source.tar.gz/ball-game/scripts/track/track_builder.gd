@tool
class_name TrackBuilder
extends Node3D
## Builds a smooth, collidable road from an ordered list of TrackSegment pieces.
##
## Add pieces under Segments (New SectionSegment / LoopSegment / GapSegment);
## the road rebuilds live in the editor. The cross-section is a flat driving
## surface between two concave lips that guide the ball back toward the middle.
## Generated mesh and collision are internal children and are never saved into
## the scene, so the segment list stays the single source of truth.
##
## TrackRoute children are alternative routes: each forks off this track and
## rejoins it further on, and is rebuilt along with it. [member network] holds
## the whole layout (this track plus its routes) for anything that has to know
## about every road: progress, the camera, terrain, scenery and supports.

signal rebuilt

enum Surface { ROAD, CURB, SIDE, WALL, SLICK }

## Pieces laid end to end, starting at this node's origin and facing -Z.
@export var segments: Array[TrackSegment] = []:
	set(value):
		_watch_segments(false)
		segments = value
		_watch_segments(true)
		_queue_rebuild()

@export_group("Cross Section")
## Width of the flat driving surface.
@export_range(1.0, 100.0, 0.1, "suffix:m") var road_width := 8.0:
	set(value):
		road_width = value
		_queue_rebuild()
## Horizontal width of each concave lip.
@export_range(0.05, 20.0, 0.05, "suffix:m") var lip_width := 1.4:
	set(value):
		lip_width = value
		_queue_rebuild()
## Height the lips rise to. Higher lips catch harder slides.
@export_range(0.0, 10.0, 0.05, "suffix:m") var lip_height := 0.7:
	set(value):
		lip_height = value
		_queue_rebuild()
@export_range(1, 32) var lip_segments := 8:
	set(value):
		lip_segments = value
		_queue_rebuild()
## Flat top of each lip, where safety walls sit.
@export_range(0.05, 5.0, 0.05, "suffix:m") var rim_width := 0.3:
	set(value):
		rim_width = value
		_queue_rebuild()
@export_range(0.05, 10.0, 0.05, "suffix:m") var thickness := 0.6:
	set(value):
		thickness = value
		_queue_rebuild()
@export_range(0.05, 2.0, 0.01, "suffix:m") var wall_thickness := 0.25:
	set(value):
		wall_thickness = value
		_queue_rebuild()

@export_group("Sampling")
## Longest step between centreline samples.
@export_range(0.1, 10.0, 0.05, "suffix:m") var max_spacing := 1.0:
	set(value):
		max_spacing = value
		_queue_rebuild()
## Largest heading, pitch or roll change between samples. Keep it well under Jolt's active edge threshold (50° by default) so the ball rolls over sample seams without bumps.
@export_range(0.25, 20.0, 0.25, "suffix:°") var max_step_angle := 2.5:
	set(value):
		max_step_angle = value
		_queue_rebuild()

@export_group("Physics")
## Surface friction. The ball's material is rough, so its own speed-based friction decides grip.
@export_range(0.0, 3.0, 0.01) var friction := 1.0:
	set(value):
		friction = value
		_queue_rebuild()
@export_flags_3d_physics var collision_layer := 1:
	set(value):
		collision_layer = value
		_queue_rebuild()

@export_group("Materials")
@export var road_material: Material:
	set(value):
		road_material = value
		_queue_rebuild()
@export var curb_material: Material:
	set(value):
		curb_material = value
		_queue_rebuild()
@export var side_material: Material:
	set(value):
		side_material = value
		_queue_rebuild()
@export var wall_material: Material:
	set(value):
		wall_material = value
		_queue_rebuild()
## Road surface of slippery pieces (grip below 1).
@export var slick_material: Material:
	set(value):
		slick_material = value
		_queue_rebuild()

@export_group("Markers")
## Moved to the start of the track on every rebuild. The race respawns the ball here.
@export var spawn_marker: Node3D:
	set(value):
		spawn_marker = value
		_queue_rebuild()
@export_range(0.0, 1000.0, 0.5, "suffix:m") var spawn_distance := 8.0:
	set(value):
		spawn_distance = value
		_queue_rebuild()
## Height of the spawn point above the road (ball radius plus a little).
@export_range(0.0, 10.0, 0.05, "suffix:m") var spawn_height := 0.55:
	set(value):
		spawn_height = value
		_queue_rebuild()
## Moved near the end of the track on every rebuild and sized to the road.
@export var finish_line: FinishLine:
	set(value):
		finish_line = value
		_queue_rebuild()
## Run-off left after the finish line.
@export_range(0.0, 1000.0, 0.5, "suffix:m") var finish_distance_from_end := 30.0:
	set(value):
		finish_distance_from_end = value
		_queue_rebuild()

@export_group("Holes")
## Holes in the road to steer round or fall through, each (metres along the
## track where it starts, its length, metres right of the centreline of its
## middle, its width). The curbs stay; only road is cut away.
@export var holes := PackedVector4Array():
	set(value):
		holes = value
		_queue_rebuild()

## The sampled centreline from the last rebuild, in this node's local space.
var path := TrackPath.new()
## This track's frames followed by every route's, in this node's local space.
## Route frames carry the distance along this track they stand for, so a
## position anywhere on the layout maps to progress along the main track.
var network := TrackPath.new()

## Lips lower over this distance either side of a fork.
const FORK_RAMP := 8.0
## Road width changes ease over this distance.
const WIDTH_EASE := 6.0
## Sides of a tube's arch.
const TUBE_SEGMENTS := 16

var _route_spans: Array[Vector2i] = []
var _route_boxes: Array[AABB] = []

var _mesh_instance: MeshInstance3D
var _body: StaticBody3D
var _collision: CollisionShape3D
var _rebuild_queued := false


func _ready() -> void:
	rebuild()


## Rebuilds the centreline, mesh, collision and marker placement now, and
## every route with it.
func rebuild() -> void:
	_rebuild_queued = false
	path = _lay_path()
	var found := routes()
	for route in found:
		route.lay_from(self)
		_open_fork(route)
	_build_geometry()
	for route in found:
		route._build_geometry()
	_build_network(found)
	_place_markers()
	rebuilt.emit()


## The alternative routes forking off this track.
func routes() -> Array[TrackRoute]:
	var found: Array[TrackRoute] = []
	for child in get_children():
		if child is TrackRoute:
			found.append(child)
	return found


## Index into [member network] of the frame nearest [param local_point] (in
## this node's space). With a [param hint] (a previous result) only frames near
## it are searched, plus any route the point is close to.
func locate(local_point: Vector3, hint := -1, window := 40) -> int:
	if network.frames.is_empty():
		return 0
	if hint < 0 or hint >= network.frames.size():
		return network.nearest_index(local_point)
	var main_hint := hint
	if network.owners[hint] != 0:
		main_hint = clampi(path.distances.bsearch(network.distances[hint]), 0, path.frames.size() - 1)
	var best := path.nearest_index(local_point, main_hint, window)
	var best_distance := network.frames[best].origin.distance_squared_to(local_point)
	for k in _route_spans.size():
		var span := _route_spans[k]
		if not _route_boxes[k].grow(25.0).has_point(local_point):
			continue
		var from := span.x
		var to := span.y
		if hint >= span.x and hint < span.y:
			from = maxi(hint - window, span.x)
			to = mini(hint + window + 1, span.y)
		for i in range(from, to):
			var d := network.frames[i].origin.distance_squared_to(local_point)
			if d < best_distance:
				best_distance = d
				best = i
	return best


func _build_network(found: Array[TrackRoute]) -> void:
	network = TrackPath.new()
	network.append_path(path, 0, path.distances)
	network.jumps = path.jumps.duplicate()
	_route_spans.clear()
	_route_boxes.clear()
	for k in found.size():
		var route := found[k]
		var start := network.frames.size()
		network.append_path(route.path, k + 1, route.main_distances)
		var box := AABB()
		for i in range(start, network.frames.size()):
			box = AABB(network.frames[i].origin, Vector3.ZERO) if i == start else box.expand(network.frames[i].origin)
		_route_spans.append(Vector2i(start, network.frames.size()))
		_route_boxes.append(box)


## Lays this track's lip flat (and drops its wall) on the side a route forks
## off, so the two roads meet edge to edge and the ball can roll across.
func _open_fork(route: TrackRoute) -> void:
	var low := route.from_distance
	var high := route.from_distance + route.fork_length
	for i in path.frames.size():
		var d := path.distances[i]
		if d < low - FORK_RAMP or d > high + FORK_RAMP:
			continue
		var share := 1.0 - smoothstep(low - FORK_RAMP, low, d) * (1.0 - smoothstep(high, high + FORK_RAMP, d))
		var lip := path.lips[i]
		var wall := path.walls[i]
		if route.side > 0.0:
			lip.y = minf(lip.y, share)
			wall.y = 0.0
		else:
			lip.x = minf(lip.x, share)
			wall.x = 0.0
		path.lips[i] = lip
		path.walls[i] = wall


## Mesh and collision from the current [member path].
func _build_geometry() -> void:
	_ensure_generated_nodes()
	var buffers := _build_surfaces()
	_mesh_instance.mesh = _to_mesh(buffers)
	# Collision comes straight from the generated triangles rather than being read
	# back from the mesh: that round trip goes through the rendering server, which
	# keeps no geometry on headless or dedicated-server builds.
	var faces := PackedVector3Array()
	for surface in Surface.size():
		if surface != Surface.SLICK:
			buffers[surface].append_faces_to(faces)
	var shape := ConcavePolygonShape3D.new()
	shape.set_faces(faces)
	_collision.shape = shape if not faces.is_empty() else null
	_build_slick_bodies()
	_build_hole_floors()


## Centreline frame at a distance along the track, in world space.
func world_frame_at(distance: float) -> Transform3D:
	return global_transform * path.frame_at_distance(distance)


## Lowest centreline height in world space (used to detect falling off).
func world_lowest_point() -> float:
	var lowest := INF
	for frame in network.frames:
		lowest = minf(lowest, (global_transform * frame.origin).y)
	return lowest


func _queue_rebuild() -> void:
	if _rebuild_queued or not is_inside_tree():
		return
	_rebuild_queued = true
	rebuild.call_deferred()


func _watch_segments(watch: bool) -> void:
	for segment in segments:
		if segment == null:
			continue
		var watching := segment.changed.is_connected(_queue_rebuild)
		if watch and not watching:
			segment.changed.connect(_queue_rebuild)
		elif not watch and watching:
			segment.changed.disconnect(_queue_rebuild)


func _lay_path() -> TrackPath:
	var laid := TrackPath.new()
	var cursor := TrackCursor.new()
	var first := segments.filter(func(s: TrackSegment) -> bool: return s != null)
	if not first.is_empty():
		laid.current_walls = Vector2(first[0].wall_left, first[0].wall_right)
		laid.current_paved = first[0].paved
		laid.current_grip = first[0].grip
		laid.current_width = first[0].width
		laid.current_tube = first[0].tube
		laid.current_curb = first[0].curb
		laid.current_curb_width = first[0].curb_width
	laid.add_frame(cursor.frame(), 0.0)
	var max_turn := deg_to_rad(max_step_angle)
	for segment in segments:
		if segment == null:
			continue
		laid.current_walls = Vector2(segment.wall_left, segment.wall_right)
		laid.current_paved = segment.paved
		laid.current_grip = segment.grip
		laid.current_width = segment.width
		laid.current_tube = segment.tube
		laid.current_curb = segment.curb
		laid.current_curb_width = segment.curb_width
		segment.lay(cursor, laid, max_spacing, max_turn)
	_ease_widths(laid)
	return laid


## Width and curb changes ease over WIDTH_EASE metres either side, within
## each run, so a narrowing plank or a deepening channel has no step.
static func _ease_widths(laid: TrackPath) -> void:
	laid.widths = _eased(laid, laid.widths)
	laid.curb_widths = _eased(laid, laid.curb_widths)
	var curbs := PackedFloat32Array()
	for lip in laid.lips:
		curbs.append(lip.x)
	curbs = _eased(laid, curbs)
	for i in curbs.size():
		laid.lips[i] = Vector2(curbs[i], curbs[i])


static func _eased(laid: TrackPath, values: PackedFloat32Array) -> PackedFloat32Array:
	var eased := values.duplicate()
	for run in laid.run_count():
		var span := laid.run_range(run)
		for i in range(span.x, span.y):
			var total := 0.0
			var weight := 0.0
			for j in range(span.x, span.y):
				var gap := absf(laid.distances[j] - laid.distances[i])
				if gap > WIDTH_EASE:
					if laid.distances[j] > laid.distances[i]:
						break
					continue
				var w := 1.0 - gap / WIDTH_EASE
				total += values[j] * w
				weight += w
			eased[i] = total / maxf(weight, 1e-6)
	return eased


func _ensure_generated_nodes() -> void:
	if _mesh_instance == null:
		_mesh_instance = MeshInstance3D.new()
		_mesh_instance.name = "GeneratedMesh"
		add_child(_mesh_instance, false, Node.INTERNAL_MODE_FRONT)
	if _body == null:
		_body = StaticBody3D.new()
		_body.name = "GeneratedBody"
		_collision = CollisionShape3D.new()
		_body.add_child(_collision)
		add_child(_body, false, Node.INTERNAL_MODE_FRONT)
	_body.collision_layer = collision_layer
	_body.collision_mask = 0
	var surface := PhysicsMaterial.new()
	surface.friction = friction
	_body.physics_material_override = surface


func _place_markers() -> void:
	if path.frames.is_empty():
		return
	if spawn_marker:
		var spawn := path.frame_at_distance(spawn_distance)
		spawn.origin += spawn.basis.y * spawn_height
		spawn_marker.global_transform = global_transform * spawn
	if finish_line:
		finish_line.global_transform = world_frame_at(maxf(path.total_length() - finish_distance_from_end, 0.0))
		finish_line.fit_to_road(road_width, _outer_half_width() * 2.0)


func _outer_half_width() -> float:
	return road_width * 0.5 + lip_width + rim_width


# --- Mesh generation -------------------------------------------------------

var _slick_buffers := {}


func _build_surfaces() -> Array[SurfaceBuffer]:
	var buffers: Array[SurfaceBuffer] = []
	for i in Surface.size():
		buffers.append(SurfaceBuffer.new())
	_slick_buffers.clear()
	var strips := _cross_section_strips()
	var outline := _outline_of(strips)
	for frames in path.paved_ranges():
		if frames.y - frames.x < 2:
			continue
		var grip := path.grips[mini(frames.x + 1, frames.y - 1)]
		for strip in strips:
			if strip.surface == Surface.ROAD and grip < 0.999:
				# Slippery road: its own surface and its own collision (tagged with its grip).
				_sweep(buffers[Surface.SLICK], strip, frames.x, frames.y)
				if not _slick_buffers.has(grip):
					_slick_buffers[grip] = SurfaceBuffer.new()
				_sweep(_slick_buffers[grip], strip, frames.x, frames.y)
			else:
				_sweep(buffers[strip.surface], strip, frames.x, frames.y)
		_cap(buffers[Surface.SIDE], outline, frames.x, false)
		_cap(buffers[Surface.SIDE], outline, frames.y - 1, true)
		if not holes.is_empty():
			_build_hole_edges(buffers[Surface.SIDE], frames)
		_build_walls(buffers[Surface.WALL], frames)
		_build_tubes(buffers[Surface.WALL], frames)
	return buffers


## Tube pieces: an arch from one rim over the road to the other, seen and
## solid from both sides, in the wall material.
func _build_tubes(buffer: SurfaceBuffer, frames: Vector2i) -> void:
	var i := frames.x
	while i < frames.y:
		if not path.tubes[i]:
			i += 1
			continue
		var last := i
		while last + 1 < frames.y and path.tubes[last + 1]:
			last += 1
		var start := maxi(i - 1, frames.x)
		var end := last + 1
		if end - start >= 2:
			var radius := road_width * 0.5 + lip_width
			var arch := PackedVector2Array()
			for k in TUBE_SEGMENTS + 1:
				var angle := PI * float(k) / TUBE_SEGMENTS
				arch.append(Vector2(cos(angle) * radius, lip_height + sin(angle) * radius))
			var outside := PackedVector2Array()
			for k in range(arch.size() - 1, -1, -1):
				outside.append(arch[k])
			_sweep(buffer, Strip.new(Surface.WALL, arch), start, end)
			_sweep(buffer, Strip.new(Surface.WALL, outside), start, end)
		i = last + 1


func _to_mesh(buffers: Array[SurfaceBuffer]) -> ArrayMesh:
	var materials: Array[Material] = [road_material, curb_material, side_material, wall_material, slick_material if slick_material else road_material]
	var mesh := ArrayMesh.new()
	for surface in Surface.size():
		if buffers[surface].is_empty():
			continue
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, buffers[surface].to_arrays())
		var material := materials[surface] if materials[surface] else _fallback_material(surface)
		mesh.surface_set_material(mesh.get_surface_count() - 1, material)
	return mesh


## Cross-section as strips, each a polyline in road space (x right, y up)
## traversed so that the top runs left to right and the bottom right to left.
## That orientation makes every swept face point outward.
func _cross_section_strips() -> Array[Strip]:
	var half := road_width * 0.5
	var outer := _outer_half_width()
	var top := lip_height
	var bottom := -thickness
	var right_lip := _lip_arc(half)
	var left_lip := PackedVector2Array()
	for k in range(right_lip.size() - 1, -1, -1):
		left_lip.append(Vector2(-right_lip[k].x, right_lip[k].y))
	var strips: Array[Strip] = [
		Strip.new(Surface.CURB, PackedVector2Array([Vector2(-outer, top), Vector2(-half - lip_width, top)])),
		Strip.new(Surface.CURB, left_lip),
		Strip.new(Surface.ROAD, PackedVector2Array([Vector2(-half, 0.0), Vector2(half, 0.0)])),
		Strip.new(Surface.CURB, right_lip),
		Strip.new(Surface.CURB, PackedVector2Array([Vector2(half + lip_width, top), Vector2(outer, top)])),
		Strip.new(Surface.SIDE, PackedVector2Array([Vector2(outer, top), Vector2(outer, bottom)])),
		Strip.new(Surface.SIDE, PackedVector2Array([Vector2(outer, bottom), Vector2(-outer, bottom)])),
		Strip.new(Surface.SIDE, PackedVector2Array([Vector2(-outer, bottom), Vector2(-outer, top)])),
	]
	return strips


## Concave lip from the road edge (half, 0) up to (half + lip_width, lip_height):
## a circular arc tangent to the road, so the ball meets no crease.
func _lip_arc(half: float) -> PackedVector2Array:
	var points := PackedVector2Array()
	var sweep := 2.0 * atan2(lip_height, lip_width)
	if sweep < 1e-3:
		points.append(Vector2(half, 0.0))
		points.append(Vector2(half + lip_width, 0.0))
		return points
	var arc_radius := lip_width / sin(sweep)
	for k in lip_segments + 1:
		var angle := sweep * float(k) / lip_segments
		points.append(Vector2(half + arc_radius * sin(angle), arc_radius * (1.0 - cos(angle))))
	return points


static func _outline_of(strips: Array[Strip]) -> PackedVector2Array:
	var outline := PackedVector2Array()
	for strip in strips:
		for point in strip.points:
			if outline.is_empty() or not outline[outline.size() - 1].is_equal_approx(point):
				outline.append(point)
	if outline.size() > 2 and outline[0].is_equal_approx(outline[outline.size() - 1]):
		outline.remove_at(outline.size() - 1)
	return outline


## Road columns when the road has holes: holes are cut on this grid.
const HOLE_COLUMNS := 16


func is_hole(along: float, x: float) -> bool:
	for hole in holes:
		if along >= hole.x and along <= hole.x + hole.y and absf(x - hole.z) <= hole.w * 0.5:
			return true
	return false


## The road strip split into HOLE_COLUMNS, so holes can be cut out of it.
func _road_columns() -> Strip:
	var half := road_width * 0.5
	var points := PackedVector2Array()
	for k in HOLE_COLUMNS + 1:
		points.append(Vector2(lerpf(-half, half, float(k) / HOLE_COLUMNS), 0.0))
	return Strip.new(Surface.ROAD, points)


func _cell_is_hole(i: int, j: int, columns: Strip) -> bool:
	var along := (path.distances[i] + path.distances[i + 1]) * 0.5
	var x := (columns.points[j].x + columns.points[j + 1].x) * 0.5 * path.widths[i]
	return is_hole(along, x)


## The cut faces round each hole, from the road down through the slab, so a
## hole reads as a hole rather than a paper-thin gap. Seen from both sides.
func _build_hole_edges(buffer: SurfaceBuffer, frames: Vector2i) -> void:
	var columns := _road_columns()
	var at := func(i: int, j: int, depth: float) -> Vector3:
		var frame := path.frames[i]
		var p := _narrowed(columns.points[j], path.widths[i], path.curb_widths[i])
		return frame.origin + frame.basis.x * p.x + frame.basis.y * depth
	for i in range(frames.x, frames.y - 1):
		for j in HOLE_COLUMNS:
			if not _cell_is_hole(i, j, columns):
				continue
			# Each side of the cell that borders solid road gets a face.
			var edges := []
			if j == 0 or not _cell_is_hole(i, j - 1, columns):
				edges.append([i, j, i + 1, j])
			if j == HOLE_COLUMNS - 1 or not _cell_is_hole(i, j + 1, columns):
				edges.append([i, j + 1, i + 1, j + 1])
			if i == frames.x or not _cell_is_hole(i - 1, j, columns):
				edges.append([i, j, i, j + 1])
			if i + 1 >= frames.y - 1 or not _cell_is_hole(i + 1, j, columns):
				edges.append([i + 1, j, i + 1, j + 1])
			for e in edges:
				var a: Vector3 = at.call(e[0], e[1], 0.0)
				var b: Vector3 = at.call(e[2], e[3], 0.0)
				var c: Vector3 = at.call(e[2], e[3], -thickness)
				var d: Vector3 = at.call(e[0], e[1], -thickness)
				var normal := (b - a).cross(d - a).normalized()
				for flip in [1.0, -1.0]:
					var base := buffer.vertices.size()
					for v in [a, b, c, d]:
						buffer.vertices.append(v)
						buffer.normals.append(normal * flip)
						buffer.uvs.append(Vector2(v.x + v.z, v.y))
					if flip > 0.0:
						buffer.add_quad(base, base + 3, base + 2, base + 1)
					else:
						buffer.add_quad(base, base + 1, base + 2, base + 3)


## A dark floor just inside each hole (seen, never touched), so a hole reads
## as a hole rather than as more pale ground far below.
func _build_hole_floors() -> void:
	var old := get_node_or_null("HoleFloors")
	if old:
		old.free()
	if holes.is_empty():
		return
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var columns := _road_columns()
	var count := 0
	for frames in path.paved_ranges():
		for i in range(frames.x, frames.y - 1):
			for j in HOLE_COLUMNS:
				if not _cell_is_hole(i, j, columns):
					continue
				var corners: Array[Vector3] = []
				for c in [[i, j], [i, j + 1], [i + 1, j + 1], [i + 1, j]]:
					var frame := path.frames[c[0]]
					var p := _narrowed(columns.points[c[1]], path.widths[c[0]], path.curb_widths[c[0]])
					corners.append(frame.origin + frame.basis.x * p.x - frame.basis.y * thickness * 0.8)
				for k in [0, 2, 1, 0, 3, 2]:
					tool.set_normal(path.frames[i].basis.y)
					tool.add_vertex(corners[k])
				count += 1
	if count == 0:
		return
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.03, 0.06, 0.1)
	dark.roughness = 1.0
	dark.cull_mode = BaseMaterial3D.CULL_DISABLED
	var view := MeshInstance3D.new()
	view.name = "HoleFloors"
	view.mesh = tool.commit()
	view.material_override = dark
	view.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(view, false, Node.INTERNAL_MODE_FRONT)


## Extrudes one strip along frames [start, end).
func _sweep(buffer: SurfaceBuffer, strip: Strip, start: int, end: int) -> void:
	var holed := strip.surface == Surface.ROAD and not holes.is_empty()
	if holed:
		strip = _road_columns()
	var columns := strip.points.size()
	var base := buffer.vertices.size()
	for i in range(start, end):
		var frame := path.frames[i]
		var along := path.distances[i]
		var lip := path.lips[i]
		var narrow := path.widths[i]
		var curb_wide := path.curb_widths[i]
		for j in columns:
			var p := _narrowed(strip.points[j], narrow, curb_wide)
			var n := strip.normals[j]
			if p.y > 0.0:
				var share := lip.x if p.x < 0.0 else lip.y
				# Lips lowered toward a fork flatten into road; raised ones
				# make a deep channel. The curve keeps its shape, stretched.
				if strip.surface == Surface.WALL:
					# Walls stand on the rim: they move with it, unstretched.
					p.y += lip_height * (share - 1.0)
				elif not is_equal_approx(share, 1.0):
					p.y *= share
					if strip.surface == Surface.CURB:
						n = Vector2(n.x * share, n.y).normalized()
			buffer.vertices.append(frame.origin + frame.basis.x * p.x + frame.basis.y * p.y)
			buffer.normals.append((frame.basis.x * n.x + frame.basis.y * n.y).normalized())
			buffer.uvs.append(Vector2(p.x, along))
	for i in range(end - start - 1):
		for j in columns - 1:
			if holed and _cell_is_hole(start + i, j, strip):
				continue
			var a := base + i * columns + j
			buffer.add_quad(a, a + 1, a + columns + 1, a + columns)


## Closes the end of a run with the cross-section outline.
func _cap(buffer: SurfaceBuffer, outline: PackedVector2Array, frame_index: int, facing_forward: bool) -> void:
	var triangles := Geometry2D.triangulate_polygon(outline)
	if triangles.is_empty():
		return
	var frame := path.frames[frame_index]
	var facing := -frame.basis.z if facing_forward else frame.basis.z
	var base := buffer.vertices.size()
	var lip := path.lips[frame_index]
	for corner in outline:
		var p := _narrowed(corner, path.widths[frame_index], path.curb_widths[frame_index])
		if p.y > 0.0:
			p.y *= lip.x if p.x < 0.0 else lip.y
		buffer.vertices.append(frame.origin + frame.basis.x * p.x + frame.basis.y * p.y)
		buffer.normals.append(facing)
		buffer.uvs.append(p)
	for t in range(0, triangles.size(), 3):
		var a := base + triangles[t]
		var b := base + triangles[t + 1]
		var c := base + triangles[t + 2]
		var normal := (buffer.vertices[b] - buffer.vertices[a]).cross(buffer.vertices[c] - buffer.vertices[a])
		if normal.dot(facing) >= 0.0:
			buffer.add_triangle(a, b, c)
		else:
			buffer.add_triangle(a, c, b)


## A cross-section point moved in for a road [param share] of its full width:
## the flat road scales, everything outside it keeps its shape and moves in.
func _narrowed(p: Vector2, share: float, curb_share := 1.0) -> Vector2:
	if is_equal_approx(share, 1.0) and is_equal_approx(curb_share, 1.0):
		return p
	var half := road_width * 0.5
	if absf(p.x) <= half + 1e-4:
		return Vector2(p.x * share, p.y)
	# Outside the road: the curb (and rim, sides) keep their shape, scaled
	# outward by curb_share from the road's (narrowed) edge.
	return Vector2(signf(p.x) * (half * share + (absf(p.x) - half) * curb_share), p.y)


## Walls sit on the lip rims. Each stretch of constant height becomes one box sweep.
func _build_walls(buffer: SurfaceBuffer, frames: Vector2i) -> void:
	for side in [-1, 1]:
		var i := frames.x
		while i < frames.y:
			var height := _wall_height(i, side)
			if height <= 0.0:
				i += 1
				continue
			var last := i
			while last + 1 < frames.y and is_equal_approx(_wall_height(last + 1, side), height):
				last += 1
			# A piece's first frame is the previous piece's last one, so start there.
			_wall_piece(buffer, side, height, maxi(i - 1, frames.x), last + 1)
			i = last + 1


func _wall_height(frame_index: int, side: int) -> float:
	var heights := path.walls[frame_index]
	return heights.x if side < 0 else heights.y


func _wall_piece(buffer: SurfaceBuffer, side: int, height: float, start: int, end: int) -> void:
	if end - start < 2:
		return
	var centre := (road_width * 0.5 + lip_width + rim_width * 0.5) * side
	var inner := centre - side * wall_thickness * 0.5
	var outer := centre + side * wall_thickness * 0.5
	var low := lip_height - 0.05
	var high := lip_height + height
	var outline := PackedVector2Array([Vector2(inner, low), Vector2(inner, high), Vector2(outer, high), Vector2(outer, low)])
	if side < 0:
		outline = PackedVector2Array([Vector2(outer, low), Vector2(outer, high), Vector2(inner, high), Vector2(inner, low)])
	for k in 4:
		_sweep(buffer, Strip.new(Surface.WALL, PackedVector2Array([outline[k], outline[(k + 1) % 4]])), start, end)
	_cap(buffer, outline, start, false)
	_cap(buffer, outline, end - 1, true)


## One static body per slippery grip value, tagged so the ball reads its grip.
func _build_slick_bodies() -> void:
	for child in _body.get_children():
		if child is StaticBody3D:
			child.free()
	for grip in _slick_buffers:
		var faces := PackedVector3Array()
		_slick_buffers[grip].append_faces_to(faces)
		var shape := ConcavePolygonShape3D.new()
		shape.set_faces(faces)
		var holder := CollisionShape3D.new()
		holder.shape = shape
		var slick := StaticBody3D.new()
		slick.collision_layer = collision_layer
		slick.collision_mask = 0
		slick.set_meta("grip", grip)
		var surface := PhysicsMaterial.new()
		surface.friction = friction * grip
		slick.physics_material_override = surface
		slick.add_child(holder)
		_body.add_child(slick)


static func _fallback_material(surface: int) -> StandardMaterial3D:
	var colors := [Color(0.16, 0.17, 0.2), Color(0.85, 0.25, 0.2), Color(0.3, 0.32, 0.36), Color(0.4, 0.8, 1.0, 0.35), Color(0.75, 0.9, 1.0)]
	var material := StandardMaterial3D.new()
	material.albedo_color = colors[surface]
	if surface == Surface.WALL:
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return material


## A polyline of the cross-section with per-point normals and one surface.
class Strip:
	var surface: int
	var points: PackedVector2Array
	var normals := PackedVector2Array()

	func _init(p_surface: int, p_points: PackedVector2Array) -> void:
		surface = p_surface
		points = p_points
		# Interior points average their two edges (smooth arcs); end points take
		# their single edge, so strips meet with hard creases.
		for j in points.size():
			var normal := Vector2.ZERO
			if j > 0:
				normal += _edge_normal(points[j] - points[j - 1])
			if j < points.size() - 1:
				normal += _edge_normal(points[j + 1] - points[j])
			normals.append(normal.normalized())

	## Left-hand perpendicular: for an edge running +x along the top it points up.
	static func _edge_normal(edge: Vector2) -> Vector2:
		return Vector2(-edge.y, edge.x).normalized()


class SurfaceBuffer:
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()

	## Takes a counter-clockwise (right-hand rule) triangle and stores it clockwise,
	## which is Godot's front-face winding.
	func add_triangle(a: int, b: int, c: int) -> void:
		indices.append(a)
		indices.append(c)
		indices.append(b)

	func add_quad(a: int, b: int, c: int, d: int) -> void:
		add_triangle(a, b, c)
		add_triangle(a, c, d)

	func is_empty() -> bool:
		return indices.is_empty()

	## Triangles as vertex triplets in rendering winding, as ConcavePolygonShape3D expects.
	func append_faces_to(faces: PackedVector3Array) -> void:
		for index in indices:
			faces.append(vertices[index])

	func to_arrays() -> Array:
		var arrays := []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = vertices
		arrays[Mesh.ARRAY_NORMAL] = normals
		arrays[Mesh.ARRAY_TEX_UV] = uvs
		arrays[Mesh.ARRAY_INDEX] = indices
		return arrays
