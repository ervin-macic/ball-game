@tool
class_name TrackSegment
extends Resource
## One piece of a TrackBuilder layout. Subclasses advance the cursor and lay
## centreline frames; the builder turns the frames into road.
##
## To add a new kind of piece, extend this class, implement [method lay], and
## call [method Resource.emit_changed] from your property setters so the track
## rebuilds live in the editor.

## Safety wall along the left edge of this piece (0 = none).
@export_range(0.0, 10.0, 0.05, "suffix:m") var wall_left := 0.0:
	set(value):
		wall_left = value
		emit_changed()
## Off: the piece is open ground, not built road. The centreline still guides
## timing, ghosts and the autopilot, and a Terrain under the track carries the
## ball (it flattens itself along these stretches).
@export var paved := true:
	set(value):
		paved = value
		emit_changed()
## Grip of this piece's road (1 = normal; lower is slippery ice that pushes,
## steers and brakes less). Slippery road gets the builder's slick material.
@export_range(0.05, 1.0, 0.01) var grip := 1.0:
	set(value):
		grip = value
		emit_changed()
## Road width as a share of the track's: below 1 is a narrow plank. Widths
## ease into each other over a few metres.
@export_range(0.2, 2.0, 0.01) var width := 1.0:
	set(value):
		width = value
		emit_changed()
## Height of the curbs (lips) as a share of the track's: above 1 makes a deep
## channel the ball can't easily leave (corkscrews), still open on top.
@export_range(0.0, 6.0, 0.05) var curb := 1.0:
	set(value):
		curb = value
		emit_changed()
## Width of the curbs as a share of the track's lip width: with a high
## [member curb] and a narrow [member width] this makes a U-shaped channel.
@export_range(0.2, 6.0, 0.05) var curb_width := 1.0:
	set(value):
		curb_width = value
		emit_changed()
## Close this piece over into a see-through tube from rim to rim: the ball
## can roll right round inside it but never fly out (corkscrews).
@export var tube := false:
	set(value):
		tube = value
		emit_changed()
## Safety wall along the right edge of this piece (0 = none).
@export_range(0.0, 10.0, 0.05, "suffix:m") var wall_right := 0.0:
	set(value):
		wall_right = value
		emit_changed()


## Advances [param cursor] through this piece, adding frames to [param path] no
## more than [param max_spacing] metres or [param max_turn] radians apart.
func lay(_cursor: TrackCursor, _path: TrackPath, _max_spacing: float, _max_turn: float) -> void:
	push_warning("TrackSegment '%s' lays nothing: use SectionSegment, LoopSegment or GapSegment." % resource_name)
