@tool
class_name CorkscrewSegment
extends TrackSegment
## A roller-coaster corkscrew: the road spirals once (or more) around an axis
## along the direction of travel, turning the ball upside down and back. The
## road leans in toward the axis, so with enough speed the ball is pressed onto
## it all the way round. It enters and leaves level and straight, offset by
## nothing, so the next piece carries on in line.

## Distance along the axis the corkscrew covers.
@export_range(5.0, 300.0, 0.5, "suffix:m") var length := 46.0:
	set(value):
		length = value
		emit_changed()
## Radius of the spiral around its axis.
@export_range(1.0, 50.0, 0.1, "suffix:m") var radius := 5.5:
	set(value):
		radius = value
		emit_changed()
@export_range(0.25, 4.0, 0.25) var turns := 1.0:
	set(value):
		turns = value
		emit_changed()
## Which way it rolls: 1 rolls right (clockwise seen from behind), -1 left.
@export_range(-1.0, 1.0, 2.0) var direction := 1.0:
	set(value):
		direction = value
		emit_changed()

## The road is banked so a ball at this speed (at the entry; slower as it
## climbs) feels the road pushing straight up into it all the way round, as a
## coaster's corkscrew is: slower balls slide toward the low side, faster ones
## toward the high side. Over the top it needs speed to stay on.
## How far the corkscrew descends from entry to exit, so gravity pays for the
## climb over the top.
@export_range(0.0, 50.0, 0.1, "suffix:m") var drop := 0.0:
	set(value):
		drop = value
		emit_changed()
@export_range(5.0, 80.0, 0.5, "suffix:m/s") var design_speed := 26.0:
	set(value):
		design_speed = value
		emit_changed()

## Steepest slope of the smoothstep easing curve.
const EASE_PEAK_RATE := 1.5
const GRAVITY := 9.8
## The ball rolls with its centre this far above the road.
const BALL_RADIUS := 0.5
## A rolling solid ball turns height into speed as v² = 2 g h / 0.714.
const ROLLING_SHARE := 0.714


func lay(cursor: TrackCursor, path: TrackPath, max_spacing: float, max_turn: float) -> void:
	var start := cursor.frame()
	var forward := TrackCursor.direction(cursor.heading, 0.0)
	var right := Basis(Vector3.UP, cursor.heading) * Vector3.RIGHT
	var sweep := TAU * turns
	# The helix is entered and left along the track's own direction: its axis is
	# turned aside by the helix angle, so the ball arrives already moving along
	# the helix (a free ball can't be thrown into a roll that starts abruptly).
	# Along the axis the helix covers reach = length / cos(slope); its entry
	# tangent lines up with the track when sin(slope) = radius·sweep / length.
	# The ball's centre rides BALL_RADIUS nearer the axis than the road, so it
	# is the ball's path (not the road's) that has to set off along the track.
	var slope := asin(clampf((radius - BALL_RADIUS) * sweep / length, 0.0, 0.95))
	var axis := (forward * cos(slope) - right * direction * sin(slope)).normalized()
	var side := axis.cross(Vector3.UP).normalized()
	var reach := length / cos(slope)
	# Curvature of the helix (1 / its bending radius).
	var pitch_length := reach / sweep
	var curvature := radius / (radius * radius + pitch_length * pitch_length)
	var origin := start.origin
	var arc := sqrt(reach * reach + (sweep * radius) * (sweep * radius))
	var steps := maxi(ceili(arc / max_spacing), ceili(sweep / max_turn)) + 1
	var previous := origin
	for i in range(1, steps + 1):
		var t := float(i) / steps
		var point := _point(origin, axis, side, reach, sweep, t)
		var ahead := _point(origin, axis, side, reach, sweep, minf(t + 0.5 / steps, 1.0))
		var behind := _point(origin, axis, side, reach, sweep, maxf(t - 0.5 / steps, 0.0))
		var tangent := (ahead - behind).normalized()
		# The helix bends toward its axis; the road's up is where the ball
		# would be pressed: that bend at the expected speed, plus gravity.
		var axis_point := origin + axis * (reach * t) + Vector3.UP * (radius - drop * t)
		var toward_axis := axis_point - point
		if toward_axis.length_squared() < 1e-6:
			toward_axis = Vector3.UP
		var bend := (toward_axis - tangent * toward_axis.dot(tangent)).normalized()
		var climb := point.y - origin.y
		var speed_squared := maxf(design_speed * design_speed - 2.0 * GRAVITY * climb / ROLLING_SHARE, 4.0)
		var pressed := bend * (curvature * speed_squared) + Vector3.UP * GRAVITY
		var road_up := (pressed - tangent * pressed.dot(tangent)).normalized()
		cursor.distance += point.distance_to(previous)
		previous = point
		path.add_frame(Transform3D(Basis(tangent.cross(road_up), road_up, -tangent), point), cursor.distance)
	cursor.position = origin + axis * reach - Vector3.UP * drop
	cursor.pitch = 0.0
	cursor.bank = 0.0


## Point on the helix at [param t] (0..1), turning at a steady rate.
func _point(origin: Vector3, axis: Vector3, side: Vector3, reach: float, sweep: float, t: float) -> Vector3:
	var angle := sweep * t * direction
	var around := -Vector3.UP * cos(angle) + side * sin(angle)
	return origin + axis * (reach * t) + Vector3.UP * (radius - drop * t) + around * radius
