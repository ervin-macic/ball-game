@tool
class_name TrackRoute
extends TrackBuilder
## An alternative route: a second road that forks off its parent TrackBuilder
## and rejoins it further on, so players can pick a line.
##
## It starts right beside the parent road, edge to edge, with the lips between
## them laid flat: the road widens and splits like a Y and the ball rolls onto
## whichever side it is steered to. It then follows the parent at the
## [member offsets] and [member heights] given, except between the [member chord]
## points, where it runs on a smooth curve of its own (a straight line when the
## parent heads the same way at both). It rejoins by ending a little above the
## parent road (or open ground), so the ball drops back onto it. Its own bends
## are banked for [member design_speed]. [member gaps] are breaks to jump.
##
## Layout rules that keep it rideable: fork on a level, unbanked straight that
## carries on straight past [member fork_length] plus FORK_RAMP (the ball needs
## about 35 m to move across at speed); let the parent head
## the same way at both chord points; end low (2 to 3 m up) over a calm stretch
## with no ramp or jump in the 30 m after it, since the ball flies a little way
## before it lands.
##
## It is laid in the parent's space and rebuilt whenever the parent is; its
## cross-section and materials follow the parent's unless [member width] is set.

## Where along the parent track the route forks off and where it rejoins.
@export var from_distance := 100.0:
	set(value):
		from_distance = value
		_queue_rebuild()
@export var to_distance := 200.0:
	set(value):
		to_distance = value
		_queue_rebuild()
## Which side of the parent road it forks to: 1 right, -1 left.
@export_range(-1.0, 1.0, 2.0) var side := 1.0:
	set(value):
		side = value
		_queue_rebuild()
## Sideways distance from the parent's centreline: (share of the route 0..1,
## metres) key points, eased between. Start edge to edge (9.9 m for a 5 m route
## beside an 8 m road with the default lips) and end near 0 to land on the parent.
@export var offsets := PackedVector2Array([Vector2(0.0, 9.9), Vector2(0.2, 9.9), Vector2(1.0, 0.0)]):
	set(value):
		offsets = value
		_queue_rebuild()
## Height above the parent road: (share 0..1, metres) key points, eased between.
## Start at 0 (level with the fork) and end high enough to drop onto the parent.
@export var heights := PackedVector2Array([Vector2(0.0, 0.0), Vector2(0.15, 0.0), Vector2(1.0, 2.5)]):
	set(value):
		heights = value
		_queue_rebuild()
## Shares of the route (start, end) between which it leaves the parent's bends
## and runs on its own smooth curve. Equal values: it follows the parent.
@export var chord := Vector2.ZERO:
	set(value):
		chord = value
		_queue_rebuild()
## The parent's height under the route is averaged over this distance, so the
## route doesn't copy small humps such as a kicker ramp.
@export_range(0.0, 100.0, 0.5, "suffix:m") var height_smoothing := 24.0:
	set(value):
		height_smoothing = value
		_queue_rebuild()
## Distance along the parent the two roads stay joined (lips flat) at the fork.
@export_range(0.0, 200.0, 0.5, "suffix:m") var fork_length := 12.0:
	set(value):
		fork_length = value
		_queue_rebuild()
## Breaks to jump: (metres after the fork along the parent, gap length, rise of
## the far side). The far side should be a little higher so the jump is needed.
@export var gaps := PackedVector3Array():
	set(value):
		gaps = value
		_queue_rebuild()
## Road width (0: the same as the parent's).
@export_range(0.0, 100.0, 0.1, "suffix:m") var width := 0.0:
	set(value):
		width = value
		_queue_rebuild()
## Safety walls (left, right) along the route, except beside the fork.
@export var route_walls := Vector2.ZERO:
	set(value):
		route_walls = value
		_queue_rebuild()
@export_range(0.05, 1.0, 0.01) var route_grip := 1.0:
	set(value):
		route_grip = value
		_queue_rebuild()
## Bends are banked so a ball at this speed needs no grip to hold them...
@export_range(0.0, 100.0, 0.5, "suffix:m/s") var design_speed := 20.0:
	set(value):
		design_speed = value
		_queue_rebuild()
## ...up to this angle.
@export_range(0.0, 80.0, 0.5, "suffix:°") var max_bank := 30.0:
	set(value):
		max_bank = value
		_queue_rebuild()

## Stationary obstacles on the route: (metres along the route, metres to the
## right of its centreline). They're solid; weave between them.
@export var obstacles := PackedVector2Array():
	set(value):
		obstacles = value
		_queue_rebuild()
@export var obstacle_scene: PackedScene:
	set(value):
		obstacle_scene = value
		_queue_rebuild()
@export_range(0.2, 5.0, 0.05, "suffix:m") var obstacle_radius := 0.65:
	set(value):
		obstacle_radius = value
		_queue_rebuild()

## Distance along the parent track each frame of [member path] stands for.
var main_distances := PackedFloat32Array()

var _syncing := false


func _ready() -> void:
	# The parent builds its routes after its own path; nothing to do alone.
	pass


func rebuild() -> void:
	var parent := get_parent() as TrackBuilder
	if parent:
		parent.rebuild()


func _queue_rebuild() -> void:
	if _syncing:
		return
	var parent := get_parent() as TrackBuilder
	if parent:
		parent._queue_rebuild()


## Lays this route's centreline beside [param main]'s (in its space).
func lay_from(main: TrackBuilder) -> void:
	_sync_from(main)
	path = TrackPath.new()
	main_distances = PackedFloat32Array()
	var main_path := main.path
	if main_path.frames.size() < 2 or to_distance <= from_distance:
		return
	var span := to_distance - from_distance
	var samples := PackedFloat32Array([from_distance])
	for d in main_path.distances:
		if d > from_distance + 0.05 and d < to_distance - 0.05:
			samples.append(d)
	samples.append(to_distance)
	# The route's own curve between the chord points: a cubic Hermite from the
	# followed position and direction at one to those at the other.
	var curved := chord.y > chord.x + 1e-3
	var a := Vector3.ZERO
	var b := Vector3.ZERO
	var a_tangent := Vector3.ZERO
	var b_tangent := Vector3.ZERO
	if curved:
		a = _followed(main_path, from_distance + span * chord.x)
		b = _followed(main_path, from_distance + span * chord.y)
		var reach := Vector2(b.x - a.x, b.z - a.z).length()
		a_tangent = (_followed(main_path, from_distance + span * chord.x + 1.0) - a)
		b_tangent = (_followed(main_path, from_distance + span * chord.y + 1.0) - b)
		a_tangent = Vector3(a_tangent.x, 0.0, a_tangent.z).normalized() * reach
		b_tangent = Vector3(b_tangent.x, 0.0, b_tangent.z).normalized() * reach
	# Centreline points, grouped into runs split by the gaps.
	var runs: Array = [[]]
	for s in samples:
		var along := s - from_distance
		var rise := 0.0
		var in_gap := false
		for gap in gaps:
			if along > gap.x and along < gap.x + gap.y:
				in_gap = true
			elif along >= gap.x + gap.y:
				rise += gap.z
		if in_gap:
			if not runs[runs.size() - 1].is_empty():
				runs.append([])
			continue
		var u := along / span
		var point := _followed(main_path, s)
		if curved and u > chord.x and u < chord.y:
			var t := inverse_lerp(chord.x, chord.y, u)
			var t2 := t * t
			var t3 := t2 * t
			var on_curve := a * (2.0 * t3 - 3.0 * t2 + 1.0) + a_tangent * (t3 - 2.0 * t2 + t) \
				+ b * (-2.0 * t3 + 3.0 * t2) + b_tangent * (t3 - t2)
			point = Vector3(on_curve.x, point.y, on_curve.z)
		point.y += rise
		runs[runs.size() - 1].append({"at": s, "point": point, "along": along, "up": main_path.frame_at_distance(s).basis.y.normalized()})
	var distance := 0.0
	var previous := Vector3.INF
	for r in runs.size():
		var run: Array = runs[r]
		if run.size() < 2:
			continue
		if r > 0 and previous != Vector3.INF:
			var takeoff := distance
			distance += previous.distance_to(run[0]["point"])
			path.jumps.append(Vector2(takeoff, distance))
			path.break_run()
		var banks := _banks(run)
		for k in run.size():
			var here: Dictionary = run[k]
			var ahead: Vector3 = run[mini(k + 1, run.size() - 1)]["point"]
			var behind: Vector3 = run[maxi(k - 1, 0)]["point"]
			var tangent := (ahead - behind).normalized()
			var along: float = here["along"]
			# Beside the fork the route lies in the parent's plane; after it,
			# level and banked into its own bends.
			var own := smoothstep(fork_length, fork_length + FORK_RAMP, along)
			var flat_right := Vector3(-tangent.z, 0.0, tangent.x).normalized()
			var banked := (Vector3.UP * cos(banks[k]) - flat_right * sin(banks[k])).normalized()
			var up: Vector3 = (here["up"] as Vector3).lerp(banked, own)
			up = (up - tangent * up.dot(tangent)).normalized()
			if k > 0:
				distance += (here["point"] as Vector3).distance_to(run[k - 1]["point"])
			var walls := route_walls
			if own < 1.0:
				if side > 0.0:
					walls.x = 0.0
				else:
					walls.y = 0.0
			path.current_walls = walls
			path.current_grip = route_grip
			path.current_paved = true
			path.add_frame(Transform3D(Basis(tangent.cross(up), up, -tangent), here["point"]), distance)
			path.lips[path.lips.size() - 1] = Vector2(own, 1.0) if side > 0.0 else Vector2(1.0, own)
			main_distances.append(here["at"])
			previous = here["point"]


func _build_geometry() -> void:
	super._build_geometry()
	_place_obstacles()


## Solid obstacles at [member obstacles], sitting on the road.
func _place_obstacles() -> void:
	var old := get_node_or_null("Obstacles")
	if old:
		old.free()
	if obstacles.is_empty() or path.frames.size() < 2:
		return
	var holder := Node3D.new()
	holder.name = "Obstacles"
	add_child(holder, false, Node.INTERNAL_MODE_FRONT)
	for spot in obstacles:
		var frame := path.frame_at_distance(spot.x)
		var at := frame.origin + frame.basis.x.normalized() * spot.y + frame.basis.y.normalized() * obstacle_radius * 0.7
		var body := StaticBody3D.new()
		body.position = at
		var shape := SphereShape3D.new()
		shape.radius = obstacle_radius
		var collider := CollisionShape3D.new()
		collider.shape = shape
		body.add_child(collider)
		if obstacle_scene:
			var model: Node3D = obstacle_scene.instantiate()
			var box := Swinger._bounds(model)
			var fit := obstacle_radius * 2.3 / maxf(maxf(box.size.x, box.size.z), 1e-3)
			model.scale = Vector3.ONE * fit
			# Bottom a little into the road, so it sits on it rather than on its tips.
			model.position = Vector3(-box.get_center().x * fit, -box.position.y * fit - obstacle_radius * 0.7 - obstacle_radius * 0.15, -box.get_center().z * fit)
			model.rotation.y = spot.x
			body.add_child(model)
		holder.add_child(body)


## Total length of the route itself.
func length() -> float:
	return path.total_length()


## The route's position at [param s] along the parent when it follows it: the
## parent's centreline moved aside by the offset and up by the height.
func _followed(main_path: TrackPath, s: float) -> Vector3:
	var span := to_distance - from_distance
	var along := s - from_distance
	var u := along / span
	var frame := main_path.frame_at_distance(s)
	var flat_right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
	# In the parent's plane beside the fork (it is level there), then level.
	var own := smoothstep(fork_length, fork_length + FORK_RAMP, along)
	var right := frame.basis.x.normalized().lerp(flat_right, own).normalized()
	var point := frame.origin + right * side * _keyed(offsets, u)
	# Exactly level with the parent at the fork; smoothed after it.
	var base := lerpf(frame.origin.y, _smoothed_height(main_path, s), own)
	point.y = base + (point.y - frame.origin.y) + _keyed(heights, u)
	return point


## The parent's centreline height at [param s], averaged over [member height_smoothing].
func _smoothed_height(main_path: TrackPath, s: float) -> float:
	if height_smoothing <= 0.0:
		return main_path.frame_at_distance(s).origin.y
	var total := 0.0
	var count := 9
	for k in count:
		total += main_path.frame_at_distance(s + height_smoothing * (float(k) / (count - 1) - 0.5)).origin.y
	return total / count


## Bank angle at each point of [param run] for its bends at design speed
## (positive leans into a left bend), smoothed over a few metres.
func _banks(run: Array) -> PackedFloat32Array:
	var count := run.size()
	var curvature := PackedFloat32Array()
	curvature.resize(count)
	for k in count:
		var behind: Vector3 = run[maxi(k - 2, 0)]["point"]
		var here: Vector3 = run[k]["point"]
		var ahead: Vector3 = run[mini(k + 2, count - 1)]["point"]
		var d0 := Vector3(here.x - behind.x, 0.0, here.z - behind.z)
		var d1 := Vector3(ahead.x - here.x, 0.0, ahead.z - here.z)
		var length_sum := d0.length() + d1.length()
		if length_sum < 1e-3 or d0.length() < 1e-4 or d1.length() < 1e-4:
			continue
		curvature[k] = d0.normalized().cross(d1.normalized()).y * 2.0 / length_sum
	var banks := PackedFloat32Array()
	banks.resize(count)
	var limit := deg_to_rad(max_bank)
	for k in count:
		var total := 0.0
		var n := 0
		for j in range(maxi(k - 12, 0), mini(k + 13, count)):
			total += curvature[j]
			n += 1
		var kappa := total / maxi(n, 1)
		banks[k] = clampf(atan(design_speed * design_speed * kappa / 9.8), -limit, limit)
	return banks


func _sync_from(main: TrackBuilder) -> void:
	_syncing = true
	road_width = width if width > 0.0 else main.road_width
	lip_width = main.lip_width
	lip_height = main.lip_height
	lip_segments = main.lip_segments
	rim_width = main.rim_width
	thickness = main.thickness
	wall_thickness = main.wall_thickness
	friction = main.friction
	collision_layer = main.collision_layer
	road_material = main.road_material
	curb_material = main.curb_material
	side_material = main.side_material
	wall_material = main.wall_material
	slick_material = main.slick_material
	_syncing = false


## Value at [param u] of (u, value) key points, eased between neighbours with
## no bend at either key (so offsets and heights flow into each other).
static func _keyed(keys: PackedVector2Array, u: float) -> float:
	if keys.is_empty():
		return 0.0
	if u <= keys[0].x:
		return keys[0].y
	for k in range(1, keys.size()):
		if u <= keys[k].x:
			var a := keys[k - 1]
			var b := keys[k]
			var t := clampf(inverse_lerp(a.x, b.x, u), 0.0, 1.0)
			return lerpf(a.y, b.y, t * t * t * (t * (t * 6.0 - 15.0) + 10.0))
	return keys[keys.size() - 1].y
