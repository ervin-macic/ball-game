class_name RemoteBall
extends AnimatableBody3D
## Another party player's ball, drawn from the positions their game broadcasts
## (~15 a second). Between updates it carries on along the last known velocity
## for a moment and eases toward where the player should be, so it moves
## smoothly. When bumping is on it is solid: the local ball bounces off it like
## a moving obstacle (it can't be pushed: its owner's game decides where it is).

## Remote balls sit on their own physics layer; the local ball only collides
## with it while bumping is on, and the camera's checks never see it.
const LAYER := 1 << 4
## How long to keep extrapolating after the last update.
const EXTRAPOLATE := 0.3
## Further than this from where it should be, it jumps there instead of gliding.
const SNAP_DISTANCE := 8.0

var player_name := ""
var _target := Vector3.ZERO
var _velocity := Vector3.ZERO
var _rotation := Quaternion.IDENTITY
var _since_update := 0.0
var _placed := false
var _visual: Node3D
var _label: Label3D


func setup(display_name: String, color: Color) -> void:
	player_name = display_name
	sync_to_physics = true
	collision_layer = 0
	collision_mask = 0
	var shape := CollisionShape3D.new()
	var sphere_shape := SphereShape3D.new()
	sphere_shape.radius = 0.5
	shape.shape = sphere_shape
	add_child(shape)

	_visual = Node3D.new()
	add_child(_visual)
	var body := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.5
	sphere.height = 1.0
	body.mesh = sphere
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.35
	material.metallic_specular = 0.6
	body.material_override = material
	_visual.add_child(body)
	# A white band around the middle shows the ball rolling.
	var band := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.47
	torus.outer_radius = 0.53
	band.mesh = torus
	var band_material := StandardMaterial3D.new()
	band_material.albedo_color = Color(1, 1, 1)
	band_material.roughness = 0.5
	band.material_override = band_material
	band.rotation_degrees = Vector3(90, 0, 0)
	band.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_visual.add_child(band)

	_label = Label3D.new()
	_label.text = display_name
	_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label.no_depth_test = true
	_label.fixed_size = true
	_label.pixel_size = 0.0009
	_label.font_size = 40
	_label.outline_size = 10
	_label.modulate = Color.WHITE.lerp(color, 0.25)
	_label.outline_modulate = Color(0, 0, 0, 0.75)
	_label.position = Vector3(0, 1.0, 0)
	_label.render_priority = 10
	add_child(_label)


func set_solid(solid: bool) -> void:
	collision_layer = LAYER if solid else 0


## The latest broadcast: position, rotation, velocity and how old it is (s).
func set_pose(at: Vector3, rotation_now: Quaternion, velocity: Vector3, age: float) -> void:
	_velocity = velocity
	_rotation = rotation_now.normalized()
	_since_update = clampf(age, 0.0, EXTRAPOLATE)
	_target = at + velocity * _since_update
	if not _placed or global_position.distance_to(_target) > SNAP_DISTANCE:
		_placed = true
		global_position = _target
		_visual.quaternion = _rotation


func _physics_process(delta: float) -> void:
	if not _placed:
		return
	if _since_update < EXTRAPOLATE:
		_since_update += delta
		_target += _velocity * delta
	global_position = global_position.lerp(_target, 1.0 - exp(-14.0 * delta))
	_visual.quaternion = _visual.quaternion.slerp(_rotation, 1.0 - exp(-14.0 * delta))
