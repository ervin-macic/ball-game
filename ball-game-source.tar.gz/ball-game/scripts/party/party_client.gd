class_name PartyClient
extends Node
## Party mode, the game's side: several players race the same level at once.
##
## The party itself (players, rounds, start times, points, the lobby and podium
## screens) lives in the host page (party.jsx), over Möbius live rooms. A web
## build gets `window.ballGameParty`; this node polls its state every frame and:
##  - loads the party's level and pins it (the menu can't switch away);
##  - puts the ball on the start line, locked, and reports "loaded";
##  - starts everyone's clock at the shared start time (a late start counts the
##    seconds already gone, so nobody gains from loading slowly);
##  - reports the finish time;
##  - broadcasts this ball's position ~15 times a second and draws the others'
##    balls (RemoteBall), solid when the host turned bumping on.
## Elsewhere (desktop, tests) [member host] is null and nothing happens, unless
## a test hands in its own host.

const WEB_HOST_INTERFACE := "ballGameParty"

@export var race: RaceManager
@export var loader: LevelLoader
@export var ball: RollingBall
@export_range(1.0, 60.0, 1.0, "suffix:Hz") var pose_rate := 15.0

## The host bridge: state() -> JSON, remotes(level) -> JSON, pose(json),
## loaded(level, round), finish(time, round). Set before _ready to replace the
## web host, as the tests do.
var host: Variant = null
## Whether this player is in a party right now.
var active := false
var phase := ""
var party_round := -1
var party_level := ""

var _prepared_round := -1
var _started_round := -1
var _reported_round := -1
var _since_pose := 0.0
var _remotes := {}
var _remote_root: Node3D
var _solid := false


func _ready() -> void:
	# Keeps talking to the others while this player has the menu open.
	process_mode = Node.PROCESS_MODE_ALWAYS
	if host == null and OS.has_feature("web"):
		host = JavaScriptBridge.get_interface(WEB_HOST_INTERFACE)
	if host == null:
		set_process(false)
		return
	_remote_root = Node3D.new()
	_remote_root.name = "PartyBalls"
	add_child(_remote_root)
	race.finished.connect(_on_finished)


func _process(delta: float) -> void:
	var parsed: Variant = JSON.parse_string(str(host.state()))
	var state: Dictionary = parsed if parsed is Dictionary else {}
	if not state.get("active", false):
		if active:
			_leave()
		return
	active = true
	_apply(state)
	_draw_others()
	_since_pose += delta
	if _since_pose >= 1.0 / pose_rate:
		_since_pose = 0.0
		_send_pose()


func _apply(state: Dictionary) -> void:
	phase = str(state.get("phase", ""))
	party_round = int(state.get("round", -1))
	party_level = str(state.get("level", ""))
	_set_solid(bool(state.get("collisions", true)))
	var entrant := bool(state.get("entrant", false))
	if phase != "loading" and phase != "racing":
		_between_levels()
		return
	loader.party_level = party_level
	if loader.level_id != party_level:
		if not loader.busy:
			loader.load_level(party_level)
		return
	if _prepared_round != party_round:
		_prepare(entrant)
	var go_in: Variant = state.get("go_in")
	if phase == "racing" and _started_round != party_round and go_in != null and float(go_in) <= 0.0:
		_started_round = party_round
		if race.party_round:
			race.start_now(-float(go_in))
		else:
			ball.locked = false


## A new level: back to the start line, locked until the shared start.
func _prepare(entrant: bool) -> void:
	_prepared_round = party_round
	_started_round = -1
	# A plain restart first, so a free run from the lobby doesn't carry its clock in.
	race.party_round = false
	race.restart()
	race.party_round = entrant
	ball.locked = entrant
	race.restart()
	host.loaded(party_level, party_round)


## Lobby, results and podium: free rolling, any level.
func _between_levels() -> void:
	loader.party_level = ""
	ball.locked = false
	if race.party_round:
		race.party_round = false
		if race.state == RaceManager.State.RUNNING:
			race.restart()
	if phase == "lobby" or phase == "podium":
		_prepared_round = -1
		_started_round = -1
		_reported_round = -1


func _leave() -> void:
	active = false
	phase = ""
	_between_levels()
	_set_solid(false)
	for remote: RemoteBall in _remotes.values():
		remote.queue_free()
	_remotes.clear()


func _on_finished(time: float, _is_personal_best: bool) -> void:
	if active and race.party_round and phase == "racing" and _reported_round != party_round:
		_reported_round = party_round
		host.finish(time, party_round)


func _set_solid(solid: bool) -> void:
	if solid == _solid:
		return
	_solid = solid
	if solid:
		ball.collision_mask |= RemoteBall.LAYER
	else:
		ball.collision_mask &= ~RemoteBall.LAYER
	for remote: RemoteBall in _remotes.values():
		remote.set_solid(solid)


func _send_pose() -> void:
	if loader.level_id.is_empty():
		return
	var p := ball.global_position
	var q := ball.global_transform.basis.get_rotation_quaternion()
	var v := ball.linear_velocity
	host.pose(JSON.stringify({
		"lv": loader.level_id,
		"p": [snappedf(p.x, 0.01), snappedf(p.y, 0.01), snappedf(p.z, 0.01)],
		"q": [snappedf(q.x, 0.001), snappedf(q.y, 0.001), snappedf(q.z, 0.001), snappedf(q.w, 0.001)],
		"v": [snappedf(v.x, 0.01), snappedf(v.y, 0.01), snappedf(v.z, 0.01)],
		"d": snappedf(race.progress, 0.1),
	}))


func _draw_others() -> void:
	var parsed: Variant = JSON.parse_string(str(host.remotes(loader.level_id)))
	var seen := {}
	if parsed is Array:
		for entry: Variant in parsed:
			if not entry is Dictionary or not entry.get("p") is Array or entry["p"].size() != 3:
				continue
			var id := str(entry.get("pid", ""))
			seen[id] = true
			var remote: RemoteBall = _remotes.get(id)
			if remote == null:
				remote = RemoteBall.new()
				remote.setup(str(entry.get("name", "Player")), Color.from_string(str(entry.get("color", "#ffffff")), Color.WHITE))
				_remote_root.add_child(remote)
				remote.set_solid(_solid)
				_remotes[id] = remote
			remote.set_pose(_vector(entry["p"]), _quaternion(entry.get("q")), _vector(entry.get("v")), float(entry.get("age", 0.0)))
	for id: String in _remotes.keys():
		if not seen.has(id):
			_remotes[id].queue_free()
			_remotes.erase(id)


static func _vector(values: Variant) -> Vector3:
	if values is Array and values.size() == 3:
		return Vector3(float(values[0]), float(values[1]), float(values[2]))
	return Vector3.ZERO


static func _quaternion(values: Variant) -> Quaternion:
	if values is Array and values.size() == 4:
		var q := Quaternion(float(values[0]), float(values[1]), float(values[2]), float(values[3]))
		if q.length_squared() > 0.5:
			return q.normalized()
	return Quaternion.IDENTITY
