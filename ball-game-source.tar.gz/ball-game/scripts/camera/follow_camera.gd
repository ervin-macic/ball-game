class_name FollowCamera
extends Camera3D
## Third-person orbit camera for a RollingBall.
##
## It trails the ball with separate horizontal and vertical lag, swings behind the
## direction of travel, looks freely with mouse or right stick, and pulls in when
## track geometry gets between it and the ball. On steep surfaces such as loops
## its frame rolls with the track. It runs every rendered frame and reads the
## ball's interpolated transform (Godot 4.4+) for smooth motion at any refresh rate.

@export var ball: RollingBall

@export_group("Framing")
@export_range(1.0, 40.0, 0.1, "suffix:m") var distance := 6.5
## Height of the look-at pivot above the ball.
@export_range(0.0, 10.0, 0.05, "suffix:m") var pivot_height := 1.1
## Resting pitch. Negative looks down on the ball from above.
@export_range(-89.0, 89.0, 0.5, "suffix:°") var default_pitch := -13.0
@export_range(-89.0, 0.0, 0.5, "suffix:°") var min_pitch := -75.0
@export_range(0.0, 89.0, 0.5, "suffix:°") var max_pitch := 35.0
## The pivot leads the ball by this much of its velocity, so you see where you are going.
@export_range(0.0, 1.0, 0.01, "suffix:s") var look_ahead_time := 0.1
@export_range(0.0, 20.0, 0.1, "suffix:m") var max_look_ahead := 2.5

@export_group("Follow Lag")
## How quickly the pivot catches up horizontally. Lower trails further behind.
@export_range(0.1, 60.0, 0.1) var follow_sharpness := 10.0
## How quickly the pivot catches up vertically. Lower keeps bumps and hops calm.
@export_range(0.1, 60.0, 0.1) var vertical_follow_sharpness := 4.5
## The pivot never trails the ball by more than this.
@export_range(0.0, 20.0, 0.1, "suffix:m") var max_lag := 3.0

@export_group("Auto Orient")
## Swing behind the direction of travel. Off leaves the view entirely to the player.
@export var auto_orient := true
## How quickly the camera swings behind the direction of travel.
@export_range(0.0, 20.0, 0.05) var auto_yaw_sharpness := 2.0
## Fastest auto swing.
@export_range(0.0, 1080.0, 1.0, "suffix:°/s") var auto_yaw_max_rate := 220.0
## How much the pitch follows climbs and descents (0 = never, 1 = fully).
@export_range(0.0, 1.0, 0.01) var auto_pitch_strength := 0.35
@export_range(0.0, 20.0, 0.05) var auto_pitch_sharpness := 2.0
## Below this speed the camera does not auto-orient.
@export_range(0.0, 50.0, 0.1, "suffix:m/s") var auto_orient_min_speed := 2.0
## Auto-orient reaches full strength at this speed.
@export_range(0.0, 100.0, 0.1, "suffix:m/s") var auto_orient_full_speed := 14.0
## Travel further than this from the view direction is treated as deliberate reversing and not chased.
@export_range(0.0, 180.0, 1.0, "suffix:°") var auto_orient_max_angle := 135.0
## After manual look input, auto-orient waits this long before taking over again.
@export_range(0.0, 10.0, 0.05, "suffix:s") var free_look_hold_time := 1.2

@export_group("Free Look")
@export_range(0.01, 2.0, 0.005, "suffix:°/px") var mouse_sensitivity := 0.12
@export_range(10.0, 720.0, 1.0, "suffix:°/s") var stick_look_speed := 180.0
@export var invert_y := false
## Capture the mouse when the game starts. The pause menu (Esc) releases it; click to recapture.
## Web builds always wait for the first click: browsers refuse pointer lock without one.
@export var capture_mouse_on_start := true
## While the mouse is free, dragging with a held button still looks around. This is
## the fallback where pointer lock is refused (some embeds and browsers).
@export var drag_to_look := true

@export_group("Collision")
@export_flags_3d_physics var collision_mask := 1
## Radius of the sphere swept from the pivot toward the camera.
@export_range(0.01, 2.0, 0.01, "suffix:m") var probe_radius := 0.3
## Extra distance kept from whatever the sweep hits.
@export_range(0.0, 2.0, 0.01, "suffix:m") var collision_margin := 0.1
@export_range(0.0, 20.0, 0.1, "suffix:m") var min_distance := 1.2
## How quickly the camera eases back out once the obstruction clears. Pulling in is instant.
@export_range(0.1, 60.0, 0.1) var push_out_sharpness := 3.0

@export_group("Surface Follow")
## The camera frame starts rolling with the track at this surface angle from up...
@export_range(0.0, 180.0, 1.0, "suffix:°") var surface_follow_start_angle := 50.0
## ...and fully follows it at this angle (inside loops).
@export_range(0.0, 180.0, 1.0, "suffix:°") var surface_follow_full_angle := 85.0
@export_range(0.1, 60.0, 0.1) var surface_follow_sharpness := 6.0

@export_group("Track Chase")
## The track being raced (set by the race). Where it tilts steeply (loops,
## corkscrews, wall rides) the camera chases along the track itself, using its
## direction and up, which are smooth everywhere, instead of the ball's contact.
@export var track: TrackBuilder
## The chase starts blending in at this track tilt from upright...
@export_range(0.0, 180.0, 1.0, "suffix:°") var chase_start_angle := 40.0
## ...and fully takes over at this one.
@export_range(0.0, 180.0, 1.0, "suffix:°") var chase_full_angle := 75.0
@export_range(0.1, 60.0, 0.1) var chase_sharpness := 5.0
@export_range(0.0, 20.0, 0.1, "suffix:m") var chase_height := 1.4
## Distance behind the ball while chasing (tighter than the orbit, so the
## camera stays inside loops and corkscrews instead of behind their walls).
@export_range(1.0, 30.0, 0.1, "suffix:m") var chase_distance := 4.2
## The chase lets go if the ball is this far from the track (it flew off).
@export_range(1.0, 50.0, 0.5, "suffix:m") var chase_reach := 8.0

@export_group("Speed FOV")
@export_range(1.0, 179.0, 0.5, "suffix:°") var base_fov := 72.0
@export_range(1.0, 179.0, 0.5, "suffix:°") var max_fov := 88.0
@export_range(0.0, 200.0, 0.5, "suffix:m/s") var fov_speed_start := 10.0
@export_range(0.0, 200.0, 0.5, "suffix:m/s") var fov_speed_full := 45.0
@export_range(0.1, 30.0, 0.1) var fov_sharpness := 3.0

var _yaw := 0.0
var _pitch := 0.0
var _distance := 0.0
var _pivot := Vector3.ZERO
var _frame := Quaternion.IDENTITY
var _frame_axis := Vector3.RIGHT
var _free_look_left := 0.0
var _probe := SphereShape3D.new()
var _query := PhysicsShapeQueryParameters3D.new()
var _has_interpolated_transform := false
var _chase := 0.0
var _track_hint := -1


func _ready() -> void:
	# This node is moved every rendered frame from an already-interpolated target,
	# so it must not be interpolated a second time.
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	_pitch = deg_to_rad(default_pitch)
	_distance = distance
	fov = base_fov
	_has_interpolated_transform = has_method("get_global_transform_interpolated")
	if ball:
		_pivot = ball.global_position + Vector3.UP * pivot_height
	if capture_mouse_on_start and not OS.has_feature("web"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


## Yaw-only basis the player steers in: forward is where the camera looks, flattened.
func get_flat_basis() -> Basis:
	return Basis(Vector3.UP, _yaw)


## Places the camera directly behind [param target] (e.g. a spawn point) with no lag.
func snap_behind(target: Transform3D) -> void:
	var forward := -target.basis.z
	forward.y = 0.0
	if forward.length_squared() > 1e-6:
		_yaw = atan2(-forward.x, -forward.z)
	_pitch = deg_to_rad(default_pitch)
	_frame = Quaternion.IDENTITY
	_pivot = target.origin + Vector3.UP * pivot_height
	_distance = distance
	_free_look_left = 0.0
	_chase = 0.0
	_track_hint = -1
	fov = base_fov
	global_position = _pivot + Basis.from_euler(Vector3(_pitch, _yaw, 0.0)) * Vector3.BACK * _distance
	_place(_pivot, Vector3.UP)
	reset_physics_interpolation()


## Swings the camera behind the current direction of travel.
func recenter() -> void:
	if ball == null:
		return
	var flat := ball.surface_to_intent(ball.linear_velocity)
	flat.y = 0.0
	if flat.length() > 0.5:
		_yaw = atan2(-flat.x, -flat.z)
	_pitch = deg_to_rad(default_pitch)
	_free_look_left = 0.0


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and _is_looking(event as InputEventMouseMotion):
		var motion := (event as InputEventMouseMotion).relative
		_yaw -= deg_to_rad(motion.x * mouse_sensitivity)
		_pitch -= deg_to_rad(motion.y * mouse_sensitivity) * (-1.0 if invert_y else 1.0)
		_clamp_pitch()
		_free_look_left = free_look_hold_time
	elif event is InputEventMouseButton and event.is_pressed() and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	elif event.is_action_pressed("camera_recenter"):
		recenter()


func _is_looking(motion: InputEventMouseMotion) -> bool:
	if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		return true
	return drag_to_look and motion.button_mask & (MOUSE_BUTTON_MASK_LEFT | MOUSE_BUTTON_MASK_RIGHT) != 0


func _process(delta: float) -> void:
	if ball == null:
		return
	var ball_position := _ball_render_position()
	var velocity := ball.linear_velocity

	var found: Variant = _track_frame(ball_position)
	var on_track := found != null
	var chase_frame: Transform3D = found if on_track else Transform3D.IDENTITY
	var chase_target := 0.0
	if on_track:
		var tilt := acos(clampf(Vector3.UP.dot(chase_frame.basis.y), -1.0, 1.0))
		chase_target = smoothstep(deg_to_rad(chase_start_angle), deg_to_rad(chase_full_angle), tilt)
	_chase = lerpf(_chase, chase_target, 1.0 - exp(-chase_sharpness * delta))

	# With a track to chase, the orbit stays upright: the chase handles tilt.
	var surface_target := Quaternion.IDENTITY if track else _surface_frame_target()
	_frame = _frame.slerp(surface_target, 1.0 - exp(-surface_follow_sharpness * delta)).normalized()
	var frame := Basis(_frame)
	var up := frame * Vector3.UP

	if _chase > 0.05 and on_track:
		# Hold the steering direction along the track while it's tilted; when
		# the track is upright enough to say which way is ahead, follow it.
		var ahead := -chase_frame.basis.z
		if chase_frame.basis.y.y > 0.3 and Vector2(ahead.x, ahead.z).length() > 0.3:
			_yaw = lerp_angle(_yaw, atan2(-ahead.x, -ahead.z), 1.0 - exp(-chase_sharpness * delta))
		_pitch = lerpf(_pitch, deg_to_rad(default_pitch), 1.0 - exp(-chase_sharpness * delta))
	else:
		_apply_stick_look(delta)
		_auto_orient(frame.inverse() * velocity, delta)
	_follow_pivot(ball_position, velocity, up, delta)

	var target_fov := lerpf(base_fov, max_fov, smoothstep(fov_speed_start, fov_speed_full, velocity.length()))
	fov = lerpf(fov, target_fov, 1.0 - exp(-fov_sharpness * delta))

	# Inside a loop or corkscrew the track itself would keep pulling the camera
	# in; the chase keeps its distance there instead. Both hand over gradually
	# as the chase blends in, so nothing jumps.
	var chasing := smoothstep(0.25, 0.75, _chase)
	# (Fully chasing, the two collision sweeps aren't needed: skip them.)
	var pivot := _pivot if chasing >= 1.0 else _clear_pivot(ball_position).lerp(_pivot, chasing)
	var orbit := frame * Basis.from_euler(Vector3(_pitch, _yaw, 0.0))
	var back := orbit * Vector3.BACK
	var allowed := distance if chasing >= 1.0 else lerpf(_clear_distance(pivot, back), distance, chasing)
	_distance = lerpf(_distance, distance, 1.0 - exp(-push_out_sharpness * delta))
	_distance = minf(_distance, allowed)
	global_position = pivot + back * _distance
	_place(pivot, up)
	if _chase > 0.001 and on_track:
		var chase := _chase_transform(ball_position, chase_frame)
		# Blend where it looks and which way is up, not the two rotations: a
		# rotation blend takes the short way round, and flips to the other way
		# the moment the two views are more than half a turn apart.
		var look := (-global_transform.basis.z).lerp(-chase.basis.z, _chase)
		var blended_up := global_transform.basis.y.lerp(chase.basis.y, _chase)
		var eye := global_position.lerp(chase.origin, _chase)
		if look.length_squared() < 1e-6:
			look = -chase.basis.z
		if blended_up.length_squared() < 1e-6 or absf(look.normalized().dot(blended_up.normalized())) > 0.999:
			blended_up = chase.basis.y
		global_transform = Transform3D(Basis.looking_at(look, blended_up), eye)


## The track frame nearest the ball (world space), or null when there is no
## track or the ball is far from it.
func _track_frame(ball_position: Vector3) -> Variant:
	if track == null or track.network.frames.size() < 2:
		return null
	var path := track.network
	var local := track.to_local(ball_position)
	_track_hint = track.locate(local, _track_hint, 30)
	# Far from the stretch it was following (the ball jumped across onto
	# another part of the road): look along the whole track now and then.
	if path.frames[_track_hint].origin.distance_to(local) > chase_reach and Engine.get_process_frames() % 10 == 0:
		_track_hint = track.locate(local)
	var i := _track_hint
	# Slide between the two nearest samples so the frame moves smoothly (never
	# across a gap or onto another route).
	var j := i + 1 if path.connected(i, i + 1) else i
	if path.connected(i, i - 1) and (j == i or path.frames[i - 1].origin.distance_squared_to(local) < path.frames[j].origin.distance_squared_to(local)):
		j = i - 1
	var a := path.frames[i]
	var b := path.frames[j]
	var span := b.origin - a.origin
	var t := clampf((local - a.origin).dot(span) / maxf(span.length_squared(), 1e-6), 0.0, 1.0)
	var frame := track.global_transform * a.interpolate_with(b, t)
	if frame.origin.distance_to(ball_position) > chase_reach:
		return null
	return frame


## Behind the ball along the track, lifted along the track's up, looking ahead.
func _chase_transform(ball_position: Vector3, frame: Transform3D) -> Transform3D:
	var ahead := -frame.basis.z.normalized()
	var up := frame.basis.y.normalized()
	var eye := ball_position - ahead * chase_distance + up * chase_height
	var look := ball_position + ahead * 4.0 + up * 0.6
	return Transform3D(Basis.looking_at(look - eye, up), eye)


func _place(look_target: Vector3, up: Vector3) -> void:
	var to_target := look_target - global_position
	if to_target.length_squared() < 1e-6:
		return
	var safe_up := up if absf(to_target.normalized().dot(up)) < 0.999 else up.cross(Vector3.RIGHT)
	global_transform = Transform3D(Basis.looking_at(to_target, safe_up), global_position)


func _ball_render_position() -> Vector3:
	if _has_interpolated_transform and ball.is_physics_interpolated_and_enabled():
		return (ball.call("get_global_transform_interpolated") as Transform3D).origin
	return ball.global_position


func _surface_frame_target() -> Quaternion:
	var surface_up := ball.get_surface_up()
	var angle := acos(clampf(Vector3.UP.dot(surface_up), -1.0, 1.0))
	var follow := smoothstep(deg_to_rad(surface_follow_start_angle), deg_to_rad(surface_follow_full_angle), angle)
	if follow <= 0.0:
		return Quaternion.IDENTITY
	var axis := Vector3.UP.cross(surface_up)
	if axis.length() > 1e-3:
		_frame_axis = axis.normalized()
	return Quaternion(_frame_axis, angle * follow)


func _apply_stick_look(delta: float) -> void:
	var look := Input.get_vector("look_left", "look_right", "look_up", "look_down")
	if look.length_squared() < 1e-6:
		return
	var rate := deg_to_rad(stick_look_speed) * delta
	_yaw -= look.x * rate
	_pitch -= look.y * rate * (-1.0 if invert_y else 1.0)
	_clamp_pitch()
	_free_look_left = free_look_hold_time


func _auto_orient(frame_velocity: Vector3, delta: float) -> void:
	_free_look_left = maxf(_free_look_left - delta, 0.0)
	var flat := Vector3(frame_velocity.x, 0.0, frame_velocity.z)
	var speed := flat.length()
	if not auto_orient or _free_look_left > 0.0 or speed < auto_orient_min_speed:
		return
	var weight := clampf(inverse_lerp(auto_orient_min_speed, maxf(auto_orient_full_speed, auto_orient_min_speed + 0.01), speed), 0.0, 1.0)
	var yaw_error := wrapf(atan2(-flat.x, -flat.z) - _yaw, -PI, PI)
	if absf(yaw_error) <= deg_to_rad(auto_orient_max_angle):
		var max_step := deg_to_rad(auto_yaw_max_rate) * delta
		_yaw += clampf(yaw_error * (1.0 - exp(-auto_yaw_sharpness * weight * delta)), -max_step, max_step)
	var slope := atan2(frame_velocity.y, speed)
	var target_pitch := deg_to_rad(default_pitch) + slope * auto_pitch_strength
	_pitch = lerpf(_pitch, target_pitch, 1.0 - exp(-auto_pitch_sharpness * weight * delta))
	_clamp_pitch()


func _follow_pivot(ball_position: Vector3, velocity: Vector3, up: Vector3, delta: float) -> void:
	var desired := ball_position + up * pivot_height + (velocity * look_ahead_time).limit_length(max_look_ahead)
	var offset := desired - _pivot
	var vertical := up * offset.dot(up)
	var horizontal := offset - vertical
	_pivot += horizontal * (1.0 - exp(-follow_sharpness * delta)) + vertical * (1.0 - exp(-vertical_follow_sharpness * delta))
	var lag := desired - _pivot
	if lag.length() > max_lag:
		_pivot = desired - lag.normalized() * max_lag


## Pulls the pivot toward the ball if geometry sits between them (e.g. a loop's roof).
func _clear_pivot(ball_position: Vector3) -> Vector3:
	var fraction := _sweep(ball_position, _pivot - ball_position)
	return ball_position + (_pivot - ball_position) * fraction


func _clear_distance(pivot: Vector3, back: Vector3) -> float:
	var fraction := _sweep(pivot, back * distance)
	if fraction >= 1.0:
		return distance
	return clampf(distance * fraction - collision_margin, min_distance, distance)


## Fraction (0..1) of [param motion] a probe sphere can travel from [param from].
func _sweep(from: Vector3, motion: Vector3) -> float:
	if motion.length_squared() < 1e-8:
		return 1.0
	_probe.radius = probe_radius
	_query.shape = _probe
	_query.transform = Transform3D(Basis.IDENTITY, from)
	_query.motion = motion
	_query.collision_mask = collision_mask
	_query.exclude = [ball.get_rid()]
	var result := get_world_3d().direct_space_state.cast_motion(_query)
	return result[0] if result.size() > 0 else 1.0


func _clamp_pitch() -> void:
	_pitch = clampf(_pitch, deg_to_rad(min_pitch), deg_to_rad(max_pitch))
