class_name GhostBall
extends MeshInstance3D
## Replays the personal-best run as a translucent ball alongside the current run,
## so you can see where you lose time. Toggled from the settings menu.

@export var race: RaceManager
## Show the ghost. The split time on the HUD works either way.
@export var enabled := true:
	set(value):
		enabled = value
		visible = false
@export var color := Color(0.45, 0.85, 1.0, 0.35)


func _ready() -> void:
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if mesh == null:
		var sphere := SphereMesh.new()
		sphere.radius = 0.5
		sphere.height = 1.0
		mesh = sphere
	var material := StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = color
	material.rim_enabled = false
	material_override = material
	visible = false


func _process(_delta: float) -> void:
	var ghost := race.records.best_ghost if race and race.records else null
	if not enabled or race.party_round or ghost == null or ghost.is_empty():
		visible = false
		return
	match race.state:
		RaceManager.State.READY:
			visible = true
			global_transform = ghost.pose_at(0.0)
		RaceManager.State.RUNNING, RaceManager.State.FINISHED:
			visible = race.race_time <= ghost.duration + 1.0
			global_transform = ghost.pose_at(race.race_time)
