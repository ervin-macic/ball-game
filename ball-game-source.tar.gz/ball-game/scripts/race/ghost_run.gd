class_name GhostRun
extends RefCounted
## One recorded run: the ball's position and rotation sampled at a fixed rate,
## plus how far along the track it had got, so a later run can be compared with
## it at the same point of the track (the split time).

const SAMPLE_HZ := 30.0
const FORMAT_VERSION := 1

var duration := 0.0
var positions := PackedVector3Array()
var rotations: Array[Quaternion] = []
## Furthest track distance reached by each sample (never decreases).
var progress := PackedFloat32Array()


func add_sample(position: Vector3, rotation: Quaternion, track_distance: float) -> void:
	positions.append(position)
	rotations.append(rotation)
	var furthest := progress[progress.size() - 1] if not progress.is_empty() else 0.0
	progress.append(maxf(furthest, track_distance))


func is_empty() -> bool:
	return positions.size() < 2


## Pose at [param seconds] into the run, interpolated between samples.
func pose_at(seconds: float) -> Transform3D:
	if positions.is_empty():
		return Transform3D.IDENTITY
	var exact := clampf(seconds, 0.0, duration) * SAMPLE_HZ
	var i := mini(floori(exact), positions.size() - 1)
	var j := mini(i + 1, positions.size() - 1)
	var t := clampf(exact - i, 0.0, 1.0)
	var rotation := rotations[i].slerp(rotations[j], t)
	return Transform3D(Basis(rotation), positions[i].lerp(positions[j], t))


## Seconds into this run when it first reached [param track_distance], or INF if it never did.
func time_at_progress(track_distance: float) -> float:
	if progress.is_empty() or track_distance > progress[progress.size() - 1]:
		return INF
	var j := progress.bsearch(track_distance)
	if j <= 0:
		return 0.0
	var span := progress[j] - progress[j - 1]
	var t := (track_distance - progress[j - 1]) / span if span > 1e-6 else 0.0
	return (j - 1 + t) / SAMPLE_HZ


## Compact JSON form: millimetres, milli-units for rotations, decimetres of progress.
func to_dict() -> Dictionary:
	var p := []
	var q := []
	var d := []
	for k in positions.size():
		var v := positions[k]
		var r := rotations[k]
		p.append_array([roundi(v.x * 1000.0), roundi(v.y * 1000.0), roundi(v.z * 1000.0)])
		q.append_array([roundi(r.x * 1000.0), roundi(r.y * 1000.0), roundi(r.z * 1000.0), roundi(r.w * 1000.0)])
		d.append(roundi(progress[k] * 10.0))
	return {"v": FORMAT_VERSION, "hz": SAMPLE_HZ, "time": duration, "p": p, "q": q, "d": d}


static func from_dict(data: Variant) -> GhostRun:
	if not data is Dictionary or int(data.get("v", 0)) != FORMAT_VERSION or float(data.get("hz", 0)) != SAMPLE_HZ:
		return null
	var p: Array = data.get("p", [])
	var q: Array = data.get("q", [])
	var d: Array = data.get("d", [])
	var count := d.size()
	if p.size() != count * 3 or q.size() != count * 4:
		return null
	var ghost := GhostRun.new()
	ghost.duration = float(data.get("time", 0.0))
	for k in count:
		var rotation := Quaternion(q[k * 4] / 1000.0, q[k * 4 + 1] / 1000.0, q[k * 4 + 2] / 1000.0, q[k * 4 + 3] / 1000.0)
		ghost.positions.append(Vector3(p[k * 3], p[k * 3 + 1], p[k * 3 + 2]) / 1000.0)
		ghost.rotations.append(rotation.normalized() if rotation.length_squared() > 1e-6 else Quaternion.IDENTITY)
		ghost.progress.append(d[k] / 10.0)
	return ghost
