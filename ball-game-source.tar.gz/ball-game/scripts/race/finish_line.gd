@tool
class_name FinishLine
extends Node3D
## Timing gate. A finish is the ball's centre passing through this node's local
## XY plane while moving toward -Z, inside the gate's width and height. Crossings
## are tested on the segment between two physics positions, so even very fast
## balls cannot skip the line, and the exact crossing moment can be interpolated.

const CHECKER_SHADER := preload("res://materials/checker.gdshader")

## Distance between the posts.
@export_range(0.5, 200.0, 0.1, "suffix:m") var gate_width := 12.0:
	set(value):
		gate_width = value
		_rebuild_visuals()
@export_range(0.5, 100.0, 0.1, "suffix:m") var gate_height := 7.0:
	set(value):
		gate_height = value
		_rebuild_visuals()
## Width of the chequered strip painted across the road.
@export_range(0.0, 200.0, 0.1, "suffix:m") var strip_width := 8.0:
	set(value):
		strip_width = value
		_rebuild_visuals()

var _visuals: Node3D


func _ready() -> void:
	_rebuild_visuals()


## Sizes the gate to a road. Called by TrackBuilder when it places the line.
func fit_to_road(road_width: float, outer_width: float) -> void:
	strip_width = road_width
	gate_width = outer_width


## Fraction (0..1) along [param previous] → [param current] where the ball
## crossed the line going forward, or -1 if it did not.
func crossing_fraction(previous: Vector3, current: Vector3) -> float:
	var to_local := global_transform.affine_inverse()
	var a := to_local * previous
	var b := to_local * current
	if not (a.z > 0.0 and b.z <= 0.0):
		return -1.0
	var t := a.z / (a.z - b.z)
	var hit := a.lerp(b, t)
	# Over the top of the gate counts too (a ball can sail through the finish
	# off a jump); under the road doesn't.
	if absf(hit.x) > gate_width * 0.5 or hit.y < -2.0:
		return -1.0
	return t


func _rebuild_visuals() -> void:
	if not is_inside_tree():
		return
	if _visuals:
		_visuals.free()
	_visuals = Node3D.new()
	_visuals.name = "Visuals"
	add_child(_visuals, false, Node.INTERNAL_MODE_FRONT)

	var checker := ShaderMaterial.new()
	checker.shader = CHECKER_SHADER
	var post := StandardMaterial3D.new()
	post.albedo_color = Color(0.92, 0.94, 0.97)
	post.emission_enabled = true
	post.emission = Color(0.25, 0.75, 1.0)
	post.emission_energy_multiplier = 0.6

	var post_x := gate_width * 0.5 + 0.3
	for side in [-1.0, 1.0]:
		_add_box(Vector3(0.45, gate_height, 0.45), Vector3(side * post_x, gate_height * 0.5, 0.0), post)
	_add_box(Vector3(post_x * 2.0 + 0.45, 1.1, 0.25), Vector3(0.0, gate_height - 0.55, 0.0), checker)
	_add_box(Vector3(strip_width, 0.04, 1.6), Vector3.ZERO, checker)


## A run just finished: confetti bursts from both posts and showers down
## just ahead of the ball ([param ball_at], moving at [param velocity]), where
## the camera is looking while it brakes to a stop.
func celebrate(ball_at := Vector3.INF, velocity := Vector3.ZERO) -> void:
	if not is_inside_tree():
		return
	var post_x := gate_width * 0.5 + 0.3
	for side in [-1.0, 1.0]:
		var burst := _confetti(70, Vector3(0.4, 0.4, 0.4), Vector3(-side * 0.6, 1.0, 0.2), 40.0, Vector2(5.0, 10.0))
		add_child(burst)
		burst.position = Vector3(side * post_x, gate_height * 0.8, 0.0)
		burst.emitting = true
	if ball_at.is_finite():
		# Where the ball will be in about half a second, a few metres up.
		var ahead := velocity * 0.45
		var shower := _confetti(220, Vector3(5.0, 0.5, 5.0), Vector3(0, 1, 0), 60.0, Vector2(1.5, 4.0))
		add_child(shower)
		shower.global_position = ball_at + ahead + Vector3.UP * 4.5
		shower.emitting = true


func _confetti(amount: int, extents: Vector3, direction: Vector3, spread: float, speed: Vector2) -> CPUParticles3D:
	var burst := CPUParticles3D.new()
	burst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	burst.one_shot = true
	burst.explosiveness = 0.85
	burst.amount = amount
	burst.lifetime = 3.2
	burst.local_coords = false
	burst.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	burst.emission_box_extents = extents
	burst.direction = direction
	burst.spread = spread
	burst.initial_velocity_min = speed.x
	burst.initial_velocity_max = speed.y
	burst.gravity = Vector3(0, -4.0, 0)
	burst.damping_min = 1.0
	burst.damping_max = 2.5
	burst.angular_velocity_min = -540.0
	burst.angular_velocity_max = 540.0
	burst.scale_amount_min = 0.8
	burst.scale_amount_max = 1.5
	var piece := QuadMesh.new()
	piece.size = Vector2(0.24, 0.15)
	var paper := StandardMaterial3D.new()
	paper.vertex_color_use_as_albedo = true
	paper.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	paper.cull_mode = BaseMaterial3D.CULL_DISABLED
	paper.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	piece.material = paper
	burst.mesh = piece
	var colors := Gradient.new()
	colors.offsets = PackedFloat32Array([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
	colors.colors = PackedColorArray([Color(1, 0.3, 0.35), Color(1, 0.8, 0.2), Color(0.3, 0.85, 0.5),
		Color(0.3, 0.6, 1), Color(0.8, 0.4, 1), Color(1, 0.55, 0.15)])
	burst.color_initial_ramp = colors
	get_tree().create_timer(burst.lifetime + 0.5, true, false, true).timeout.connect(burst.queue_free)
	return burst


func _add_box(size: Vector3, centre: Vector3, material: Material) -> void:
	var box := BoxMesh.new()
	box.size = size
	box.material = material
	var instance := MeshInstance3D.new()
	instance.mesh = box
	instance.position = centre
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_visuals.add_child(instance)
