class_name CommunityBoard
extends Node
## The community leaderboard: every finished run is sent, with its ghost as
## proof, to the leaderboard every Möbius player shares; the fastest players are
## read back for the leaderboard (Tab) and the finish banner.
##
## The network work is the host page's: a web build in Möbius gets
## `window.ballGameCommunity` (submit, refresh and state, see index.jsx), which
## talks to the app's own service. Calls never block; this node polls the
## host's state and emits [signal changed] when it moves on. Elsewhere (desktop,
## tests) [member host] is null and the board stays [code]unavailable[/code].

signal changed

const WEB_HOST_INTERFACE := "ballGameCommunity"

@export var race: RaceManager
## Turn off to keep runs from being sent (tests, practice modes).
@export var send_runs := true
@export_range(0.05, 5.0, 0.05, "suffix:s") var poll_interval := 0.25

## The host bridge: anything with submit(track, time, ghost_json, request_id),
## refresh(track) and state(track) -> JSON text. Set before _ready to replace
## the web host, as the tests do.
var host: Variant = null
## "unavailable", "idle", "loading", "ready" or "error".
var status := "unavailable"
## Why the board is unavailable or failed, for the player.
var message := ""
## Last board read: {top: [{rank, player, time, runs}], runs, players, you, player}.
var board := {}
## The latest sent run: {id, status: "sending" | "done" | "error", message, result}.
var submission := {}

var _version := -1
var _since_poll := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if host == null and OS.has_feature("web"):
		host = JavaScriptBridge.get_interface(WEB_HOST_INTERFACE)
	if host == null:
		message = "The community leaderboard is available when you play in Möbius."
		set_process(false)
		return
	status = "idle"
	race.finished.connect(_on_finished)


func is_available() -> bool:
	return host != null


## Asks for a fresh copy of the board (the leaderboard does this when shown).
func refresh() -> void:
	if host:
		host.refresh(race.track_id)
		_poll()


func _on_finished(time: float, _is_personal_best: bool) -> void:
	var ghost := race.last_recording
	if not send_runs or not race.save_records or race.party_round or ghost == null or ghost.is_empty():
		return
	var request_id := Crypto.new().generate_random_bytes(16).hex_encode()
	host.submit(race.track_id, time, JSON.stringify(ghost.to_dict()), request_id)
	# Never show the previous run's ranking under this one, even for a moment.
	submission = {"id": request_id, "status": "sending"}
	changed.emit()
	_poll()


func _process(delta: float) -> void:
	_since_poll += delta
	if _since_poll >= poll_interval:
		_poll()


func _poll() -> void:
	_since_poll = 0.0
	var parsed: Variant = JSON.parse_string(str(host.state(race.track_id)))
	if not parsed is Dictionary or int(parsed.get("version", 0)) == _version:
		return
	_version = int(parsed.get("version", 0))
	status = str(parsed.get("status", "idle"))
	message = str(parsed.get("message", ""))
	board = parsed.get("board", {}) if parsed.get("board") is Dictionary else {}
	submission = parsed.get("submission", {}) if parsed.get("submission") is Dictionary else {}
	changed.emit()


## One line about the latest sent run for the finish banner, or "" if there's nothing to say yet.
func submission_line() -> String:
	match submission.get("status", ""):
		"sending":
			return "Sending to the community leaderboard…"
		"error":
			return "Community leaderboard: " + str(submission.get("message", "not sent"))
		"done":
			var result: Dictionary = submission.get("result", {})
			if result.get("rank") == null:
				return ""
			return "Community  #%d of %s" % [int(result["rank"]), MenuStyle.count(int(result.get("players", result["rank"])), "player")]
	return ""
