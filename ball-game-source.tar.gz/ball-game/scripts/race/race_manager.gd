class_name RaceManager
extends Node
## Owns one time-trial run: waiting for the first input, timing, the finish,
## instant restarts, leaving the track (a 3-2-1 countdown, then back to the
## start line), and the run's records (every finished run, the best time, and a
## ghost of the best run with live splits).
##
## Timing runs on physics ticks, so it is identical at any frame rate. At the
## finish, the crossing moment is interpolated inside the tick (sub-tick precision).

signal state_changed(state: State)
signal finished(time: float, is_personal_best: bool)

enum State {
	READY,    ## On the start line; the clock starts on the first input.
	RUNNING,
	FINISHED, ## Time frozen, the ball brakes to a stop; restart to go again.
}

@export var ball: RollingBall
@export var camera: FollowCamera
## Provides the spawn point, the finish line and the fall-out height. Normally
## handed over by the LevelLoader through use_level().
@export var track: TrackBuilder
## Safety net only: every level has solid ground and a border, so a ball can't
## normally get this far below the track (leaving the track counts down to a
## restart long before).
@export_range(1.0, 5000.0, 0.5, "suffix:m") var fall_reset_depth := 1000.0
## Off the track: this far below the nearest part of it...
@export_range(1.0, 100.0, 0.5, "suffix:m") var off_track_drop := 4.0
## ...or this far beside it...
@export_range(1.0, 500.0, 0.5, "suffix:m") var off_track_reach := 32.0
## ...for this long sets off_track, and the countdown to a restart begins.
## Long enough that a slip over the edge, a short hop or a dip into a gap that
## the ball recovers from never brings it up.
@export_range(0.0, 10.0, 0.05, "suffix:s") var off_track_grace := 1.0
## Underneath the road (it missed a jump and carried on below the next
## stretch) there is no way back up, so off_track shows almost at once and the
## countdown starts straight away.
@export_range(0.0, 10.0, 0.05, "suffix:s") var under_road_grace := 0.25
## Once off the track, this long (counted down on screen: 3, 2, 1) to get back
## on before the ball goes back to the start line.
@export_range(0.5, 10.0, 0.5, "suffix:s") var off_track_countdown := 3.0
## Progress along the track only counts while the ball is this close to it
## (so rolling along the ground under a raised stretch doesn't count).
@export_range(1.0, 100.0, 0.5, "suffix:m") var progress_reach := 9.0
## In a corkscrew's deep channel the ball is eased back toward the channel's
## middle (a groove): this spring (1/s²) and damping (1/s) act sideways only,
## and only while the ball is on or near the surface. Too little speed still
## drops it off the top; too much still rides it high on the wall.
@export_range(0.0, 100.0, 0.1) var channel_spring := 6.0
@export_range(0.0, 50.0, 0.1) var channel_damping := 3.0
## Records are kept under this track name (see RunRecords); each level has its own.
@export var track_id := "test_track"
## Turn off to keep runs from touching saved records (tests, practice modes).
@export var save_records := true
## A party level is running (PartyClient): everyone starts together, restarting
## puts the ball back on the start line without stopping the clock, and runs
## don't count as personal records (a restart mid-run would spoil the ghost).
var party_round := false

var state := State.READY
## Seconds since the first input of this run; frozen at the finish.
var race_time := 0.0
## Personal best for [member track_id], or INF.
var best_time: float:
	get:
		return records.best_time if records else INF
## This track's best time, run history and best ghost.
var records: RunRecords
## Seconds behind (+) or ahead of (-) the best run at the same point of the
## track, or NAN when there is no best run to compare with.
var split_delta := NAN
## Outcome of the last finish: {is_best, rank, total, previous_best}.
var last_finish := {}
## The recording of the last finished run.
var last_recording: GhostRun

var _previous_ball_position := Vector3.ZERO
var _fall_height := -INF
var _recording: GhostRun
var _next_sample_time := 0.0
var _track_hint := -1
var _furthest := 0.0
var _off_track_time := 0.0
var _under_road_time := 0.0
## The ball is underneath the built road nearest to it (see _is_under_road).
var _under_road := false
## The track's alternative routes, in the order the network numbers them.
var _routes: Array[TrackRoute] = []
## Furthest distance along the track this run has reached.
var progress: float:
	get:
		return _furthest
## True while the ball has been off the track for a moment (see off_track_grace).
var off_track := false
## Seconds left before an off-track ball goes back to the start line, or -1
## while it isn't counting down.
var reset_in := -1.0


func _ready() -> void:
	if ball == null or camera == null:
		push_error("RaceManager needs a ball and a camera.")
		set_physics_process(false)
		return
	ball.control_started.connect(_on_control_started)
	if track and records == null:
		use_track(track, track_id)
	elif track == null:
		set_physics_process(false)


## Races on [param level]'s track, with that level's records.
func use_level(level: Level) -> void:
	use_track(level.track, LevelCatalog.records_id(level.level_id), level.fall_reset_height)


## Races on [param new_track] under [param id]'s records. A finite
## [param fall_height] overrides the usual fall-out height below the track.
func use_track(new_track: TrackBuilder, id: String, fall_height := NAN) -> void:
	if new_track == null or new_track.spawn_marker == null or new_track.finish_line == null:
		push_error("RaceManager needs a track with spawn_marker and finish_line assigned.")
		set_physics_process(false)
		return
	track = new_track
	track_id = id
	_routes = new_track.routes()
	camera.track = new_track
	records = RunRecords.new(track_id, save_records)
	_fall_height = fall_height if is_finite(fall_height) else track.world_lowest_point() - fall_reset_depth
	set_physics_process(true)
	restart()


## Back to the start line: ball reset, camera snapped behind it, clock cleared.
## (Nothing to do before a level is in: the game can start on a level that
## is still downloading.)
func restart() -> void:
	if track == null:
		return
	var spawn := track.spawn_marker.global_transform
	ball.respawn(spawn)
	camera.snap_behind(spawn)
	if party_round and state == State.RUNNING:
		ball.start_control()
		_track_hint = -1
		_furthest = 0.0
		_off_track_time = 0.0
		_under_road_time = 0.0
		off_track = false
		reset_in = -1.0
		_previous_ball_position = spawn.origin
		return
	# Waits on the start line without rolling until the first input.
	ball.parked = true
	race_time = 0.0
	split_delta = NAN
	_recording = null
	_off_track_time = 0.0
	_under_road_time = 0.0
	off_track = false
	reset_in = -1.0
	_previous_ball_position = spawn.origin
	_set_state(State.READY)


func _physics_process(delta: float) -> void:
	if Input.is_action_just_pressed("restart"):
		restart()
		return
	var ball_position := ball.global_position
	if state == State.RUNNING:
		race_time += delta
		_track_progress(ball_position)
		_guide_through_channel(delta)
		off_track = _is_off_track(ball_position, delta)
		# Off the track: 3, 2, 1, then back to the start line, unless the
		# ball gets back on first.
		if off_track:
			reset_in = off_track_countdown if reset_in < 0.0 else reset_in - delta
			if reset_in <= 0.0:
				restart()
				return
		else:
			reset_in = -1.0
		# Through the gate finishes, however the ball got there: a run that
		# strays off the track for longer than the countdown is sent back to
		# the start, so reaching the gate means every excursion was short.
		var crossing := track.finish_line.crossing_fraction(_previous_ball_position, ball_position)
		if crossing >= 0.0:
			_finish(race_time - (1.0 - crossing) * delta)
	if state != State.FINISHED and ball_position.y < _fall_height:
		restart()
		return
	_previous_ball_position = ball_position


func _on_control_started() -> void:
	ball.parked = false
	if state == State.READY:
		race_time = 0.0
		_recording = GhostRun.new()
		_next_sample_time = 0.0
		_track_hint = -1
		_furthest = 0.0
		_set_state(State.RUNNING)


## Whether the ball has been well below or beside the track for the grace
## time, or underneath the road for a moment.
func _is_off_track(ball_position: Vector3, delta: float) -> bool:
	if _track_hint < 0:
		return false
	var nearest := track.to_global(track.network.frames[_track_hint].origin)
	var below := nearest.y - ball_position.y
	var beside := Vector2(nearest.x - ball_position.x, nearest.z - ball_position.z).length()
	if below > off_track_drop or beside > off_track_reach:
		_off_track_time += delta
	else:
		_off_track_time = 0.0
	_under_road_time = _under_road_time + delta if _under_road else 0.0
	return _off_track_time > off_track_grace or _under_road_time > under_road_grace


## Whether [param ball_position] is underneath the built road at network frame
## [param index]: the ball's centre below the deck's underside, within its
## width, beside that very slice of it (past the end of a stretch, over a gap,
## doesn't count). A ball on the road is half its size above the surface, and
## nothing in between is possible, so the margin needs no tuning. Open ground
## has nothing to be under (a pond is lower than the path across it).
func _is_under_road(ball_position: Vector3, index: int) -> bool:
	var at := _on_slice(ball_position, index)
	return track.network.paved[index] and not is_nan(at.y) and at.y < -_road_of(index).thickness


## Whether [param ball_position] is on the road (or open ground the track
## runs over) at network frame [param index], or just above it: within its
## width, beside that very slice of it.
func _is_on_road(ball_position: Vector3, index: int) -> bool:
	var at := _on_slice(ball_position, index)
	return not is_nan(at.y) and at.y > -0.3 and at.y < ball.radius + 2.0


## Where [param ball_position] is relative to network frame [param index]:
## (sideways, up from the road surface, along). Up is NAN when the ball isn't
## beside that slice of the road or is wider out than the road and its lips.
func _on_slice(ball_position: Vector3, index: int) -> Vector3:
	var network := track.network
	var road := _road_of(index)
	var frame := track.global_transform * network.frames[index]
	var offset := ball_position - frame.origin
	var along := offset.dot(frame.basis.z.normalized())
	var side := offset.dot(frame.basis.x.normalized())
	var half_width := road.road_width * 0.5 * network.widths[index] + road.lip_width
	if absf(along) >= 1.5 or absf(side) >= half_width:
		return Vector3(side, NAN, along)
	return Vector3(side, offset.dot(frame.basis.y.normalized()), along)


## The road network frame [param index] belongs to: the track itself or one of
## its routes, each with its own width.
func _road_of(index: int) -> TrackBuilder:
	var owner := track.network.owners[index]
	return track if owner == 0 else _routes[owner - 1]


func _guide_through_channel(delta: float) -> void:
	var network := track.network
	var in_channel := _track_hint >= 0 and network.lips[_track_hint].x >= 1.5
	ball.spin_follows_roll = in_channel
	if not in_channel:
		return
	var frame := track.global_transform * network.frames[_track_hint]
	var right := frame.basis.x.normalized()
	var rel := ball.global_position - frame.origin
	if rel.dot(frame.basis.y.normalized()) > 3.0:
		return
	var offset := rel.dot(right)
	var sideways := ball.linear_velocity.dot(right)
	ball.linear_velocity -= right * (offset * channel_spring + sideways * channel_damping) * delta


## Starts the clock now, without waiting for input (a party's start signal).
## [param late] seconds of the run have already gone (a slow load or frame):
## they count, so a late start never shortens anyone's time.
func start_now(late := 0.0) -> void:
	if state == State.READY:
		ball.locked = false
		ball.start_control()
		race_time = maxf(late, 0.0)
		_next_sample_time = race_time


## Samples the ghost recording and updates the live split against the best run.
func _track_progress(ball_position: Vector3) -> void:
	# Anywhere on the layout counts: a route's frames carry the distance along
	# the main track they stand for.
	_track_hint = track.locate(track.to_local(ball_position), _track_hint, 40)
	# Off the stretch it was following and onto another part of the road (a
	# jump straight across the tutorial's loop, say): carry on from there.
	# Only a ball on a road counts, so crossing open ground never does.
	if not _is_on_road(ball_position, _track_hint) and Engine.get_physics_frames() % 6 == 0:
		var anywhere := track.locate(track.to_local(ball_position))
		if anywhere != _track_hint and _is_on_road(ball_position, anywhere):
			_track_hint = anywhere
	var here := track.network.distances[_track_hint]
	_under_road = _is_under_road(ball_position, _track_hint)
	# Splits compare the moment each run first reaches a point of the track, so
	# they only change when the ball gets further: in the air over a gap the
	# nearest road point stands still, and a split taken then would only grow.
	var on_track := not _under_road and track.to_global(track.network.frames[_track_hint].origin).distance_to(ball_position) <= progress_reach
	var advanced := on_track and here > _furthest
	if on_track:
		_furthest = maxf(_furthest, here)
	if race_time >= _next_sample_time:
		_recording.add_sample(ball_position, ball.global_transform.basis.get_rotation_quaternion(), _furthest)
		_next_sample_time += 1.0 / GhostRun.SAMPLE_HZ
	var best := records.best_ghost
	if best and advanced:
		var best_time_here := best.time_at_progress(_furthest)
		if is_finite(best_time_here):
			split_delta = race_time - best_time_here


func _finish(time: float) -> void:
	race_time = time
	# The run is over: the ball brakes to a stop on the run-off.
	ball.brake_to_stop = true
	if track.finish_line:
		track.finish_line.celebrate(ball.global_position, ball.linear_velocity)
	var previous_best := records.best_time
	_recording.duration = time
	last_recording = _recording
	if party_round:
		last_finish = {"is_best": false, "party": true, "previous_best": previous_best}
		_set_state(State.FINISHED)
		finished.emit(time, false)
		return
	if is_finite(previous_best):
		split_delta = time - previous_best
	last_finish = records.add_run(time, _recording)
	last_finish["previous_best"] = previous_best
	_set_state(State.FINISHED)
	finished.emit(time, last_finish["is_best"])


func _set_state(new_state: State) -> void:
	state = new_state
	state_changed.emit(state)
