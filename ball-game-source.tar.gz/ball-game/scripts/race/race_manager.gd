class_name RaceManager
extends Node
## Owns one time-trial run: waiting for the first input, timing, the finish,
## instant restarts, falling out of the world, and the run's records (every
## finished run, the best time, and a ghost of the best run with live splits).
##
## Timing runs on physics ticks, so it is identical at any frame rate. At the
## finish, the crossing moment is interpolated inside the tick (sub-tick precision).

signal state_changed(state: State)
signal finished(time: float, is_personal_best: bool)

enum State {
	READY,    ## On the start line; the clock starts on the first input.
	RUNNING,
	FINISHED, ## Time frozen, the ball brakes to a stop; restart to go again.
}

@export var ball: RollingBall
@export var camera: FollowCamera
## Provides the spawn point, the finish line and the fall-out height. Normally
## handed over by the LevelLoader through use_level().
@export var track: TrackBuilder
## Safety net only: every level has solid ground and a border, so a ball can't
## normally get this far below the track. Leaving the track never restarts the
## run by itself; the player presses restart.
@export_range(1.0, 5000.0, 0.5, "suffix:m") var fall_reset_depth := 1000.0
## Off the track: this far below the nearest part of it...
@export_range(1.0, 100.0, 0.5, "suffix:m") var off_track_drop := 4.0
## ...or this far beside it...
@export_range(1.0, 500.0, 0.5, "suffix:m") var off_track_reach := 32.0
## ...for this long sets off_track (the HUD then suggests restarting).
@export_range(0.0, 10.0, 0.05, "suffix:s") var off_track_grace := 1.0
## Progress along the track only counts while the ball is this close to it
## (so rolling along the ground under a raised stretch doesn't count).
@export_range(1.0, 100.0, 0.5, "suffix:m") var progress_reach := 9.0
## A finish only counts after following the track to within this distance of
## it, so open ground can't be used as a shortcut.
@export_range(0.0, 500.0, 1.0, "suffix:m") var finish_progress_margin := 40.0
## In a corkscrew's deep channel the ball is eased back toward the channel's
## middle (a groove): this spring (1/s²) and damping (1/s) act sideways only,
## and only while the ball is on or near the surface. Too little speed still
## drops it off the top; too much still rides it high on the wall.
@export_range(0.0, 100.0, 0.1) var channel_spring := 6.0
@export_range(0.0, 50.0, 0.1) var channel_damping := 3.0
## Records are kept under this track name (see RunRecords); each level has its own.
@export var track_id := "test_track"
## Turn off to keep runs from touching saved records (tests, practice modes).
@export var save_records := true
## A party level is running (PartyClient): everyone starts together, restarting
## puts the ball back on the start line without stopping the clock, and runs
## don't count as personal records (a restart mid-run would spoil the ghost).
var party_round := false

var state := State.READY
## Seconds since the first input of this run; frozen at the finish.
var race_time := 0.0
## Personal best for [member track_id], or INF.
var best_time: float:
	get:
		return records.best_time if records else INF
## This track's best time, run history and best ghost.
var records: RunRecords
## Seconds behind (+) or ahead of (-) the best run at the same point of the
## track, or NAN when there is no best run to compare with.
var split_delta := NAN
## Outcome of the last finish: {is_best, rank, total, previous_best}.
var last_finish := {}
## The recording of the last finished run.
var last_recording: GhostRun

var _previous_ball_position := Vector3.ZERO
var _fall_height := -INF
var _recording: GhostRun
var _next_sample_time := 0.0
var _track_hint := -1
var _furthest := 0.0
var _off_track_time := 0.0
## Furthest distance along the track this run has reached.
var progress: float:
	get:
		return _furthest
## True while the ball has been off the track for a moment (see off_track_grace).
var off_track := false


func _ready() -> void:
	if ball == null or camera == null:
		push_error("RaceManager needs a ball and a camera.")
		set_physics_process(false)
		return
	ball.control_started.connect(_on_control_started)
	if track and records == null:
		use_track(track, track_id)
	elif track == null:
		set_physics_process(false)


## Races on [param level]'s track, with that level's records.
func use_level(level: Level) -> void:
	use_track(level.track, LevelCatalog.records_id(level.level_id), level.fall_reset_height)


## Races on [param new_track] under [param id]'s records. A finite
## [param fall_height] overrides the usual fall-out height below the track.
func use_track(new_track: TrackBuilder, id: String, fall_height := NAN) -> void:
	if new_track == null or new_track.spawn_marker == null or new_track.finish_line == null:
		push_error("RaceManager needs a track with spawn_marker and finish_line assigned.")
		set_physics_process(false)
		return
	track = new_track
	track_id = id
	camera.track = new_track
	records = RunRecords.new(track_id, save_records)
	_fall_height = fall_height if is_finite(fall_height) else track.world_lowest_point() - fall_reset_depth
	set_physics_process(true)
	restart()


## Back to the start line: ball reset, camera snapped behind it, clock cleared.
func restart() -> void:
	var spawn := track.spawn_marker.global_transform
	ball.respawn(spawn)
	camera.snap_behind(spawn)
	if party_round and state == State.RUNNING:
		ball.start_control()
		_track_hint = -1
		_furthest = 0.0
		_off_track_time = 0.0
		off_track = false
		_previous_ball_position = spawn.origin
		return
	race_time = 0.0
	split_delta = NAN
	_recording = null
	_off_track_time = 0.0
	off_track = false
	_previous_ball_position = spawn.origin
	_set_state(State.READY)


func _physics_process(delta: float) -> void:
	if Input.is_action_just_pressed("restart"):
		restart()
		return
	var ball_position := ball.global_position
	if state == State.RUNNING:
		race_time += delta
		_track_progress(ball_position)
		_guide_through_channel(delta)
		off_track = _is_off_track(ball_position, delta)
		var crossing := track.finish_line.crossing_fraction(_previous_ball_position, ball_position)
		var finish_at := track.path.total_length() - track.finish_distance_from_end
		if crossing >= 0.0 and _furthest >= finish_at - finish_progress_margin:
			_finish(race_time - (1.0 - crossing) * delta)
	if state != State.FINISHED and ball_position.y < _fall_height:
		restart()
		return
	_previous_ball_position = ball_position


func _on_control_started() -> void:
	if state == State.READY:
		race_time = 0.0
		_recording = GhostRun.new()
		_next_sample_time = 0.0
		_track_hint = -1
		_furthest = 0.0
		_set_state(State.RUNNING)


## Whether the ball has been well below or beside the track for the grace time.
func _is_off_track(ball_position: Vector3, delta: float) -> bool:
	if _track_hint < 0:
		return false
	var nearest := track.to_global(track.network.frames[_track_hint].origin)
	var below := nearest.y - ball_position.y
	var beside := Vector2(nearest.x - ball_position.x, nearest.z - ball_position.z).length()
	if below > off_track_drop or beside > off_track_reach:
		_off_track_time += delta
	else:
		_off_track_time = 0.0
	return _off_track_time > off_track_grace


func _guide_through_channel(delta: float) -> void:
	var network := track.network
	var in_channel := _track_hint >= 0 and network.lips[_track_hint].x >= 1.5
	ball.spin_follows_roll = in_channel
	if not in_channel:
		return
	var frame := track.global_transform * network.frames[_track_hint]
	var right := frame.basis.x.normalized()
	var rel := ball.global_position - frame.origin
	if rel.dot(frame.basis.y.normalized()) > 3.0:
		return
	var offset := rel.dot(right)
	var sideways := ball.linear_velocity.dot(right)
	ball.linear_velocity -= right * (offset * channel_spring + sideways * channel_damping) * delta


## Starts the clock now, without waiting for input (a party's start signal).
## [param late] seconds of the run have already gone (a slow load or frame):
## they count, so a late start never shortens anyone's time.
func start_now(late := 0.0) -> void:
	if state == State.READY:
		ball.locked = false
		ball.start_control()
		race_time = maxf(late, 0.0)
		_next_sample_time = race_time


## Samples the ghost recording and updates the live split against the best run.
func _track_progress(ball_position: Vector3) -> void:
	# Anywhere on the layout counts: a route's frames carry the distance along
	# the main track they stand for.
	_track_hint = track.locate(track.to_local(ball_position), _track_hint, 40)
	var here := track.network.distances[_track_hint]
	# Splits compare the moment each run first reaches a point of the track, so
	# they only change when the ball gets further: in the air over a gap the
	# nearest road point stands still, and a split taken then would only grow.
	var on_track := track.to_global(track.network.frames[_track_hint].origin).distance_to(ball_position) <= progress_reach
	var advanced := on_track and here > _furthest
	if on_track:
		_furthest = maxf(_furthest, here)
	if race_time >= _next_sample_time:
		_recording.add_sample(ball_position, ball.global_transform.basis.get_rotation_quaternion(), _furthest)
		_next_sample_time += 1.0 / GhostRun.SAMPLE_HZ
	var best := records.best_ghost
	if best and advanced:
		var best_time_here := best.time_at_progress(_furthest)
		if is_finite(best_time_here):
			split_delta = race_time - best_time_here


func _finish(time: float) -> void:
	race_time = time
	# The run is over: the ball brakes to a stop on the run-off.
	ball.brake_to_stop = true
	if track.finish_line:
		track.finish_line.celebrate(ball.global_position, ball.linear_velocity)
	var previous_best := records.best_time
	_recording.duration = time
	last_recording = _recording
	if party_round:
		last_finish = {"is_best": false, "party": true, "previous_best": previous_best}
		_set_state(State.FINISHED)
		finished.emit(time, false)
		return
	if is_finite(previous_best):
		split_delta = time - previous_best
	last_finish = records.add_run(time, _recording)
	last_finish["previous_best"] = previous_best
	_set_state(State.FINISHED)
	finished.emit(time, last_finish["is_best"])


func _set_state(new_state: State) -> void:
	state = new_state
	state_changed.emit(state)
