class_name RunRecords
extends RefCounted
## One track's personal records: the best time, every finished run, and the
## ghost of the fastest recorded run. Stored with GameStore unless [member persist] is off
## (tests, practice modes), in which case they live for the session only.

const MAX_RUNS := 5000
const BEST_TIMES_KEY := "best_times.json"
const LEGACY_DESKTOP_BESTS := "user://best_times.cfg"

var track_id: String
var persist: bool
var best_time := INF
var best_ghost: GhostRun
## Finished runs, oldest first: {"t": seconds, "at": unix time}.
var runs: Array = []


func _init(p_track_id: String, p_persist: bool) -> void:
	track_id = p_track_id
	persist = p_persist
	if persist:
		_load()


## Records a finished run. Returns {is_best, rank (1 = fastest of all runs), total}.
func add_run(seconds: float, ghost: GhostRun) -> Dictionary:
	var is_best := seconds < best_time
	runs.append({"t": snappedf(seconds, 0.001), "at": int(Time.get_unix_time_from_system())})
	if runs.size() > MAX_RUNS:
		runs = runs.slice(runs.size() - MAX_RUNS)
	if is_best:
		best_time = seconds
	# The ghost is the fastest run that has a recording. A best set before ghosts
	# were recorded has none, and must not leave the player without a ghost.
	var new_ghost := ghost != null and not ghost.is_empty() and (best_ghost == null or seconds < best_ghost.duration)
	if new_ghost:
		best_ghost = ghost
	if persist:
		GameStore.write(_runs_key(), runs)
		if is_best:
			var bests: Variant = GameStore.read(BEST_TIMES_KEY)
			bests = bests if bests is Dictionary else {}
			bests[track_id] = seconds
			GameStore.write(BEST_TIMES_KEY, bests)
		if new_ghost:
			GameStore.write(_ghost_key(), ghost.to_dict())
	return {"is_best": is_best, "rank": rank_of(seconds), "total": runs.size()}


## Position of [param seconds] among all runs (1 = fastest).
func rank_of(seconds: float) -> int:
	var faster := 0
	for run in runs:
		if float(run["t"]) < seconds - 0.0005:
			faster += 1
	return faster + 1


## The [param count] fastest runs, fastest first.
func top(count: int) -> Array:
	var sorted := runs.duplicate()
	sorted.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a["t"]) < float(b["t"]))
	return sorted.slice(0, count)


func _load() -> void:
	var bests: Variant = GameStore.read(BEST_TIMES_KEY)
	if bests is Dictionary and bests.has(track_id):
		best_time = float(bests[track_id])
	else:
		_import_legacy_desktop_best()
	var stored: Variant = GameStore.read(_runs_key())
	if stored is Array:
		runs = stored
	elif is_finite(best_time):
		runs = [{"t": snappedf(best_time, 0.001), "at": 0}]
	best_ghost = GhostRun.from_dict(GameStore.read(_ghost_key()))


func _import_legacy_desktop_best() -> void:
	var legacy := ConfigFile.new()
	if OS.has_feature("web") or legacy.load(LEGACY_DESKTOP_BESTS) != OK:
		return
	best_time = float(legacy.get_value("best_times", track_id, INF))
	if is_finite(best_time):
		GameStore.write(BEST_TIMES_KEY, {track_id: best_time})


func _runs_key() -> String:
	return "runs_%s.json" % track_id


func _ghost_key() -> String:
	return "ghost_%s.json" % track_id
