class_name TouchControls
extends CanvasLayer
## On-screen controls for touch screens, laid out the way mobile 3D ball and
## platform games do it (Marble It Up: Mayhem!'s analog stick and jump button,
## the floating sticks of most phone games):
##
## - a floating stick under the left thumb, wherever it lands, steers: the
##   further it's pushed, the harder the ball rolls, like a gamepad's stick;
## - dragging anywhere on the right looks around, as a mouse does on a desktop
##   (double tap there swings the camera behind the ball, like C), and the
##   camera swings behind the ball by itself just as on a desktop: a thumb
##   resting on that side takes the view only once it really drags;
## - the big button bottom right jumps: tap for a hop, hold for a full jump,
##   exactly as Space;
## - small buttons top left (just right of Möbius's exit button) open the
##   menu, restart the run and show the level's leaderboard (tap again to hide
##   it).
##
## The stick hands PlayerInput the same camera-relative intent a gamepad's
## left stick does, so the ball handles exactly as it does there: the physics
## never know which device drove them. Shown from the start on touch-first
## devices (ScreenFit), and on any other device once its screen is touched;
## there, keys, a mouse or a gamepad put them away again.

const ACCENT := Color(1.0, 0.48, 0.1)
const BUTTONS := ["menu", "restart", "board"]
const BUTTON_NAMES := {"menu": "Menu", "restart": "Restart", "board": "Leaderboard"}

@export var camera: FollowCamera
@export var race: RaceManager
@export var menu: PauseMenu
@export var board: LeaderboardOverlay
@export var levels: LevelLoader
@export var fit: ScreenFit

@export_group("Stick")
## The stick's ring, in UI pixels. The thumb's distance from its centre is how
## hard the ball is driven.
@export_range(20.0, 200.0, 1.0, "suffix:px") var stick_radius := 58.0
## Share of the ring a resting thumb can wander in without moving the ball.
@export_range(0.0, 0.5, 0.01) var dead_zone := 0.08
## Share of the ring where the stick is all the way over: full drive without
## having to reach the rim.
@export_range(0.3, 1.0, 0.01) var full_at := 0.85
## Share of the screen, from the left, where a touch takes the stick.
@export_range(0.2, 0.8, 0.01) var stick_area := 0.5

@export_group("Look")
## Degrees the camera turns per UI pixel dragged (Settings: touch look speed).
@export_range(0.01, 2.0, 0.01, "suffix:°/px") var look_sensitivity := 0.3
## Two touches on the look side this close together swing the camera behind the ball.
@export_range(0.1, 0.6, 0.01, "suffix:s") var double_tap_time := 0.3
## A touch on the look side only takes the view once it has moved this far
## from where it landed: a deliberate drag. A thumb resting on the screen, or
## landing just off the jump button, leaves the camera following the ball.
@export_range(0.0, 80.0, 1.0, "suffix:px") var look_start := 20.0
## A thumb on the look side keeps the view to itself only while it moves at
## least this far (from where it last did): a resting thumb's tremor doesn't
## stop the camera swinging behind the ball.
@export_range(0.0, 40.0, 1.0, "suffix:px") var look_slop := 10.0
## Once the thumb stops turning the view, the camera leaves it there this long,
## then swings behind the direction of travel again.
@export_range(0.0, 3.0, 0.05, "suffix:s") var look_hold := 0.4

@export_group("Buttons")
@export_range(24.0, 120.0, 1.0, "suffix:px") var jump_radius := 46.0
## The jump button also answers a little outside its circle: thumbs land wide.
@export_range(1.0, 2.0, 0.05) var jump_reach := 1.35
@export_range(32.0, 72.0, 1.0, "suffix:px") var button_size := 46.0
## Where the small buttons start, from the safe area's top-left corner. While
## the game fills the screen, Möbius keeps its own round exit button in that
## corner (10 px in, 40 px across, in browser pixels), so they start to its
## right rather than under it.
@export var corner_offset := Vector2(66.0, 10.0)
## Space between the controls and the edges of the safe area.
@export_range(0.0, 80.0, 1.0, "suffix:px") var margin := 22.0

## How far the stick is pushed: up is forward, like a gamepad stick
## (Input.get_vector's convention), length 0..1.
var stick := Vector2.ZERO
## Shown and taking touches.
var active := false

var _canvas: Control
var _touched := false
var _roles := {}
var _stick_index := -1
var _stick_base := Vector2.ZERO
var _stick_thumb := Vector2.ZERO
var _stick_rest := Vector2.ZERO
var _jump_index := -1
var _jump_centre := Vector2.ZERO
var _buttons := {}
var _pressed_button := ""
var _last_look_touch := -1.0
var _last_look_position := Vector2.ZERO
## Where each look touch last moved far enough to hold the view.
var _look_anchor := {}
## Where each look touch landed, until it has moved look_start from there.
var _look_landed := {}
var _board_on := false


func _ready() -> void:
	layer = 11
	process_mode = Node.PROCESS_MODE_ALWAYS
	_canvas = Control.new()
	_canvas.name = "Controls"
	_canvas.set_anchors_preset(Control.PRESET_FULL_RECT)
	_canvas.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_canvas.draw.connect(_draw_controls)
	add_child(_canvas)
	if fit:
		fit.changed.connect(_lay_out)
	_lay_out()
	_set_active(false)


## Whether the stick is being held: PlayerInput steers with it then.
func is_steering() -> bool:
	return active and _stick_index >= 0


func _process(_delta: float) -> void:
	var wanted := _wanted()
	if wanted != active:
		_set_active(wanted)
	if active and board != null and board.is_shown() != _board_on:
		_board_on = board.is_shown()
		_canvas.queue_redraw()


## Up on touch-first devices or once the screen is touched, while the game
## runs: not over the menu, a loading level or a paused (hidden) game.
func _wanted() -> bool:
	return (_touched or (fit != null and fit.touch_first)) and not get_tree().paused \
		and not (menu != null and menu.is_open()) and not (levels != null and levels.busy)


func _set_active(on: bool) -> void:
	active = on
	visible = on
	if camera:
		camera.touch_mode = on
	if not on:
		release_all()


## Lets go of everything held (a menu opened, the game hid or paused).
func release_all() -> void:
	_roles.clear()
	_look_anchor.clear()
	_look_landed.clear()
	_stick_index = -1
	stick = Vector2.ZERO
	if _jump_index >= 0:
		_jump_index = -1
		Input.action_release("jump")
	_pressed_button = ""
	if _canvas:
		_canvas.queue_redraw()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		release_all()


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed:
			_touched = true
			if not active and _wanted():
				_set_active(true)
		if not active:
			return
		if touch.pressed:
			_press(touch.index, touch.position)
		else:
			_lift(touch.index, touch.position)
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		if not active:
			return
		var drag := event as InputEventScreenDrag
		_drag(drag.index, drag.position, drag.relative)
		get_viewport().set_input_as_handled()
	elif _touched and (fit == null or not fit.touch_first) and _is_other_device(event):
		# Keys, a mouse or a gamepad on a device that isn't touch first.
		_touched = false


static func _is_other_device(event: InputEvent) -> bool:
	if event is InputEventKey or event is InputEventJoypadButton:
		return event.is_pressed()
	if event is InputEventJoypadMotion:
		return absf((event as InputEventJoypadMotion).axis_value) > 0.5
	if event is InputEventMouseMotion:
		var motion := event as InputEventMouseMotion
		return motion.device != InputEvent.DEVICE_ID_EMULATION and motion.relative.length() > 6.0
	return false


func _press(index: int, at: Vector2) -> void:
	for name: String in _buttons:
		if (_buttons[name] as Rect2).grow(6.0).has_point(at):
			_roles[index] = "button"
			_pressed_button = name
			_canvas.queue_redraw()
			return
	if _jump_index < 0 and at.distance_to(_jump_centre) <= jump_radius * jump_reach:
		_roles[index] = "jump"
		_jump_index = index
		Input.action_press("jump")
		_canvas.queue_redraw()
		return
	if _stick_index < 0 and at.x < _size().x * stick_area:
		_roles[index] = "stick"
		_stick_index = index
		var room := _usable().grow(-stick_radius * 0.6)
		_stick_base = at.clamp(room.position, room.end) if room.has_area() else at
		_stick_thumb = at
		_update_stick()
		return
	_roles[index] = "look"
	_look_anchor[index] = at
	_look_landed[index] = at
	var now := Time.get_ticks_msec() / 1000.0
	if now - _last_look_touch < double_tap_time and at.distance_to(_last_look_position) < 60.0:
		if camera:
			camera.recenter()
		_last_look_touch = -1.0
	else:
		_last_look_touch = now
		_last_look_position = at


func _drag(index: int, at: Vector2, relative: Vector2) -> void:
	match _roles.get(index, ""):
		"stick":
			_stick_thumb = at
			# A thumb that runs past the ring drags the ring along, so turning
			# back never needs the whole way back first.
			var offset := at - _stick_base
			if offset.length() > stick_radius:
				_stick_base = at - offset.normalized() * stick_radius
			_update_stick()
		"look":
			if camera == null:
				return
			if _look_landed.has(index):
				# Not a drag yet: the view stays the camera's.
				if at.distance_to(_look_landed[index]) < look_start:
					return
				_look_landed.erase(index)
			# Every movement turns the view; only a real one (look_slop from
			# where the last did) keeps the camera from swinging back.
			var anchor: Vector2 = _look_anchor.get(index, at)
			var moved := at.distance_to(anchor) >= look_slop
			if moved:
				_look_anchor[index] = at
			camera.look_by(relative * look_sensitivity, look_hold if moved else 0.0)


func _lift(index: int, at: Vector2) -> void:
	var role: String = _roles.get(index, "")
	_roles.erase(index)
	_look_anchor.erase(index)
	_look_landed.erase(index)
	match role:
		"stick":
			_stick_index = -1
			stick = Vector2.ZERO
			_canvas.queue_redraw()
		"jump":
			_jump_index = -1
			Input.action_release("jump")
			_canvas.queue_redraw()
		"button":
			# A button acts when the finger lifts on it (slide off to cancel).
			var name := _pressed_button
			_pressed_button = ""
			_canvas.queue_redraw()
			if _buttons.has(name) and (_buttons[name] as Rect2).grow(6.0).has_point(at):
				press_button(name)


## What the top-left buttons do (also for tests).
func press_button(name: String) -> void:
	match name:
		"menu":
			release_all()
			Input.action_release("leaderboard")
			if menu:
				menu.open()
		"restart":
			if race:
				race.restart()
		"board":
			if Input.is_action_pressed("leaderboard"):
				Input.action_release("leaderboard")
			else:
				Input.action_press("leaderboard")
			_canvas.queue_redraw()


## The stick's thumb position becomes a deflection: nothing inside the dead
## zone, then rising evenly to all the way over at full_at of the ring.
func _update_stick() -> void:
	var raw := (_stick_thumb - _stick_base) / stick_radius
	var amount := raw.length()
	if amount <= dead_zone:
		stick = Vector2.ZERO
	else:
		stick = raw / amount * clampf(inverse_lerp(dead_zone, full_at, amount), 0.0, 1.0)
	_canvas.queue_redraw()


# --- Layout and drawing --------------------------------------------------------

func _size() -> Vector2:
	return fit.size if fit else _canvas.get_viewport_rect().size


func _usable() -> Rect2:
	return fit.usable_rect() if fit else Rect2(Vector2.ZERO, _size())


func _lay_out() -> void:
	var area := _usable()
	_jump_centre = area.end - Vector2.ONE * (margin + jump_radius)
	_stick_rest = Vector2(area.position.x + margin + stick_radius, area.end.y - margin - stick_radius)
	var portrait := fit != null and fit.portrait
	var corner := area.position + corner_offset
	var step := button_size + 10.0
	_buttons.clear()
	for i in BUTTONS.size():
		var offset := Vector2(0.0, step * i) if portrait else Vector2(step * i, 0.0)
		_buttons[BUTTONS[i]] = Rect2(corner + offset, Vector2.ONE * button_size)
	if _canvas:
		_canvas.queue_redraw()


## Where a button is, in UI pixels (tests, and anything that points at it).
func button_rect(name: String) -> Rect2:
	return _buttons.get(name, Rect2())


func jump_centre() -> Vector2:
	return _jump_centre


func _draw_controls() -> void:
	if not active:
		return
	# The stick: where the thumb holds it, or a faint ring where it usually goes.
	if _stick_index >= 0:
		_ring(_stick_base, stick_radius, Color(0.02, 0.04, 0.08, 0.28), Color(1, 1, 1, 0.45), 3.0)
		if stick.length() > 0.0:
			# The rim fills as the stick goes over, like a throttle.
			var start := stick.angle() - stick.length() * PI
			_canvas.draw_arc(_stick_base, stick_radius, start, start + stick.length() * TAU, 48, Color(1, 1, 1, 0.9), 4.0, true)
		var knob := _stick_base + (_stick_thumb - _stick_base).limit_length(stick_radius)
		_canvas.draw_circle(knob, stick_radius * 0.42, Color(1, 1, 1, 0.78), true, -1.0, true)
	else:
		_ring(_stick_rest, stick_radius, Color(0.02, 0.04, 0.08, 0.14), Color(1, 1, 1, 0.22), 2.0)
		_canvas.draw_circle(_stick_rest, stick_radius * 0.42, Color(1, 1, 1, 0.22), true, -1.0, true)
	# Jump.
	var held := _jump_index >= 0
	_ring(_jump_centre, jump_radius, Color(ACCENT, 0.85) if held else Color(0.02, 0.04, 0.08, 0.38), Color(1, 1, 1, 0.75 if held else 0.5), 3.0)
	var chevron := jump_radius * 0.34
	var lift := Vector2(0.0, -jump_radius * 0.1)
	_canvas.draw_polyline(PackedVector2Array([
		_jump_centre + lift + Vector2(-chevron, chevron * 0.55),
		_jump_centre + lift + Vector2(0.0, -chevron * 0.55),
		_jump_centre + lift + Vector2(chevron, chevron * 0.55)]), Color.WHITE, 6.0, true)
	_canvas.draw_line(_jump_centre + Vector2(-chevron * 0.7, chevron * 0.95), _jump_centre + Vector2(chevron * 0.7, chevron * 0.95), Color(1, 1, 1, 0.55), 3.0, true)
	# Menu, restart, leaderboard.
	for name: String in _buttons:
		var box: Rect2 = _buttons[name]
		var lit := name == _pressed_button or (name == "board" and _board_on)
		var style := StyleBoxFlat.new()
		style.bg_color = Color(MenuStyle.GOLD, 0.9) if lit else Color(0.02, 0.04, 0.08, 0.55)
		style.border_color = Color(1, 1, 1, 0.3)
		style.set_border_width_all(1)
		style.set_corner_radius_all(int(box.size.x * 0.3))
		style.anti_aliasing = true
		_canvas.draw_style_box(style, box)
		_draw_icon(name, box, Color(0.08, 0.06, 0.02) if lit else Color.WHITE)


func _ring(centre: Vector2, radius: float, fill: Color, line: Color, width: float) -> void:
	_canvas.draw_circle(centre, radius, fill, true, -1.0, true)
	_canvas.draw_arc(centre, radius, 0.0, TAU, 64, line, width, true)


func _draw_icon(name: String, box: Rect2, color: Color) -> void:
	var c := box.get_center()
	var s := box.size.x
	match name:
		"menu":
			# Pause: the menu pauses the game.
			for x in [-0.11, 0.11]:
				_canvas.draw_rect(Rect2(c + Vector2(x * s - s * 0.05, -s * 0.17), Vector2(s * 0.1, s * 0.34)), color)
		"restart":
			var r := s * 0.2
			_canvas.draw_arc(c, r, deg_to_rad(-60.0), deg_to_rad(230.0), 24, color, s * 0.075, true)
			var tip := c + Vector2.from_angle(deg_to_rad(-60.0)) * r
			_canvas.draw_colored_polygon(PackedVector2Array([
				tip + Vector2(-s * 0.13, -s * 0.03), tip + Vector2(s * 0.06, -s * 0.12), tip + Vector2(s * 0.04, s * 0.09)]), color)
		"board":
			# A podium.
			var heights := [0.26, 0.4, 0.18]
			var width := s * 0.17
			for i in 3:
				var h: float = s * heights[i]
				_canvas.draw_rect(Rect2(c + Vector2((i - 1.5) * width + i * s * 0.015, s * 0.22 - h), Vector2(width, h)), color)
