class_name LoadingScreen
extends CanvasLayer
## Covers the game while a level downloads and builds: the level's name and
## description, a progress bar for the download, then "Building the level…".
##
## Building a level (terrain, scenery, the track) runs in one go on the main
## thread, and a web build has no other thread to keep the page moving, so the
## screen must be on show before that starts: LevelLoader waits for it to be
## drawn (wait_until_drawn) before building.

const BACKGROUND := Color(0.086, 0.125, 0.18)
const ACCENT := Color(1.0, 0.48, 0.1)

var _root: Control
var _picture: TextureRect
var _title: Label
var _blurb: Label
var _status: Label
var _bar: ProgressBar
var _tween: Tween


func _init() -> void:
	layer = 90
	process_mode = Node.PROCESS_MODE_ALWAYS
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_root)
	var background := ColorRect.new()
	background.color = BACKGROUND
	background.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(background)
	# A picture of the level, darkened toward the middle where the text sits.
	_picture = TextureRect.new()
	_picture.set_anchors_preset(Control.PRESET_FULL_RECT)
	_picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_picture.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_picture)
	var shade := TextureRect.new()
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	shade.stretch_mode = TextureRect.STRETCH_SCALE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fade := GradientTexture2D.new()
	fade.fill = GradientTexture2D.FILL_RADIAL
	fade.fill_from = Vector2(0.5, 0.5)
	fade.fill_to = Vector2(1.1, 1.1)
	var colors := Gradient.new()
	colors.set_color(0, Color(BACKGROUND, 0.82))
	colors.set_color(1, Color(BACKGROUND, 0.35))
	fade.gradient = colors
	shade.texture = fade
	_root.add_child(shade)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(center)
	var column := VBoxContainer.new()
	column.custom_minimum_size = Vector2(520, 0)
	column.add_theme_constant_override("separation", 14)
	center.add_child(column)
	_title = _label(46, Color.WHITE)
	column.add_child(_title)
	_blurb = _label(19, Color(1, 1, 1, 0.7))
	_blurb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_blurb)
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 10)
	column.add_child(spacer)
	_bar = ProgressBar.new()
	_bar.custom_minimum_size = Vector2(0, 10)
	_bar.show_percentage = false
	_bar.max_value = 1.0
	var track := StyleBoxFlat.new()
	track.bg_color = Color(1, 1, 1, 0.12)
	track.set_corner_radius_all(5)
	var fill := StyleBoxFlat.new()
	fill.bg_color = ACCENT
	fill.set_corner_radius_all(5)
	_bar.add_theme_stylebox_override("background", track)
	_bar.add_theme_stylebox_override("fill", fill)
	column.add_child(_bar)
	_status = _label(17, Color(1, 1, 1, 0.75))
	column.add_child(_status)
	visible = false


func _label(size: int, color: Color) -> Label:
	var label := Label.new()
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.5))
	label.add_theme_constant_override("outline_size", 4 if size > 30 else 0)
	return label


## Shows the screen for level [param entry] (a LevelCatalog entry).
func open(entry: Dictionary) -> void:
	if _tween:
		_tween.kill()
	_root.modulate.a = 1.0
	var image := str(entry.get("image", ""))
	_picture.texture = load(image) if not image.is_empty() and ResourceLoader.exists(image) else null
	_title.text = str(entry.get("title", ""))
	_blurb.text = str(entry.get("blurb", ""))
	_status.text = "Loading…"
	_bar.value = 0.0
	visible = true


func set_download(progress: float) -> void:
	_bar.value = clampf(progress, 0.0, 1.0)
	_status.text = "Downloading the level…  %d%%" % roundi(progress * 100.0)


func set_building() -> void:
	_bar.value = 1.0
	_status.text = "Building the level…"


func set_failed(message: String) -> void:
	_status.text = message
	_tween = create_tween()
	_tween.tween_interval(2.5)
	_tween.tween_callback(close)


## Waits until the screen as it is now has reached the display.
func wait_until_drawn() -> void:
	for i in 2:
		if DisplayServer.get_name() == "headless":
			await get_tree().process_frame
		else:
			await RenderingServer.frame_post_draw


func close() -> void:
	if not visible:
		return
	if _tween:
		_tween.kill()
	_tween = create_tween()
	_tween.tween_property(_root, "modulate:a", 0.0, 0.3)
	_tween.tween_callback(func() -> void: visible = false)
