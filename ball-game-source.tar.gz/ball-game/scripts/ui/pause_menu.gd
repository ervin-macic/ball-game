class_name PauseMenu
extends CanvasLayer
## The pause menu, for the things that aren't about one level: picking a level
## and the settings. Esc, P or the gamepad's Start button opens and closes it;
## the game is paused while open. The level being played has its leaderboard
## on Tab instead (LeaderboardOverlay).

@export var settings: GameSettings
@export var race: RaceManager
## Lists the levels and switches between them.
@export var levels: LevelLoader

var _panel_root: Control
var _tabs: TabContainer
var _value_labels := {}
var _controls := {}
var _resume: Button
var _level_rows: GridContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 10
	_build()
	settings.changed.connect(_sync_controls)
	_panel_root.hide()


func is_open() -> bool:
	return _panel_root.visible


func open() -> void:
	_fill_levels()
	_sync_controls()
	_panel_root.show()
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_resume.grab_focus()


func close() -> void:
	_panel_root.hide()
	get_tree().paused = false
	settings.save()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause_menu"):
		get_viewport().set_input_as_handled()
		if is_open():
			close()
		else:
			open()


func _build() -> void:
	_panel_root = Control.new()
	_panel_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_panel_root)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.06, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_panel_root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	_panel_root.add_child(center)

	var panel := MenuStyle.panel(880)
	center.add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 16)
	panel.add_child(column)
	var title := Label.new()
	title.text = "Paused"
	title.add_theme_font_size_override("font_size", 30)
	column.add_child(title)

	_tabs = TabContainer.new()
	_tabs.custom_minimum_size = Vector2(0, 500)
	_style_tabs(_tabs)
	column.add_child(_tabs)
	_tabs.add_child(_build_levels_tab())
	_tabs.add_child(_build_settings_tab())

	var buttons := HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 12)
	column.add_child(buttons)
	var hint := _card_label("Hold Tab (or Back on a gamepad) while playing to see this level's leaderboard", 13, Color(1, 1, 1, 0.55))
	hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	buttons.add_child(hint)
	var restart := Button.new()
	restart.text = "Restart run"
	restart.custom_minimum_size = Vector2(150, 44)
	_style_button(restart, false)
	restart.pressed.connect(func() -> void:
		close()
		race.restart())
	buttons.add_child(restart)
	_resume = Button.new()
	_resume.text = "Resume"
	_resume.custom_minimum_size = Vector2(150, 44)
	_style_button(_resume, true)
	_resume.pressed.connect(close)
	buttons.add_child(_resume)


func _build_levels_tab() -> Control:
	var scroll := ScrollContainer.new()
	scroll.name = "Levels"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 14)
	grid.add_theme_constant_override("v_separation", 14)
	scroll.add_child(grid)
	_level_rows = grid
	return scroll


const CARD_SIZE := Vector2(400, 210)
const GOLD := MenuStyle.GOLD
const SKY := MenuStyle.SKY


func _fill_levels() -> void:
	if levels == null:
		return
	for child in _level_rows.get_children():
		child.queue_free()
	var bests: Variant = GameStore.read(RunRecords.BEST_TIMES_KEY)
	for entry in LevelCatalog.available():
		var id: String = entry["id"]
		var best := float(bests.get(LevelCatalog.records_id(id), INF)) if bests is Dictionary else INF
		_level_rows.add_child(_level_card(entry, best))


## One level: its picture, name, description and your best time. Picking it
## switches to it (the level being played is marked instead).
func _level_card(entry: Dictionary, best: float) -> Button:
	var id: String = entry["id"]
	var current := id == levels.level_id
	var pinned := not levels.party_level.is_empty() and id != levels.party_level
	var card := Button.new()
	card.name = "Level_" + id
	card.custom_minimum_size = CARD_SIZE
	card.clip_contents = true
	card.focus_mode = Control.FOCUS_ALL
	card.disabled = current or levels.busy or pinned
	card.tooltip_text = "Playing now" if current else ("The party picks the level" if pinned else "Play " + str(entry["title"]))
	for state in ["normal", "hover", "pressed", "focus", "disabled"]:
		card.add_theme_stylebox_override(state, _card_style(state, current))
	card.pressed.connect(func() -> void:
		close()
		levels.load_level(id))
	var image := str(entry.get("image", ""))
	var picture := TextureRect.new()
	picture.set_anchors_preset(Control.PRESET_FULL_RECT)
	picture.offset_left = 3
	picture.offset_top = 3
	picture.offset_right = -3
	picture.offset_bottom = -3
	picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	picture.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if not image.is_empty() and ResourceLoader.exists(image):
		picture.texture = load(image)
	if pinned:
		picture.modulate = Color(0.45, 0.45, 0.5)
	card.add_child(picture)
	# Darken toward the bottom, where the words are.
	var shade := TextureRect.new()
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	shade.stretch_mode = TextureRect.STRETCH_SCALE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fade := GradientTexture2D.new()
	fade.fill_from = Vector2(0.5, 0.0)
	fade.fill_to = Vector2(0.5, 1.0)
	var colors := Gradient.new()
	colors.offsets = PackedFloat32Array([0.0, 0.35, 1.0])
	colors.colors = PackedColorArray([Color(0, 0, 0, 0.05), Color(0.02, 0.04, 0.08, 0.15), Color(0.02, 0.04, 0.08, 0.92)])
	fade.gradient = colors
	shade.texture = fade
	card.add_child(shade)
	var words := VBoxContainer.new()
	words.set_anchors_preset(Control.PRESET_FULL_RECT)
	words.offset_left = 16
	words.offset_right = -16
	words.offset_bottom = -12
	words.alignment = BoxContainer.ALIGNMENT_END
	words.add_theme_constant_override("separation", 4)
	words.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(words)
	var title := _card_label(str(entry["title"]), 24, Color.WHITE)
	title.add_theme_constant_override("outline_size", 6)
	title.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	words.add_child(title)
	var blurb := _card_label(str(entry["blurb"]), 13, Color(1, 1, 1, 0.82))
	blurb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	blurb.max_lines_visible = 2
	words.add_child(blurb)
	var chips := HBoxContainer.new()
	chips.add_theme_constant_override("separation", 8)
	chips.mouse_filter = Control.MOUSE_FILTER_IGNORE
	words.add_child(chips)
	chips.add_child(_chip("Best  " + RaceHud.format_time(best) if is_finite(best) else "No time yet", GOLD if is_finite(best) else Color(1, 1, 1, 0.6)))
	# Badges in the top corner.
	var badges := HBoxContainer.new()
	badges.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	badges.offset_left = -200
	badges.offset_right = -12
	badges.offset_top = 12
	badges.alignment = BoxContainer.ALIGNMENT_END
	badges.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(badges)
	if current:
		badges.add_child(_chip("▶  Playing now", SKY, true))
	elif pinned:
		badges.add_child(_chip("Party level only", Color(1, 1, 1, 0.7), true))
	return card


## Pill-shaped tabs over a clear page.
static func _style_tabs(tabs: TabContainer) -> void:
	var page := StyleBoxEmpty.new()
	page.content_margin_top = 14
	tabs.add_theme_stylebox_override("panel", page)
	for state in ["tab_selected", "tab_unselected", "tab_hovered", "tab_focus"]:
		var style := StyleBoxFlat.new()
		style.set_corner_radius_all(16)
		style.content_margin_left = 18
		style.content_margin_right = 18
		style.content_margin_top = 6
		style.content_margin_bottom = 6
		match state:
			"tab_selected":
				style.bg_color = SKY
			"tab_hovered":
				style.bg_color = Color(1, 1, 1, 0.14)
			"tab_focus":
				style.draw_center = false
				style.set_border_width_all(2)
				style.border_color = GOLD
			_:
				style.bg_color = Color(1, 1, 1, 0.06)
		tabs.add_theme_stylebox_override(state, style)
	tabs.add_theme_color_override("font_selected_color", Color(0.04, 0.08, 0.14))
	tabs.add_theme_color_override("font_unselected_color", Color(1, 1, 1, 0.8))
	tabs.add_theme_color_override("font_hovered_color", Color.WHITE)
	tabs.add_theme_constant_override("h_separation", 8)
	tabs.add_theme_font_size_override("font_size", 16)
	var nothing := StyleBoxEmpty.new()
	tabs.add_theme_stylebox_override("tabbar_background", nothing)


static func _card_style(state: String, current: bool) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.1, 0.13, 0.19)
	style.set_corner_radius_all(14)
	style.set_border_width_all(3)
	style.border_color = Color(1, 1, 1, 0.08)
	match state:
		"hover", "focus":
			style.border_color = GOLD
		"pressed":
			style.border_color = GOLD.lightened(0.3)
	if current:
		style.border_color = SKY
	return style


static func _card_label(text: String, size: int, color: Color) -> Label:
	return MenuStyle.label(text, size, color)


## A small rounded tag, e.g. a best time.
static func _chip(text: String, color: Color, solid := false) -> PanelContainer:
	var chip := PanelContainer.new()
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(color, 0.95) if solid else Color(0.02, 0.04, 0.08, 0.7)
	style.border_color = color
	style.set_border_width_all(0 if solid else 1)
	style.set_corner_radius_all(10)
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 3
	style.content_margin_bottom = 3
	chip.add_theme_stylebox_override("panel", style)
	var label := _card_label(text, 13, Color(0.05, 0.07, 0.1) if solid else color)
	chip.add_child(label)
	return chip


## Settings, grouped into cards: camera on the left; sound, racing aids and
## graphics on the right.
const SETTING_GROUPS := [
	["Camera", ["camera_distance", "camera_pitch", "fov", "speed_fov", "mouse_sensitivity", "invert_y", "auto_orient"]],
	["Sound", ["volume", "rolling_sound"]],
	["Racing", ["ghost", "split"]],
	["Graphics", ["render_scale", "fast_antialiasing", "shadows"]],
]


func _build_settings_tab() -> Control:
	var scroll := ScrollContainer.new()
	scroll.name = "Settings"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var page := VBoxContainer.new()
	page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page.add_theme_constant_override("separation", 12)
	scroll.add_child(page)
	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 14)
	page.add_child(columns)
	var left := VBoxContainer.new()
	var right := VBoxContainer.new()
	for column in [left, right]:
		column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		column.add_theme_constant_override("separation", 12)
		columns.add_child(column)
	for i in SETTING_GROUPS.size():
		var group: Array = SETTING_GROUPS[i]
		(left if i == 0 else right).add_child(_settings_card(group[0], group[1]))
	var reset := Button.new()
	reset.text = "Reset to defaults"
	reset.size_flags_horizontal = Control.SIZE_SHRINK_END
	reset.custom_minimum_size = Vector2(180, 36)
	_style_button(reset, false)
	reset.pressed.connect(settings.reset_to_defaults)
	left.add_child(reset)
	return scroll


func _settings_card(title: String, keys: Array) -> PanelContainer:
	var card := _card()
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 6)
	card.add_child(rows)
	var heading := _card_label(title.to_upper(), 13, SKY)
	heading.add_theme_constant_override("outline_size", 0)
	rows.add_child(heading)
	for key: String in keys:
		var entry := _schema_entry(key)
		var row := HBoxContainer.new()
		row.custom_minimum_size = Vector2(0, 34)
		row.add_theme_constant_override("separation", 10)
		var label := _card_label(entry["label"], 15, Color(1, 1, 1, 0.9))
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		row.add_child(label)
		if entry.has("min"):
			var slider := HSlider.new()
			slider.min_value = entry["min"]
			slider.max_value = entry["max"]
			slider.step = entry["step"]
			slider.custom_minimum_size = Vector2(150, 30)
			slider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			_style_slider(slider)
			slider.value_changed.connect(func(value: float) -> void: settings.set_value(key, value))
			row.add_child(slider)
			var value_label := _card_label("", 14, GOLD)
			value_label.custom_minimum_size = Vector2(58, 0)
			value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
			value_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			row.add_child(value_label)
			_controls[key] = slider
			_value_labels[key] = value_label
		else:
			var toggle := Button.new()
			toggle.toggle_mode = true
			toggle.custom_minimum_size = Vector2(64, 28)
			toggle.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			toggle.focus_mode = Control.FOCUS_ALL
			for state in ["normal", "hover", "focus"]:
				toggle.add_theme_stylebox_override(state, _pill(Color(1, 1, 1, 0.1), state != "normal"))
			for state in ["pressed", "hover_pressed"]:
				toggle.add_theme_stylebox_override(state, _pill(SKY, state == "hover_pressed"))
			toggle.add_theme_color_override("font_pressed_color", Color(0.04, 0.08, 0.14))
			toggle.add_theme_color_override("font_hover_pressed_color", Color(0.04, 0.08, 0.14))
			toggle.add_theme_font_size_override("font_size", 13)
			toggle.toggled.connect(func(on: bool) -> void:
				toggle.text = "ON" if on else "OFF"
				settings.set_value(key, on))
			row.add_child(toggle)
			_controls[key] = toggle
		rows.add_child(row)
	return card


static func _pill(color: Color, lit: bool) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(14)
	style.set_border_width_all(2 if lit else 0)
	style.border_color = GOLD
	style.content_margin_left = 10
	style.content_margin_right = 10
	return style


static func _card() -> PanelContainer:
	return MenuStyle.card()


static func _style_slider(slider: HSlider) -> void:
	var track := StyleBoxFlat.new()
	track.bg_color = Color(1, 1, 1, 0.12)
	track.set_corner_radius_all(4)
	track.content_margin_top = 3
	track.content_margin_bottom = 3
	var fill := StyleBoxFlat.new()
	fill.bg_color = SKY
	fill.set_corner_radius_all(4)
	fill.content_margin_top = 3
	fill.content_margin_bottom = 3
	slider.add_theme_stylebox_override("slider", track)
	slider.add_theme_stylebox_override("grabber_area", fill)
	slider.add_theme_stylebox_override("grabber_area_highlight", fill)
	slider.add_theme_icon_override("grabber", _knob(Color.WHITE))
	slider.add_theme_icon_override("grabber_highlight", _knob(GOLD))


static var _knobs := {}


## A round slider knob, drawn once per colour.
static func _knob(color: Color) -> Texture2D:
	if _knobs.has(color):
		return _knobs[color]
	var size := 20
	var image := Image.create(size, size, false, Image.FORMAT_RGBA8)
	var centre := Vector2(size, size) * 0.5 - Vector2(0.5, 0.5)
	for y in size:
		for x in size:
			var d := Vector2(x, y).distance_to(centre)
			var alpha := clampf(size * 0.5 - 1.0 - d, 0.0, 1.0)
			var shade := color.darkened(0.15 * clampf((d - 5.0) / 4.0, 0.0, 1.0))
			image.set_pixel(x, y, Color(shade, alpha))
	var texture := ImageTexture.create_from_image(image)
	_knobs[color] = texture
	return texture


static func _style_button(button: Button, primary: bool) -> void:
	for state in ["normal", "hover", "pressed", "focus"]:
		var style := StyleBoxFlat.new()
		style.set_corner_radius_all(12)
		style.content_margin_left = 18
		style.content_margin_right = 18
		if primary:
			style.bg_color = GOLD if state != "pressed" else GOLD.darkened(0.15)
			if state == "hover" or state == "focus":
				style.bg_color = GOLD.lightened(0.12)
		else:
			style.bg_color = Color(1, 1, 1, 0.08 if state == "normal" else 0.14)
		if state == "focus":
			style.set_border_width_all(2)
			style.border_color = Color.WHITE
		button.add_theme_stylebox_override(state, style)
	if primary:
		for color in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
			button.add_theme_color_override(color, Color(0.08, 0.06, 0.02))


func _sync_controls() -> void:
	for key in _controls:
		var control: Control = _controls[key]
		var value: Variant = settings.values[key]
		if control is HSlider:
			(control as HSlider).set_value_no_signal(value)
			var entry := _schema_entry(key)
			var text := ("%.2f" if entry["step"] < 0.1 else ("%.1f" if entry["step"] < 1.0 else "%d")) % value
			(_value_labels[key] as Label).text = text + entry["unit"]
		elif control is Button:
			(control as Button).set_pressed_no_signal(value)
			(control as Button).text = "ON" if value else "OFF"


static func _schema_entry(key: String) -> Dictionary:
	for entry in GameSettings.SCHEMA:
		if entry["key"] == key:
			return entry
	return {}
