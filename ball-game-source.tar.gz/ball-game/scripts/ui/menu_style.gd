class_name MenuStyle
extends RefCounted
## The look the pause menu and the leaderboard share: colours, the dark panel,
## rounded cards, labels and leaderboard rows.

const GOLD := Color(1.0, 0.82, 0.32)
const SKY := Color(0.35, 0.72, 1.0)


## The dark rounded panel a menu or board sits on, [param width] wide.
static func panel(width: float) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(width, 0)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.07, 0.1, 0.15, 0.97)
	style.set_corner_radius_all(16)
	style.set_content_margin_all(24)
	style.border_color = Color(0.25, 0.55, 0.85, 0.5)
	style.set_border_width_all(1)
	panel.add_theme_stylebox_override("panel", style)
	return panel


## A rounded panel the settings and leaderboards sit on.
static func card() -> PanelContainer:
	var card := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color(1, 1, 1, 0.045)
	style.border_color = Color(1, 1, 1, 0.08)
	style.set_border_width_all(1)
	style.set_corner_radius_all(14)
	style.set_content_margin_all(16)
	card.add_theme_stylebox_override("panel", style)
	return card


static func label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


## Small muted text under a list, wrapping.
static func footer() -> Label:
	var footer := Label.new()
	footer.modulate = Color(0.75, 0.8, 0.9)
	footer.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return footer


## One leaderboard line: a rank badge (gold, silver, bronze for the top three),
## a name, the time, and a detail on the right.
static func board_row(rank: int, name: String, time: float, detail: String, mine := false) -> PanelContainer:
	var row := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color(SKY, 0.16) if mine else Color(1, 1, 1, 0.03)
	style.set_corner_radius_all(9)
	style.content_margin_left = 8
	style.content_margin_right = 10
	style.content_margin_top = 4
	style.content_margin_bottom = 4
	row.add_theme_stylebox_override("panel", style)
	var line := HBoxContainer.new()
	line.add_theme_constant_override("separation", 10)
	row.add_child(line)
	var medal := [GOLD, Color(0.82, 0.86, 0.92), Color(0.86, 0.58, 0.36)]
	var badge := PanelContainer.new()
	badge.custom_minimum_size = Vector2(28, 26)
	var badge_style := StyleBoxFlat.new()
	badge_style.bg_color = medal[rank - 1] if rank >= 1 and rank <= 3 else Color(1, 1, 1, 0.1)
	badge_style.set_corner_radius_all(13)
	badge.add_theme_stylebox_override("panel", badge_style)
	var number := label(str(rank), 13, Color(0.08, 0.08, 0.1) if rank <= 3 else Color.WHITE)
	number.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	number.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	badge.add_child(number)
	line.add_child(badge)
	var who := label(name, 15, Color.WHITE)
	who.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	who.clip_text = true
	who.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	line.add_child(who)
	var when_label := label(detail, 12, Color(1, 1, 1, 0.55))
	when_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	line.add_child(when_label)
	var clock := label(RaceHud.format_time(time), 16, GOLD if rank == 1 else Color.WHITE)
	clock.custom_minimum_size = Vector2(86, 0)
	clock.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	clock.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	line.add_child(clock)
	return row


## 1, "run" → "1 run"; 3, "run" → "3 runs".
static func count(n: int, noun: String) -> String:
	return "%d %s%s" % [n, noun, "" if n == 1 else "s"]


## A run's date and time in the player's time zone ("earlier" when unknown).
static func when(unix_time: int) -> String:
	if unix_time <= 0:
		return "earlier"
	var date := Time.get_datetime_dict_from_unix_time(unix_time + int(Time.get_time_zone_from_system()["bias"]) * 60)
	return "%d-%02d-%02d %02d:%02d" % [date["year"], date["month"], date["day"], date["hour"], date["minute"]]
