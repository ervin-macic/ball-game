class_name RaceHud
extends CanvasLayer
## Race timer, personal best, live split against the best run, speed and run
## status, and the 3-2-1 countdown while the ball is off the track.

@export var race: RaceManager
@export var ball: RollingBall
## Adds the run's community ranking to the finish banner once it's known.
@export var community: CommunityBoard
## Shows level downloads and loading problems.
@export var levels: LevelLoader
@export var finish_color := Color(0.45, 0.95, 0.55)
@export var record_color := Color(1.0, 0.82, 0.3)
@export var ahead_color := Color(0.45, 0.95, 0.55)
@export var behind_color := Color(1.0, 0.45, 0.4)
## Show the split time against the best run (set from the settings menu).
@export var show_split := true

@onready var _timer: Label = %Timer
@onready var _best: Label = %Best
@onready var _speed: Label = %Speed
@onready var _status: Label = %Status
@onready var _split: Label = %Split
@onready var _countdown: Label = %Countdown

const OFF_TRACK_TEXT := "Off the track  ·  back to the start in"

var _finish_text := ""


func _ready() -> void:
	race.state_changed.connect(_on_state_changed)
	race.finished.connect(_on_finished)
	if community:
		community.changed.connect(_show_finish)
	if levels:
		levels.loading.connect(func(id: String, progress: float) -> void:
			_status.text = "Loading %s…  %d%%" % [LevelCatalog.find(id).get("title", id), roundi(progress * 100.0)]
			_status.show())
		levels.failed.connect(func(_id: String, message: String) -> void:
			_status.text = message
			_status.show())
	_on_state_changed(race.state)


func _process(_delta: float) -> void:
	_show_off_track_hint()
	_timer.text = format_time(race.race_time)
	_speed.text = "%d km/h" % roundi(ball.linear_velocity.length() * 3.6)
	var delta := race.split_delta
	_split.visible = show_split and not is_nan(delta) and race.state != RaceManager.State.READY
	if _split.visible:
		_split.text = format_delta(delta)
		_split.modulate = ahead_color if delta < 0.0 else behind_color


## -0.4231 → "-0.423", 1.5 → "+1.500" (a true minus sign).
static func format_delta(seconds: float) -> String:
	return ("−%.3f" if seconds < 0.0 else "+%.3f") % absf(seconds)


## 83.4567 → "1:23.457". Non-finite or negative times show as dashes.
static func format_time(seconds: float) -> String:
	if not is_finite(seconds) or seconds < 0.0:
		return "-:--.---"
	var millis := roundi(seconds * 1000.0)
	var minutes := floori(millis / 60000.0)
	var whole_seconds := floori(millis / 1000.0) - minutes * 60
	return "%d:%02d.%03d" % [minutes, whole_seconds, millis % 1000]


func _on_state_changed(state: RaceManager.State) -> void:
	_best.text = "BEST  " + format_time(race.best_time)
	match state:
		RaceManager.State.READY:
			_timer.modulate = Color.WHITE
			_status.text = "Get ready…" if race.party_round else "Move to start"
			_status.show()
		RaceManager.State.RUNNING:
			_status.hide()


var _hinting := false
var _counting := 0


## While the ball is off the track: what's happening, and a big 3, 2, 1 to
## the moment it goes back to the start line (unless it gets back on).
func _show_off_track_hint() -> void:
	var wanted := race.state == RaceManager.State.RUNNING and race.off_track
	if wanted != _hinting:
		_hinting = wanted
		if wanted:
			_status.text = OFF_TRACK_TEXT
			_status.show()
		elif _status.text == OFF_TRACK_TEXT:
			# (Left alone otherwise: a restart has just put up "Move to start".)
			_status.hide()
	var number := ceili(race.reset_in) if wanted and race.reset_in > 0.0 else 0
	if number == _counting:
		return
	_counting = number
	_countdown.visible = number > 0
	if number > 0:
		_countdown.text = str(number)
		# Each second lands with a little punch.
		_countdown.scale = Vector2.ONE * 1.4
		create_tween().tween_property(_countdown, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _show_finish() -> void:
	if race.state != RaceManager.State.FINISHED:
		return
	var line := community.submission_line() if community and not race.party_round else ""
	_status.text = _finish_text + ("\n" + line if line else "")


func _on_finished(time: float, is_personal_best: bool) -> void:
	var color := record_color if is_personal_best else finish_color
	var result := race.last_finish
	if result.get("party", false):
		_finish_text = "FINISH  %s" % format_time(time)
		_show_finish()
		_status.show()
		return
	_finish_text = "FINISH  %s%s\n#%d of %d runs  ·  R / Y to go again" % [
		format_time(time), "   NEW BEST" if is_personal_best else "", result.get("rank", 1), result.get("total", 1)]
	_show_finish()
	_status.show()
	_best.text = "BEST  " + format_time(race.best_time)
	var tween := create_tween()
	_timer.modulate = Color.WHITE
	tween.tween_property(_timer, "modulate", color, 0.12)
	tween.tween_property(_timer, "modulate", Color.WHITE.lerp(color, 0.6), 0.6)
