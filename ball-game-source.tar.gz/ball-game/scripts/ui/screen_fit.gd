class_name ScreenFit
extends Node
## Fits the game's UI to the screen it is played on.
##
## Phones and tablets (touch first) lay the UI out in the browser's own pixels,
## so a 44 px button is a thumb-sized 44 px however dense the screen, a little
## smaller on small phones and a little bigger on tablets. Desktops keep the
## window's pixels exactly as before. Small screens (most phones) get the
## compact layouts of the HUD and menus, and the safe area the page reports
## (a notch, rounded corners, the home bar) stays clear of controls and text.
## The HUD, menus, loading screen and touch controls listen to [signal changed].

signal changed

## The page's bridge (index.jsx): device() describes the screen.
const HOST_INTERFACE := "ballGameHost"
## Short side, in browser pixels, the phone layout is drawn for: smaller
## phones shrink the UI a little, bigger screens (tablets) grow it.
const REFERENCE_SHORT_SIDE := 430.0
const MIN_ZOOM := 0.85
const MAX_ZOOM := 1.3
## Below this many UI pixels high or wide, the HUD and menus go compact.
const COMPACT_HEIGHT := 600.0
const COMPACT_WIDTH := 720.0

## -1 asks the page (or the platform) whether this is a touch-first device;
## 0 and 1 decide it (tests, or a desktop build tried out as a phone).
@export_range(-1, 1) var force_touch_first := -1
## Off, the layout is only what apply_layout() is given (tests try out
## screens without resizing the window or scaling its UI).
@export var follow_window := true

## Laid out for a phone or tablet: touch controls from the start, browser-pixel UI.
var touch_first := false
## Screen pixels per UI pixel (the root window's content scale factor).
var ui_scale := 1.0
## The UI's size, in UI pixels.
var size := Vector2(1600, 900)
var compact := false
var portrait := false
## Clear margins at each edge, in UI pixels.
var safe := {"left": 0.0, "top": 0.0, "right": 0.0, "bottom": 0.0}

var _decided := false
var _since_check := 0.0


func _ready() -> void:
	is_touch_first()
	get_tree().root.size_changed.connect(refit)
	refit()


## The safe area can change without the window resizing (the page reports it
## a moment after a rotation), so phones look again now and then.
func _process(delta: float) -> void:
	if not touch_first or not follow_window:
		return
	_since_check += delta
	if _since_check >= 0.5:
		_since_check = 0.0
		refit()


func is_touch_first() -> bool:
	if not _decided:
		_decided = true
		if force_touch_first >= 0:
			touch_first = force_touch_first == 1
		else:
			var device := _device()
			touch_first = bool(device.get("touch_first", OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")))
	return touch_first


## Works the layout out again for the window as it is now, and tells the UI
## when anything changed.
func refit() -> void:
	is_touch_first()
	if not follow_window:
		return
	var device := _device()
	var pixels := Vector2(get_tree().root.size)
	if pixels.x < 1.0 or pixels.y < 1.0:
		return
	var ratio := float(device.get("pixel_ratio", DisplayServer.screen_get_scale()))
	var safe_css: Variant = device.get("safe", {})
	apply_layout(layout(pixels, ratio, touch_first, safe_css if safe_css is Dictionary else {}))


## Takes [param fitted] (from layout()) as the screen's layout: scales the
## window's UI to it on touch-first devices, and tells the UI if anything changed.
func apply_layout(fitted: Dictionary) -> void:
	var window := get_tree().root
	if follow_window and touch_first and not is_equal_approx(window.content_scale_factor, fitted["scale"]):
		window.content_scale_factor = fitted["scale"]
	var before := [ui_scale, size, compact, portrait, safe]
	ui_scale = fitted["scale"]
	size = fitted["size"]
	compact = fitted["compact"]
	portrait = fitted["portrait"]
	safe = fitted["safe"]
	if [ui_scale, size, compact, portrait, safe] != before:
		changed.emit()


## The layout for a screen [param pixels] big (screen pixels) at
## [param pixel_ratio] screen pixels per browser pixel, with [param safe_css]
## margins (browser pixels, from the page). Returns the UI scale (screen
## pixels per UI pixel), the UI's size, whether it's compact or portrait, and
## the safe margins in UI pixels.
static func layout(pixels: Vector2, pixel_ratio: float, is_touch_first: bool, safe_css := {}) -> Dictionary:
	pixel_ratio = maxf(pixel_ratio, 0.5)
	var scale := 1.0
	if is_touch_first:
		var css := pixels / pixel_ratio
		scale = pixel_ratio * clampf(minf(css.x, css.y) / REFERENCE_SHORT_SIDE, MIN_ZOOM, MAX_ZOOM)
	var ui_size := pixels / scale
	var margins := {}
	for edge in ["left", "top", "right", "bottom"]:
		margins[edge] = maxf(float(safe_css.get(edge, 0.0)), 0.0) * pixel_ratio / scale
	return {
		"scale": scale,
		"size": ui_size,
		"compact": ui_size.y < COMPACT_HEIGHT or ui_size.x < COMPACT_WIDTH,
		"portrait": ui_size.y > ui_size.x,
		"safe": margins,
	}


## Asks the page to draw the whole game with at most [param pixels] (0: at the
## screen's own density). The page then reports a lower pixel ratio, so the
## window shrinks to match and the UI keeps its size (refit). Nothing outside
## a browser.
func limit_pixels(pixels: float) -> void:
	var host: Variant = _host()
	if host != null and host.set_pixel_budget != null:
		host.set_pixel_budget(pixels)


## The rectangle clear of the safe margins, inset by [param margin] more.
func usable_rect(margin := 0.0) -> Rect2:
	var left: float = safe["left"] + margin
	var top: float = safe["top"] + margin
	return Rect2(left, top, size.x - left - safe["right"] - margin, size.y - top - safe["bottom"] - margin)


func _host() -> Variant:
	return JavaScriptBridge.get_interface(HOST_INTERFACE) if OS.has_feature("web") else null


func _device() -> Dictionary:
	var host: Variant = _host()
	if host == null or host.device == null:
		return {}
	var parsed: Variant = JSON.parse_string(str(host.device()))
	return parsed if parsed is Dictionary else {}
