class_name LeaderboardOverlay
extends CanvasLayer
## This level's leaderboards, shown for as long as Tab (or a gamepad's Back
## button) is held: the community's fastest players and your own fastest runs.
## Like a scoreboard, the game carries on underneath. The general things, the
## levels and the settings, are in the pause menu (Esc).

@export var race: RaceManager
@export var community: CommunityBoard
@export var levels: LevelLoader
## Not shown over the pause menu, where Tab moves between its controls.
@export var menu: PauseMenu
@export var leaderboard_size := 10

## Looking again soon after doesn't ask the community board for a fresh copy
## every time.
const REFRESH_INTERVAL := 15.0

var _root: Control
var _title: Label
var _community_rows: VBoxContainer
var _community_footer: Label
var _board_rows: VBoxContainer
var _board_footer: Label
var _refreshed_at := -INF
var _refreshed_track := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 9
	_build()
	_root.hide()
	if community:
		community.changed.connect(func() -> void:
			if is_shown():
				_fill_community())
	race.finished.connect(func(_time: float, _best: bool) -> void:
		if is_shown():
			_fill_runs())


func is_shown() -> bool:
	return _root.visible


func _process(_delta: float) -> void:
	var wanted := Input.is_action_pressed("leaderboard") and not (menu and menu.is_open()) and not (levels and levels.busy)
	if wanted != is_shown():
		if wanted:
			show_board()
		else:
			hide_board()


## Shows the boards for the level being played, asking the community board
## for a fresh copy if the last one is old.
func show_board() -> void:
	_fill_runs()
	_fill_community()
	var now := Time.get_ticks_msec() / 1000.0
	if community and (now - _refreshed_at > REFRESH_INTERVAL or race.track_id != _refreshed_track):
		_refreshed_at = now
		_refreshed_track = race.track_id
		community.refresh()
	_root.show()


func hide_board() -> void:
	_root.hide()


func _build() -> void:
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.06, 0.45)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(center)
	var panel := MenuStyle.panel(880)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 14)
	panel.add_child(column)
	var heading := HBoxContainer.new()
	column.add_child(heading)
	_title = MenuStyle.label("", 30, Color.WHITE)
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading.add_child(_title)
	var kind := MenuStyle.label("LEADERBOARD", 13, MenuStyle.SKY)
	kind.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	heading.add_child(kind)
	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 14)
	column.add_child(columns)
	for side in 2:
		var card := MenuStyle.card()
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		columns.add_child(card)
		var list := VBoxContainer.new()
		list.add_theme_constant_override("separation", 6)
		card.add_child(list)
		list.add_child(MenuStyle.label("COMMUNITY · FASTEST PLAYERS" if side == 0 else "YOUR FASTEST RUNS", 13, MenuStyle.SKY))
		var rows := VBoxContainer.new()
		rows.add_theme_constant_override("separation", 4)
		list.add_child(rows)
		var footer := MenuStyle.footer()
		list.add_child(footer)
		if side == 0:
			_community_rows = rows
			_community_footer = footer
		else:
			_board_rows = rows
			_board_footer = footer
	var hint := MenuStyle.label("Shown while Tab is held  ·  Esc for the menu", 13, Color(1, 1, 1, 0.5))
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	column.add_child(hint)


func _fill_runs() -> void:
	var entry := LevelCatalog.find(levels.level_id) if levels else {}
	_title.text = str(entry.get("title", "This track"))
	for child in _board_rows.get_children():
		child.queue_free()
	var records := race.records
	var best_runs := records.top(leaderboard_size) if records else []
	if best_runs.is_empty():
		var empty := MenuStyle.footer()
		empty.text = "No finished runs yet. Cross the finish line to set a time."
		_board_rows.add_child(empty)
	for i in best_runs.size():
		var run: Dictionary = best_runs[i]
		_board_rows.add_child(MenuStyle.board_row(i + 1, "Run", float(run["t"]), MenuStyle.when(int(run["at"]))))
	_board_footer.text = "%s finished on this track" % MenuStyle.count(records.runs.size() if records else 0, "run")


func _fill_community() -> void:
	for child in _community_rows.get_children():
		child.queue_free()
	if community == null:
		_community_footer.text = "The community leaderboard is available when you play in Möbius."
		return
	var board := community.board
	var top: Array = board.get("top", [])
	var me := str(board.get("player", ""))
	for entry: Dictionary in top:
		var player := str(entry.get("player", ""))
		_community_rows.add_child(MenuStyle.board_row(int(entry.get("rank", 0)), "@" + player, float(entry.get("time", INF)),
			MenuStyle.count(int(entry.get("runs", 0)), "run"), player == me and not me.is_empty()))
	_community_footer.text = _community_summary(board, top.is_empty())


func _community_summary(board: Dictionary, empty: bool) -> String:
	match community.status:
		"unavailable", "error":
			return community.message
		"idle", "loading":
			if board.is_empty():
				return "Loading the community leaderboard…"
	if empty:
		return "No community runs yet. Finish a run to set the first time."
	var lines := PackedStringArray(["%s by %s" % [MenuStyle.count(int(board.get("runs", 0)), "run"), MenuStyle.count(int(board.get("players", 0)), "player")]])
	var you: Variant = board.get("you")
	if you is Dictionary and you.get("rank") != null:
		lines.append("You (@%s): #%d with %s" % [board.get("player", ""), int(you["rank"]), RaceHud.format_time(float(you["best"]))])
	elif board.get("player") == null:
		lines.append("Connect a Möbius account with an @handle (Möbius · You) to put your runs on it.")
	return "\n".join(lines)
