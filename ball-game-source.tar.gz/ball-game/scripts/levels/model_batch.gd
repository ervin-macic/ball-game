class_name ModelBatch
extends RefCounted
## Draws many copies of a model as one batch per mesh (MultiMesh), for
## decorations placed in code: a handful of copies costs one draw call per
## material instead of one per copy.


## Adds copies of [param model] (a scene, or a single mesh) at [param places]
## (in [param parent]'s space) to [param parent], one MultiMeshInstance3D per
## mesh in the model.
static func add(parent: Node3D, model: Resource, places: Array[Transform3D]) -> void:
	if model is Mesh:
		_add_mesh(parent, model as Mesh, Transform3D.IDENTITY, places, String(model.resource_name))
		return
	var root: Node3D = (model as PackedScene).instantiate()
	for part in root.find_children("*", "MeshInstance3D", true, false):
		var to_root := Transform3D.IDENTITY
		var walk: Node = part
		while walk != root and walk is Node3D:
			to_root = (walk as Node3D).transform * to_root
			walk = walk.get_parent()
		_add_mesh(parent, (part as MeshInstance3D).mesh, to_root, places, "%s_%s" % [model.resource_path.get_file().get_basename(), part.name])
	root.free()


static func _add_mesh(parent: Node3D, mesh: Mesh, offset: Transform3D, places: Array[Transform3D], label: String) -> void:
	var multimesh := MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.mesh = mesh
	multimesh.instance_count = places.size()
	for i in places.size():
		multimesh.set_instance_transform(i, places[i] * offset)
	var view := MultiMeshInstance3D.new()
	view.name = label.validate_node_name() if label != "" else "Batch"
	view.multimesh = multimesh
	# A batch picks the mesh's lower-detail versions as if drawn at its
	# model's size: account for the biggest copy's scale (see PropScatter).
	var biggest := 0.0
	for at in places:
		biggest = maxf(biggest, at.basis.get_scale().x)
	view.lod_bias = maxf(biggest, 0.01)
	parent.add_child(view)
