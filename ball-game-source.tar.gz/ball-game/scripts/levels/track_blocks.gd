class_name TrackBlocks
extends Node3D
## Solid blocks carrying a track's open-ground stretches (pieces with paved
## off) in a level with no terrain: the road breaks into boxes to hop along.
## Each block's top is its stretch, as wide as the road with its curbs, and
## every block reaches down to the same floor, [member depth] below the lowest
## top. Keep those stretches straight and level: a block is a plain box.

@export var track: TrackBuilder
@export_range(1.0, 200.0, 0.5, "suffix:m") var depth := 8.0
## Given each block's size (see block.gdshader's half_size).
@export var material: ShaderMaterial


func _ready() -> void:
	if track.path.frames.is_empty():
		await track.rebuilt
	build()


func build() -> void:
	for child in get_children():
		child.free()
	var tops := stretches()
	if tops.is_empty():
		return
	var lowest := INF
	for top in tops:
		lowest = minf(lowest, minf(top[0].origin.y, top[1].origin.y))
	var floor_height := lowest - depth
	var width := track.road_width + 2.0 * track.lip_width
	var surface := PhysicsMaterial.new()
	surface.friction = track.friction
	for k in tops.size():
		var start: Transform3D = tops[k][0]
		var end: Transform3D = tops[k][1]
		var up := start.basis.y.normalized()
		var top_height := (start.origin.y + end.origin.y) * 0.5
		var size := Vector3(width, top_height - floor_height, start.origin.distance_to(end.origin))
		var body := StaticBody3D.new()
		body.name = "Block%d" % (k + 1)
		body.collision_layer = track.collision_layer
		body.collision_mask = 0
		body.physics_material_override = surface
		add_child(body)
		body.global_transform = Transform3D(start.basis.orthonormalized(), (start.origin + end.origin) * 0.5 - up * size.y * 0.5)
		var shape := CollisionShape3D.new()
		shape.shape = BoxShape3D.new()
		(shape.shape as BoxShape3D).size = size
		body.add_child(shape)
		var mesh := BoxMesh.new()
		mesh.size = size
		var look := MeshInstance3D.new()
		look.mesh = mesh
		if material:
			var own := material.duplicate() as ShaderMaterial
			own.set_shader_parameter("half_size", size * 0.5)
			look.material_override = own
		body.add_child(look)


## The open-ground stretches as world-space frames at the start and end of
## each (the start is where the piece before it, a gap's landing, left off).
func stretches() -> Array:
	var found := []
	var path := track.path
	for run in path.run_count():
		var span := path.run_range(run)
		var i := span.x
		while i < span.y:
			if path.paved[i]:
				i += 1
				continue
			var start := maxi(i - 1, span.x)
			var end := i
			while end < span.y and not path.paved[end]:
				end += 1
			found.append([track.global_transform * path.frames[start], track.global_transform * path.frames[end - 1]])
			i = end
	return found
