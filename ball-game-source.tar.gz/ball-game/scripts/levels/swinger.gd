class_name Swinger
extends Node3D
## A heavy weight swinging on a chain across the track from a beam on two
## posts, like a pendulum: time your run past it or get knocked aside.
##
## It swings on the race clock (its own clock between runs), so every run and
## the ghost meet it the same way at the same moment. The weight is any model
## (a log, an anchor, a giant ornament) or a plain ball; it's solid and moves
## the ball it hits.

@export var track: TrackBuilder
@export var terrain: Terrain
## Where along the track it hangs.
@export var at_distance := 100.0
## The weight: a model, sized to the solid ball (times [member weight_scale]).
@export var weight: PackedScene
@export var weight_scale := 1.0
## Radius of the solid ball standing in for the weight's shape.
@export_range(0.3, 10.0, 0.05, "suffix:m") var weight_radius := 1.3
## Chain length from the pivot to the weight's centre.
@export_range(1.0, 30.0, 0.1, "suffix:m") var arm := 7.0
## How far it swings either side of hanging straight down.
@export_range(5.0, 89.0, 0.5, "suffix:°") var amplitude := 55.0
@export_range(0.5, 20.0, 0.05, "suffix:s") var period := 3.2
## Offset within the swing (0..1 of a period) at the start of a run.
@export_range(0.0, 1.0, 0.01) var phase := 0.0
## Air left between the weight and the track where it passes closest (at the
## bottom of its swing; on a climb, just uphill of it), and between the weight
## and the posts at either end of its swing.
@export_range(0.0, 10.0, 0.05, "suffix:m") var clearance := 0.2
## Material of the plain ball used when there is no weight model.
@export var weight_material: Material
@export var post_material: Material
@export var chain_color := Color(0.25, 0.24, 0.23)

## Tests and recording tools hold every weight still at the top of its swing
## (the autopilot can't time its run past them; a test checks they swing).
static var hold_still := false

## Thickness of the posts and the beam.
const POST := 0.5

var _race: RaceManager
var _idle_clock := 0.0
var _pivot := Transform3D.IDENTITY
var _bob: AnimatableBody3D


func _ready() -> void:
	add_to_group("race_aware")
	if track.path.frames.is_empty():
		await track.rebuilt
	build()


func bind_race(race: RaceManager) -> void:
	_race = race


func build() -> void:
	var frame := track.world_frame_at(at_distance)
	var forward := Vector3(-frame.basis.z.x, 0.0, -frame.basis.z.z).normalized()
	var right := forward.cross(Vector3.UP).normalized()
	var road := frame.origin
	# The pivot: above the road, high enough that the weight just clears it.
	_pivot = Transform3D(Basis(right, Vector3.UP, -forward), road + Vector3.UP * _pivot_height(road, right, forward))
	_build_frame(road, right, forward)
	_bob = AnimatableBody3D.new()
	_bob.name = "Weight"
	_bob.sync_to_physics = true
	add_child(_bob)
	var shape := SphereShape3D.new()
	shape.radius = weight_radius
	var holder := CollisionShape3D.new()
	holder.shape = shape
	_bob.add_child(holder)
	var surface := PhysicsMaterial.new()
	surface.bounce = 0.5
	_bob.physics_material_override = surface
	if weight:
		# The model is sized to fill the solid ball (times weight_scale) and
		# centred on it.
		var model: Node3D = weight.instantiate()
		var box := _bounds(model)
		var fit := weight_radius * 2.0 / maxf(maxf(box.size.x, box.size.y), maxf(box.size.z, 1e-3)) * weight_scale
		model.scale = Vector3.ONE * fit
		model.position = -box.get_center() * fit
		_bob.add_child(model)
	else:
		var ball := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = weight_radius
		sphere.height = weight_radius * 2.0
		sphere.material = weight_material
		ball.mesh = sphere
		_bob.add_child(ball)
	# The chain hangs from the pivot down to the weight.
	var chain := MeshInstance3D.new()
	var rod := CylinderMesh.new()
	rod.top_radius = 0.09
	rod.bottom_radius = 0.09
	rod.height = arm - weight_radius * 0.5
	rod.radial_segments = 6
	var metal := StandardMaterial3D.new()
	metal.albedo_color = chain_color
	metal.metallic = 0.6
	metal.roughness = 0.5
	rod.material = metal
	chain.mesh = rod
	chain.position = Vector3(0.0, arm * 0.5 + weight_radius * 0.25, 0.0)
	_bob.add_child(chain)
	_place(_angle(0.0))


func _physics_process(delta: float) -> void:
	if _bob == null:
		return
	var clock := 0.0
	if _race and _race.state != RaceManager.State.READY:
		clock = _race.race_time
	else:
		_idle_clock += delta
		clock = _idle_clock
	_place(_angle(clock))


## Swing angle (radians, positive toward the track's right) at [param clock].
func _angle(clock: float) -> float:
	if hold_still:
		return deg_to_rad(amplitude)
	return deg_to_rad(amplitude) * sin(TAU * (clock / period + phase))


## Where the weight hangs at swing [param angle] (radians, as [method _angle]).
func weight_transform(angle: float) -> Transform3D:
	# Swing about the track's direction, so the weight sweeps across the road;
	# the weight's up always points back along the chain to the pivot.
	var swing := Basis(_pivot.basis.z.normalized(), angle)
	return Transform3D(swing * _pivot.basis, _pivot.origin + swing * Vector3.DOWN * arm)


func _place(angle: float) -> void:
	_bob.global_transform = weight_transform(angle)


## How high above [param road] to hang the pivot so that the whole swing stays
## [member clearance] clear of the top of the track: of the road (which can
## climb or bank under the weight) and the curbs either side.
##
## Swinging, the weight sweeps a band round the pivot: the arc of its centre,
## thickened by its radius plus the clearance. Each point of the track's top
## has to stay below that band. A point a little ahead of or behind the swing
## only meets the thinner slice of the band at that distance.
func _pivot_height(road: Vector3, right: Vector3, forward: Vector3) -> float:
	var keep := weight_radius + clearance
	var swing := deg_to_rad(amplitude)
	var height := arm + keep
	# On a climb the road rises into the weight's reach just ahead of it (or
	# behind it), so take slices of the track out past that reach.
	var along := -keep - 1.0
	while along <= keep + 1.0:
		for point in track.world_top_at(at_distance + along):
			var offset := point - road
			var ahead := offset.dot(forward)
			if absf(ahead) >= keep:
				continue
			var thick := sqrt(keep * keep - ahead * ahead)
			var outer := arm + thick
			var across := absf(offset.dot(right))
			if across <= outer * sin(swing):
				# The weight swings right past it, straight between it and the pivot.
				height = maxf(height, offset.y + sqrt(outer * outer - across * across))
			else:
				# Only the end of the swing comes near it.
				var past := across - arm * sin(swing)
				if past < thick:
					height = maxf(height, offset.y + arm * cos(swing) + sqrt(thick * thick - past * past))
		along += 0.2
	return height


## Two posts beside the road holding a beam across it, out of the weight's
## way at either end of its swing.
func _build_frame(road: Vector3, right: Vector3, forward: Vector3) -> void:
	var reach := arm * sin(deg_to_rad(amplitude)) + weight_radius + clearance
	var half := maxf(track.road_width * 0.5 + track.lip_width + track.rim_width + 1.2, reach + POST * 0.5)
	var top := _pivot.origin.y + 0.3
	var material := post_material
	if material == null:
		var wood := StandardMaterial3D.new()
		wood.albedo_color = Color(0.45, 0.32, 0.2)
		material = wood
	var body := StaticBody3D.new()
	body.name = "Frame"
	add_child(body)
	for side: float in [-1.0, 1.0]:
		var foot := road + right * side * half
		var ground := terrain.height_at(foot) if terrain else road.y - 20.0
		var bottom := minf(ground, road.y - 2.0)
		_beam(body, material, Vector3(POST, top - bottom, POST), Vector3(foot.x, (top + bottom) * 0.5, foot.z), forward)
	_beam(body, material, Vector3(half * 2.0 + POST, POST, POST), Vector3(road.x, top, road.z), forward)


func _beam(body: StaticBody3D, material: Material, size: Vector3, centre: Vector3, forward: Vector3) -> void:
	var box := BoxMesh.new()
	box.size = size
	box.material = material
	var view := MeshInstance3D.new()
	view.mesh = box
	body.add_child(view)
	view.global_transform = Transform3D(Basis(forward.cross(Vector3.UP).normalized(), Vector3.UP, -forward), centre)
	var shape := BoxShape3D.new()
	shape.size = size
	var holder := CollisionShape3D.new()
	holder.shape = shape
	body.add_child(holder)
	holder.global_transform = view.global_transform


## Bounding box of every mesh in [param root] (in its own space).
static func _bounds(root: Node3D) -> AABB:
	var box := AABB()
	var first := true
	for node in root.find_children("*", "MeshInstance3D", true, false):
		var view := node as MeshInstance3D
		var to_root := Transform3D.IDENTITY
		var walk: Node = view
		while walk != root and walk is Node3D:
			to_root = (walk as Node3D).transform * to_root
			walk = walk.get_parent()
		var part := to_root * view.mesh.get_aabb()
		box = part if first else box.merge(part)
		first = false
	return box
