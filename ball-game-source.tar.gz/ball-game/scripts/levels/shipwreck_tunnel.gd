class_name ShipwreckTunnel
extends Node3D
## The ribs and broken planking of a wrecked ship's hull, arching over a
## stretch of track so the ball rolls through it. The ribs and planks are
## solid: brush the sides and you bounce off.

@export var track: TrackBuilder
@export var from_distance := 345.0
@export var to_distance := 375.0
## Hull half-width at the ground (the ribs arch over this).
@export_range(4.0, 30.0, 0.1, "suffix:m") var radius := 9.5
@export_range(1.0, 10.0, 0.1, "suffix:m") var rib_spacing := 3.4
@export var material: Material
@export var seed := 5


func _ready() -> void:
	if track.path.frames.is_empty():
		await track.rebuilt
	build()


func build() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var body := StaticBody3D.new()
	body.name = "Hull"
	var surface := PhysicsMaterial.new()
	surface.bounce = 0.35
	body.physics_material_override = surface
	add_child(body)
	var length := to_distance - from_distance
	var ribs := int(length / rib_spacing) + 1
	for k in ribs:
		var d := from_distance + k * rib_spacing
		var frame := _flat_frame(d)
		# Hull shape: widest mid-ship, narrowing toward bow and stern.
		var t := float(k) / maxf(ribs - 1, 1)
		var r := radius * (0.82 + 0.18 * sin(PI * t))
		# Some ribs are broken off on one side; a few stand only as stumps.
		var reach_left := PI if rng.randf() > 0.25 else rng.randf_range(0.35, 0.7) * PI
		var reach_right := 0.0 if rng.randf() > 0.25 else rng.randf_range(0.3, 0.65) * PI
		var steps := 14
		for s in steps:
			var a0 := lerpf(0.0, PI, float(s) / steps)
			var a1 := lerpf(0.0, PI, float(s + 1) / steps)
			if a1 > reach_left or a0 < reach_right:
				continue
			var p0 := frame * Vector3(cos(a0) * r, sin(a0) * r * 0.95 - 0.6, 0.0)
			var p1 := frame * Vector3(cos(a1) * r, sin(a1) * r * 0.95 - 0.6, 0.0)
			_beam(tool, body, p0, p1, frame.basis.z, Vector2(0.55, 0.7))
	# Planking along the lower sides, with gaps where it has rotted away.
	for side: float in [-1.0, 1.0]:
		for row in 3:
			var angle := lerpf(0.08, 0.42, float(row) / 2.0) * PI
			var d := from_distance
			while d < to_distance - 1.0:
				var run := rng.randf_range(3.0, 7.0)
				var end := minf(d + run, to_distance)
				if rng.randf() > 0.3:
					var a := _flat_frame(d)
					var b := _flat_frame(end)
					var x := cos(angle) * radius * side
					var y := sin(angle) * radius * 0.95 - 0.6
					var offset := Vector3(x, y, 0.0)
					_beam(tool, body, a * offset, b * offset, Vector3.UP, Vector2(0.25, 1.1))
				d = end + rng.randf_range(0.5, 2.5)
	# A broken mast lying across the top of the hull.
	var mid := _flat_frame((from_distance + to_distance) * 0.5)
	_beam(tool, body, mid * Vector3(-radius * 1.1, radius * 0.7, -6.0), mid * Vector3(radius * 0.9, radius * 1.05, 5.0),
		Vector3.UP, Vector2(0.7, 0.7))
	tool.generate_normals()
	var view := MeshInstance3D.new()
	view.name = "Ribs"
	view.mesh = tool.commit()
	if material:
		view.mesh.surface_set_material(0, material)
	add_child(view)


## The track frame at [param d], levelled (no pitch or roll).
func _flat_frame(d: float) -> Transform3D:
	var frame := track.world_frame_at(d)
	var forward := Vector3(-frame.basis.z.x, 0.0, -frame.basis.z.z).normalized()
	var right := forward.cross(Vector3.UP).normalized()
	return Transform3D(Basis(right, Vector3.UP, -forward), frame.origin)


## A rectangular beam from [param a] to [param b] (thickness, depth), drawn and solid.
func _beam(tool: SurfaceTool, body: StaticBody3D, a: Vector3, b: Vector3, side_hint: Vector3, size: Vector2) -> void:
	var along := b - a
	var length := along.length()
	if length < 0.01:
		return
	var axis := along / length
	var across := axis.cross(side_hint).normalized()
	if across.length_squared() < 0.5:
		across = axis.cross(Vector3.FORWARD).normalized()
	var up := across.cross(axis).normalized()
	var basis := Basis(across * size.x, up * size.y, axis * length)
	var centre := (a + b) * 0.5
	var box := BoxMesh.new()
	box.size = Vector3.ONE
	var arrays := box.get_mesh_arrays()
	var verts: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var uvs: PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV]
	var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
	for index in indices:
		tool.set_uv(uvs[index] * Vector2(1.0, length * 0.5))
		tool.add_vertex(centre + basis * verts[index])
	var shape := BoxShape3D.new()
	shape.size = Vector3(size.x, size.y, length)
	var holder := CollisionShape3D.new()
	holder.shape = shape
	holder.transform = Transform3D(Basis(across, up, axis), centre)
	body.add_child(holder)
