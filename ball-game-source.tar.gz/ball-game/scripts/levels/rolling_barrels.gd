class_name RollingBarrels
extends Node3D
## Barrels rolling down a stretch of road toward the player, three abreast on
## one axle, so the way past is to jump over them. They run on the race clock,
## like the swinging weights, so every run (and the ghost) meets them at the
## same moments; between runs they keep their own time.
##
## Each barrel row rises out of the road at [member to_distance], rolls back
## along it at [member speed] and sinks away again at [member from_distance].

## Lap tests park the barrels out of the way (the autopilot can't time jumps
## over moving things), as they hold the swinging weights still.
static var hold_still := false

## The road they roll on: a TrackRoute or the main track.
@export var track: TrackBuilder
## Where they roll, in metres along [member track]: from to_distance back to from_distance.
@export var from_distance := 100.0
@export var to_distance := 180.0
@export_range(1, 12) var count := 3
@export_range(0.5, 40.0, 0.1, "suffix:m/s") var speed := 7.0
## Barrels side by side in each row, and how long each is.
@export_range(1, 6) var abreast := 3
@export_range(0.3, 3.0, 0.05, "suffix:m") var barrel_length := 1.35
@export var barrel: PackedScene
@export var phase := 0.0

const SINK := 2.5

var _race: RaceManager
var _idle_clock := 0.0
var _rows: Array[AnimatableBody3D] = []
var _spins: Array[Node3D] = []
var _radius := 0.55


func _ready() -> void:
	add_to_group("race_aware")
	if track.path.frames.is_empty():
		await track.rebuilt
	_build()


func bind_race(race: RaceManager) -> void:
	_race = race


func _build() -> void:
	var fit := 1.0
	var box := AABB(Vector3.ZERO, Vector3(1.1, barrel_length, 1.1))
	if barrel:
		var probe: Node3D = barrel.instantiate()
		box = Swinger._bounds(probe)
		probe.free()
		fit = barrel_length / maxf(box.size.y, 1e-3)
	_radius = maxf(box.size.x, box.size.z) * fit * 0.5
	var width := barrel_length * abreast
	for i in count:
		var row := AnimatableBody3D.new()
		row.name = "Barrels_%d" % i
		row.sync_to_physics = true
		var shape := CylinderShape3D.new()
		shape.radius = _radius
		shape.height = width
		var holder := CollisionShape3D.new()
		holder.shape = shape
		holder.rotation.z = PI * 0.5 # the axle runs across the road
		row.add_child(holder)
		var spin := Node3D.new()
		row.add_child(spin)
		for k in abreast:
			var x := (k - (abreast - 1) * 0.5) * barrel_length
			if barrel:
				var model: Node3D = barrel.instantiate()
				model.scale = Vector3.ONE * fit
				# Lying on its side, axis across the road, centred on the axle.
				model.rotation.z = PI * 0.5
				model.position = Vector3(x + box.get_center().y * fit, -box.get_center().x * fit, -box.get_center().z * fit)
				spin.add_child(model)
			else:
				var mesh := CylinderMesh.new()
				mesh.top_radius = _radius
				mesh.bottom_radius = _radius
				mesh.height = barrel_length * 0.96
				var view := MeshInstance3D.new()
				view.mesh = mesh
				view.rotation.z = PI * 0.5
				view.position.x = x
				spin.add_child(view)
		add_child(row)
		_rows.append(row)
		_spins.append(spin)
	_place(0.0)


func _physics_process(delta: float) -> void:
	if _rows.is_empty():
		return
	var clock := 0.0
	if _race and _race.state != RaceManager.State.READY:
		clock = _race.race_time
	else:
		_idle_clock += delta
		clock = _idle_clock
	_place(clock)


## Where the barrel rows are at race time [param clock].
func _place(clock: float) -> void:
	var span := to_distance - from_distance
	for i in _rows.size():
		var row := _rows[i]
		if hold_still:
			row.global_position = Vector3(0.0, -10000.0 - i * 10.0, 0.0)
			continue
		var travelled := fposmod(clock * speed + phase + span * float(i) / _rows.size(), span)
		var s := to_distance - travelled
		var frame := track.world_frame_at(s)
		var up := frame.basis.y.normalized()
		# Rise out of the road at the far end, sink away at the near end.
		var showing := smoothstep(0.0, SINK, travelled) * smoothstep(0.0, SINK, span - travelled)
		var centre := frame.origin + up * (_radius - (1.0 - showing) * (_radius * 2.0 + 0.2))
		row.global_transform = Transform3D(frame.basis.orthonormalized(), centre)
		# Rolling toward the player: turning backwards about the axle.
		_spins[i].rotation.x = -s / _radius
