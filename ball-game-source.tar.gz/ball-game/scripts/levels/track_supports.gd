class_name TrackSupports
extends Node3D
## Pillars from the ground up to raised road, every [member spacing] metres.
## They are solid, so a ball down on the ground can bounce off them. None are
## placed in loops, on open-ground stretches, or where a pillar would stand in
## the path of an open-ground stretch passing underneath. Routes get them too.

@export var track: TrackBuilder
@export var terrain: Terrain
@export var material: Material
@export_range(2.0, 200.0, 0.5, "suffix:m") var spacing := 16.0
@export_range(0.2, 10.0, 0.05, "suffix:m") var width := 1.2
## Pillars only where the road is at least this high above the ground.
@export_range(0.0, 20.0, 0.1, "suffix:m") var min_height := 1.5
## Two pillars at the road edges instead of one in the middle.
@export var paired := false
## Keep this far from the centreline of open-ground stretches.
@export_range(0.0, 50.0, 0.5, "suffix:m") var ground_clearance := 9.0


func build() -> void:
	var path := track.network
	var ground_points: Array[Vector3] = []
	for span in path.ground_ranges():
		for i in range(span.x, span.y):
			ground_points.append(track.to_global(path.frames[i].origin))
	var transforms: Array[Transform3D] = []
	var next := spacing * 0.5
	for i in path.frames.size():
		if i > 0 and path.owners[i] != path.owners[i - 1]:
			next = path.distances[i] + spacing * 0.5
		if not path.paved[i] or path.distances[i] < next:
			continue
		var frame := track.global_transform * path.frames[i]
		if frame.basis.y.normalized().y < 0.9:
			continue
		next = path.distances[i] + spacing
		var offsets: Array[float] = [0.0]
		if paired:
			offsets = [-1.0, 1.0]
		for side: float in offsets:
			var top: Vector3 = frame.origin + frame.basis.x.normalized() * side * (track.road_width * 0.5 + track.lip_width * 0.5) - frame.basis.y.normalized() * track.thickness
			var ground: float = terrain.height_at(top) if terrain else top.y - 20.0
			var height: float = top.y - ground
			if height < min_height or _near(top, ground_points) or _road_below(top, ground, i):
				continue
			var centre := Vector3(top.x, (top.y + ground - 0.5) * 0.5, top.z)
			var yaw := atan2(-frame.basis.z.x, -frame.basis.z.z)
			transforms.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3(width, height + 0.5, width)), centre))
	if transforms.is_empty():
		return
	var box := BoxMesh.new()
	box.material = material
	var multimesh := MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.mesh = box
	multimesh.instance_count = transforms.size()
	var body := StaticBody3D.new()
	body.name = "SupportBodies"
	add_child(body)
	for k in transforms.size():
		multimesh.set_instance_transform(k, transforms[k])
		var shape := BoxShape3D.new()
		shape.size = transforms[k].basis.get_scale()
		var holder := CollisionShape3D.new()
		holder.shape = shape
		holder.transform = Transform3D(transforms[k].basis.orthonormalized(), transforms[k].origin)
		body.add_child(holder)
	var view := MultiMeshInstance3D.new()
	view.name = "Supports"
	view.multimesh = multimesh
	add_child(view)


## Whether another stretch of the layout passes under [param top] (a spiral, a
## crossing, or a route over the main road), where a pillar would stand on or
## through it. [param from] is the frame the pillar holds up.
func _road_below(top: Vector3, ground: float, from: int) -> bool:
	var path := track.network
	var clearance := track.road_width * 0.5 + track.lip_width + track.rim_width + width
	for k in range(0, path.frames.size(), 2):
		if path.owners[k] == path.owners[from] and absf(path.distances[k] - path.distances[from]) < 30.0:
			continue
		var p := track.to_global(path.frames[k].origin)
		if p.y < top.y - 1.0 and p.y > ground - 1.0 and Vector2(p.x - top.x, p.z - top.z).length() < clearance:
			return true
	return false


func _near(point: Vector3, ground_points: Array[Vector3]) -> bool:
	for g in ground_points:
		if Vector2(g.x - point.x, g.z - point.z).length() < ground_clearance:
			return true
	return false
