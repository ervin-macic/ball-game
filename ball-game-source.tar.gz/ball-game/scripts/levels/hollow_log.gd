class_name HollowLog
extends Node3D
## A huge fallen tree lying along the track, hollowed out by rot, that the
## ball rolls straight through. The trunk is lumpy and slightly bowed, with a
## jagged broken end where the ball goes in and a flared root end where it
## comes out; bark outside (mossy on top), dark rotten wood inside and pale
## wood on the broken rims, with shelf fungus on its flanks. The forest floor
## is the floor of the tunnel; the shell is solid.

@export var track: TrackBuilder
@export var terrain: Terrain
## Where along the track the middle of the log lies.
@export var at_distance := 510.0
@export_range(4.0, 80.0, 0.5, "suffix:m") var length := 26.0
@export_range(1.0, 20.0, 0.1, "suffix:m") var outer_radius := 4.6
@export_range(0.2, 5.0, 0.1, "suffix:m") var wall := 1.15
## How far the tunnel's bottom sits below the ground (so the ground is its floor).
@export_range(0.0, 3.0, 0.05, "suffix:m") var sunk := 0.6
@export var bark_texture: Texture2D
@export var bark_normal: Texture2D
@export var fungus: PackedScene
@export var fern: PackedScene
@export var noise_seed := 11

const RINGS := 30
const SEGMENTS := 44
const MOSS := Color(0.52, 0.7, 0.32)
const ROT := Color(0.52, 0.38, 0.26)
const RIM := Color(0.86, 0.68, 0.46)

var _noise := FastNoiseLite.new()


func _ready() -> void:
	if track.path.frames.is_empty():
		await track.rebuilt
	build()


func build() -> void:
	_noise.seed = noise_seed
	_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_noise.frequency = 0.35
	var frame := track.world_frame_at(at_distance)
	var forward := Vector3(-frame.basis.z.x, 0.0, -frame.basis.z.z).normalized()
	var right := forward.cross(Vector3.UP).normalized()
	var ground := terrain.height_at(frame.origin) if terrain else frame.origin.y
	global_transform = Transform3D(Basis(right, Vector3.UP, -forward), Vector3(frame.origin.x, ground, frame.origin.z))
	var bark := _material(Color.WHITE, bark_texture, bark_normal, true)
	var rot := _material(ROT, bark_texture, bark_normal, true)
	var rim := _material(RIM, null, null, false)
	var outer := SurfaceTool.new()
	var inner := SurfaceTool.new()
	var rims := SurfaceTool.new()
	for tool in [outer, inner, rims]:
		tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var faces := PackedVector3Array()
	# Each column runs along the log at one angle around it, from its own start
	# to its own end, so both ends are ragged rather than cut square.
	var outer_points := []
	var inner_points := []
	for j in SEGMENTS + 1:
		var theta := -PI * 0.5 + TAU * j / SEGMENTS
		var outer_column := []
		var inner_column := []
		var z_in := length * 0.5 - _jag(theta, 0.0) * 2.6
		var z_out := -length * 0.5 + _jag(theta, 50.0) * 1.0
		for i in RINGS + 1:
			var t := float(i) / RINGS
			var z := lerpf(z_in, z_out, t)
			outer_column.append(_shell_point(theta, z, t, true))
			inner_column.append(_shell_point(theta, z, t, false))
		outer_points.append(outer_column)
		inner_points.append(inner_column)
	for j in SEGMENTS:
		for i in RINGS:
			_quad(outer, outer_points, j, i, false, true, faces)
			_quad(inner, inner_points, j, i, true, false, faces)
		# Broken rims at both ends, joining outside to inside.
		for i in [0, RINGS]:
			var a: Vector3 = outer_points[j][i]
			var b: Vector3 = outer_points[j + 1][i]
			var c: Vector3 = inner_points[j + 1][i]
			var d: Vector3 = inner_points[j][i]
			var corners := [a, b, c, d] if i == 0 else [a, d, c, b]
			for k in [0, 1, 2, 0, 2, 3]:
				rims.set_color(RIM)
				rims.set_uv(Vector2(corners[k].x, corners[k].y) * 0.3)
				rims.add_vertex(corners[k])
				faces.append(corners[k])
	var mesh := ArrayMesh.new()
	for pair in [[outer, bark], [inner, rot], [rims, rim]]:
		var tool: SurfaceTool = pair[0]
		tool.generate_normals()
		tool.generate_tangents()
		tool.commit(mesh)
		mesh.surface_set_material(mesh.get_surface_count() - 1, pair[1])
	var view := MeshInstance3D.new()
	view.name = "Log"
	view.mesh = mesh
	add_child(view)
	var body := StaticBody3D.new()
	body.name = "Shell"
	var shape := ConcavePolygonShape3D.new()
	shape.backface_collision = true
	shape.set_faces(faces)
	var holder := CollisionShape3D.new()
	holder.shape = shape
	body.add_child(holder)
	add_child(body)
	_decorate()
	# No light inside: a light makes the browser prepare every material near
	# it twice (lit by it and not), and the run stalls as each first comes into
	# its reach. The rotten wood inside is a lighter brown instead.


func _axis_height() -> float:
	return outer_radius - wall - sunk


## A point on the outside or inside of the shell at angle [param theta] around
## the log and [param z] along it ([param t] runs 0 at the broken end to 1 at
## the root end).
func _shell_point(theta: float, z: float, t: float, outside: bool) -> Vector3:
	var around := Vector3(cos(theta), sin(theta), 0.0)
	var lump := _noise.get_noise_3d(around.x * 2.0, around.y * 2.0, z * 0.25)
	var bend := Vector3(0.7 * sin(PI * t), 0.25 * sin(PI * t), 0.0)
	var radius := outer_radius * (1.0 + 0.08 * lump)
	# The root end flares out.
	radius *= 1.0 + 0.38 * smoothstep(0.8, 1.0, t) * (0.8 + 0.4 * _noise.get_noise_1d(theta * 3.0))
	if not outside:
		radius = (outer_radius - wall) * (1.0 + 0.05 * _noise.get_noise_3d(around.x * 3.0 + 9.0, around.y * 3.0, z * 0.4))
	var centre := Vector3(0.0, _axis_height(), 0.0) + bend
	return centre + around * radius + Vector3(0.0, 0.0, z)


## Raggedness of an end at [param theta] (0..1): teeth and splinters, least at
## the bottom where the log rests on the ground.
func _jag(theta: float, offset: float) -> float:
	var teeth := absf(sin(theta * 5.0 + offset)) * 0.5 + 0.5 * (_noise.get_noise_1d(theta * 9.0 + offset) * 0.5 + 0.5)
	var bottom := smoothstep(-1.0, -0.2, sin(theta))
	return clampf(teeth, 0.0, 1.0) * bottom


func _quad(tool: SurfaceTool, points: Array, j: int, i: int, flip: bool, mossy: bool, faces: PackedVector3Array) -> void:
	var a: Vector3 = points[j][i]
	var b: Vector3 = points[j + 1][i]
	var c: Vector3 = points[j + 1][i + 1]
	var d: Vector3 = points[j][i + 1]
	var uvs := [Vector2(j, i), Vector2(j + 1, i), Vector2(j + 1, i + 1), Vector2(j, i + 1)]
	var corners := [a, b, c, d]
	var order := [0, 2, 1, 0, 3, 2] if flip else [0, 1, 2, 0, 2, 3]
	for k in order:
		var p: Vector3 = corners[k]
		var color := Color.WHITE
		if mossy:
			var up := (p.y - _axis_height()) / outer_radius
			color = Color.WHITE.lerp(MOSS, smoothstep(0.35, 0.85, up))
		tool.set_color(color)
		# Bark texture: about 3 m per repeat around and along.
		tool.set_uv(Vector2(uvs[k].x * TAU * outer_radius / SEGMENTS / 3.0, uvs[k].y * length / RINGS / 3.0))
		tool.add_vertex(p)
		faces.append(p)


func _material(tint: Color, albedo: Texture2D, normal: Texture2D, textured: bool) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = tint
	material.vertex_color_use_as_albedo = true
	material.roughness = 0.9
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	if textured and albedo:
		material.albedo_texture = albedo
	if textured and normal:
		material.normal_enabled = true
		material.normal_texture = normal
	return material


## Shelf fungus on the flanks and ferns by the two openings.
func _decorate() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = noise_seed
	if fungus:
		for k in 9:
			var side := -1.0 if k % 2 == 0 else 1.0
			var theta := (0.0 if side > 0.0 else PI) + rng.randf_range(-0.35, 0.45) * side
			var z := rng.randf_range(-length * 0.4, length * 0.4)
			var t := inverse_lerp(length * 0.5, -length * 0.5, z)
			var at := _shell_point(theta, z, t, true)
			var outward := Vector3(cos(theta), 0.0, 0.0).normalized()
			var shelf: Node3D = fungus.instantiate()
			# Its shelves stick out along the model's +z: turn that outward.
			shelf.basis = Basis.looking_at(-outward, Vector3.UP).scaled(Vector3.ONE * rng.randf_range(1.2, 2.0))
			shelf.position = at + outward * 0.1
			add_child(shelf)
	if fern:
		for end in [-1.0, 1.0]:
			for side in [-1.0, 1.0]:
				var plant: Node3D = fern.instantiate()
				plant.scale = Vector3.ONE * rng.randf_range(1.2, 1.8)
				plant.rotation.y = rng.randf_range(0.0, TAU)
				plant.position = Vector3(side * (outer_radius + 1.2), 0.0, end * (length * 0.5 + 0.5))
				add_child(plant)
