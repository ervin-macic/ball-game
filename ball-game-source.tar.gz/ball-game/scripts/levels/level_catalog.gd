class_name LevelCatalog
extends RefCounted
## Every playable level, in menu order. "pack" names the separately downloaded
## resource pack a web build needs before the scene can load ("" = built in).
## "image" is the loading screen's picture (in the main pack, so it shows
## while the level downloads). "records" is the name its runs, ghost and leaderboards are kept under: a new
## name when a track is redesigned, so old times (kept) aren't mixed with new.

const DEFAULT_ID := "test_track"

const LEVELS: Array[Dictionary] = [
	{
		"id": "test_track",
		"title": "Test Track",
		"blurb": "The original grid course: ramps, banks, a jump and a loop.",
		"scene": "res://levels/test/test_level.tscn",
		"pack": "",
		"image": "res://ui/loading/test_track.jpg",
	},
	{
		"id": "beach",
		"title": "Beach Boardwalk",
		"blurb": "A pirate bay: open corkscrew, a shipwreck, a steam vent, a towering cliff, rolling barrels.",
		"scene": "res://levels/beach/beach_level.tscn",
		"pack": "level_beach.pck",
		"image": "res://ui/loading/beach.jpg",
		"records": "beach_8",
	},
	{
		"id": "jungle",
		"title": "Forest",
		"blurb": "Log bridge or wiggles, a lily-pad hop, cobblestone walls, a hollow log, a wall ride.",
		"scene": "res://levels/jungle/jungle_level.tscn",
		"pack": "level_jungle.pck",
		"image": "res://ui/loading/jungle.jpg",
		"records": "jungle_8",
	},
	{
		"id": "winter",
		"title": "Winter Wonderland",
		"blurb": "Holey ice bridge or bobsled, an open corkscrew, a huge bowl, a finish leap, a cabin.",
		"scene": "res://levels/winter/winter_level.tscn",
		"pack": "level_winter.pck",
		"image": "res://ui/loading/winter.jpg",
		"records": "winter_9",
	},
]


static func find(id: String) -> Dictionary:
	for entry in LEVELS:
		if entry["id"] == id:
			return entry
	return {}


## Levels this build can play: built in, or (on the web) downloadable as a pack.
## Name a level's runs, ghost and leaderboards are kept under.
static func records_id(id: String) -> String:
	return str(find(id).get("records", id))


static func available() -> Array[Dictionary]:
	var found: Array[Dictionary] = []
	for entry in LEVELS:
		if ResourceLoader.exists(entry["scene"]) or (OS.has_feature("web") and not entry["pack"].is_empty()):
			found.append(entry)
	return found
