class_name Level
extends Node3D
## Root of a playable level scene: the track plus everything around it (sky,
## light, terrain, props, sound). The LevelLoader puts one level at a time into
## the game and hands its track to the race.
##
## Nodes that need the race (hazards timed by the run clock, for example) join
## the "race_aware" group and implement bind_race(race: RaceManager).

## Records and leaderboards are kept under this id, so each level has its own.
@export var level_id := "test_track"
@export var title := "Tutorial Level"
@export var track: TrackBuilder
## Replaces the ball's look in this level (null keeps the default ball).
@export var ball_material: Material
## Falling below this height restarts the run. NAN: the race decides from the
## track's lowest point.
@export var fall_reset_height := NAN


## Gives race-aware nodes the race once the level is in the game.
func bind_race(race: RaceManager) -> void:
	for node in get_tree().get_nodes_in_group("race_aware"):
		if is_ancestor_of(node) and node.has_method("bind_race"):
			node.bind_race(race)
