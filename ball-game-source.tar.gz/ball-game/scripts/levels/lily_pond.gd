class_name LilyPond
extends Node3D
## A shallow pond across an open-ground stretch of the track, with lily pads
## to hop along. A ball in the water is dragged to a crawl (and can't go faster
## than [member wade_speed]); one that jumps from pad to pad keeps its speed.

@export var track: TrackBuilder
@export var terrain: Terrain
## Where along the track the pond starts and ends.
@export var from_distance := 420.0
@export var to_distance := 490.0
## Half the pond's width across the track.
@export_range(2.0, 40.0, 0.5, "suffix:m") var half_width := 11.0
## Water depth over the ground (the ball is half under at 0.6).
@export_range(0.1, 3.0, 0.05, "suffix:m") var depth := 0.65
## Drag on a ball in the water (1/s): its speed falls by this share per second.
@export_range(0.0, 20.0, 0.1) var drag := 2.4
## Fastest a ball can move through the water (horizontally).
@export_range(0.5, 100.0, 0.5, "suffix:m/s") var wade_speed := 100.0
## Exactly this many pads, evenly spread (0: one every [member pad_spacing]).
@export_range(0, 50) var pad_count := 0
## Pads: one every this many metres, zigzagging this far either side.
@export_range(2.0, 30.0, 0.5, "suffix:m") var pad_spacing := 7.0
@export_range(0.0, 10.0, 0.1, "suffix:m") var pad_zigzag := 1.6
@export_range(0.5, 5.0, 0.05, "suffix:m") var pad_radius := 1.7
@export_range(0.0, 1.0, 0.01) var pad_bounce := 0.9
@export var water_color := Color(0.16, 0.32, 0.22, 0.82)

@export var pad_color := Color(0.33, 0.6, 0.2)
@export var flower: PackedScene

var _water: Area3D
var _surface := 0.0


func _ready() -> void:
	if track.path.frames.is_empty():
		await track.rebuilt
	build()


func build() -> void:
	var mid := track.world_frame_at((from_distance + to_distance) * 0.5)
	var ground := terrain.height_at(mid.origin) if terrain else mid.origin.y
	_surface = ground + depth
	_build_water()
	_build_pads()


func _physics_process(delta: float) -> void:
	if _water == null:
		return
	# Drag balls in the water (only the part of them below the surface counts).
	for body in _water.get_overlapping_bodies():
		if body is RigidBody3D and (body as RigidBody3D).global_position.y < _surface + 0.1:
			var rigid := body as RigidBody3D
			var horizontal := Vector3(rigid.linear_velocity.x, 0.0, rigid.linear_velocity.z)
			var slowed := horizontal * exp(-drag * delta)
			slowed = slowed.limit_length(maxf(wade_speed, slowed.length() - 40.0 * delta))
			rigid.linear_velocity += slowed - horizontal


## The water: a strip following the track, from bank to bank, as one mesh and
## one area that detects balls in it.
func _build_water() -> void:
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	_water = Area3D.new()
	_water.name = "Water"
	_water.collision_layer = 0
	_water.collision_mask = 1
	_water.monitoring = true
	add_child(_water)
	var steps := maxi(ceili((to_distance - from_distance) / 3.0), 2)
	var previous: Array = []
	for k in steps + 1:
		var d := lerpf(from_distance, to_distance, float(k) / steps)
		var frame := track.world_frame_at(d)
		var right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
		# Round the pond's ends.
		var end_share := sin(PI * float(k) / steps)
		var reach := half_width * (0.35 + 0.65 * sqrt(end_share))
		var left_point := Vector3(frame.origin.x, _surface, frame.origin.z) - right * reach
		var right_point := Vector3(frame.origin.x, _surface, frame.origin.z) + right * reach
		if not previous.is_empty():
			for corner in [previous[0], previous[1], right_point, previous[0], right_point, left_point]:
				tool.set_uv(Vector2(corner.x, corner.z) * 0.1)
				tool.set_normal(Vector3.UP)
				tool.add_vertex(corner - global_position)
			var shape := BoxShape3D.new()
			var length: float = (left_point - (previous[0] as Vector3)).length() + 0.5
			shape.size = Vector3(reach * 2.0, depth + 0.3, length)
			var holder := CollisionShape3D.new()
			holder.shape = shape
			var centre: Vector3 = (previous[0] + previous[1] + left_point + right_point) * 0.25
			var forward: Vector3 = ((left_point + right_point) * 0.5 - (previous[0] + previous[1]) * 0.5).normalized()
			holder.transform = Transform3D(Basis(forward.cross(Vector3.UP).normalized(), Vector3.UP, -forward), centre - Vector3.UP * (depth + 0.3) * 0.5 + Vector3.UP * 0.05)
			_water.add_child(holder)
		previous = [left_point, right_point]
	var mesh := tool.commit()
	var material := StandardMaterial3D.new()
	material.albedo_color = water_color
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.roughness = 0.45
	material.metallic = 0.0
	material.metallic_specular = 0.25
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	mesh.surface_set_material(0, material)
	var view := MeshInstance3D.new()
	view.name = "WaterSurface"
	view.mesh = mesh
	view.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(view)


## A lily pad: a round leaf with the V-shaped notch cut from its rim to the
## middle, the edge curling up a little, veins radiating from the centre.
## [param radius] across, lying in the xz plane with its top at y = 0.07.
func _pad_mesh() -> ArrayMesh:
	const NOTCH := 0.26 # half the notch's angle, radians
	const SPOKES := 28
	var rings := PackedFloat32Array([0.0, 0.18, 0.45, 0.72, 0.9, 1.0])
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var point := func(ring: int, spoke: int) -> Vector3:
		var r := rings[ring] * pad_radius
		var angle := lerpf(NOTCH, TAU - NOTCH, float(spoke) / SPOKES)
		var curl := smoothstep(0.75, 1.0, rings[ring]) * 0.08
		return Vector3(cos(angle) * r, 0.07 + curl - rings[ring] * 0.015, sin(angle) * r)
	var shade := func(ring: int, spoke: int) -> Color:
		var angle := lerpf(NOTCH, TAU - NOTCH, float(spoke) / SPOKES)
		var vein := pow(absf(cos(angle * 7.0)), 18.0) * smoothstep(0.1, 0.4, rings[ring])
		var color := pad_color.lerp(Color(0.62, 0.72, 0.3), 0.55 * (1.0 - smoothstep(0.0, 0.3, rings[ring])))
		color = color.darkened(0.28 * vein)
		# A reddish rim, as on many water lilies.
		return color.lerp(Color(0.5, 0.25, 0.18), 0.35 * smoothstep(0.88, 1.0, rings[ring]))
	for ring in rings.size() - 1:
		for spoke in SPOKES:
			var quad := [[ring, spoke], [ring + 1, spoke], [ring + 1, spoke + 1], [ring, spoke + 1]]
			for k in [0, 2, 1, 0, 3, 2]:
				var c: Array = quad[k]
				tool.set_color(shade.call(c[0], c[1]))
				tool.add_vertex(point.call(c[0], c[1]))
	# The rim and the notch's cut edges: a thin wall down to the water.
	var edge := rings.size() - 1
	for spoke in SPOKES:
		var a: Vector3 = point.call(edge, spoke)
		var b: Vector3 = point.call(edge, spoke + 1)
		_wall(tool, a, b, pad_color.darkened(0.35))
	for spoke in [0, SPOKES]:
		for ring in edge:
			var a: Vector3 = point.call(ring, spoke)
			var b: Vector3 = point.call(ring + 1, spoke)
			_wall(tool, a if spoke == 0 else b, b if spoke == 0 else a, pad_color.darkened(0.35))
	tool.generate_normals()
	var mesh := tool.commit()
	var leaf := StandardMaterial3D.new()
	leaf.vertex_color_use_as_albedo = true
	leaf.roughness = 0.5
	leaf.cull_mode = BaseMaterial3D.CULL_DISABLED
	mesh.surface_set_material(0, leaf)
	return mesh


func _wall(tool: SurfaceTool, a: Vector3, b: Vector3, color: Color) -> void:
	var a_low := Vector3(a.x, -0.05, a.z)
	var b_low := Vector3(b.x, -0.05, b.z)
	for v in [a, b_low, b, a, a_low, b_low]:
		tool.set_color(color)
		tool.add_vertex(v)


## Lily pads floating along the line, zigzagging a little.
func _build_pads() -> void:
	var pad := _pad_mesh()
	var bounce := PhysicsMaterial.new()
	bounce.bounce = pad_bounce
	bounce.friction = 0.6
	var spots := PackedFloat32Array()
	if pad_count > 0:
		for k in pad_count:
			spots.append(lerpf(from_distance, to_distance, float(k + 1) / (pad_count + 1)))
	else:
		var along := from_distance + pad_spacing * 0.6
		while along < to_distance - pad_spacing * 0.4:
			spots.append(along)
			along += pad_spacing
	var count := 0
	for d in spots:
		var frame := track.world_frame_at(d)
		var right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
		var side := pad_zigzag * (1.0 if count % 2 == 0 else -1.0)
		var at := Vector3(frame.origin.x, _surface + 0.04, frame.origin.z) + right * side
		var body := StaticBody3D.new()
		body.name = "Pad_%d" % count
		body.physics_material_override = bounce
		body.position = at - global_position
		body.rotation.y = d
		var view := MeshInstance3D.new()
		view.mesh = pad
		body.add_child(view)
		var shape := CylinderShape3D.new()
		shape.radius = pad_radius
		shape.height = 0.14
		var holder := CollisionShape3D.new()
		holder.shape = shape
		body.add_child(holder)
		if flower and (count % 3 == 1 or pad_count > 0):
			var bloom: Node3D = flower.instantiate()
			bloom.scale = Vector3.ONE * 0.6
			bloom.position = Vector3(pad_radius * 0.45, 0.07, 0.0)
			body.add_child(bloom)
		add_child(body)
		count += 1
