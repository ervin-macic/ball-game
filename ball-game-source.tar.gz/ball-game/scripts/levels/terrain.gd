class_name Terrain
extends Node3D
## Rolling ground under and around a track, with collision.
##
## The natural shape is noise around [member base_height], optionally tilted
## (a beach sloping into the sea). Two rules then fit it to the track:
## - along open-ground stretches (unpaved pieces) it flattens to the centreline,
##   so the ball rolls off the road onto the ground and back;
## - under built road it stays at least [member road_clearance] below the road,
##   so hills never poke through.
## The mesh and the collision come from the same heights.

@export var track: TrackBuilder
@export var material: Material
## Ground extent (x, z), centred on the track.
@export var size := Vector2(700.0, 700.0)
## Grid spacing. Smaller follows the track's ground stretches more closely.
@export_range(0.5, 10.0, 0.1, "suffix:m") var cell := 2.5
@export_group("Shape")
@export var base_height := -20.0
@export_range(0.0, 100.0, 0.1, "suffix:m") var noise_height := 6.0
@export_range(10.0, 1000.0, 1.0, "suffix:m") var noise_scale := 140.0
@export var noise_seed := 7
## Height change per metre along (x, z): tilts the whole ground, e.g. down to a shore.
@export var tilt := Vector2.ZERO
@export_group("Hills and mountains")
## Hills rising away from the track (0: none). They start [member hills_start]
## metres from the centreline and reach full height at [member hills_full].
@export_range(0.0, 500.0, 0.5, "suffix:m") var hills_height := 0.0
@export_range(0.0, 500.0, 0.5, "suffix:m") var hills_start := 30.0
@export_range(1.0, 1000.0, 0.5, "suffix:m") var hills_full := 120.0
@export_range(10.0, 2000.0, 1.0, "suffix:m") var hills_scale := 160.0
## Hills only where the natural ground is at least this high (e.g. inland of a
## beach; -INF: everywhere).
@export var hills_above := -INF
## Mountains along the edge of the ground (0: none), over this width.
@export_range(0.0, 1000.0, 0.5, "suffix:m") var rim_height := 0.0
@export_range(1.0, 500.0, 0.5, "suffix:m") var rim_width := 120.0
## A clearing past the end of the track, ringed by hills that open toward the
## track: (metres from the track's end to the clearing's middle, the
## clearing's radius, the hills' height, how far they take to rise). Zero
## radius: none.
@export var end_clearing := Vector4.ZERO
@export_group("Track fitting")
## Half width of the flattened strip along open-ground stretches.
@export_range(1.0, 50.0, 0.1, "suffix:m") var ground_half_width := 8.0
## How far the flattened strip blends back into the natural ground.
@export_range(0.5, 100.0, 0.1, "suffix:m") var ground_blend := 14.0
## Minimum gap between the bottom of built road and the ground beneath it.
@export_range(0.0, 50.0, 0.1, "suffix:m") var road_clearance := 1.5
## Beside the road the allowed ground height rises by this much per metre.
@export_range(0.05, 5.0, 0.05) var clearance_slope := 0.6
@export_group("Drawing")
## Ground further than this from every road isn't drawn (it would only be
## seen past the hill crests, if at all). 0 draws all of it.
@export_range(0.0, 2000.0, 1.0, "suffix:m") var keep_within := 0.0
## Distances at which the ground switches to half and to quarter detail.
@export var detail_ranges := Vector2(170.0, 380.0)
## Ground entirely below this height isn't drawn (under the beach's sea).
@export var hide_below := -INF
@export_group("Physics")
@export_range(0.0, 3.0, 0.01) var friction := 1.0
@export_range(0.0, 1.0, 0.01) var bounce := 0.0

var heights := PackedFloat32Array()
var columns := 0
var rows := 0
## World-space position of grid point (0, 0).
var origin := Vector3.ZERO

var _body: StaticBody3D


func _ready() -> void:
	if track:
		if track.path.frames.is_empty():
			await track.rebuilt
		build()


## Whether a world position lies over the ground grid (with [param inset] to spare).
func contains(world: Vector3, inset := 0.0) -> bool:
	return world.x >= origin.x + inset and world.z >= origin.z + inset \
		and world.x <= origin.x + (columns - 1) * cell - inset and world.z <= origin.z + (rows - 1) * cell - inset


## Ground height at a world position, on exactly the triangles the ground is
## drawn with (so props stand on the visible surface), clamped to the grid.
func height_at(world: Vector3) -> float:
	if heights.is_empty():
		return base_height
	var gx := clampf((world.x - origin.x) / cell, 0.0, columns - 1.001)
	var gz := clampf((world.z - origin.z) / cell, 0.0, rows - 1.001)
	var ix := int(gx)
	var iz := int(gz)
	var fx := gx - ix
	var fz := gz - iz
	var a := heights[iz * columns + ix]
	var b := heights[iz * columns + ix + 1]
	var c := heights[(iz + 1) * columns + ix]
	var d := heights[(iz + 1) * columns + ix + 1]
	# Each cell is split along its b-c diagonal, as in _build_mesh.
	if fx + fz <= 1.0:
		return a + (b - a) * fx + (c - a) * fz
	return d + (c - d) * (1.0 - fx) + (b - d) * (1.0 - fz)


func build() -> void:
	var centre := _track_centre()
	columns = int(ceil(size.x / cell)) + 1
	rows = int(ceil(size.y / cell)) + 1
	origin = Vector3(centre.x - (columns - 1) * cell * 0.5, 0.0, centre.z - (rows - 1) * cell * 0.5)
	_shape_heights()
	_build_mesh()
	_build_collision()


func _track_centre() -> Vector3:
	if track == null or track.path.frames.is_empty():
		return global_position
	var box := AABB(track.to_global(track.network.frames[0].origin), Vector3.ZERO)
	for frame in track.network.frames:
		box = box.expand(track.to_global(frame.origin))
	return box.get_center()


func _shape_heights() -> void:
	var noise := FastNoiseLite.new()
	noise.seed = noise_seed
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 1.0 / noise_scale
	noise.fractal_octaves = 3
	var count := columns * rows
	heights.resize(count)
	var cap := PackedFloat32Array()
	cap.resize(count)
	cap.fill(INF)
	var ground_distance := PackedFloat32Array()
	ground_distance.resize(count)
	ground_distance.fill(INF)
	var ground_height := PackedFloat32Array()
	ground_height.resize(count)
	for iz in rows:
		for ix in columns:
			var x := origin.x + ix * cell
			var z := origin.z + iz * cell
			heights[iz * columns + ix] = base_height + noise.get_noise_2d(x, z) * noise_height + tilt.x * x + tilt.y * z
	if track and (hills_height > 0.0 or rim_height > 0.0):
		_raise_hills(noise)
	if track and end_clearing.y > 0.0:
		_shape_end_clearing(noise)

	if track:
		var path := track.network
		var road_half := track.road_width * 0.5 + track.lip_width + track.rim_width
		var under := track.thickness + road_clearance
		# Built road: cap the ground below it, rising away from its edges.
		var cap_reach := road_half + 24.0
		var last_stamp := -INF
		for i in path.frames.size():
			if not path.paved[i] or absf(path.distances[i] - last_stamp) < cell * 0.75:
				continue
			last_stamp = path.distances[i]
			var at := track.to_global(path.frames[i].origin)
			_stamp(at, cap_reach, func(index: int, d: float) -> void:
				var allowed := at.y - under + maxf(d - road_half, 0.0) * clearance_slope
				cap[index] = minf(cap[index], allowed))
		# Open ground: remember the nearest centreline height.
		var reach := ground_half_width + ground_blend
		for span in path.ground_ranges():
			for i in range(span.x, span.y):
				var at := track.to_global(path.frames[i].origin)
				_stamp(at, reach, func(index: int, d: float) -> void:
					if d < ground_distance[index]:
						ground_distance[index] = d
						ground_height[index] = at.y)

	for index in count:
		var h := minf(heights[index], cap[index])
		var d := ground_distance[index]
		if d < INF:
			var w := 1.0 - smoothstep(ground_half_width, ground_half_width + ground_blend, d)
			h = lerpf(h, ground_height[index], w)
		heights[index] = h


## Adds hills that rise with distance from the track, and a mountain rim along
## the edge, so the level feels enclosed rather than an endless plain.
func _raise_hills(noise: FastNoiseLite) -> void:
	var distance := _track_distance_field()
	var ridges := FastNoiseLite.new()
	ridges.seed = noise_seed + 101
	ridges.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	ridges.frequency = 1.0 / hills_scale
	ridges.fractal_type = FastNoiseLite.FRACTAL_RIDGED
	ridges.fractal_octaves = 4
	for iz in rows:
		for ix in columns:
			var index := iz * columns + ix
			var x := origin.x + ix * cell
			var z := origin.z + iz * cell
			var shape := 0.45 + 0.55 * clampf(ridges.get_noise_2d(x, z) * 0.5 + 0.5, 0.0, 1.0)
			var natural := heights[index]
			var lift := 0.0
			if hills_height > 0.0:
				var mask := 1.0 if hills_above == -INF else smoothstep(hills_above, hills_above + 3.0, natural)
				lift += hills_height * smoothstep(hills_start, hills_full, distance[index]) * shape * mask
			if rim_height > 0.0:
				var edge := float(mini(mini(ix, columns - 1 - ix), mini(iz, rows - 1 - iz))) * cell
				lift = maxf(lift, rim_height * smoothstep(rim_width, 0.0, edge) * (0.6 + 0.4 * shape))
			heights[index] = natural + lift


## The clearing past the end of the track and the ring of hills around it.
func _shape_end_clearing(noise: FastNoiseLite) -> void:
	var end := track.global_transform * track.path.frames[track.path.frames.size() - 1]
	var forward := Vector3(-end.basis.z.x, 0.0, -end.basis.z.z).normalized()
	var centre := end.origin + forward * end_clearing.x
	var clearing_height := end.origin.y - track.thickness - road_clearance
	var radius := end_clearing.y
	var hill := end_clearing.z
	var rise := end_clearing.w
	for iz in rows:
		for ix in columns:
			var index := iz * columns + ix
			var p := Vector3(origin.x + ix * cell, 0.0, origin.z + iz * cell)
			var d := Vector2(p.x - centre.x, p.z - centre.z).length()
			if d > radius + rise * 2.5:
				continue
			# Open toward the track: no hills behind the end of the road.
			var ahead := (p - end.origin).dot(forward)
			var open := smoothstep(-30.0, 0.0, ahead)
			var lumpy := 0.7 + 0.6 * (noise.get_noise_2d(p.x * 2.0, p.z * 2.0) * 0.5 + 0.5)
			var ring := clearing_height + hill * smoothstep(radius, radius + rise, d) * lumpy * open
			# Near the clearing the ring's gentle slope replaces the ground
			# (natural hills there would drop into it as a cliff); further out
			# it hands back to the natural hills.
			var own := (1.0 - smoothstep(radius + rise, radius + rise * 2.5, d)) * smoothstep(-25.0, -5.0, ahead)
			heights[index] = maxf(lerpf(heights[index], ring, own), ring)


## Horizontal distance from every grid point to the track's centreline
## (a two-pass chamfer transform seeded along the centreline).
func _track_distance_field() -> PackedFloat32Array:
	var count := columns * rows
	var distance := PackedFloat32Array()
	distance.resize(count)
	distance.fill(1e9)
	for frame in track.network.frames:
		var at := track.to_global(frame.origin)
		_stamp(at, cell * 1.5, func(index: int, d: float) -> void:
			distance[index] = minf(distance[index], d))
	var straight := cell
	var diagonal := cell * 1.41421
	for iz in rows:
		for ix in columns:
			var i := iz * columns + ix
			var best := distance[i]
			if ix > 0: best = minf(best, distance[i - 1] + straight)
			if iz > 0:
				best = minf(best, distance[i - columns] + straight)
				if ix > 0: best = minf(best, distance[i - columns - 1] + diagonal)
				if ix < columns - 1: best = minf(best, distance[i - columns + 1] + diagonal)
			distance[i] = best
	for iz in range(rows - 1, -1, -1):
		for ix in range(columns - 1, -1, -1):
			var i := iz * columns + ix
			var best := distance[i]
			if ix < columns - 1: best = minf(best, distance[i + 1] + straight)
			if iz < rows - 1:
				best = minf(best, distance[i + columns] + straight)
				if ix < columns - 1: best = minf(best, distance[i + columns + 1] + diagonal)
				if ix > 0: best = minf(best, distance[i + columns - 1] + diagonal)
			distance[i] = best
	return distance


## Calls [param apply](index, horizontal distance) for grid points within [param radius] of [param at].
func _stamp(at: Vector3, radius: float, apply: Callable) -> void:
	var x0 := maxi(int(floor((at.x - radius - origin.x) / cell)), 0)
	var x1 := mini(int(ceil((at.x + radius - origin.x) / cell)), columns - 1)
	var z0 := maxi(int(floor((at.z - radius - origin.z) / cell)), 0)
	var z1 := mini(int(ceil((at.z + radius - origin.z) / cell)), rows - 1)
	for iz in range(z0, z1 + 1):
		var dz := origin.z + iz * cell - at.z
		for ix in range(x0, x1 + 1):
			var dx := origin.x + ix * cell - at.x
			var d := sqrt(dx * dx + dz * dz)
			if d <= radius:
				apply.call(iz * columns + ix, d)


## Ground drawn in square blocks of this many cells, each with three levels of
## detail, so blocks behind the camera aren't drawn and far ones are cheap.
const BLOCK_CELLS := 40
## Each level of detail skips this many grid points.
const DETAIL_STEPS: Array[int] = [1, 2, 4]


func _build_mesh() -> void:
	for child in get_children():
		if child.name.begins_with("Ground_"):
			child.free()
	_drawn_distance = _track_distance_field() if track and keep_within > 0.0 else PackedFloat32Array()
	var distance := _drawn_distance
	var ranges := [0.0, detail_ranges.x, detail_ranges.y, 0.0]
	for bz in range(0, rows - 1, BLOCK_CELLS):
		for bx in range(0, columns - 1, BLOCK_CELLS):
			var span := Rect2i(bx, bz, mini(BLOCK_CELLS, columns - 1 - bx), mini(BLOCK_CELLS, rows - 1 - bz))
			if not distance.is_empty() and _block_distance(distance, span) > keep_within:
				continue
			if _block_top(span) < hide_below:
				continue
			var centre := Vector3(origin.x + (span.position.x + span.size.x * 0.5) * cell, 0.0, origin.z + (span.position.y + span.size.y * 0.5) * cell)
			for level in DETAIL_STEPS.size():
				var mesh := _block_mesh(span, DETAIL_STEPS[level], centre)
				if mesh == null:
					continue
				var view := MeshInstance3D.new()
				view.name = "Ground_%d_%d_%d" % [bx, bz, level]
				view.mesh = mesh
				# The ground receives shadows; casting them too would redraw it
				# into the shadow map for little visible gain.
				view.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				view.visibility_range_begin = ranges[level]
				view.visibility_range_end = ranges[level + 1]
				add_child(view)
				view.global_position = centre


## Highest ground in a block.
func _block_top(span: Rect2i) -> float:
	var top := -INF
	for iz in range(span.position.y, span.end.y + 1):
		for ix in range(span.position.x, span.end.x + 1):
			top = maxf(top, heights[iz * columns + ix])
	return top


var _drawn_distance := PackedFloat32Array()


## Whether the ground at grid point ([param ix], [param iz]) is drawn: within
## keep_within of a road and above hide_below.
func _cell_drawn(ix: int, iz: int) -> bool:
	var index := iz * columns + ix
	if heights[index] < hide_below:
		return false
	return _drawn_distance.is_empty() or _drawn_distance[index] <= keep_within


## Whether the ground under a world position is drawn (scenery placed where it
## isn't would float at the world's edge).
func is_drawn(world: Vector3, inset := 0.0) -> bool:
	if not contains(world):
		return false
	var ix := clampi(roundi((world.x - origin.x) / cell), 0, columns - 1)
	var iz := clampi(roundi((world.z - origin.z) / cell), 0, rows - 1)
	if _drawn_distance.is_empty():
		return heights[iz * columns + ix] >= hide_below
	return _drawn_distance[iz * columns + ix] <= keep_within - inset


## Nearest distance from any grid point of a block to the track.
func _block_distance(distance: PackedFloat32Array, span: Rect2i) -> float:
	var nearest := INF
	for iz in range(span.position.y, span.end.y + 1):
		for ix in range(span.position.x, span.end.x + 1):
			nearest = minf(nearest, distance[iz * columns + ix])
	return nearest


## One block's ground, every [param step]th grid point, around [param centre].
## A skirt hangs from its edges so neighbours at another level of detail
## never show a crack between them.
func _block_mesh(span: Rect2i, step: int, centre: Vector3) -> ArrayMesh:
	var xs := _steps(span.position.x, span.end.x, step)
	var zs := _steps(span.position.y, span.end.y, step)
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	_vertex_counter = 0
	var grid := {}
	for iz in zs:
		for ix in xs:
			grid[Vector2i(ix, iz)] = _ground_vertex(tool, ix, iz, centre, 0.0)
	var quads := 0
	for j in zs.size() - 1:
		for i in xs.size() - 1:
			if not (_cell_drawn(xs[i], zs[j]) or _cell_drawn(xs[i + 1], zs[j]) or _cell_drawn(xs[i], zs[j + 1]) or _cell_drawn(xs[i + 1], zs[j + 1])):
				continue
			quads += 1
			var a: int = grid[Vector2i(xs[i], zs[j])]
			var b: int = grid[Vector2i(xs[i + 1], zs[j])]
			var c: int = grid[Vector2i(xs[i], zs[j + 1])]
			var d: int = grid[Vector2i(xs[i + 1], zs[j + 1])]
			for index in [a, b, c, b, d, c]:
				tool.add_index(index)
	# Skirts, drawn from both sides.
	var edges := [[], [], [], []]
	for ix in xs:
		edges[0].append(Vector2i(ix, zs[0]))
		edges[1].append(Vector2i(ix, zs[zs.size() - 1]))
	for iz in zs:
		edges[2].append(Vector2i(xs[0], iz))
		edges[3].append(Vector2i(xs[xs.size() - 1], iz))
	if quads == 0:
		return null
	for edge: Array in edges:
		for k in edge.size() - 1:
			if not (_cell_drawn(edge[k].x, edge[k].y) or _cell_drawn(edge[k + 1].x, edge[k + 1].y)):
				continue
			var top_a: int = grid[edge[k]]
			var top_b: int = grid[edge[k + 1]]
			var low_a := _ground_vertex(tool, edge[k].x, edge[k].y, centre, SKIRT_DEPTH)
			var low_b := _ground_vertex(tool, edge[k + 1].x, edge[k + 1].y, centre, SKIRT_DEPTH)
			for index in [top_a, top_b, low_a, top_b, low_b, low_a, top_a, low_a, top_b, top_b, low_a, low_b]:
				tool.add_index(index)
	var mesh := tool.commit()
	if material:
		mesh.surface_set_material(0, material)
	return mesh


const SKIRT_DEPTH := 4.0


static func _steps(from: int, to: int, step: int) -> Array[int]:
	var points: Array[int] = []
	var at := from
	while at < to:
		points.append(at)
		at += step
	points.append(to)
	return points


## Adds the vertex of grid point ([param ix], [param iz]) relative to
## [param centre], [param drop] metres below the ground, and returns its index.
func _ground_vertex(tool: SurfaceTool, ix: int, iz: int, centre: Vector3, drop: float) -> int:
	var index := iz * columns + ix
	var world := Vector3(origin.x + ix * cell, heights[index] - drop, origin.z + iz * cell)
	var hl := heights[iz * columns + maxi(ix - 1, 0)]
	var hr := heights[iz * columns + mini(ix + 1, columns - 1)]
	var hd := heights[maxi(iz - 1, 0) * columns + ix]
	var hu := heights[mini(iz + 1, rows - 1) * columns + ix]
	tool.set_normal(Vector3(hl - hr, 2.0 * cell, hd - hu).normalized())
	tool.set_tangent(Plane(1.0, 0.0, 0.0, 1.0))
	tool.set_uv(Vector2(world.x, world.z))
	tool.add_vertex(world - centre)
	return _vertex_count_of(tool)


var _vertex_counter := 0


func _vertex_count_of(_tool: SurfaceTool) -> int:
	_vertex_counter += 1
	return _vertex_counter - 1


func _build_collision() -> void:
	if _body == null:
		_body = StaticBody3D.new()
		_body.name = "GroundBody"
		add_child(_body)
	for child in _body.get_children():
		child.free()
	var surface := PhysicsMaterial.new()
	surface.friction = friction
	surface.bounce = bounce
	_body.physics_material_override = surface
	var shape := HeightMapShape3D.new()
	shape.map_width = columns
	shape.map_depth = rows
	shape.map_data = heights
	var holder := CollisionShape3D.new()
	holder.shape = shape
	_body.add_child(holder)
	# The shape is centred with 1 m spacing; scale and centre it on the grid.
	holder.global_transform = Transform3D(
		Basis.from_scale(Vector3(cell, 1.0, cell)),
		Vector3(origin.x + (columns - 1) * cell * 0.5, 0.0, origin.z + (rows - 1) * cell * 0.5))
