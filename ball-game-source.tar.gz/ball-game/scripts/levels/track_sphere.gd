class_name TrackSphere
extends Node3D
## A big ball standing in a jump gap: too far to roll across, so the player
## jumps onto it and rolls over its top to the road beyond. It sits at
## [member distance] along the track, its top [member top_height] above the
## centreline there (a gap's centreline runs straight from its edge to the far
## side).

@export var track: TrackBuilder
@export_range(0.0, 10000.0, 0.1, "suffix:m") var distance := 0.0
@export_range(1.0, 100.0, 0.1, "suffix:m") var radius := 9.0
@export_range(-50.0, 50.0, 0.1, "suffix:m") var top_height := 2.0
@export var material: Material


func _ready() -> void:
	if track.path.frames.is_empty():
		await track.rebuilt
	build()


func build() -> void:
	for child in get_children():
		child.free()
	var body := StaticBody3D.new()
	body.name = "Sphere"
	body.collision_layer = track.collision_layer
	body.collision_mask = 0
	var surface := PhysicsMaterial.new()
	surface.friction = track.friction
	body.physics_material_override = surface
	add_child(body)
	body.global_position = centre()
	var shape := CollisionShape3D.new()
	shape.shape = SphereShape3D.new()
	(shape.shape as SphereShape3D).radius = radius
	body.add_child(shape)
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 64
	mesh.rings = 32
	var look := MeshInstance3D.new()
	look.mesh = mesh
	look.material_override = material
	body.add_child(look)


## Where the sphere's centre is, in world space.
func centre() -> Vector3:
	return track.world_frame_at(distance).origin + Vector3.UP * (top_height - radius)
