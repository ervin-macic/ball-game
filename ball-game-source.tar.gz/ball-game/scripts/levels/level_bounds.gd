class_name LevelBounds
extends Node3D
## Keeps the ball in the world: tall invisible walls around the level's edge
## and, where a level has no terrain, a solid floor. Nothing falls into the void.

@export var track: TrackBuilder
## When set, the walls follow the terrain's edge; otherwise they enclose the
## track with [member margin] to spare.
@export var terrain: Terrain
@export_range(10.0, 2000.0, 1.0, "suffix:m") var margin := 150.0
## Height of a solid floor (NAN: none, the terrain is the ground).
@export var floor_height := NAN
@export_range(10.0, 2000.0, 1.0, "suffix:m") var wall_height := 600.0


func _ready() -> void:
	if track and track.path.frames.is_empty():
		await track.rebuilt
	if terrain and terrain.heights.is_empty():
		await get_tree().process_frame
	build()


func build() -> void:
	var box := _area()
	var body := StaticBody3D.new()
	body.name = "Bounds"
	add_child(body)
	var low := box.position.y - wall_height * 0.5
	if is_finite(floor_height):
		var ground := CollisionShape3D.new()
		ground.shape = WorldBoundaryShape3D.new()
		ground.position = Vector3(0.0, floor_height, 0.0)
		body.add_child(ground)
	var centre := box.get_center()
	var size := box.size
	for side in 4:
		var wall := BoxShape3D.new()
		var along_x := side < 2
		wall.size = Vector3(size.x + 20.0 if along_x else 10.0, wall_height, 10.0 if along_x else size.z + 20.0)
		var holder := CollisionShape3D.new()
		holder.shape = wall
		var offset := Vector3(0.0, 0.0, (size.z * 0.5 + 5.0) * (1.0 if side == 0 else -1.0)) if along_x \
			else Vector3((size.x * 0.5 + 5.0) * (1.0 if side == 2 else -1.0), 0.0, 0.0)
		holder.position = Vector3(centre.x, low + wall_height * 0.5, centre.z) + offset
		body.add_child(holder)


## The playable area: the terrain's extent, or the track's with a margin.
func _area() -> AABB:
	if terrain and not terrain.heights.is_empty():
		var size := Vector3((terrain.columns - 1) * terrain.cell, 0.0, (terrain.rows - 1) * terrain.cell)
		return AABB(Vector3(terrain.origin.x, terrain.base_height, terrain.origin.z), size)
	var box := AABB(track.to_global(track.network.frames[0].origin), Vector3.ZERO)
	for frame in track.network.frames:
		box = box.expand(track.to_global(frame.origin))
	return box.grow(margin)
