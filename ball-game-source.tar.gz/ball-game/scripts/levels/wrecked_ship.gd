class_name WreckedShip
extends Node3D
## A pirate ship wrecked on the beach, broken in two and lying along the track
## so the ball rolls right through it: in through the smashed stern, along the
## dark hold under the deck, out of the break, across a few metres of sand
## and through the bow half. Both halves sit sunk in the sand (which is the
## hold's floor) and list a little to opposite sides.
##
## The halves are cut from one ship model with a shader, which also leaves the
## hold empty (so the feet of the masts don't stand in the way). The hull's
## sides and the deck are solid boxes.

@export var track: TrackBuilder
@export var terrain: Terrain
@export var ship: PackedScene
## Where along the track the break between the halves is.
@export var at_distance := 438.0
## Metres per model unit (the Quaternius ship is about 15 units long).
@export var ship_scale := 3.3
## Parts of the ship kept for each half, along its length in model units (its
## bow points to -x): the stern half and the bow half.
@export var stern_part := Vector2(-0.4, 4.6)
@export var bow_part := Vector2(-6.2, -1.3)
## Sand between the halves.
@export_range(0.0, 30.0, 0.5, "suffix:m") var gap := 5.0
## Height (model units) where the sand meets the hull: the hold's floor.
@export var sand_level := -0.55
@export_range(0.0, 30.0, 0.5, "suffix:°") var list_angle := 5.0

## The middle of the hold, in model units: nothing of the model is drawn
## there (the feet of the masts), while the hull's sides stay.
const HOLD_MIN := Vector3(-7.0, -1.3, -1.3)
const HOLD_MAX := Vector3(5.2, 0.74, 1.3)
## The hull's sides (half width, model units) and the deck's underside.
const HULL_HALF_WIDTH := 2.3
const DECK_UNDERSIDE := 0.76
const SECTION_SHADER := preload("res://Assets/Materials/ship_section.gdshader")


func _ready() -> void:
	if track.path.frames.is_empty():
		await track.rebuilt
	build()


func build() -> void:
	var root: Node3D = ship.instantiate()
	var parts := root.find_children("*", "MeshInstance3D", true, false)
	if parts.is_empty():
		root.free()
		return
	var source := parts[0] as MeshInstance3D
	var mesh := source.mesh
	# The model's own node scale (the mesh is in hundredths of model units).
	var model_scale := 1.0
	var node: Node = source
	while node != null and node is Node3D:
		model_scale *= (node as Node3D).transform.basis.get_scale().x
		node = node.get_parent()
	root.free()
	var stern_length := (stern_part.y - stern_part.x) * ship_scale
	var bow_length := (bow_part.y - bow_part.x) * ship_scale
	_place_half("Stern", mesh, model_scale, stern_part, at_distance - gap * 0.5 - stern_length * 0.5, 1.0)
	_place_half("Bow", mesh, model_scale, bow_part, at_distance + gap * 0.5 + bow_length * 0.5, -1.0)


## One half of the ship centred [param at] along the track, its kept part
## [param part] (model units along x) lined up with the track.
func _place_half(half_name: String, mesh: Mesh, model_scale: float, part: Vector2, at: float, lean: float) -> void:
	var frame := track.world_frame_at(at)
	var forward := Vector3(-frame.basis.z.x, 0.0, -frame.basis.z.z).normalized()
	var right := forward.cross(Vector3.UP).normalized()
	# Model x runs backwards along the track (the bow leads), y up, z = -right.
	var rotation := Basis(-forward, Vector3.UP, -right)
	rotation = Basis(forward, deg_to_rad(list_angle) * lean) * rotation
	var centre_x := (part.x + part.y) * 0.5
	var ground := terrain.height_at(frame.origin) if terrain else frame.origin.y
	var anchor := Vector3(frame.origin.x, ground, frame.origin.z)
	var origin := anchor - rotation * (Vector3(centre_x, sand_level, 0.0) * ship_scale)
	var body := StaticBody3D.new()
	body.name = half_name
	add_child(body)
	body.global_transform = Transform3D(rotation, origin)
	# Drawn: the model (in its own units, hundredths) scaled to metres.
	var view := MeshInstance3D.new()
	view.mesh = mesh
	view.scale = Vector3.ONE * model_scale * ship_scale
	var to_mesh := 1.0 / model_scale
	for surface in mesh.get_surface_count():
		view.set_surface_override_material(surface, _section(mesh.surface_get_material(surface), part * to_mesh, to_mesh))
	body.add_child(view)
	# Solid: the two sides of the hull and the deck over the hold.
	var length := (part.y - part.x) * ship_scale
	var wall_height := (DECK_UNDERSIDE + 0.6 - sand_level + 1.0) * ship_scale
	for side in [-1.0, 1.0]:
		_box(body, Vector3(length, wall_height, 1.2), Vector3(centre_x * ship_scale, (sand_level - 1.0 + DECK_UNDERSIDE + 0.6) * 0.5 * ship_scale, side * (HULL_HALF_WIDTH * ship_scale + 0.6)))
	_box(body, Vector3(length, 1.6, (HULL_HALF_WIDTH * 2.0) * ship_scale + 2.4), Vector3(centre_x * ship_scale, DECK_UNDERSIDE * ship_scale + 0.8, 0.0))
	# (No lantern light in the hold: a light makes the browser prepare every
	# material near it twice, lit by it and not, and the run stalls as each
	# first comes into its reach.)


func _box(body: StaticBody3D, size: Vector3, at: Vector3) -> void:
	var shape := BoxShape3D.new()
	shape.size = size
	var holder := CollisionShape3D.new()
	holder.shape = shape
	holder.position = at
	body.add_child(holder)


## The model's material, cut to [param part] (mesh units along x) with the
## hold left empty.
func _section(original: Material, part: Vector2, to_mesh: float) -> ShaderMaterial:
	var section := ShaderMaterial.new()
	section.shader = SECTION_SHADER
	section.set_shader_parameter("keep_from", part.x)
	section.set_shader_parameter("keep_to", part.y)
	section.set_shader_parameter("hollow_min", HOLD_MIN * to_mesh)
	section.set_shader_parameter("hollow_max", HOLD_MAX * to_mesh)
	if original is BaseMaterial3D:
		var base := original as BaseMaterial3D
		section.set_shader_parameter("albedo_color", base.albedo_color)
		section.set_shader_parameter("use_texture", base.albedo_texture != null)
		if base.albedo_texture:
			section.set_shader_parameter("albedo_texture", base.albedo_texture)
	return section
