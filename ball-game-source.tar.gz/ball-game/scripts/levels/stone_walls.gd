class_name StoneWalls
extends StaticBody3D
## Cobblestone walls along both sides of every open-ground stretch of a track,
## standing on the terrain. A ball that left the course and rolled along the
## ground can't rejoin it there: it has to go back to where it fell off.
##
## The walls run a little past each end of a stretch, alongside the ramps that
## lead up from the ground, so there's no gap to slip through at the corners.

@export var track: TrackBuilder
@export var terrain: Terrain
## Distance of the walls' middle from the track's centreline.
@export_range(2.0, 40.0, 0.1, "suffix:m") var offset := 10.0
@export_range(0.5, 10.0, 0.1, "suffix:m") var height := 2.6
@export_range(0.2, 4.0, 0.05, "suffix:m") var thickness := 0.9
## How far the walls carry on past each end of a stretch.
@export_range(0.0, 60.0, 0.5, "suffix:m") var extend := 14.0
## Texture repeat, in metres.
@export_range(0.5, 10.0, 0.1, "suffix:m") var tile := 2.4
@export var material: Material
## Stretches (along the track: from, to) to leave open, e.g. a pond's banks.
@export var gaps := PackedVector2Array()

const STEP := 2.0


func _ready() -> void:
	if track.path.frames.is_empty():
		await track.rebuilt
	build()


func build() -> void:
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var faces := PackedVector3Array()
	var path := track.path
	for span in path.ground_ranges():
		var from := maxf(path.distances[span.x] - extend, 0.0)
		var to := minf(path.distances[span.y - 1] + extend, path.total_length())
		for side in [-1.0, 1.0]:
			_wall(tool, faces, from, to, side)
	tool.generate_tangents()
	var view := MeshInstance3D.new()
	view.name = "Walls"
	view.mesh = tool.commit()
	if material:
		view.material_override = material
	add_child(view)
	var shape := ConcavePolygonShape3D.new()
	shape.backface_collision = true
	shape.set_faces(faces)
	var holder := CollisionShape3D.new()
	holder.shape = shape
	add_child(holder)
	var surface := PhysicsMaterial.new()
	surface.friction = 0.8
	surface.bounce = 0.15
	physics_material_override = surface


func _open(d: float) -> bool:
	for gap in gaps:
		if d >= gap.x and d <= gap.y:
			return true
	return false


## One wall from [param from] to [param to] along the track, on [param side].
func _wall(tool: SurfaceTool, faces: PackedVector3Array, from: float, to: float, side: float) -> void:
	var steps := maxi(ceili((to - from) / STEP), 1)
	var previous := {}
	var forward := Vector3.FORWARD
	for k in steps + 1:
		var d := lerpf(from, to, float(k) / steps)
		if _open(d):
			if not previous.is_empty():
				_end_cap(tool, faces, previous, forward)
			previous = {}
			continue
		var frame := track.world_frame_at(d)
		var right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
		forward = Vector3(-frame.basis.z.x, 0.0, -frame.basis.z.z).normalized()
		var middle := frame.origin + right * offset * side
		var ground := terrain.height_at(middle) if terrain else frame.origin.y
		# Never lower than the road beside it: the wall must stand above the ground lane.
		var base := ground - 0.6
		var top := ground + height
		var inner := middle - right * side * thickness * 0.5
		var outer := middle + right * side * thickness * 0.5
		var ring := {
			"d": d,
			"in_low": Vector3(inner.x, base, inner.z), "in_high": Vector3(inner.x, top, inner.z),
			"out_low": Vector3(outer.x, base, outer.z), "out_high": Vector3(outer.x, top, outer.z),
		}
		if previous.is_empty():
			_end_cap(tool, faces, ring, -forward)
		else:
			var toward_track := -right * side
			_quad(tool, faces, previous["in_low"], ring["in_low"], ring["in_high"], previous["in_high"], previous["d"], d, base, top, toward_track)
			_quad(tool, faces, ring["out_low"], previous["out_low"], previous["out_high"], ring["out_high"], d, previous["d"], base, top, -toward_track)
			_quad(tool, faces, previous["in_high"], ring["in_high"], ring["out_high"], previous["out_high"], previous["d"], d, 0.0, thickness, Vector3.UP)
		previous = ring
	if not previous.is_empty():
		_end_cap(tool, faces, previous, forward)


func _end_cap(tool: SurfaceTool, faces: PackedVector3Array, ring: Dictionary, facing: Vector3) -> void:
	_quad(tool, faces, ring["in_low"], ring["out_low"], ring["out_high"], ring["in_high"], 0.0, thickness,
		(ring["in_low"] as Vector3).y, (ring["in_high"] as Vector3).y, facing)


## A quad a-b-c-d facing [param facing], textured by distance
## along (u0..u1) and height (v0..v1). Both windings go to the collision.
func _quad(tool: SurfaceTool, faces: PackedVector3Array, a: Vector3, b: Vector3, c: Vector3, d: Vector3,
		u0: float, u1: float, v0: float, v1: float, facing: Vector3) -> void:
	var normal := (b - a).cross(d - a).normalized()
	var uvs := [Vector2(u0, -v0), Vector2(u1, -v0), Vector2(u1, -v1), Vector2(u0, -v1)]
	var corners := [a, b, c, d]
	if normal.dot(facing) < 0.0:
		# Wound the other way round: flip it to face [param facing].
		normal = -normal
		corners = [a, d, c, b]
		uvs = [uvs[0], uvs[3], uvs[2], uvs[1]]
	for k in [0, 2, 1, 0, 3, 2]:
		tool.set_normal(normal)
		tool.set_uv(uvs[k] / tile)
		tool.add_vertex(corners[k] - global_position)
		faces.append(corners[k] - global_position)
