class_name Vent
extends Node3D
## A steam vent in the ground on the track: a ball that rolls onto it is blasted
## up into the sky (keeping some of its speed along the ground), and comes down
## further along the course.

@export var track: TrackBuilder
@export var terrain: Terrain
@export var at_distance := 100.0
## Metres to the right of the centreline.
@export var offset := 0.0
@export_range(0.5, 10.0, 0.1, "suffix:m") var radius := 2.4
## Upward speed of the blast.
@export_range(1.0, 80.0, 0.5, "suffix:m/s") var blast := 31.0
## Share of the ball's speed along the ground it keeps.
@export_range(0.0, 1.0, 0.01) var keep := 0.6
@export var rim_color := Color(0.28, 0.25, 0.23)
@export var steam_color := Color(0.95, 0.96, 0.98, 0.8)

var _area: Area3D
var _cooldown := {}
var _puff: CPUParticles3D


func _ready() -> void:
	if track.path.frames.is_empty():
		await track.rebuilt
	build()


func build() -> void:
	var frame := track.world_frame_at(at_distance)
	var right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
	var spot := frame.origin + right * offset
	spot.y = terrain.height_at(spot) if terrain else spot.y
	global_position = spot
	# A low rock rim around a dark mouth, flush with the ground.
	var rim := MeshInstance3D.new()
	var ring := TorusMesh.new()
	ring.inner_radius = radius * 0.82
	ring.outer_radius = radius * 1.12
	ring.rings = 24
	ring.ring_segments = 8
	var stone := StandardMaterial3D.new()
	stone.albedo_color = rim_color
	stone.roughness = 0.9
	ring.material = stone
	rim.mesh = ring
	rim.scale = Vector3(1.0, 0.35, 1.0)
	rim.position = Vector3.UP * 0.02
	add_child(rim)
	var mouth := MeshInstance3D.new()
	var disc := CylinderMesh.new()
	disc.top_radius = radius * 0.85
	disc.bottom_radius = radius * 0.85
	disc.height = 0.04
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.06, 0.06, 0.07)
	disc.material = dark
	mouth.mesh = disc
	mouth.position = Vector3.UP * 0.03
	add_child(mouth)
	# Steam: always wisping, bursting when it fires.
	_puff = CPUParticles3D.new()
	_puff.amount = 90
	_puff.lifetime = 1.6
	_puff.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	_puff.emission_sphere_radius = radius * 0.6
	_puff.direction = Vector3.UP
	_puff.spread = 12.0
	_puff.initial_velocity_min = 3.0
	_puff.initial_velocity_max = 7.0
	_puff.gravity = Vector3.UP * 1.5
	_puff.scale_amount_min = 1.0
	_puff.scale_amount_max = 2.6
	var cloud := SphereMesh.new()
	cloud.radius = 0.35
	cloud.height = 0.7
	cloud.radial_segments = 8
	cloud.rings = 4
	var steam := StandardMaterial3D.new()
	steam.albedo_color = steam_color
	steam.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	steam.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	cloud.material = steam
	_puff.mesh = cloud
	add_child(_puff)
	# The trigger: a short cylinder over the mouth.
	_area = Area3D.new()
	_area.collision_layer = 0
	_area.collision_mask = 1
	var shape := CylinderShape3D.new()
	shape.radius = radius
	shape.height = 2.0
	var holder := CollisionShape3D.new()
	holder.shape = shape
	holder.position = Vector3.UP * 1.0
	_area.add_child(holder)
	add_child(_area)
	_area.body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	for body in _cooldown.keys():
		_cooldown[body] -= delta
		if _cooldown[body] <= 0.0:
			_cooldown.erase(body)


func _on_body_entered(body: Node) -> void:
	if not (body is RigidBody3D) or _cooldown.has(body):
		return
	var rigid := body as RigidBody3D
	var v := rigid.linear_velocity
	var thrown := Vector3(v.x * keep, blast, v.z * keep)
	if rigid.has_method("launch"):
		rigid.launch(thrown)
	else:
		rigid.linear_velocity = thrown
	_cooldown[body] = 1.0
	_puff.amount = 90
	_puff.restart()
