class_name PropScatter
extends Node3D
## Scatters props (trees, rocks, plants...) around a track on a Terrain and
## gives the solid ones collision, so the ball bounces off them.
##
## Each kind of prop is a Dictionary:
##   scene     path of the model (.glb or .tscn)            required
##   count     how many to try to place                      required
##   band      Vector2(min, max) metres from the centreline  default (12, 80)
##   scale     Vector2(min, max) uniform scale               default (1, 1)
##   collision "none" | "trunk" | "hull" | "sphere"          default "none"
##   radius    trunk/sphere radius in model units            default 0.1
##   canopy    Vector2(bottom as share of height, radius in model units): kept
##             clear of raised road                          optional
##   dynamic   true: a loose body the ball can knock about   default false
##   mass      kg for dynamic props                          default 4
##   min_height / max_height  ground heights allowed         default ±INF
##   spacing   minimum metres to other props of this kind    default 3
##   sink      metres pushed into the ground                 default 0
##   bounce    0..1                                          default 0.35
##   fade      metres beyond which this kind isn't drawn     default FAR_FADE
##             (150 for anything under Plants/; placements: always drawn)
##   snow      true: snow settles on its upward faces (winter trees)
##   shadows   cast shadows                                  default: only kinds
##             placed within 30 m of the track, and not small Plants/ (far
##             ones and small plants cost much, show little)
##   chunk     metres square drawn as one batch                default CHUNK
##             (scenery far off: bigger, so fewer, batches)
## Explicit placements use the same keys plus "at": Vector2(distance along
## the track, sideways offset; positive is right), and optional "yaw" (degrees)
## and "scale" (a single number). "on_ground": false with "y" places it at that
## height instead of on the terrain (things floating in the sea).
##
## Static props are drawn with one MultiMesh per kind and area (CHUNK metres
## square): a forest costs a few draw calls, distant areas use the models'
## lower-detail versions, and areas out of view or beyond "fade" are skipped.

@export var track: TrackBuilder
@export var terrain: Terrain
@export var seed := 1
## Racing line kept clear on open-ground stretches (half width).
@export_range(0.0, 30.0, 0.1, "suffix:m") var ground_lane := 4.5
## Height above built road kept clear for the ball and camera.
@export_range(0.0, 30.0, 0.1, "suffix:m") var headroom := 5.0

var kinds: Array[Dictionary] = []
var placements: Array[Dictionary] = []

var _rng := RandomNumberGenerator.new()
var _mesh_cache := {}
var _points_cache := {}
var _snow_cache := {}
const SNOW_SHADER := preload("res://Assets/Materials/snow_cover.gdshader")
var _frame_buckets := {}
const BUCKET := 12.0
const CHUNK := 60.0
## Scattered scenery further than this from the camera isn't drawn (fog and
## the hills hide it by then).
const FAR_FADE := 300.0

## Stretches of the track kept clear of scattered props: (from distance, to
## distance, half width in metres), e.g. around a wreck the track runs through.
@export var clear_spans := PackedVector3Array()

var _looks := {}


## Places everything. Call after the track and terrain are built.
func build() -> void:
	_rng.seed = seed
	_index_frames()
	var placed_by_kind := {}
	for kind in placements:
		var spot: Vector3
		if kind.has("world"):
			spot = kind["world"]
		else:
			var at: Vector2 = kind["at"]
			var frame := track.world_frame_at(at.x)
			spot = frame.origin + frame.basis.x.normalized() * at.y
		if kind.get("on_ground", true):
			spot.y = terrain.height_at(spot) if terrain else spot.y
		else:
			spot.y = float(kind.get("y", spot.y))
		var yaw: float = kind.get("yaw", _rng.randf_range(0.0, 360.0))
		var sink: float = kind.get("sink", 0.0)
		var basis := Basis(Vector3.UP, deg_to_rad(yaw)).scaled(Vector3.ONE * float(kind.get("scale", 1.0)))
		_place(kind, Transform3D(basis, spot - Vector3.UP * sink), placed_by_kind)
	for kind in kinds:
		_scatter(kind, placed_by_kind)
	var snowy := {}
	for kind in kinds + placements:
		if kind.get("snow", false):
			snowy[kind["scene"]] = true
	# One group per model and look (shadows, fade-out distance), so a model
	# used both beside the track and far off on the hills is drawn the right
	# way in each place.
	for group in placed_by_kind:
		var look: Dictionary = _looks[group]
		var scene_path: String = look["scene"]
		var chunks := {}
		var size: float = look["chunk"]
		for at: Transform3D in placed_by_kind[group]:
			var key := Vector2i(floori(at.origin.x / size), floori(at.origin.z / size))
			if not chunks.has(key):
				chunks[key] = []
			chunks[key].append(at)
		for key in chunks:
			var transforms: Array = chunks[key]
			var multimesh := MultiMesh.new()
			multimesh.transform_format = MultiMesh.TRANSFORM_3D
			multimesh.mesh = _snowy_mesh(scene_path) if snowy.get(scene_path, false) else _merged_mesh(scene_path)
			multimesh.instance_count = transforms.size()
			for i in transforms.size():
				multimesh.set_instance_transform(i, transforms[i])
			var view := MultiMeshInstance3D.new()
			view.name = "Props_%s_%d_%d" % [String(scene_path).get_file().get_basename(), key.x, key.y]
			view.multimesh = multimesh
			# A batch picks its lower-detail version as if its copies were
			# drawn at their model's size; they're scaled, so how far each
			# version strays from the model has to be scaled too (by the
			# biggest copy's), or a tree three times life size would turn
			# coarse three times too close.
			var biggest := 0.0
			for at: Transform3D in transforms:
				biggest = maxf(biggest, at.basis.get_scale().x)
			view.lod_bias = maxf(biggest, 0.01)
			if not look["shadows"]:
				view.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			if look["fade"] > 0.0:
				view.visibility_range_end = look["fade"]
				view.visibility_range_end_margin = 20.0
				view.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_DISABLED
			add_child(view)


func _scatter(kind: Dictionary, placed_by_kind: Dictionary) -> void:
	# Spots are drawn beside the main road (so a level's scenery doesn't
	# reshuffle when a route is added); they are kept clear of every road.
	var path := track.path
	if path.frames.is_empty():
		return
	var band: Vector2 = kind.get("band", Vector2(12.0, 80.0))
	var scale_range: Vector2 = kind.get("scale", Vector2.ONE)
	var spacing: float = kind.get("spacing", 3.0)
	var spots: Array[Vector3] = []
	var wanted: int = kind["count"]
	var tries := wanted * 25
	while spots.size() < wanted and tries > 0:
		tries -= 1
		var frame := track.global_transform * path.frames[_rng.randi_range(0, path.frames.size() - 1)]
		var side := 1.0 if _rng.randf() < 0.5 else -1.0
		var flat_right := Vector3(frame.basis.x.x, 0.0, frame.basis.x.z).normalized()
		var flat_forward := Vector3(-frame.basis.z.x, 0.0, -frame.basis.z.z).normalized()
		var spot := frame.origin + flat_right * side * _rng.randf_range(band.x, band.y) + flat_forward * _rng.randf_range(-6.0, 6.0)
		if terrain and not terrain.is_drawn(spot, 6.0):
			continue
		spot.y = terrain.height_at(spot) if terrain else 0.0
		if spot.y < kind.get("min_height", -INF) or spot.y > kind.get("max_height", INF):
			continue
		var s := _rng.randf_range(scale_range.x, scale_range.y)
		if not _clear_of_track(kind, spot, s) or _in_clear_span(spot):
			continue
		var crowded := false
		for other in spots:
			if Vector2(other.x - spot.x, other.z - spot.z).length() < spacing:
				crowded = true
				break
		if crowded:
			continue
		spots.append(spot)
		var basis := Basis(Vector3.UP, _rng.randf_range(0.0, TAU)).scaled(Vector3.ONE * s)
		var sink: float = kind.get("sink", 0.0)
		_place(kind, Transform3D(basis, spot - Vector3.UP * sink), placed_by_kind)


func _in_clear_span(spot: Vector3) -> bool:
	for span in clear_spans:
		var d := span.x
		while d <= span.y:
			var at := track.world_frame_at(d).origin
			if Vector2(at.x - spot.x, at.z - spot.z).length() < span.z:
				return true
			d += 3.0
	return false


## Whether a prop of [param kind] at [param spot] with scale [param s] stays off
## the racing lane of open-ground stretches and out of raised road.
func _clear_of_track(kind: Dictionary, spot: Vector3, s: float) -> bool:
	var size := _model_size(kind["scene"]) * s
	var model_radius: float = kind.get("radius", 0.1)
	var radius: float = maxf(model_radius * s, minf(size.x, size.z) * 0.15)
	var canopy: Vector2 = kind.get("canopy", Vector2(1.0, 0.0))
	var canopy_bottom := spot.y + size.y * canopy.x
	var canopy_radius: float = canopy.y * s
	var road_half := track.road_width * 0.5 + track.lip_width + track.rim_width
	var path := track.network
	for i in _nearby_frames(spot, maxf(radius, canopy_radius) + road_half + 10.0):
		var at := track.to_global(path.frames[i].origin)
		var d := Vector2(at.x - spot.x, at.z - spot.z).length()
		if not path.paved[i]:
			if d < ground_lane + radius:
				return false
			continue
		var road_low := at.y - track.thickness - 1.0
		var road_high := at.y + headroom
		# Trunk or body against the road block.
		if d < road_half + radius + 0.5 and spot.y + size.y > road_low and spot.y < road_high:
			return false
		# Canopy over or beside the road.
		if canopy_radius > 0.0 and d < road_half + canopy_radius and spot.y + size.y > road_low and canopy_bottom < road_high:
			return false
	return true


## How a kind is drawn: whether it casts shadows (placements and kinds near
## the track do) and how far away it fades out (plants at 150 m, scattered
## scenery at FAR_FADE, placements never, unless the kind says otherwise).
func _look_of(kind: Dictionary) -> Dictionary:
	var scene_path: String = kind["scene"]
	var placed := kind.has("at") or kind.has("world")
	var band: Vector2 = kind.get("band", Vector2(12.0, 80.0))
	var default_fade := 150.0 if "/Plants/" in scene_path else (0.0 if placed else FAR_FADE)
	# Small plants beside the track would cost a shadow pass for shadows you
	# hardly see; trees, rocks and props near the track keep theirs.
	var near := band.x < 30.0 and not "/Plants/" in scene_path
	return {"scene": scene_path, "shadows": bool(kind.get("shadows", placed or near)),
		"fade": float(kind.get("fade", default_fade)), "chunk": float(kind.get("chunk", CHUNK))}


func _place(kind: Dictionary, at: Transform3D, placed_by_kind: Dictionary) -> void:
	var scene_path: String = kind["scene"]
	var collision: String = kind.get("collision", "none")
	var s := at.basis.get_scale().x
	if kind.get("dynamic", false):
		var body := RigidBody3D.new()
		body.mass = kind.get("mass", 4.0)
		body.physics_material_override = _surface(kind)
		body.transform = at.orthonormalized()
		var view: Node3D = load(scene_path).instantiate()
		view.scale = Vector3.ONE * s
		body.add_child(view)
		var holder := CollisionShape3D.new()
		holder.shape = _hull(scene_path)
		holder.scale = Vector3.ONE * s
		body.add_child(holder)
		body.can_sleep = true
		body.sleeping = true
		add_child(body)
		return
	var look := _look_of(kind)
	var group := "%s|%s|%d|%d" % [scene_path, look["shadows"], int(look["fade"]), int(look["chunk"])]
	_looks[group] = look
	if not placed_by_kind.has(group):
		placed_by_kind[group] = []
	placed_by_kind[group].append(at)
	if collision == "none":
		return
	var holder := CollisionShape3D.new()
	var size := _model_size(scene_path)
	match collision:
		"trunk":
			var cylinder := CylinderShape3D.new()
			var trunk: float = kind.get("radius", 0.1)
			cylinder.radius = trunk * s
			cylinder.height = size.y * s
			holder.shape = cylinder
			holder.position = Vector3.UP * size.y * s * 0.5
		"sphere":
			var sphere := SphereShape3D.new()
			var round_radius: float = kind.get("radius", 0.5)
			sphere.radius = round_radius * s
			holder.shape = sphere
			holder.position = Vector3.UP * sphere.radius
		_:
			holder.shape = _hull(scene_path)
			holder.scale = Vector3.ONE * s
	var body := StaticBody3D.new()
	body.physics_material_override = _surface(kind)
	body.transform = Transform3D(at.basis.orthonormalized(), at.origin)
	body.add_child(holder)
	add_child(body)


## The model with every surface's material swapped for the snow-cover shader
## (same texture and colour, plus snow on top).
func _snowy_mesh(scene_path: String) -> Mesh:
	if _snow_cache.has(scene_path):
		return _snow_cache[scene_path]
	var source := _merged_mesh(scene_path)
	var mesh: Mesh = source.duplicate()
	for surface in mesh.get_surface_count():
		var original := source.surface_get_material(surface)
		var snow := ShaderMaterial.new()
		snow.shader = SNOW_SHADER
		if original is BaseMaterial3D:
			var base := original as BaseMaterial3D
			snow.set_shader_parameter("albedo_color", base.albedo_color)
			snow.set_shader_parameter("use_texture", base.albedo_texture != null)
			if base.albedo_texture:
				snow.set_shader_parameter("albedo_texture", base.albedo_texture)
			snow.set_shader_parameter("alpha_scissor", base.alpha_scissor_threshold if base.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR else 0.0)
		mesh.surface_set_material(surface, snow)
	_snow_cache[scene_path] = mesh
	return mesh


func _surface(kind: Dictionary) -> PhysicsMaterial:
	var surface := PhysicsMaterial.new()
	surface.bounce = kind.get("bounce", 0.35)
	surface.friction = 0.6
	return surface


## All meshes of a model merged into one (each surface keeps its material).
## A model that is a single mesh placed untransformed (however deep in the
## scene: imported models sit under a RootNode) is used as imported, so it
## keeps the lower-detail versions Godot made for distance.
func _merged_mesh(scene_path: String) -> Mesh:
	if _mesh_cache.has(scene_path):
		return _mesh_cache[scene_path]
	var root: Node3D = load(scene_path).instantiate()
	var parts := root.find_children("*", "MeshInstance3D", true, false)
	if parts.size() == 1 and _to_root(parts[0], root).is_equal_approx(Transform3D.IDENTITY) \
			and _uses_own_materials(parts[0] as MeshInstance3D):
		var single: Mesh = (parts[0] as MeshInstance3D).mesh
		root.free()
		_mesh_cache[scene_path] = single
		return single
	var merged := ArrayMesh.new()
	for node in root.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := node as MeshInstance3D
		var to_root := _to_root(mesh_instance, root)
		for surface in mesh_instance.mesh.get_surface_count():
			var tool := SurfaceTool.new()
			tool.append_from(mesh_instance.mesh, surface, to_root)
			tool.commit(merged)
			merged.surface_set_material(merged.get_surface_count() - 1, mesh_instance.get_active_material(surface))
	root.free()
	_mesh_cache[scene_path] = merged
	return merged


## Where [param node] sits in [param root]'s space.
static func _to_root(node: Node, root: Node) -> Transform3D:
	var to_root := Transform3D.IDENTITY
	var walk: Node = node
	while walk != root and walk is Node3D:
		to_root = (walk as Node3D).transform * to_root
		walk = walk.get_parent()
	return to_root


## Whether [param part] draws with its mesh's own materials (nothing overridden).
static func _uses_own_materials(part: MeshInstance3D) -> bool:
	if part.material_override:
		return false
	for i in part.get_surface_override_material_count():
		if part.get_surface_override_material(i):
			return false
	return true


func _model_size(scene_path: String) -> Vector3:
	var points := _points(scene_path)
	if points.is_empty():
		return Vector3.ONE
	var box := AABB(points[0], Vector3.ZERO)
	for p in points:
		box = box.expand(p)
	return box.size


func _hull(scene_path: String) -> ConvexPolygonShape3D:
	var shape := ConvexPolygonShape3D.new()
	shape.points = _points(scene_path)
	return shape


## Every vertex of a model in its root's space. Read from the imported meshes,
## which keep their geometry even where the renderer doesn't (headless runs).
func _points(scene_path: String) -> PackedVector3Array:
	if _points_cache.has(scene_path):
		return _points_cache[scene_path]
	var root: Node3D = load(scene_path).instantiate()
	var points := PackedVector3Array()
	for node in root.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := node as MeshInstance3D
		var to_root := _to_root(mesh_instance, root)
		for surface in mesh_instance.mesh.get_surface_count():
			for v in mesh_instance.mesh.surface_get_arrays(surface)[Mesh.ARRAY_VERTEX]:
				points.append(to_root * v)
	root.free()
	_points_cache[scene_path] = points
	return points


func _index_frames() -> void:
	_frame_buckets.clear()
	var path := track.network
	for i in path.frames.size():
		var at := track.to_global(path.frames[i].origin)
		var key := Vector2i(floori(at.x / BUCKET), floori(at.z / BUCKET))
		if not _frame_buckets.has(key):
			_frame_buckets[key] = PackedInt32Array()
		_frame_buckets[key].append(i)


func _nearby_frames(spot: Vector3, radius: float) -> PackedInt32Array:
	var found := PackedInt32Array()
	var reach := ceili(radius / BUCKET)
	var centre := Vector2i(floori(spot.x / BUCKET), floori(spot.z / BUCKET))
	for dz in range(-reach, reach + 1):
		for dx in range(-reach, reach + 1):
			var key := centre + Vector2i(dx, dz)
			if _frame_buckets.has(key):
				found.append_array(_frame_buckets[key])
	return found
