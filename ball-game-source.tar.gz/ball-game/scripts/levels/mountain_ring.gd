class_name MountainRing
extends MeshInstance3D
## A ring of mountain ranges on the horizon, far beyond the playable area, so
## the world doesn't end in an empty plain. Scenery only (no collision); the
## level's fog blends it into the sky.

## Centred on this terrain's middle (or on this node when unset).
@export var terrain: Terrain
@export var radius := 1500.0
@export_range(10.0, 3000.0, 1.0, "suffix:m") var depth := 700.0
@export var base_height := -40.0
@export var peak_min := 180.0
@export var peak_max := 520.0
@export var seed := 3
@export var low_color := Color(0.25, 0.32, 0.24)
@export var high_color := Color(0.42, 0.45, 0.48)
## Peaks above this share of the range's height are capped with snow (1: none).
@export_range(0.0, 1.0, 0.01) var snow_line := 1.0
@export var snow_color := Color(0.95, 0.97, 1.0)
@export var segments := 360
## Surface of the ranges (a large-scale triplanar rock works well); without one
## the colours above are used.
@export var material: Material


func _ready() -> void:
	if terrain:
		if terrain.heights.is_empty():
			await get_tree().process_frame
		global_position = Vector3(terrain.origin.x + (terrain.columns - 1) * terrain.cell * 0.5, 0.0,
			terrain.origin.z + (terrain.rows - 1) * terrain.cell * 0.5)
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var noise := FastNoiseLite.new()
	noise.seed = seed
	noise.frequency = 0.012
	noise.fractal_type = FastNoiseLite.FRACTAL_RIDGED
	noise.fractal_octaves = 4
	# Rows from the front foot to the back foot of the range.
	var rows := [[0.0, 0.0], [0.18, 0.35], [0.38, 0.8], [0.5, 1.0], [0.68, 0.7], [1.0, 0.0]]
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var grid := []
	for i in segments + 1:
		var angle := TAU * float(i % segments) / segments
		var direction := Vector3(cos(angle), 0.0, sin(angle))
		var peak := lerpf(peak_min, peak_max, clampf(noise.get_noise_1d(float(i % segments)) * 0.5 + 0.5, 0.0, 1.0))
		var column := []
		for r in rows.size():
			var reach: float = rows[r][0]
			var share: float = rows[r][1]
			var wobble := noise.get_noise_2d(float(i % segments), r * 17.0) * 0.25
			var height := base_height + peak * clampf(share + wobble * share, 0.0, 1.2)
			column.append(direction * (radius + depth * reach) + Vector3.UP * height)
		grid.append(column)
	for i in segments:
		for r in rows.size() - 1:
			var quad := [grid[i][r], grid[i + 1][r], grid[i + 1][r + 1], grid[i][r + 1]]
			for k in [0, 2, 1, 0, 3, 2]:
				var p: Vector3 = quad[k]
				var t := clampf((p.y - base_height) / peak_max, 0.0, 1.0)
				var color := low_color.lerp(high_color, t)
				if t > snow_line:
					color = snow_color
				tool.set_color(color)
				tool.add_vertex(p)
	tool.generate_normals()
	var surface := material
	if surface == null:
		var plain := StandardMaterial3D.new()
		plain.vertex_color_use_as_albedo = true
		plain.roughness = 1.0
		plain.cull_mode = BaseMaterial3D.CULL_DISABLED
		surface = plain
	var built := tool.commit()
	built.surface_set_material(0, surface)
	mesh = built
