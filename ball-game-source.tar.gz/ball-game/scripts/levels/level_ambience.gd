class_name LevelAmbience
extends Node
## A level's background sound: one looping bed, plus occasional one-shots
## (a gull, a sleigh bell) at random intervals. Keeps playing while paused.

@export var bed: AudioStream
@export_range(-60.0, 12.0, 0.5, "suffix:dB") var bed_volume_db := -6.0
@export var one_shots: Array[AudioStream] = []
@export_range(-60.0, 12.0, 0.5, "suffix:dB") var one_shot_volume_db := -10.0
@export var interval := Vector2(9.0, 20.0)

var _bed_player: AudioStreamPlayer
var _shot_player: AudioStreamPlayer
var _until_next := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if bed:
		if "loop" in bed:
			bed.loop = true
		_bed_player = AudioStreamPlayer.new()
		_bed_player.stream = bed
		_bed_player.volume_db = bed_volume_db
		add_child(_bed_player)
		_bed_player.play()
	_shot_player = AudioStreamPlayer.new()
	_shot_player.volume_db = one_shot_volume_db
	add_child(_shot_player)
	_until_next = randf_range(interval.x, interval.y) * 0.5


func _process(delta: float) -> void:
	if one_shots.is_empty():
		return
	_until_next -= delta
	if _until_next <= 0.0:
		_until_next = randf_range(interval.x, interval.y)
		_shot_player.stream = one_shots.pick_random()
		_shot_player.pitch_scale = randf_range(0.95, 1.05)
		_shot_player.play()
