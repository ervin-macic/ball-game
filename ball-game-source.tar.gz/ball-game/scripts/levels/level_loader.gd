class_name LevelLoader
extends Node
## Puts one level at a time into the game: downloads its pack when a web build
## needs one, swaps the scene in, hands its track to the race and dresses the
## ball. Remembers the last level played.

signal loading(id: String, progress: float)
signal changed(level: Level)
signal failed(id: String, message: String)

const STORE_KEY := "level.json"
const WEB_HOST_INTERFACE := "ballGameAssets"

@export var race: RaceManager
@export var ball: RollingBall
## Where the level scene goes.
@export var slot: Node3D
## Turn off to keep from remembering the level (tests).
@export var persist := true

var level: Level
var level_id := ""
var busy := false
## While a party runs, only its level may be loaded (the menu's picker can't
## take a player away from the others).
var party_level := ""

var _default_ball_material: Material
var _ball_mesh: MeshInstance3D
## Covers the game while a level downloads and builds.
var screen: LoadingScreen


func _ready() -> void:
	screen = LoadingScreen.new()
	screen.name = "LoadingScreen"
	add_child(screen)
	var meshes := ball.find_children("*", "MeshInstance3D", true, false)
	_ball_mesh = meshes[0] if not meshes.is_empty() else null
	if _ball_mesh:
		_default_ball_material = _ball_mesh.material_override
	var saved: Variant = GameStore.read(STORE_KEY) if persist else null
	var wanted: String = saved.get("id", "") if saved is Dictionary else ""
	# The built-in level loads at once so the game always starts on a track;
	# a remembered level that needs a download follows it.
	_install(LevelCatalog.DEFAULT_ID)
	if not wanted.is_empty() and wanted != LevelCatalog.DEFAULT_ID and not LevelCatalog.find(wanted).is_empty():
		load_level(wanted)


## Switches to level [param id], downloading its pack first if needed.
func load_level(id: String) -> void:
	var entry := LevelCatalog.find(id)
	if entry.is_empty() or busy or (not party_level.is_empty() and id != party_level):
		return
	if id == level_id:
		# Already here (and its pack mounted): just build it afresh.
		_install(id)
		return
	busy = true
	screen.open(entry)
	loading.emit(id, 0.0)
	var message := await _ensure_pack(entry)
	if message.is_empty() and not ResourceLoader.exists(entry["scene"]):
		message = "This level isn't part of this build."
	if not message.is_empty():
		busy = false
		screen.set_failed(message)
		failed.emit(id, message)
		return
	# Building runs in one go: put "Building…" on screen before it starts.
	screen.set_building()
	await screen.wait_until_drawn()
	_install(id)
	await _prewarm(level)
	busy = false
	await get_tree().process_frame
	screen.close()


func _install(id: String) -> void:
	var entry := LevelCatalog.find(id)
	var scene: PackedScene = load(entry["scene"])
	var next: Level = scene.instantiate()
	if level:
		slot.remove_child(level)
		level.queue_free()
	level = next
	level_id = id
	slot.add_child(level)
	race.use_level(level)
	level.bind_race(race)
	if _ball_mesh:
		_ball_mesh.material_override = level.ball_material if level.ball_material else _default_ball_material
	if persist:
		GameStore.write(STORE_KEY, {"id": id})
	changed.emit(level)


## Draws everything in [param root] once, behind the loading screen, so its
## shaders are compiled and its textures uploaded now rather than with a
## stutter the first time each thing comes into view mid-run (on the web, the
## first sight of a new material stalls a frame for as long as compiling takes).
## Everything is made visible from anywhere for a couple of frames, then put back.
func _prewarm(root: Node) -> void:
	if DisplayServer.get_name() == "headless":
		return
	# Hold the level still meanwhile, so nothing hides itself again (the wave does).
	var mode := root.process_mode
	root.process_mode = Node.PROCESS_MODE_DISABLED
	var restore: Array = []
	for node in root.find_children("*", "Node3D", true, false):
		var node3d := node as Node3D
		var saved := {"node": node3d, "visible": node3d.visible}
		node3d.visible = true
		if node3d is GeometryInstance3D:
			var geometry := node3d as GeometryInstance3D
			saved["margin"] = geometry.extra_cull_margin
			saved["range_end"] = geometry.visibility_range_end
			geometry.extra_cull_margin = 16384.0
			geometry.visibility_range_end = 0.0
		restore.append(saved)
	await screen.wait_until_drawn()
	for saved: Dictionary in restore:
		var node3d: Node3D = saved["node"]
		if not is_instance_valid(node3d):
			continue
		node3d.visible = saved["visible"]
		if saved.has("margin"):
			(node3d as GeometryInstance3D).extra_cull_margin = saved["margin"]
			(node3d as GeometryInstance3D).visibility_range_end = saved["range_end"]
	root.process_mode = mode


## Mounts a level's resource pack on the web, asking the host page to download
## it first (it reports progress). Returns "" when the level's scene can load,
## or a message for the player.
func _ensure_pack(entry: Dictionary) -> String:
	if ResourceLoader.exists(entry["scene"]) or entry["pack"].is_empty():
		return ""
	var host: Variant = JavaScriptBridge.get_interface(WEB_HOST_INTERFACE) if OS.has_feature("web") else null
	if host == null:
		return "This level needs a download that only the web version provides."
	var pack: String = entry["pack"]
	host.fetch_pack(pack)
	var state := {}
	while true:
		var parsed: Variant = JSON.parse_string(str(host.pack_state(pack)))
		state = parsed if parsed is Dictionary else {"status": "error", "message": "The level download failed."}
		if state.get("status") != "loading":
			break
		var total := float(state.get("total", 0))
		if total > 0.0:
			var share := float(state.get("received", 0)) / total
			screen.set_download(share)
			loading.emit(entry["id"], share)
		await get_tree().process_frame
	if state.get("status") != "ready":
		return str(state.get("message", "The level download failed. Check your connection and try again."))
	if not ProjectSettings.load_resource_pack(str(state["path"])):
		return "The level download was damaged. Try again."
	loading.emit(entry["id"], 1.0)
	return ""
