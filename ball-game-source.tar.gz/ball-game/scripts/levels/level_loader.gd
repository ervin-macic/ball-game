class_name LevelLoader
extends Node
## Puts one level at a time into the game: downloads its pack when a web build
## needs one, swaps the scene in, hands its track to the race and dresses the
## ball. Remembers the last level played.

signal loading(id: String, progress: float)
signal changed(level: Level)
signal failed(id: String, message: String)

const STORE_KEY := "level.json"
const WEB_HOST_INTERFACE := "ballGameAssets"
## The host page's own bridge (index.jsx): takes the loading report.
const PAGE_INTERFACE := "ballGameHost"
## Drawn this far off on every side while graphics are prepared, so nothing is
## culled away (see _prepare_graphics).
const EVERYWHERE := 16384.0

@export var race: RaceManager
@export var ball: RollingBall
## Where the level scene goes.
@export var slot: Node3D
## The ghost of the best run: drawn once while a level loads (see
## _prepare_graphics), as it only appears from the second run on.
@export var ghost: GhostBall
## Turn off to keep from remembering the level (tests).
@export var persist := true
## The level the game opens on. Empty: the one played last time (with
## persist), or the tutorial.
@export var first_level := ""

var level: Level
var level_id := ""
var busy := false
## While a party runs, only its level may be loaded (the menu's picker can't
## take a player away from the others).
var party_level := ""

var _default_ball_material: Material
var _ball_mesh: MeshInstance3D
var _shader_keys := {}
## Covers the game while a level downloads and builds.
var screen: LoadingScreen


func _ready() -> void:
	screen = LoadingScreen.new()
	screen.name = "LoadingScreen"
	add_child(screen)
	var meshes := ball.find_children("*", "MeshInstance3D", true, false)
	_ball_mesh = meshes[0] if not meshes.is_empty() else null
	if _ball_mesh:
		_default_ball_material = _ball_mesh.material_override
	var saved: Variant = GameStore.read(STORE_KEY) if persist and first_level.is_empty() else null
	var wanted: String = first_level if not first_level.is_empty() else (saved.get("id", "") if saved is Dictionary else "")
	if not wanted.is_empty() and wanted != LevelCatalog.DEFAULT_ID and not LevelCatalog.find(wanted).is_empty():
		# Straight to the level played last time: building the tutorial first
		# only added its graphics to the wait. It's the fallback if that level
		# can't load (load_level).
		load_level(wanted)
	else:
		_install(LevelCatalog.DEFAULT_ID)


## Switches to level [param id], downloading its pack first if needed.
func load_level(id: String) -> void:
	var entry := LevelCatalog.find(id)
	if entry.is_empty() or busy or (not party_level.is_empty() and id != party_level):
		return
	if id == level_id:
		# Already here (and its pack mounted): just build it afresh.
		_install(id)
		return
	busy = true
	var started := Time.get_ticks_msec()
	screen.open(entry)
	loading.emit(id, 0.0)
	var message := await _ensure_pack(entry)
	if message.is_empty() and not ResourceLoader.exists(entry["scene"]):
		message = "This level isn't part of this build."
	if not message.is_empty():
		busy = false
		screen.set_failed(message)
		failed.emit(id, message)
		if level == null:
			# Nothing to play yet (the game started on this level): the
			# tutorial is always there.
			_install(LevelCatalog.DEFAULT_ID)
		return
	var downloaded := Time.get_ticks_msec()
	# Building runs in one go: put "Building…" on screen before it starts.
	screen.set_building()
	await screen.wait_until_drawn()
	var build_started := Time.get_ticks_msec()
	_install(id)
	var built := Time.get_ticks_msec()
	var steps := await _prepare_graphics(level)
	var prepared := Time.get_ticks_msec()
	busy = false
	await get_tree().process_frame
	screen.close()
	_report({"level": id, "seconds": _seconds(prepared - started), "download": _seconds(downloaded - started),
		"build": _seconds(built - build_started), "graphics": _seconds(prepared - built), "steps": steps})


func _install(id: String) -> void:
	var entry := LevelCatalog.find(id)
	var scene: PackedScene = load(entry["scene"])
	var next: Level = scene.instantiate()
	if level:
		slot.remove_child(level)
		level.queue_free()
	level = next
	level_id = id
	slot.add_child(level)
	race.use_level(level)
	level.bind_race(race)
	if _ball_mesh:
		_ball_mesh.material_override = level.ball_material if level.ball_material else _default_ball_material
	if persist:
		GameStore.write(STORE_KEY, {"id": id})
	changed.emit(level)


## Draws everything in [param root] behind the loading screen, so its graphics
## are compiled and uploaded now rather than with a stall the first time each
## thing comes into view mid-run. A browser compiles each graphics program in
## one go on the page's only thread (a third of a second or more on Windows),
## so things are drawn a look at a time on separate frames, and the screen
## counts them off instead of freezing. Returns how many steps it took.
func _prepare_graphics(root: Node) -> int:
	if DisplayServer.get_name() == "headless":
		return 0
	# Hold the level still meanwhile, so nothing hides itself again (the wave
	# does). Its particles do run, or there'd be nothing of them to draw.
	# That also takes its ground out of the physics world, so the ball is held
	# too, with its controls (the clock can't start behind the screen), and put
	# back on the start line afterwards.
	var mode := root.process_mode
	root.process_mode = Node.PROCESS_MODE_DISABLED
	var ball_was := [ball.freeze, ball.locked]
	ball.freeze = true
	ball.locked = true
	var shown: Array = []
	var drawn: Array = []
	var emitters: Array = []
	var looks := {}
	# Particles come last: they need a few frames to have any in the air.
	var particle_looks := {}
	for node in root.find_children("*", "Node3D", true, false):
		var node3d := node as Node3D
		shown.append([node3d, node3d.visible])
		node3d.visible = true
		var geometry := node3d as GeometryInstance3D
		if geometry == null:
			continue
		drawn.append([geometry, geometry.extra_cull_margin, geometry.visibility_range_begin, geometry.visibility_range_end])
		geometry.extra_cull_margin = EVERYWHERE
		geometry.visibility_range_begin = 0.0
		geometry.visibility_range_end = 0.0
		var particles := geometry as CPUParticles3D
		if particles:
			emitters.append([particles, particles.process_mode, particles.emitting, particles.one_shot])
			particles.process_mode = Node.PROCESS_MODE_ALWAYS
			particles.one_shot = false
			particles.emitting = true
		_add_look(particle_looks if particles else looks, geometry)
	# The ghost (from the second run on) and the finish's confetti are drawn
	# too, out in front of the start.
	for extra in _extras():
		extra.extra_cull_margin = EVERYWHERE
		_add_look(particle_looks, extra)
	for look in particle_looks:
		looks["particles " + look] = particle_looks[look]
	# Everything starts hidden from the renderer; each look is shown for one
	# frame. (Straight to the renderer: hiding a node would hide its children.)
	for list: Array in looks.values():
		_show_to_renderer(list, false)
	var step := 0
	for list: Array in looks.values():
		_show_to_renderer(list, true)
		await RenderingServer.frame_post_draw
		_show_to_renderer(list, false)
		step += 1
		screen.set_preparing(float(step) / looks.size())
	for entry: Array in shown:
		if is_instance_valid(entry[0]):
			(entry[0] as Node3D).visible = entry[1]
	for entry: Array in emitters:
		if is_instance_valid(entry[0]):
			var particles: CPUParticles3D = entry[0]
			particles.process_mode = entry[1]
			particles.one_shot = entry[3]
			particles.emitting = entry[2]
	for entry: Array in drawn:
		if not is_instance_valid(entry[0]):
			continue
		var geometry: GeometryInstance3D = entry[0]
		geometry.extra_cull_margin = entry[1]
		geometry.visibility_range_begin = entry[2]
		geometry.visibility_range_end = entry[3]
		RenderingServer.instance_set_visible(geometry.get_instance(), geometry.is_visible_in_tree())
	root.process_mode = mode
	ball.freeze = ball_was[0]
	ball.locked = ball_was[1]
	race.restart()
	for list: Array in looks.values():
		for item: Variant in list:
			if is_instance_valid(item) and (item as Node).has_meta("warm_up_extra"):
				(item as Node).queue_free()
	return step


## Shows or hides [param list]'s geometry to the renderer only (some may have
## gone meanwhile, like a burst of confetti that ran its course).
static func _show_to_renderer(list: Array, shown: bool) -> void:
	for item: Variant in list:
		if is_instance_valid(item):
			RenderingServer.instance_set_visible((item as GeometryInstance3D).get_instance(), shown)


func _add_look(looks: Dictionary, geometry: GeometryInstance3D) -> void:
	var look := _look_of(geometry)
	if not looks.has(look):
		looks[look] = []
	looks[look].append(geometry)


## Stand-ins for things that only show up later in a run, placed in front of
## the start: the ghost, and a little of the finish line's confetti.
func _extras() -> Array[GeometryInstance3D]:
	var extras: Array[GeometryInstance3D] = []
	var start := race.track.spawn_marker.global_transform
	var ahead := start.origin - start.basis.z.normalized() * 4.0 + Vector3.UP
	if ghost and ghost.mesh:
		var copy := MeshInstance3D.new()
		copy.mesh = ghost.mesh
		copy.material_override = ghost.material_override
		copy.cast_shadow = ghost.cast_shadow
		extras.append(copy)
	var confetti := race.track.finish_line.confetti_sample()
	extras.append(confetti)
	for extra in extras:
		extra.set_meta("warm_up_extra", true)
		slot.add_child(extra)
		extra.global_position = ahead
	return extras


## What a piece of geometry is drawn with, as far as compiling goes: the
## shaders of its materials (a material's switches decide its shader, its
## values don't), whether it's drawn as many copies at once, and whether it
## casts shadows.
func _look_of(geometry: GeometryInstance3D) -> String:
	var keys := PackedStringArray()
	for material in _materials_of(geometry):
		keys.append(_shader_key(material))
	keys.sort()
	var many := geometry is MultiMeshInstance3D or geometry is CPUParticles3D or geometry is GPUParticles3D
	var shadows := geometry.cast_shadow != GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return "%s|%s|%s" % [",".join(keys), many, shadows]


static func _materials_of(geometry: GeometryInstance3D) -> Array[Material]:
	var found: Array[Material] = []
	if geometry.material_override:
		found.append(geometry.material_override)
		return found
	var mesh: Mesh = null
	if geometry is MeshInstance3D:
		mesh = (geometry as MeshInstance3D).mesh
		for i in (geometry as MeshInstance3D).get_surface_override_material_count():
			var material := (geometry as MeshInstance3D).get_surface_override_material(i)
			if material:
				found.append(material)
	elif geometry is MultiMeshInstance3D and (geometry as MultiMeshInstance3D).multimesh:
		mesh = (geometry as MultiMeshInstance3D).multimesh.mesh
	elif geometry is CPUParticles3D:
		mesh = (geometry as CPUParticles3D).mesh
	elif geometry is CSGShape3D and geometry.get("material"):
		found.append(geometry.get("material"))
	if mesh and found.is_empty():
		for i in mesh.get_surface_count():
			if mesh.surface_get_material(i):
				found.append(mesh.surface_get_material(i))
	return found


func _shader_key(material: Material) -> String:
	var id := material.get_instance_id()
	if _shader_keys.has(id):
		return _shader_keys[id]
	var key := ""
	if material is ShaderMaterial:
		var shader := (material as ShaderMaterial).shader
		key = "shader %d" % (shader.get_instance_id() if shader else 0)
	else:
		var parts := PackedStringArray([material.get_class()])
		for property in material.get_property_list():
			var type: int = property["type"]
			if property["usage"] & PROPERTY_USAGE_STORAGE and (type == TYPE_BOOL or type == TYPE_INT):
				parts.append(str(material.get(property["name"])))
		key = " ".join(parts)
	_shader_keys[id] = key
	return key


## Tells the page how long the level took to get ready, and in which parts
## (seconds), for looking into slow loads on a player's own machine.
func _report(report: Dictionary) -> void:
	print("[ball-game] %s ready in %.1f s: download %.1f s, build %.1f s, graphics %.1f s in %d steps" % [
		report["level"], report["seconds"], report["download"], report["build"], report["graphics"], report["steps"]])
	var page: Variant = JavaScriptBridge.get_interface(PAGE_INTERFACE) if OS.has_feature("web") else null
	if page != null:
		page.level_ready(JSON.stringify(report))


static func _seconds(milliseconds: int) -> float:
	return snappedf(milliseconds / 1000.0, 0.01)


## Mounts a level's resource pack on the web, asking the host page to download
## it first (it reports progress). Returns "" when the level's scene can load,
## or a message for the player.
func _ensure_pack(entry: Dictionary) -> String:
	if ResourceLoader.exists(entry["scene"]) or entry["pack"].is_empty():
		return ""
	var host: Variant = JavaScriptBridge.get_interface(WEB_HOST_INTERFACE) if OS.has_feature("web") else null
	if host == null:
		return "This level needs a download that only the web version provides."
	var pack: String = entry["pack"]
	host.fetch_pack(pack)
	var state := {}
	while true:
		var parsed: Variant = JSON.parse_string(str(host.pack_state(pack)))
		state = parsed if parsed is Dictionary else {"status": "error", "message": "The level download failed."}
		if state.get("status") != "loading":
			break
		var total := float(state.get("total", 0))
		if total > 0.0:
			var share := float(state.get("received", 0)) / total
			screen.set_download(share)
			loading.emit(entry["id"], share)
		await get_tree().process_frame
	if state.get("status") != "ready":
		return str(state.get("message", "The level download failed. Check your connection and try again."))
	if not ProjectSettings.load_resource_pack(str(state["path"])):
		return "The level download was damaged. Try again."
	loading.emit(entry["id"], 1.0)
	return ""
