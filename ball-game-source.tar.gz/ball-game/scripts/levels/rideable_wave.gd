class_name RideableWave
extends AnimatableBody3D
## A wave that rolls in from the sea across an open-ground stretch of track,
## square to the track. Its front is a moving quarter-pipe: a concave face that
## scoops the ball up as it arrives, so a player can ride along it like a
## half-pipe (or get carried inland if they don't).
##
## It runs on the race clock while racing, so every run (and the ghost) meets
## the same waves at the same moments; between runs it keeps its own time.

@export var track: TrackBuilder
## The stretch of track the wave runs along (distances along the track).
@export var from_distance := 400.0
@export var to_distance := 480.0
## Which side of the track the sea is on: -1 left, +1 right.
@export var sea_side := -1.0
## Seconds between waves, and the offset of the first one within the cycle.
@export_range(4.0, 60.0, 0.1, "suffix:s") var period := 12.0
@export var phase := 0.0
## Where the face starts (seaward of the centreline) and where it dies (inland).
@export_range(0.0, 100.0, 0.5, "suffix:m") var start_offset := 30.0
@export_range(0.0, 100.0, 0.5, "suffix:m") var end_offset := 16.0
## Speed it rolls inland.
@export_range(0.5, 40.0, 0.1, "suffix:m/s") var speed := 6.5
## Radius of the quarter-pipe face (its height is about 0.8 of this).
@export_range(1.0, 20.0, 0.1, "suffix:m") var face_radius := 5.5
@export var water_color := Color(0.05, 0.42, 0.58)
@export var shallow_color := Color(0.22, 0.75, 0.8)
@export var foam_color := Color(0.96, 0.98, 1.0)
@export var crash_sound: AudioStream

const RISE := 1.2
const COLLAPSE := 1.2
## Steepest point of the face (degrees from flat): close to a vertical wall.
const FACE_ANGLE := 78.0

var _race: RaceManager
var _origin := Vector3.ZERO
var _along := Vector3.RIGHT
var _inland := Vector3.BACK
var _half_length := 40.0
var _idle_clock := 0.0
var _last_cycle := -1
var _spray: CPUParticles3D
var _sound: AudioStreamPlayer3D


func _ready() -> void:
	add_to_group("race_aware")
	sync_to_physics = true
	collision_layer = 1
	collision_mask = 0
	var surface := PhysicsMaterial.new()
	surface.friction = 0.35
	physics_material_override = surface


func bind_race(race: RaceManager) -> void:
	_race = race
	_build()


func _build() -> void:
	var a := track.world_frame_at(from_distance).origin
	var b := track.world_frame_at(to_distance).origin
	var chord := Vector3(b.x - a.x, 0.0, b.z - a.z)
	_along = chord.normalized()
	_half_length = chord.length() * 0.5 + 18.0
	var mid := track.world_frame_at((from_distance + to_distance) * 0.5)
	var right := Vector3(mid.basis.x.x, 0.0, mid.basis.x.z).normalized()
	_inland = -right * sea_side
	_inland = (_inland - _along * _inland.dot(_along)).normalized()
	_origin = (a + b) * 0.5
	var faces := PackedVector3Array()
	var view := MeshInstance3D.new()
	view.name = "Water"
	view.mesh = _build_mesh(faces)
	view.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(view)
	var shape := ConcavePolygonShape3D.new()
	shape.backface_collision = true
	shape.set_faces(faces)
	var holder := CollisionShape3D.new()
	holder.shape = shape
	add_child(holder)
	_spray = _make_spray()
	add_child(_spray)
	_sound = AudioStreamPlayer3D.new()
	_sound.stream = crash_sound
	_sound.unit_size = 30.0
	_sound.max_db = 6.0
	add_child(_sound)
	_place(start_offset, 0.0)


func _physics_process(delta: float) -> void:
	if _race == null:
		return
	var clock := 0.0
	if _race.state != RaceManager.State.READY:
		clock = _race.race_time
	else:
		_idle_clock += delta
		clock = _idle_clock
	var cycle := floori((clock + phase) / period)
	var t := fposmod(clock + phase, period)
	var travel := (start_offset + end_offset) / speed
	var front := start_offset
	var size := 0.0
	if t < RISE:
		size = t / RISE
	elif t < RISE + travel:
		front = start_offset - speed * (t - RISE)
		size = 1.0
	elif t < RISE + travel + COLLAPSE:
		front = -end_offset
		size = 1.0 - (t - RISE - travel) / COLLAPSE
	if cycle != _last_cycle and t >= RISE:
		_last_cycle = cycle
		if _sound.stream:
			_sound.play()
	_spray.emitting = size > 0.6
	_place(front, size)


## Front of the wave [param front] metres seaward (+) or inland (-) of the
## centreline, risen to [param size] of its full height (sunk into the sand below).
func _place(front: float, size: float) -> void:
	visible = size > 0.02
	var ground := _origin - _inland * front
	var sink := (face_radius + 1.5) * (1.0 - size)
	global_transform = Transform3D(Basis(_along, Vector3.UP, _inland), Vector3(ground.x, _origin.y - 0.15 - sink, ground.z))


## The wave in local space: x along the beach, y up, +z inland (the direction
## it rolls). From the inland foot, a concave quarter-pipe face rises to the
## lip, which curls over; behind it a long back slope runs down to the sea.
func _build_mesh(faces: PackedVector3Array) -> ArrayMesh:
	var profile := PackedVector2Array() # (z, y)
	var steps := 10
	for k in steps + 1:
		var a := deg_to_rad(FACE_ANGLE) * k / steps
		profile.append(Vector2(-face_radius * sin(a), face_radius * (1.0 - cos(a))))
	var lip := profile[profile.size() - 1]
	# Behind the lip the water falls away quickly to a shallow sheet, so a ball
	# the wave rolls over stays in sight.
	profile.append(Vector2(lip.x - 0.5, lip.y + 0.35))
	profile.append(Vector2(lip.x - 1.6, lip.y + 0.1))
	profile.append(Vector2(lip.x - 3.2, lip.y * 0.35))
	profile.append(Vector2(lip.x - 5.5, 0.35))
	profile.append(Vector2(lip.x - 11.0, -0.4))
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var columns := 36
	for i in columns:
		for j in profile.size() - 1:
			var corners: Array[Vector3] = []
			var colors: Array[Color] = []
			for c in [[i, j], [i + 1, j], [i + 1, j + 1], [i, j + 1]]:
				var x := lerpf(-_half_length, _half_length, float(c[0]) / columns)
				var taper := smoothstep(0.0, 0.2, 1.0 - absf(x) / _half_length)
				var p := profile[c[1]]
				corners.append(Vector3(x, p.y * taper + sin(x * 0.3 + p.x) * 0.08, p.x))
				var height_share := clampf(p.y / maxf(lip.y, 0.01), 0.0, 1.0)
				var color := water_color.lerp(shallow_color, height_share)
				color.a = 0.62
				if c[1] >= steps - 1 and c[1] <= steps + 2:
					color = color.lerp(foam_color, 0.9)
					color.a = 0.85
				colors.append(color)
			for k in [0, 1, 2, 0, 2, 3]:
				tool.set_color(colors[k])
				tool.add_vertex(corners[k])
				faces.append(corners[k])
	tool.generate_normals()
	var mesh := tool.commit()
	var material := StandardMaterial3D.new()
	material.vertex_color_use_as_albedo = true
	material.roughness = 0.12
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	# See-through water (foam less so), so the ball shows through the face.
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_ALWAYS
	mesh.surface_set_material(0, material)
	return mesh


func _make_spray() -> CPUParticles3D:
	var spray := CPUParticles3D.new()
	spray.amount = 320
	spray.lifetime = 1.0
	spray.local_coords = false
	spray.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	spray.emission_box_extents = Vector3(_half_length * 0.9, 0.2, 0.5)
	spray.position = Vector3(0.0, face_radius * 0.85, -face_radius * 0.95)
	spray.direction = Vector3(0, 1, 0.5)
	spray.spread = 30.0
	spray.initial_velocity_min = 2.0
	spray.initial_velocity_max = 6.0
	spray.gravity = Vector3(0, -9.8, 0)
	spray.scale_amount_min = 0.5
	spray.scale_amount_max = 1.2
	var drop := SphereMesh.new()
	drop.radius = 0.16
	drop.height = 0.32
	drop.radial_segments = 6
	drop.rings = 3
	var foam := StandardMaterial3D.new()
	foam.albedo_color = foam_color
	foam.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	drop.material = foam
	spray.mesh = drop
	spray.emitting = false
	return spray
