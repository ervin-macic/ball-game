class_name PlayerInput
extends Node
## Reads the local player's keyboard or gamepad and drives a RollingBall
## relative to where the camera is looking.

@export var ball: RollingBall
@export var camera: FollowCamera


func _physics_process(_delta: float) -> void:
	if ball == null or camera == null:
		return
	var stick := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var move := camera.get_flat_basis() * Vector3(stick.x, 0.0, stick.y)
	ball.drive(move, Input.is_action_pressed("jump"), Input.is_action_just_pressed("jump"))
