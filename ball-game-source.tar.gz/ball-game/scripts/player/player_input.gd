class_name PlayerInput
extends Node
## Reads the local player's keyboard, gamepad or touch screen and drives a
## RollingBall relative to where the camera is looking.
##
## Every device ends up as the same intent: a stick deflection (keys are all
## the way over, a gamepad's or the touch stick's analog) turned by the
## camera's heading, plus jump held and just pressed. The ball can't tell them
## apart, so it handles the same on all of them.

@export var ball: RollingBall
@export var camera: FollowCamera
## The on-screen stick and buttons (touch screens). The jump button presses
## the jump action itself.
@export var touch: TouchControls


func _physics_process(_delta: float) -> void:
	if ball == null or camera == null:
		return
	var stick := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if touch and touch.is_steering():
		stick = touch.stick
	var move := camera.get_flat_basis() * Vector3(stick.x, 0.0, stick.y)
	ball.drive(move, Input.is_action_pressed("jump"), Input.is_action_just_pressed("jump"))
