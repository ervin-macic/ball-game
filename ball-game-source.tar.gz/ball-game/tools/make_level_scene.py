#!/usr/bin/env python3
"""Writes a level scene (levels/<id>/<id>_level.tscn) from a compact spec.

Run with no arguments to regenerate every level from tools/level_specs.py.
The scene holds the track pieces, sky, sun and the environment nodes; the
level's own script (levels/<id>/<id>_level.gd) fills in terrain, props and
anything special when the level loads. Edit the spec, re-run, re-test.
"""
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
from level_specs import LEVELS  # noqa: E402

SEGMENT_SCRIPTS = {"section": "3_section", "loop": "4_loop", "gap": "5_gap", "corkscrew": "41_corkscrew"}


def sun_transform(elevation_deg: float, sky_u: float) -> str:
    """Directional light pointing from the sun's place in the panorama.

    Godot maps a direction d to panorama u = atan2(d.x, -d.z) / 2pi (wrapped),
    so the sun sits at azimuth a = 2pi * u.
    """
    a = 2 * math.pi * sky_u
    e = math.radians(elevation_deg)
    to_sun = (math.sin(a) * math.cos(e), math.sin(e), -math.cos(a) * math.cos(e))
    # The light shines along its -Z, so its Z axis points toward the sun.
    z = to_sun
    up = (0.0, 1.0, 0.0)
    x = (up[1] * z[2] - up[2] * z[1], up[2] * z[0] - up[0] * z[2], up[0] * z[1] - up[1] * z[0])
    n = math.sqrt(sum(c * c for c in x)) or 1.0
    x = tuple(c / n for c in x)
    y = (z[1] * x[2] - z[2] * x[1], z[2] * x[0] - z[0] * x[2], z[0] * x[1] - z[1] * x[0])
    f = lambda v: ", ".join(f"{c:.6f}" for c in v)
    # Transform3D(x_axis, y_axis, z_axis, origin) as columns.
    return f"Transform3D({x[0]:.6f}, {y[0]:.6f}, {z[0]:.6f}, {x[1]:.6f}, {y[1]:.6f}, {z[1]:.6f}, {x[2]:.6f}, {y[2]:.6f}, {z[2]:.6f}, 0, 60, 0)"


def value(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, str):
        return f'"{v}"'
    return repr(float(v)) if isinstance(v, float) else str(v)


def write(spec: dict) -> Path:
    lid = spec["id"]
    out = ROOT / "levels" / lid / f"{lid}_level.tscn"
    ext = [
        ("Script", f"res://levels/{lid}/{lid}_level.gd", "1_level"),
        ("Script", "res://scripts/track/track_builder.gd", "2_builder"),
        ("Script", "res://scripts/track/section_segment.gd", "3_section"),
        ("Script", "res://scripts/track/loop_segment.gd", "4_loop"),
        ("Script", "res://scripts/track/gap_segment.gd", "5_gap"),
        ("Script", "res://scripts/track/track_segment.gd", "6_segment"),
        ("Script", "res://scripts/race/finish_line.gd", "7_finish"),
        ("Texture2D", spec["sky"], "8_sky"),
        ("Script", "res://scripts/levels/terrain.gd", "9_terrain"),
        ("Script", "res://scripts/levels/track_supports.gd", "10_supports"),
        ("Script", "res://scripts/levels/prop_scatter.gd", "11_props"),
        ("Script", "res://scripts/levels/level_bounds.gd", "30_bounds"),
        ("Script", "res://scripts/levels/mountain_ring.gd", "31_mountains"),
        ("Script", "res://scripts/track/corkscrew_segment.gd", "41_corkscrew"),
        ("Script", "res://scripts/track/track_route.gd", "42_route"),
    ]
    if spec.get("ranges"):
        ext.append(("Material", spec["ranges"], "40_ranges"))
    materials = {}
    for key in ("road", "curb", "side", "wall", "slick", "ground", "supports", "ball"):
        if spec["materials"].get(key):
            rid = f"{12 + len(materials)}_{key}"
            materials[key] = rid
            kind = "ShaderMaterial" if spec["materials"][key].endswith(("curb.tres", "ground.tres", "ball.tres")) and "coconut" not in spec["materials"][key] else "Material"
            ext.append(("Material", spec["materials"][key], rid))
    # Route models ("obstacle_scene": "res://...") become external scenes too.
    scene_ids = {}
    for route in spec.get("routes", []):
        if route.get("obstacle_scene") and route["obstacle_scene"] not in scene_ids:
            rid = f"{50 + len(scene_ids)}_scene"
            scene_ids[route["obstacle_scene"]] = rid
            ext.append(("PackedScene", route["obstacle_scene"], rid))
    lines = ["[gd_scene format=3]", ""]
    for kind, path, rid in ext:
        lines.append(f'[ext_resource type="{kind}" path="{path}" id="{rid}"]')
    lines.append("")
    seg_ids = []
    for n, seg in enumerate(spec["segments"], 1):
        kind, name, props = seg[0], seg[1], seg[2] if len(seg) > 2 else {}
        sid = f"Segment_{n:02d}"
        seg_ids.append(sid)
        lines += ["", f'[sub_resource type="Resource" id="{sid}"]', f'script = ExtResource("{SEGMENT_SCRIPTS[kind]}")', f'resource_name = "{name}"']
        for k, v in props.items():
            lines.append(f"{k} = {value(v)}")
    env = spec["environment"]
    lines += ["", '[sub_resource type="PanoramaSkyMaterial" id="Sky_material"]', 'panorama = ExtResource("8_sky")', f'energy_multiplier = {env.get("sky_energy", 1.0)}',
              "", '[sub_resource type="Sky" id="Sky_main"]', 'sky_material = SubResource("Sky_material")',
              "", '[sub_resource type="Environment" id="Environment_main"]', "background_mode = 2", 'sky = SubResource("Sky_main")',
              "ambient_light_source = 3", f'ambient_light_energy = {env.get("ambient", 1.0)}', "reflected_light_source = 2", "tonemap_mode = 3",
              f'tonemap_exposure = {env.get("exposure", 1.0)}', "glow_enabled = true", "glow_intensity = 0.4", "glow_bloom = 0.02",
              "fog_enabled = true", f'fog_light_color = {env["fog_color"]}', f'fog_density = {env.get("fog_density", 0.0015)}',
              f'fog_sky_affect = {env.get("fog_sky_affect", 0.0)}']
    lines += ["", f'[node name="{spec["node"]}" type="Node3D" node_paths=PackedStringArray("track")]', 'script = ExtResource("1_level")',
              f'level_id = "{lid}"', f'title = "{spec["title"]}"', 'track = NodePath("Track")']
    if "ball" in materials:
        lines.append(f'ball_material = ExtResource("{materials["ball"]}")')
    if spec.get("fall_reset_height") is not None:
        lines.append(f'fall_reset_height = {spec["fall_reset_height"]}')
    lines += ["", '[node name="WorldEnvironment" type="WorldEnvironment" parent="."]', 'environment = SubResource("Environment_main")',
              "", '[node name="Sun" type="DirectionalLight3D" parent="."]', f'transform = {sun_transform(env["sun_elevation"], env["sun_u"])}',
              f'light_color = {env.get("sun_color", "Color(1, 0.97, 0.9, 1)")}', f'light_energy = {env.get("sun_energy", 1.2)}', "shadow_enabled = true",
              f'directional_shadow_max_distance = {env.get("shadow_distance", 100.0)}', "directional_shadow_mode = 1"]
    track = spec["track"]
    lines += ["", '[node name="Track" type="Node3D" parent="." node_paths=PackedStringArray("spawn_marker", "finish_line")]', 'script = ExtResource("2_builder")',
              "segments = Array[ExtResource(\"6_segment\")]([" + ", ".join(f'SubResource("{s}")' for s in seg_ids) + "])"]
    for k, v in track.items():
        lines.append(f"{k} = {value(v)}")
    for key, prop in (("road", "road_material"), ("curb", "curb_material"), ("side", "side_material"), ("wall", "wall_material"), ("slick", "slick_material")):
        if key in materials:
            lines.append(f'{prop} = ExtResource("{materials[key]}")')
    lines += ['spawn_marker = NodePath("Spawn")', 'finish_line = NodePath("FinishLine")',
              "", '[node name="Spawn" type="Marker3D" parent="Track"]', "", '[node name="FinishLine" type="Node3D" parent="Track"]', 'script = ExtResource("7_finish")']
    # Alternative routes: TrackRoute children of the track.
    for route in spec.get("routes", []):
        lines += ["", f'[node name="{route["name"]}" type="Node3D" parent="Track"]', 'script = ExtResource("42_route")']
        for k, v in route.items():
            if k == "name":
                continue
            if k == "obstacle_scene":
                v = f'ExtResource("{scene_ids[v]}")'
            elif k in ("offsets", "heights", "straighten", "obstacles"):
                v = "PackedVector2Array(" + ", ".join(f"{a}, {b}" for a, b in v) + ")"
            elif k == "gaps":
                v = "PackedVector3Array(" + ", ".join(f"{a}, {b}, {c}" for a, b, c in v) + ")"
            elif k == "holes":
                v = "PackedVector4Array(" + ", ".join(f"{a}, {b}, {c}, {d}" for a, b, c, d in v) + ")"
            elif k in ("route_walls", "chord"):
                v = f"Vector2({v[0]}, {v[1]})"
            lines.append(f"{k} = {v if isinstance(v, str) else value(v)}")
    terrain = spec["terrain"]
    lines += ["", '[node name="Terrain" type="Node3D" parent="." node_paths=PackedStringArray("track")]', 'script = ExtResource("9_terrain")', 'track = NodePath("../Track")']
    if "ground" in materials:
        lines.append(f'material = ExtResource("{materials["ground"]}")')
    for k, v in terrain.items():
        lines.append(f"{k} = {v if isinstance(v, str) else value(v)}")
    lines += ["", '[node name="Supports" type="Node3D" parent="." node_paths=PackedStringArray("track", "terrain")]', 'script = ExtResource("10_supports")',
              'track = NodePath("../Track")', 'terrain = NodePath("../Terrain")']
    if "supports" in materials:
        lines.append(f'material = ExtResource("{materials["supports"]}")')
    for k, v in spec.get("supports", {}).items():
        lines.append(f"{k} = {value(v)}")
    lines += ["", '[node name="Bounds" type="Node3D" parent="." node_paths=PackedStringArray("track", "terrain")]', 'script = ExtResource("30_bounds")',
              'track = NodePath("../Track")', 'terrain = NodePath("../Terrain")']
    if spec.get("mountains"):
        lines += ["", '[node name="Mountains" type="MeshInstance3D" parent="." node_paths=PackedStringArray("terrain")]', 'script = ExtResource("31_mountains")',
                  'terrain = NodePath("../Terrain")']
        for k, v in spec["mountains"].items():
            lines.append(f"{k} = {v if isinstance(v, str) else value(v)}")
    lines += ["", '[node name="Props" type="Node3D" parent="." node_paths=PackedStringArray("track", "terrain")]', 'script = ExtResource("11_props")',
              'track = NodePath("../Track")', 'terrain = NodePath("../Terrain")', f'seed = {spec.get("seed", 1)}']
    out.write_text("\n".join(lines) + "\n")
    return out


if __name__ == "__main__":
    wanted = sys.argv[1:]
    for spec in LEVELS:
        if not wanted or spec["id"] in wanted:
            print("wrote", write(spec).relative_to(ROOT))
