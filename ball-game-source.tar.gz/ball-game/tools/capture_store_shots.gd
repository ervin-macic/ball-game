extends SceneTree
## Captures App Store screenshots: the test autopilot drives one lap, then a
## slightly slower second lap against the first lap's ghost, photographing it
## every SHOT_EVERY metres, at the finish, and with the settings menu open.
## Needs a display (xvfb works); --fixed-fps keeps physics deterministic:
##
##   xvfb-run godot --path . --rendering-driver opengl3 --fixed-fps 60 \
##     --script res://tools/capture_store_shots.gd -- <out_dir>

const MAIN_SCENE := preload("res://scenes/main.tscn")
const Autopilot := preload("res://tests/autopilot.gd")
const SIZE := Vector2i(1600, 900)
const SHOT_EVERY := 40.0
## The second lap drives this much slower, so the ghost pulls ahead and the split shows.
const SECOND_LAP_PACE := 0.95

var _out := ""


func _initialize() -> void:
	_capture.call_deferred()


func _capture() -> void:
	var args := OS.get_cmdline_user_args()
	_out = args[0] if args.size() > 0 else "user://store_shots"
	DirAccess.make_dir_recursive_absolute(_out)
	DisplayServer.window_set_size(SIZE)
	root.size = SIZE
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	root.add_child(main)
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var pilot := Autopilot.new()
	pilot.ball = ball
	pilot.track = (main.get_node("RaceManager") as RaceManager).track
	main.add_child(pilot)

	RenderingServer.render_loop_enabled = false # the first lap only makes the ghost
	await _lap(race)
	print("first lap %.3f s" % race.race_time)
	RenderingServer.render_loop_enabled = true
	race.restart()
	pilot.reset()
	ball.max_drive_speed *= SECOND_LAP_PACE
	ball.air_max_speed *= SECOND_LAP_PACE
	await _frames(30)
	var next_shot := 10.0
	while race.state != RaceManager.State.FINISHED:
		await physics_frame
		if pilot.progress >= next_shot:
			await _shot("lap_%03dm" % roundi(next_shot))
			next_shot += SHOT_EVERY
	print("second lap %.3f s" % race.race_time)
	await _frames(45)
	await _shot("finish")
	var menu: PauseMenu = main.get_node("PauseMenu")
	menu.open()
	await _frames(5)
	await _shot("menu_settings")
	quit(0)


func _lap(race: RaceManager) -> void:
	var ticks := 0
	while race.state != RaceManager.State.FINISHED and ticks < 120 * 120:
		await physics_frame
		ticks += 1


func _frames(count: int) -> void:
	for i in count:
		await process_frame


func _shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var image := root.get_texture().get_image()
	image.save_jpg(_out.path_join(name + ".jpg"), 0.9)
	print("shot ", name)
