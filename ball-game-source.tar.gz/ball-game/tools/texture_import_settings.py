#!/usr/bin/env python3
"""Sets every Assets texture to lossy WebP with mipmaps (small level packs for
the web), normal maps flagged as such, skies a little higher quality. Kenney
palette textures stay lossless (tiny, and must keep exact colours).
Run after adding textures, then let Godot re-import (godot --headless --import).
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent / "Assets"
changed = 0
for imp in ROOT.rglob("*.import"):
    source = imp.with_suffix("")
    if source.suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp"):
        continue
    text = imp.read_text()
    if 'importer="texture"' not in text or source.name == "colormap.png" or source.name.startswith("Atlas"):
        continue
    quality = "0.85" if "HDRIs" in str(source) else "0.78"
    settings = {
        "compress/mode": "1",
        "compress/lossy_quality": quality,
        "mipmaps/generate": "true",
        "detect_3d/compress_to": "0",
        "compress/normal_map": "1" if "nor_gl" in source.name or "NormalGL" in source.name else "0",
    }
    new = text
    for key, value in settings.items():
        pattern = rf"^{re.escape(key)}=.*$"
        new = re.sub(pattern, f"{key}={value}", new, flags=re.M) if re.search(pattern, new, flags=re.M) else new.rstrip() + f"\n{key}={value}\n"
    if new != text:
        imp.write_text(new)
        changed += 1
print(f"updated {changed} import settings")
