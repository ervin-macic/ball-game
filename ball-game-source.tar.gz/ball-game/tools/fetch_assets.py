#!/usr/bin/env python3
"""Re-downloads the third-party CC0 assets the themed levels use.

The source files under Assets/ (textures, sky panoramas, Kenney models) can
be deleted to save space and restored at any time with:

    python3 tools/fetch_assets.py            # fetch whatever is missing
    python3 tools/fetch_assets.py --check    # only report what is missing

Godot needs them present to import and export the levels. The ambience
sounds in Assets/Sounds are not fetched: they were mixed and looped from
Freesound CC0 recordings (see Assets/Sounds/SOURCES.json) and are kept as is.
Everything here is CC0 (public domain); see CREDITS.md.
"""
import argparse
import io
import sys
import urllib.request
import zipfile
from pathlib import Path

ASSETS = Path(__file__).resolve().parent.parent / "Assets"
UA = {"User-Agent": "Mozilla/5.0 (ball-game asset fetch)"}

# Poly Haven textures: (folder under Assets/Textures, asset id). 1K JPG colour,
# OpenGL normal and packed AO/roughness/metal maps.
POLYHAVEN_TEXTURES = [
    ("Summer", "sand_03"), ("Summer", "damp_beach_sand"), ("Summer", "cliff_side"),
    ("Shared", "weathered_planks"), ("Shared", "tree_bark_03"),
    ("Jungle", "forrest_ground_01"), ("Jungle", "mossy_rock"), ("Jungle", "mossy_cobblestone"),
    ("Winter", "snow_02"),
]
# ambientCG textures: (folder, asset id, files kept from the 1K JPG zip).
AMBIENTCG_TEXTURES = [
    ("Winter", "Ice003", ["Ice003_1K-JPG_Color.jpg", "Ice003_1K-JPG_NormalGL.jpg", "Ice003_1K-JPG_Roughness.jpg"]),
]
# Poly Haven HDRIs, used as LDR sky panoramas: tonemapped preview resized to 4096 x 2048.
POLYHAVEN_SKIES = ["kloofendal_43d_clear_puresky", "kloofendal_48d_partly_cloudy_puresky"]
# Kenney kits: zip URL and the folder inside it the models come from.
KENNEY_KITS = {
    "Nature": ("https://kenney.nl/media/pages/assets/nature-kit/37ac38a37b-1677698939/kenney_nature-kit.zip", "Models/GLTF format"),
    "Holiday": ("https://kenney.nl/media/pages/assets/holiday-kit/3976a6496a-1733923970/kenney_holiday-kit.zip", "Models/GLB format"),
    "Pirate": ("https://kenney.nl/media/pages/assets/pirate-kit/e6d4bb1525-1771333093/kenney_pirate-kit.zip", "Models/GLB format"),
}


def get(url: str) -> bytes:
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=120) as response:
        return response.read()


def needed(path: Path, check: bool, missing: list) -> bool:
    if path.exists():
        return False
    missing.append(path.relative_to(ASSETS))
    return not check


def textures(check: bool, missing: list) -> None:
    for folder, asset in POLYHAVEN_TEXTURES:
        for kind in ("diff", "nor_gl", "arm"):
            target = ASSETS / "Textures" / folder / asset / f"{asset}_{kind}_1k.jpg"
            if needed(target, check, missing):
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(get(f"https://dl.polyhaven.org/file/ph-assets/Textures/jpg/1k/{asset}/{target.name}"))
    # The boardwalk planks run across the track: a copy turned 90 degrees.
    planks = ASSETS / "Textures/Shared/weathered_planks"
    for kind in ("diff", "nor_gl", "arm"):
        target = planks / f"weathered_planks_{kind}_1k_rot90.jpg"
        if needed(target, check, missing):
            from PIL import Image
            image = Image.open(planks / f"weathered_planks_{kind}_1k.jpg").convert("RGB").transpose(Image.Transpose.ROTATE_90)
            if kind == "nor_gl":  # turn the normals with the picture
                r, g, b = image.split()
                image = Image.merge("RGB", (g.point(lambda v: 255 - v), r, b))
            image.save(target, quality=92)
    for folder, asset, keep in AMBIENTCG_TEXTURES:
        targets = [ASSETS / "Textures" / folder / asset / name for name in keep]
        if any(needed(t, check, missing) for t in targets):
            archive = zipfile.ZipFile(io.BytesIO(get(f"https://ambientcg.com/get?file={asset}_1K-JPG.zip")))
            for target in targets:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(target.name))


def skies(check: bool, missing: list) -> None:
    for sky in POLYHAVEN_SKIES:
        target = ASSETS / "HDRIs" / f"{sky}_4k.jpg"
        if needed(target, check, missing):
            from PIL import Image
            Image.MAX_IMAGE_PIXELS = None
            image = Image.open(io.BytesIO(get(f"https://dl.polyhaven.org/file/ph-assets/HDRIs/extra/Tonemapped%20JPG/{sky}.jpg")))
            image.draft("RGB", (4096, 2048))
            image.convert("RGB").resize((4096, 2048), Image.LANCZOS).save(target, quality=88, optimize=True)


def models(check: bool, missing: list) -> None:
    wanted: dict[str, list[Path]] = {}
    for model in sorted(ASSETS.glob("Models/*/*/*.glb.import")):
        glb = model.with_suffix("")
        kit = glb.parent.name
        if kit in KENNEY_KITS and needed(glb, check, missing):
            wanted.setdefault(kit, []).append(glb)
    for kit, targets in wanted.items():
        url, inner = KENNEY_KITS[kit]
        archive = zipfile.ZipFile(io.BytesIO(get(url)))
        names = {Path(n).name: n for n in archive.namelist() if f"/{inner}/" in f"/{n}" or n.startswith(inner)}
        for target in targets:
            target.write_bytes(archive.read(names[target.name]))
            palette = target.parent / "Textures" / "colormap.png"
            source = next((n for n in archive.namelist() if n.startswith(inner) and n.endswith("Textures/colormap.png")), None)
            if source and not palette.exists():
                palette.parent.mkdir(exist_ok=True)
                palette.write_bytes(archive.read(source))


def quaternius(check: bool, missing: list) -> None:
    """Quaternius models (CC0, via Poly Pizza), with their textures moved into
    Models/Quaternius/Textures by tools/glb_share_textures.py."""
    import json
    import subprocess
    import tempfile
    pirate = ASSETS / "Models/Props/QuaterniusPirate"
    sources = json.loads((ASSETS / "Models/QuaterniusPirate/SOURCES.json").read_text())
    todo = [s for s in sources if pirate.joinpath(s["file"] + ".import").exists() and needed(pirate / s["file"], check, missing)]
    if todo:
        with tempfile.TemporaryDirectory() as tmp:
            paths = []
            for source in todo:
                path = Path(tmp) / source["file"]
                path.write_bytes(get(source["download"]))
                paths.append(str(path))
            subprocess.run([sys.executable, str(Path(__file__).with_name("glb_share_textures.py")), str(pirate),
                            str(ASSETS / "Models/QuaterniusPirate/Textures"), *paths], check=True)
    sources = json.loads((ASSETS / "Models/Quaternius/SOURCES.json").read_text())
    for kind in ("Trees", "Plants", "Rocks"):
        folder = ASSETS / "Models" / kind / "Quaternius"
        wanted = [s for s in sources if (folder / s["file"]).with_suffix(".glb.import").exists() or kind == _kind_of(s["file"])]
        todo = [s for s in wanted if needed(folder / s["file"], check, missing)]
        if not todo:
            continue
        with tempfile.TemporaryDirectory() as tmp:
            paths = []
            for source in todo:
                path = Path(tmp) / source["file"]
                path.write_bytes(get(source["download"]))
                paths.append(str(path))
            subprocess.run([sys.executable, str(Path(__file__).with_name("glb_share_textures.py")), str(folder),
                            str(ASSETS / "Models/Quaternius/Textures"), *paths], check=True)


def _kind_of(file: str) -> str:
    if file.startswith(("rock_",)):
        return "Rocks"
    if file.startswith(("fern", "plant", "grass", "tall_grass", "mushroom", "bush")):
        return "Plants"
    return "Trees"


def fetchable() -> list[Path]:
    """Every asset file this tool can download again (relative to Assets/)."""
    global needed
    found: list = []
    original = needed
    needed = lambda path, check, missing: missing.append(path.relative_to(ASSETS)) or False
    try:
        for step in (textures, skies, models, quaternius):
            step(True, found)
    finally:
        needed = original
    return sorted(set(found))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--check", action="store_true", help="only list missing files")
    args = parser.parse_args()
    missing: list = []
    textures(args.check, missing)
    skies(args.check, missing)
    models(args.check, missing)
    quaternius(args.check, missing)
    if args.check:
        print("\n".join(str(m) for m in missing) or "All asset files are present.")
        sys.exit(1 if missing else 0)
    print(f"Fetched {len(missing)} files." if missing else "All asset files are present.")


if __name__ == "__main__":
    main()
