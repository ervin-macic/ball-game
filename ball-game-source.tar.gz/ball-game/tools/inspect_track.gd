extends SceneTree
## Prints where each piece of a level's track ends (position, height, slope)
## and writes the centreline as JSON for plotting:
##
##   godot --headless --path . --script res://tools/inspect_track.gd -- <scene.tscn> [out.json]

func _initialize() -> void:
	_inspect.call_deferred()


func _inspect() -> void:
	var args := OS.get_cmdline_user_args()
	var level: Node = load(args[0]).instantiate()
	var track: TrackBuilder = level.track if level is Level else level
	var cursor := TrackCursor.new()
	var path := TrackPath.new()
	path.add_frame(cursor.frame(), 0.0)
	var max_turn := deg_to_rad(track.max_step_angle)
	for segment in track.segments:
		path.current_paved = segment.paved
		segment.lay(cursor, path, track.max_spacing, max_turn)
		print("%-22s %-6s d=%6.1f  pos=(%7.1f, %6.1f, %7.1f)  pitch=%5.1f  heading=%6.1f" % [
			segment.resource_name, "road" if segment.paved else "GROUND", cursor.distance,
			cursor.position.x, cursor.position.y, cursor.position.z, rad_to_deg(cursor.pitch), rad_to_deg(cursor.heading)])
	if args.size() > 1:
		var points := []
		for i in path.frames.size():
			var o := path.frames[i].origin
			points.append([snappedf(o.x, 0.1), snappedf(o.y, 0.1), snappedf(o.z, 0.1), path.paved[i]])
		FileAccess.open(args[1], FileAccess.WRITE).store_string(JSON.stringify(points))
	level.free()
	quit()
