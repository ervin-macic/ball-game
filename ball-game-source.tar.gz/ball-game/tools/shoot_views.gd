extends SceneTree
## Photographs a level from fixed viewpoints placed along its track, for
## checking scenery. Needs a display (xvfb works):
##
##   xvfb-run godot --path . --rendering-driver opengl3 --script res://tools/shoot_views.gd -- \
##     <level_id> <out_dir> name=distance,back,up,side,look_distance,look_up [...]
##
## The camera stands [back] metres behind the track point at [distance] (and
## [up] above it, [side] to its right) and looks at the point [look_distance]
## along the track, [look_up] above it. Distances past the end carry on straight.
## A view named with a "route:" prefix (route:Name:view=...) uses that route.

const MAIN_SCENE := preload("res://scenes/main.tscn")
const SIZE := Vector2i(1600, 900)


func _initialize() -> void:
	_run.call_deferred()


func _frame(track: TrackBuilder, distance: float) -> Transform3D:
	var total := track.path.total_length()
	if distance <= total:
		return track.world_frame_at(maxf(distance, 0.0))
	var end := track.world_frame_at(total)
	var forward := -end.basis.z.normalized()
	return Transform3D(end.basis, end.origin + forward * (distance - total))


func _run() -> void:
	var args := Array(OS.get_cmdline_user_args())
	var id: String = args[0]
	var out: String = args[1]
	DirAccess.make_dir_recursive_absolute(out)
	DisplayServer.window_set_size(SIZE)
	root.size = SIZE
	Swinger.hold_still = true
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	root.add_child(main)
	var loader: LevelLoader = main.get_node("LevelLoader")
	loader.load_level(id)
	while loader.level_id != id:
		await process_frame
	for i in 40:
		await process_frame
	main.get_node("HUD").visible = false
	var follow: Camera3D = main.get_node("FollowCamera")
	follow.set_process(false)
	follow.set_physics_process(false)
	var camera := Camera3D.new()
	camera.fov = 70.0
	camera.far = 3000.0
	root.add_child(camera)
	camera.make_current()
	var level: Level = loader.level
	for spec: String in args.slice(2):
		var name := spec.get_slice("=", 0)
		var numbers := spec.get_slice("=", 1).split(",")
		var v: Array[float] = []
		for n in numbers:
			v.append(float(n))
		var track := level.track
		if name.begins_with("route:"):
			track = level.track.get_node(name.get_slice(":", 1)) as TrackBuilder
			name = name.get_slice(":", 2)
		var at := _frame(track, v[0])
		var look := _frame(track, v[4])
		var right := at.basis.x.normalized()
		var position := at.origin + at.basis.z.normalized() * v[1] + Vector3.UP * v[2] + right * v[3]
		camera.look_at_from_position(position, look.origin + Vector3.UP * v[5], Vector3.UP)
		for i in 8:
			await process_frame
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_jpg(out.path_join(name + ".jpg"), 0.88)
		print("shot ", name)
	quit(0)
