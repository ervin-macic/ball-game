extends SceneTree
## Writes every level's track outline (spawn, finish gate, centreline) as JSON,
## one <level_id>.json per level, so the community leaderboard service can check
## that a submitted run actually followed that track. Re-run it whenever a
## track changes:
##
##   godot --headless --path . --script res://tools/export_track_outline.gd -- <out_dir>

const MAIN_SCENE := preload("res://scenes/main.tscn")
## Centreline points are kept about this far apart.
const STEP := 2.0
## How far beside the centreline a run may stray: built road keeps the ball
## close; open ground (and the beach wave) lets it wander as far as the race allows.
const OFF_ROAD_PAVED := 20.0


func _initialize() -> void:
	_export.call_deferred()


func _export() -> void:
	var args := OS.get_cmdline_user_args()
	if args.is_empty():
		push_error("usage: -- <out_dir>")
		quit(2)
		return
	DirAccess.make_dir_recursive_absolute(args[0])
	Swinger.hold_still = true # the autopilot can't time its run past them
	RollingBarrels.hold_still = true
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	root.add_child(main)
	await physics_frame
	var loader: LevelLoader = main.get_node("LevelLoader")
	var race: RaceManager = main.get_node("RaceManager")
	for entry in LevelCatalog.available():
		loader.load_level(entry["id"])
		while loader.level_id != entry["id"]:
			await process_frame
		await physics_frame
		var path_out: String = args[0].path_join(race.track_id + ".json")
		FileAccess.open(path_out, FileAccess.WRITE).store_string(JSON.stringify(_outline(race)))
		print("wrote %s (%.1f m of track)" % [path_out, race.track.path.total_length()])
	quit(0)


func _outline(race: RaceManager) -> Dictionary:
	var track := race.track
	var path := track.path
	var points := []
	var next := 0.0
	for i in path.frames.size():
		if path.distances[i] + 1e-3 < next and i != path.frames.size() - 1:
			continue
		var at := track.to_global(path.frames[i].origin)
		points.append([_r(at.x), _r(at.y), _r(at.z), _r(path.distances[i])])
		next = path.distances[i] + STEP
	# Alternative routes: their own centrelines, each point with the distance
	# along the main track it stands for.
	var branches := []
	for route in track.routes():
		var branch := []
		var step_next := -INF
		var route_path := route.path
		for i in route_path.frames.size():
			if route_path.distances[i] + 1e-3 < step_next and i != route_path.frames.size() - 1:
				continue
			var at := track.to_global(route_path.frames[i].origin)
			branch.append([_r(at.x), _r(at.y), _r(at.z), _r(route.main_distances[i])])
			step_next = route_path.distances[i] + STEP
		branches.append(branch)
	var spawn := track.spawn_marker.global_position
	var finish := track.finish_line.global_transform
	var has_ground := not path.ground_ranges().is_empty()
	return {
		"track_id": race.track_id,
		"length": _r(path.total_length()),
		"finish_distance": _r(path.total_length() - track.finish_distance_from_end),
		"half_width": _r(track.road_width * 0.5),
		"off_road": race.off_track_reach if has_ground else OFF_ROAD_PAVED,
		"spawn": [_r(spawn.x), _r(spawn.y), _r(spawn.z)],
		"finish": {
			"origin": [_r(finish.origin.x), _r(finish.origin.y), _r(finish.origin.z)],
			"forward": [_r(-finish.basis.z.x), _r(-finish.basis.z.y), _r(-finish.basis.z.z)],
			"gate_width": _r(track.finish_line.gate_width),
		},
		"max_speed": race.ball.max_speed,
		"centreline": points,
		"branches": branches,
	}


static func _r(value: float) -> float:
	return snappedf(value, 0.01)
