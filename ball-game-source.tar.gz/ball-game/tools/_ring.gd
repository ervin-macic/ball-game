extends SceneTree
func _initialize():
	_go.call_deferred()
func _go():
	DisplayServer.window_set_size(Vector2i(960, 540)); root.size = Vector2i(960, 540)
	var level: Level = load("res://levels/beach/beach_level.tscn").instantiate()
	root.add_child(level)
	var cam := Camera3D.new(); root.add_child(cam); cam.current = true; cam.far = 4000
	var f := level.track.world_frame_at(700.0)
	cam.global_transform = f.translated(f.basis.y * 3.0)
	for i in 8: await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_jpg("/tmp/ring_on.jpg")
	quit()
