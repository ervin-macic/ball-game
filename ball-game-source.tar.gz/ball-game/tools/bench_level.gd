extends SceneTree
## Rough render cost of a level: average frame time over a few frames from
## points along the track (software rendering under xvfb is slow, so compare
## levels against each other rather than reading the numbers as real fps).
##
##   xvfb-run godot --path . --rendering-driver opengl3 --script res://tools/bench_level.gd -- <level_id>...

const MAIN_SCENE := preload("res://scenes/main.tscn")


func _initialize() -> void:
	_bench.call_deferred()


func _bench() -> void:
	DisplayServer.window_set_size(Vector2i(960, 540))
	root.size = Vector2i(960, 540)
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	root.add_child(main)
	var loader: LevelLoader = main.get_node("LevelLoader")
	var race: RaceManager = main.get_node("RaceManager")
	var args := OS.get_cmdline_user_args()
	var hide := ""
	if args.size() > 1 and args[-1].begins_with("hide="):
		hide = args[-1].substr(5)
		args = args.slice(0, args.size() - 1)
	for id in args:
		loader.load_level(id)
		while loader.level_id != id:
			await process_frame
		if not hide.is_empty():
			for name in hide.split(","):
				var node := loader.level.get_node_or_null(name)
				if node:
					node.visible = false
		var total := 0.0
		var frames := 0
		var calls := 0
		var primitives := 0
		var objects := 0
		var length := race.track.path.total_length()
		for k in 5:
			var frame := race.track.world_frame_at(length * (k + 0.5) / 5.0)
			race.ball.respawn(Transform3D(frame.basis, frame.origin + frame.basis.y * 0.6))
			race.camera.snap_behind(frame)
			for i in 3:
				await process_frame
			var started := Time.get_ticks_usec()
			for i in 4:
				await RenderingServer.frame_post_draw
			total += (Time.get_ticks_usec() - started) / 1000.0
			frames += 4
			calls += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
			primitives += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)
			objects += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME)
		print("%s: %.0f ms per frame (software), on average %d draw calls, %d objects, %d k primitives" % [id, total / frames,
			calls / 5, objects / 5, primitives / 5000])
	quit()
