#!/usr/bin/env python3
"""Moves the textures embedded in GLB models out into one shared folder.

Quaternius' models each embed the same bark/leaf/rock textures; left as is,
every model would carry (and a level pack would download) its own copy.
This rewrites each .glb to reference shared PNGs by relative path, once per
texture (deduplicated by content, downscaled to at most --max-size).

    python3 tools/glb_share_textures.py <out_models_dir> <shared_textures_dir> in1.glb [in2.glb ...]
"""
import hashlib
import io
import json
import os
import struct
import sys
from pathlib import Path

from PIL import Image


def read_glb(data: bytes):
    json_len = struct.unpack("<I", data[12:16])[0]
    doc = json.loads(data[20:20 + json_len])
    bin_start = 20 + json_len + 8
    bin_len = struct.unpack("<I", data[20 + json_len:24 + json_len])[0]
    return doc, data[bin_start:bin_start + bin_len]


def write_glb(doc: dict, blob: bytes) -> bytes:
    text = json.dumps(doc, separators=(",", ":")).encode()
    text += b" " * (-len(text) % 4)
    blob += b"\0" * (-len(blob) % 4)
    total = 12 + 8 + len(text) + 8 + len(blob)
    return (struct.pack("<III", 0x46546C67, 2, total) + struct.pack("<II", len(text), 0x4E4F534A) + text
            + struct.pack("<II", len(blob), 0x004E4942) + blob)


def main() -> None:
    out_dir, tex_dir, *inputs = sys.argv[1:]
    max_size = 1024
    out_dir, tex_dir = Path(out_dir), Path(tex_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    tex_dir.mkdir(parents=True, exist_ok=True)
    for path in map(Path, inputs):
        doc, blob = read_glb(path.read_bytes())
        image_views = set()
        for image in doc.get("images", []):
            view = doc["bufferViews"][image["bufferView"]]
            start = view.get("byteOffset", 0)
            raw = blob[start:start + view["byteLength"]]
            picture = Image.open(io.BytesIO(raw))
            if max(picture.size) > max_size:
                scale = max_size / max(picture.size)
                picture = picture.resize((round(picture.size[0] * scale), round(picture.size[1] * scale)), Image.LANCZOS)
            name = Path(image.get("name") or hashlib.md5(raw).hexdigest()[:10]).stem + ".png"
            target = tex_dir / name
            if target.exists() and hashlib.md5(target.read_bytes()).hexdigest() != hashlib.md5(raw).hexdigest():
                pass  # same name, kept: Quaternius reuses names for identical textures
            if not target.exists():
                picture.save(target, optimize=True)
            image_views.add(image.pop("bufferView"))
            image.pop("mimeType", None)
            image["uri"] = os.path.relpath(target, out_dir).replace(os.sep, "/")
        # Rebuild the binary chunk without the image bytes.
        remap, new_blob = {}, bytearray()
        for index, view in enumerate(doc["bufferViews"]):
            if index in image_views:
                continue
            start = view.get("byteOffset", 0)
            new_blob += b"\0" * (-len(new_blob) % 4)
            view["byteOffset"] = len(new_blob)
            new_blob += blob[start:start + view["byteLength"]]
            remap[index] = len(remap)
        doc["bufferViews"] = [v for i, v in enumerate(doc["bufferViews"]) if i not in image_views]
        for accessor in doc.get("accessors", []):
            if "bufferView" in accessor:
                accessor["bufferView"] = remap[accessor["bufferView"]]
        doc["buffers"] = [{"byteLength": len(new_blob)}]
        (out_dir / path.name).write_bytes(write_glb(doc, bytes(new_blob)))
        print(path.name, "->", len((out_dir / path.name).read_bytes()), "bytes")


if __name__ == "__main__":
    main()
