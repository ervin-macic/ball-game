extends SceneTree
## Photographs one level: the autopilot drives a lap and a shot is saved every
## SHOT_EVERY metres. Needs a display (xvfb works):
##
##   xvfb-run godot --path . --rendering-driver opengl3 --fixed-fps 60 \
##     --script res://tools/capture_level.gd -- <level_id> <out_dir> [every_m] [from_m] [to_m] [routes]

const MAIN_SCENE := preload("res://scenes/main.tscn")
const Autopilot := preload("res://tests/autopilot.gd")
const SIZE := Vector2i(1600, 900)


func _initialize() -> void:
	_capture.call_deferred()


func _capture() -> void:
	var args := Array(OS.get_cmdline_user_args())
	var take_routes := args.has("routes")
	args.erase("routes")
	var id: String = args[0]
	var out: String = args[1]
	var every := float(args[2]) if args.size() > 2 else 50.0
	var from := float(args[3]) if args.size() > 3 else every
	var to := float(args[4]) if args.size() > 4 else INF
	DirAccess.make_dir_recursive_absolute(out)
	DisplayServer.window_set_size(SIZE)
	root.size = SIZE
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	root.add_child(main)
	var loader: LevelLoader = main.get_node("LevelLoader")
	loader.load_level(id)
	while loader.level_id != id:
		await process_frame
	var race: RaceManager = main.get_node("RaceManager")
	var pilot := Autopilot.new()
	pilot.ball = main.get_node("Ball")
	pilot.track = race.track
	pilot.take_routes = take_routes
	main.add_child(pilot)
	for i in 20:
		await process_frame
	await _shot(out, "start")
	# Draw only the frames that are photographed: software rendering is slow.
	RenderingServer.render_loop_enabled = false
	var next := from
	while race.state != RaceManager.State.FINISHED and next <= to:
		await physics_frame
		if race.state == RaceManager.State.READY:
			pilot.reset()
		if pilot.progress >= next:
			await _shot(out, "%s_%03dm" % [id, roundi(next)])
			next += every
	await _shot(out, "%s_finish" % id)
	quit(0)


func _shot(out: String, name: String) -> void:
	RenderingServer.render_loop_enabled = true
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_jpg(out.path_join(name + ".jpg"), 0.88)
	print("shot ", name)
	RenderingServer.render_loop_enabled = false
