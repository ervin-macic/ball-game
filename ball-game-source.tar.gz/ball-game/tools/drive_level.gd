extends SceneTree
## Drives one level with the test autopilot and reports the lap: time, any
## restarts (and where), top speed, and how long each piece took.
##
##   godot --headless --path . --fixed-fps 120 --script res://tools/drive_level.gd -- <level_id> [ghost.json] [routes]
##
## With a second argument the finished lap's recording is saved there (the
## leaderboard service's tests replay it as a known-good run). With "routes"
## the autopilot takes every alternative route instead of the main road.

const MAIN_SCENE := preload("res://scenes/main.tscn")
const Autopilot := preload("res://tests/autopilot.gd")


func _initialize() -> void:
	_drive.call_deferred()


func _drive() -> void:
	var args := Array(OS.get_cmdline_user_args())
	var take_routes := args.has("routes")
	args.erase("routes")
	var id: String = args[0]
	Swinger.hold_still = true # the autopilot can't time its run past them
	RollingBarrels.hold_still = true
	var main := MAIN_SCENE.instantiate()
	main.get_node("PlayerInput").queue_free()
	main.get_node("RaceManager").save_records = false
	main.get_node("Settings").persist = false
	main.get_node("LevelLoader").persist = false
	root.add_child(main)
	var loader: LevelLoader = main.get_node("LevelLoader")
	var started := Time.get_ticks_msec()
	loader.load_level(id)
	while loader.level_id != id:
		await process_frame
	print("loaded %s in %d ms" % [id, Time.get_ticks_msec() - started])
	var race: RaceManager = main.get_node("RaceManager")
	var ball: RollingBall = main.get_node("Ball")
	var pilot := Autopilot.new()
	pilot.ball = ball
	pilot.track = race.track
	pilot.take_routes = take_routes
	main.add_child(pilot)
	var restarts := []
	race.state_changed.connect(func(state: RaceManager.State) -> void:
		if state == RaceManager.State.READY:
			restarts.append([pilot.progress, ball.global_position]))
	var top := 0.0
	var first_off := -1.0

	var ticks := 0
	while race.state != RaceManager.State.FINISHED and ticks < 120 * 150 and restarts.size() < 3:
		await physics_frame
		ticks += 1
		top = maxf(top, ball.linear_velocity.length())
		if race.off_track and first_off < 0.0:
			first_off = pilot.progress
			print("  left the track at %.0f m" % first_off)

		if restarts.size() > 0 and race.state == RaceManager.State.READY:
			pilot.reset()
	if race.state == RaceManager.State.FINISHED:
		# The run is over: the ball should brake to a stop on the run-off.
		for i in 120 * 5:
			await physics_frame
		var here: int = race.track.locate(race.track.to_local(ball.global_position), -1, 60)
		print("  after the finish: stopped %.1f m before the end of the track, %.1f m/s, %.1f m from the road" % [
			race.track.path.total_length() - race.track.network.distances[here], ball.linear_velocity.length(),
			race.track.to_global(race.track.network.frames[here].origin).distance_to(ball.global_position)])
	print("%s: %s in %.3f s, progress %.0f/%.0f m, top speed %.1f m/s" % [id, RaceManager.State.keys()[race.state], race.race_time, pilot.progress, race.track.path.total_length(), top])
	if take_routes:
		print("  took %d of %d routes" % [pilot.routes_taken.size(), race.track.routes().size()])
		for route in race.track.routes():
			print("  rode %.0f of %.0f m of %s" % [pilot.ridden.get(route.name, 0.0), route.length(), route.name])
	if args.size() > 1 and race.state == RaceManager.State.FINISHED:
		FileAccess.open(args[1], FileAccess.WRITE).store_string(JSON.stringify(race.last_recording.to_dict()))
	for r in restarts:
		print("  restart at %.0f m, ball at %s" % [r[0], r[1]])
	quit(0 if race.state == RaceManager.State.FINISHED and restarts.is_empty() and first_off < 0.0 else 1)
