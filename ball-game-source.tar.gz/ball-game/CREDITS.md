# Ball Game asset credits

Every third-party asset in the themed levels is CC0 (public domain): no
attribution is required. They are listed here with thanks and as a provenance
record. `tools/fetch_assets.py` re-downloads the textures, skies and models.

## Textures (Poly Haven, ambientCG)

- “Sand 03” by Charlotte Baglioni, Poly Haven (https://polyhaven.com/a/sand_03): CC0
- “Damp Beach Sand” by Dimitrios Savva, Poly Haven (https://polyhaven.com/a/damp_beach_sand): CC0
- “Weathered Planks” by Dario Barresi and Dimitrios Savva, Poly Haven (https://polyhaven.com/a/weathered_planks): CC0
- “Tree Bark 03” by Rob Tuytel, Poly Haven (https://polyhaven.com/a/tree_bark_03): CC0
- “Forest Ground 01” by Rob Tuytel, Poly Haven (https://polyhaven.com/a/forrest_ground_01): CC0
- “Mossy Rock” by Rob Tuytel, Poly Haven (https://polyhaven.com/a/mossy_rock): CC0
- “Mossy Cobblestone” by Sơn Nguyễn, Poly Haven (https://polyhaven.com/a/mossy_cobblestone): the forest's walls, CC0
- “Cliff Side” by James Ray Cock, Jenelle van Heerden and Dario Barresi, Poly Haven (https://polyhaven.com/a/cliff_side): CC0
- “Snow 02” by Rob Tuytel, Poly Haven (https://polyhaven.com/a/snow_02): CC0
- “Ice 003” by ambientCG / Lennart Demes (https://ambientcg.com/a/Ice003): CC0

## Skies (Poly Haven HDRIs, used as panoramas)

- “Kloofendal 43d Clear (Pure Sky)” by Greg Zaal (https://polyhaven.com/a/kloofendal_43d_clear_puresky): beach, CC0
- “Kloofendal 48d Partly Cloudy (Pure Sky)” by Greg Zaal and Jarod Guest (https://polyhaven.com/a/kloofendal_48d_partly_cloudy_puresky): forest and winter, CC0

## 3D models

- Stylized Nature MegaKit and Ultimate Stylized Nature Pack by Quaternius (https://quaternius.com), downloaded from Poly Pizza (https://poly.pizza/u/Quaternius): CC0. Trees, pines, palms, ferns, plants, grass and rocks; `Assets/Models/Quaternius/SOURCES.json` lists each model and its download.

- Pirate Kit by Quaternius (https://quaternius.com), downloaded from Poly Pizza: CC0. The beach's ships (the anchored galleon and the wreck the track runs through), docks, pirate house, cannons, barrels, chests, gold, flags, skulls, bones and pirate palms; `Assets/Models/QuaterniusPirate/SOURCES.json` lists each model and its download.

- The Forest's fallen hollow log is built in code, textured with the Quaternius bark above and dressed with its shelf fungus and ferns (no CC0 hollow-log model could be found).

- Nature Kit, Holiday Kit and Pirate Kit by Kenney (www.kenney.nl): CC0. The winter cabin past the finish is assembled from the Holiday Kit's cabin pieces; the forest's huge boulders are Nature Kit rocks. Licence files are in `Assets/Models/`; `Assets/Models/SOURCES.json` lists every model used.

## Sounds (Freesound, CC0 only)

- “Big waves hit land.wav” by straget (https://freesound.org/people/straget/sounds/412308/): CC0, used in `Summer/beach_ambience.ogg`
- “Seagull on beach” by squashy555 (https://freesound.org/people/squashy555/sounds/353416/): CC0, used in `Summer/beach_ambience.ogg`
- “Waves Crashing Against Wall/Breakwater.wav” by Ali_6868 (https://freesound.org/people/Ali_6868/sounds/384359/): CC0, used in `Summer/wave_crash.ogg`
- “Amazon Jungle in the Morning at Rainforest Tambopata National Reserve” by alberto_cendra_woodman (https://freesound.org/people/alberto_cendra_woodman/sounds/737513/): CC0, used in `Jungle/jungle_ambience.ogg`
- “Jungle, Tropical birds and insects” by myrinvp (https://freesound.org/people/myrinvp/sounds/423711/): CC0, used in `Jungle/jungle_ambience.ogg`
- “winter wind in trees.wav” by lwdickens (https://freesound.org/people/lwdickens/sounds/261226/): CC0, used in `Winter/winter_ambience.ogg`
- “Sleigh_Bells (7-22-12 edit).mp3” by jsm1963 (https://freesound.org/people/jsm1963/sounds/453202/): CC0, used in `Winter/sleigh_bells.ogg`

Sounds were trimmed, mixed and looped for the game; see `Assets/Sounds/SOURCES.json`.
