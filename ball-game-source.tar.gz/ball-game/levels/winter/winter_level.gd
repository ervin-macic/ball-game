extends Level
## Winter Wonderland: an icy bobsled run with candy-cane curbs, a jump over a
## frozen river, a snowy village of snowmen and presents (knock them about),
## a candy loop and a dive to the finish, with snow falling throughout.

const MODELS := "res://Assets/Models/"
const SOUNDS := "res://Assets/Sounds/Winter/"
const VILLAGE_FROM := 563.0
const VILLAGE_TO := 713.0
const RIVER_AT := 482.0
## The cabin past the finish: metres beyond the end of the track, and its size.
const CABIN_AHEAD := 32.0
const CABIN_SCALE := 6.0

var _snow: CPUParticles3D
var _camera: Camera3D


func _ready() -> void:
	$Supports.build()
	var props: PropScatter = $Props
	props.kinds = [
		{"scene": MODELS + "Trees/Holiday/tree-snow-a.glb", "count": 70, "band": Vector2(9, 90), "scale": Vector2(4.0, 6.5),
			"collision": "trunk", "radius": 0.12, "canopy": Vector2(0.15, 0.6), "spacing": 6.0},
		{"scene": MODELS + "Trees/Holiday/tree-snow-b.glb", "count": 60, "band": Vector2(9, 90), "scale": Vector2(4.0, 6.5),
			"collision": "trunk", "radius": 0.12, "canopy": Vector2(0.15, 0.6), "spacing": 6.0},
		{"scene": MODELS + "Trees/Holiday/tree-snow-c.glb", "count": 60, "band": Vector2(20, 140), "scale": Vector2(4.0, 7.0),
			"collision": "trunk", "radius": 0.12, "canopy": Vector2(0.15, 0.6), "spacing": 7.0},
		{"scene": MODELS + "Trees/Nature/tree_pineTallB.glb", "count": 50, "band": Vector2(12, 120), "scale": Vector2(7.0, 10.0),
			"collision": "trunk", "radius": 0.05, "canopy": Vector2(0.2, 0.2), "spacing": 6.0, "snow": true},
		# Pines and bare trees across the snowy hills around the course.
		{"scene": MODELS + "Trees/Quaternius/pine_a.glb", "count": 90, "band": Vector2(18, 260), "scale": Vector2(1.5, 2.4),
			"collision": "trunk", "radius": 0.3, "canopy": Vector2(0.15, 2.5), "spacing": 14.0, "fade": 280.0, "snow": true},
		{"scene": MODELS + "Trees/Quaternius/pine_b.glb", "count": 90, "band": Vector2(18, 260), "scale": Vector2(1.5, 2.4),
			"collision": "trunk", "radius": 0.3, "canopy": Vector2(0.15, 2.5), "spacing": 14.0, "fade": 280.0, "snow": true},
		{"scene": MODELS + "Trees/Quaternius/pine_d.glb", "count": 70, "band": Vector2(18, 260), "scale": Vector2(1.5, 2.4),
			"collision": "trunk", "radius": 0.3, "canopy": Vector2(0.15, 2.5), "spacing": 14.0, "fade": 280.0, "snow": true},
		{"scene": MODELS + "Trees/Quaternius/dead_tree_a.glb", "count": 40, "band": Vector2(12, 200), "scale": Vector2(1.0, 1.6),
			"collision": "trunk", "radius": 0.3, "canopy": Vector2(0.3, 2.5), "spacing": 12.0, "snow": true},
		{"scene": MODELS + "Rocks/Holiday/rocks-large.glb", "count": 20, "band": Vector2(8, 80), "scale": Vector2(1.5, 3.0),
			"collision": "hull", "spacing": 9.0, "sink": 0.3},
		{"scene": MODELS + "Rocks/Holiday/rocks-medium.glb", "count": 20, "band": Vector2(7, 60), "scale": Vector2(1.5, 2.5),
			"collision": "hull", "spacing": 7.0, "sink": 0.2},
		{"scene": MODELS + "Rocks/Holiday/snow-pile.glb", "count": 40, "band": Vector2(6, 60), "scale": Vector2(3.0, 6.0), "spacing": 5.0},
		{"scene": MODELS + "Props/Holiday/snowman.glb", "count": 14, "band": Vector2(9, 50), "scale": Vector2(2.2, 3.0),
			"collision": "hull", "spacing": 10.0},
	]
	var placements: Array[Dictionary] = []
	# Candy canes line the village path; snowmen, reindeer and friends stand among them.
	var d := VILLAGE_FROM + 6.0
	var side := 1.0
	while d < VILLAGE_TO - 6.0:
		placements.append({"scene": MODELS + "Props/Holiday/candy-cane-%s.glb" % ("red" if side > 0 else "green"), "at": Vector2(d, 7.0 * side),
			"scale": 6.0, "yaw": 90.0 if side > 0 else -90.0, "collision": "hull"})
		d += 11.0
		side = -side
	placements.append_array([
		{"scene": MODELS + "Props/Holiday/snowman-hat.glb", "at": Vector2(579, -5.5), "scale": 2.6, "yaw": 80, "collision": "hull"},
		{"scene": MODELS + "Props/Holiday/snowman.glb", "at": Vector2(597, 5.2), "scale": 2.4, "yaw": -100, "collision": "hull"},
		{"scene": MODELS + "Props/Holiday/reindeer.glb", "at": Vector2(611, -9.0), "scale": 3.0, "yaw": 40, "collision": "hull"},
		{"scene": MODELS + "Props/Holiday/sled.glb", "at": Vector2(615, -12.0), "scale": 3.0, "yaw": 40, "collision": "hull"},
		{"scene": MODELS + "Props/Holiday/nutcracker.glb", "at": Vector2(625, 6.0), "scale": 3.0, "yaw": -90, "collision": "hull"},
		{"scene": MODELS + "Props/Holiday/lantern.glb", "at": Vector2(633, -6.0), "scale": 2.0, "collision": "trunk", "radius": 0.15},
		{"scene": MODELS + "Props/Holiday/gingerbread-man.glb", "at": Vector2(641, 5.5), "scale": 6.0, "yaw": -90, "collision": "hull"},
		{"scene": MODELS + "Trees/Holiday/tree-decorated-snow.glb", "at": Vector2(651, -16.0), "scale": 8.0, "collision": "trunk", "radius": 0.15},
		{"scene": MODELS + "Props/Holiday/snowman-hat.glb", "at": Vector2(699, -5.2), "scale": 2.8, "yaw": 90, "collision": "hull"},
		{"scene": MODELS + "Props/Holiday/lantern.glb", "at": Vector2(689, 6.0), "scale": 2.0, "collision": "trunk", "radius": 0.15},
		{"scene": MODELS + "Trees/Holiday/tree-decorated.glb", "at": Vector2(20, 12.0), "scale": 5.0, "collision": "trunk", "radius": 0.15},
	])
	# Presents to knock about in the plaza.
	var presents := ["present-a-cube", "present-b-round", "present-a-rectangle"]
	for k in 14:
		var at := Vector2(657.0 + k * 3.6, (4.6 + (k % 3) * 0.9) * (1.0 if k % 2 == 0 else -1.0))
		placements.append({"scene": MODELS + "Props/Holiday/%s.glb" % presents[k % 3], "at": at, "scale": 2.2 + (k % 3) * 0.3,
			"yaw": k * 37.0, "dynamic": true, "mass": 2.0, "bounce": 0.3})
	placements.append_array(_clearing_forest())
	props.placements = placements
	props.build()
	_add_frozen_river()
	_add_snowfall()
	_add_cabin()
	var ambience := LevelAmbience.new()
	ambience.name = "Ambience"
	ambience.bed = _sound("winter_ambience.ogg")
	var bells := _sound("sleigh_bells.ogg")
	if bells:
		ambience.one_shots = [bells]
	ambience.interval = Vector2(14.0, 28.0)
	add_child(ambience)
	# Giant baubles swinging across the climb to the candy loop.
	_add_swingers([Vector2(745.0, 0.0), Vector2(775.0, 0.5)], func(swinger: Swinger) -> void:
		swinger.weight_radius = 1.7
		swinger.weight_material = load("res://Assets/Materials/ornament_ball.tres")
		swinger.post_material = load("res://Assets/Materials/planks_triplanar.tres"))


## Past the finish: a log cabin in a snowy clearing under the mountain face,
## with a big decorated Christmas tree and presents. Built from the Kenney
## Holiday cabin modules (1 m pieces), scaled up.
func _add_cabin() -> void:
	var holiday := MODELS + "Props/Holiday/"
	var terrain: Terrain = $Terrain
	var end := track.world_frame_at(track.path.total_length())
	var forward := Vector3(-end.basis.z.x, 0.0, -end.basis.z.z).normalized()
	var right := Vector3(-forward.z, 0.0, forward.x)
	var spot := end.origin + forward * CABIN_AHEAD
	spot.y = terrain.height_at(spot)
	var cabin := StaticBody3D.new()
	cabin.name = "Cabin"
	# Local axes: +x along the front, +z away from the track; the front faces the finish.
	cabin.transform = Transform3D(Basis(right, Vector3.UP, forward).scaled(Vector3.ONE * CABIN_SCALE), spot)
	add_child(cabin)
	var wide := 3
	var piece := func(file: String, at: Vector3, turn: float) -> void:
		var model: Node3D = load(holiday + file).instantiate()
		model.position = at
		model.rotation.y = deg_to_rad(turn)
		cabin.add_child(model)
	# Cells (i, j) sit at x = i - 1, z = j; the front row is j = 0.
	for i in wide:
		var x := float(i - 1)
		piece.call("cabin-doorway.glb" if i == 1 else "cabin-window-a.glb", Vector3(x, 0, 0), 180.0)
		piece.call("cabin-wall.glb" if i != 1 else "cabin-window-a.glb", Vector3(x, 0, 1), 0.0)
		piece.call("cabin-roof-snow.glb", Vector3(x, 1, 1), -90.0)
		piece.call("cabin-roof-snow.glb", Vector3(x, 1, 0), 90.0)
	for j in 2:
		piece.call("cabin-window-a.glb" if j == 0 else "cabin-wall.glb", Vector3(-1, 0, j), -90.0)
		piece.call("cabin-wall.glb" if j == 0 else "cabin-window-a.glb", Vector3(1, 0, j), 90.0)
	piece.call("cabin-corner-logs.glb", Vector3(-1, 0, 1), 0.0)
	piece.call("cabin-corner-logs.glb", Vector3(1, 0, 1), 90.0)
	piece.call("cabin-corner-logs.glb", Vector3(1, 0, 0), 180.0)
	piece.call("cabin-corner-logs.glb", Vector3(-1, 0, 0), -90.0)
	piece.call("wreath-decorated.glb", Vector3(0, 0.62, -0.62), 180.0)
	piece.call("lantern.glb", Vector3(0.62, 0, -0.75), 0.0)
	_add_gables(cabin)
	var walls := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(3.2, 1.9, 2.2)
	walls.shape = box
	walls.position = Vector3(0, 0.95, 0.5)
	cabin.add_child(walls)
	# Smoke from the chimney end of the ridge.
	var smoke := CPUParticles3D.new()
	smoke.amount = 40
	smoke.lifetime = 6.0
	smoke.preprocess = 6.0
	smoke.direction = Vector3(0.15, 1, 0)
	smoke.spread = 8.0
	smoke.gravity = Vector3(0.25, 0.35, 0)
	smoke.initial_velocity_min = 0.25
	smoke.initial_velocity_max = 0.4
	smoke.scale_amount_min = 0.6
	smoke.scale_amount_max = 1.6
	var puff := SphereMesh.new()
	puff.radius = 0.12
	puff.height = 0.24
	var grey := StandardMaterial3D.new()
	grey.albedo_color = Color(0.85, 0.86, 0.9, 0.35)
	grey.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	grey.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	puff.material = grey
	smoke.mesh = puff
	smoke.position = Vector3(1.0, 1.75, 0.5)
	cabin.add_child(smoke)
	# The Christmas tree beside the cabin, presents under it.
	var tree_spot := end.origin + forward * (CABIN_AHEAD - 12.0) + right * 15.0
	tree_spot.y = terrain.height_at(tree_spot)
	var tree: Node3D = load(MODELS + "Trees/Holiday/tree-decorated-snow.glb").instantiate()
	tree.scale = Vector3.ONE * 9.0
	tree.position = tree_spot
	var trunk := StaticBody3D.new()
	var trunk_shape := CollisionShape3D.new()
	var cylinder := CylinderShape3D.new()
	cylinder.radius = 1.2
	cylinder.height = 6.0
	trunk_shape.shape = cylinder
	trunk_shape.position = tree_spot + Vector3.UP * 3.0
	trunk.add_child(trunk_shape)
	add_child(trunk)
	add_child(tree)
	var presents := ["present-a-cube", "present-b-round", "present-a-rectangle"]
	for k in 7:
		var angle := k * TAU / 7.0 + 0.3
		var at := tree_spot + Vector3(cos(angle), 0.0, sin(angle)) * (4.5 + (k % 2) * 1.2)
		at.y = terrain.height_at(at)
		var gift: Node3D = load(holiday + "%s.glb" % presents[k % 3]).instantiate()
		gift.scale = Vector3.ONE * (2.6 + (k % 3) * 0.4)
		gift.position = at
		gift.rotation.y = angle
		add_child(gift)


## A thick snowy forest on the hills round the cabin's clearing, so the
## finish looks out on trees rather than the edge of the world. Trees near the
## clearing are solid and cast shadows; the rest are scenery.
func _clearing_forest() -> Array[Dictionary]:
	var terrain: Terrain = $Terrain
	var end := track.world_frame_at(track.path.total_length())
	var forward := Vector3(-end.basis.z.x, 0.0, -end.basis.z.z).normalized()
	var clearing: Vector4 = terrain.end_clearing
	var centre := end.origin + forward * clearing.x
	var radius := clearing.y
	var reach := radius + clearing.w * 2.2
	var trees := [
		[MODELS + "Trees/Quaternius/pine_a.glb", Vector2(1.8, 2.6)],
		[MODELS + "Trees/Quaternius/pine_b.glb", Vector2(1.8, 2.6)],
		[MODELS + "Trees/Quaternius/pine_d.glb", Vector2(1.8, 2.6)],
		[MODELS + "Trees/Holiday/tree-snow-a.glb", Vector2(5.0, 7.5)],
		[MODELS + "Trees/Holiday/tree-snow-c.glb", Vector2(5.0, 7.5)],
	]
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var found: Array[Dictionary] = []
	var step := 6.5
	var x := -reach
	while x <= reach:
		var z := -reach
		while z <= reach:
			var spot := centre + Vector3(x + rng.randf_range(-2.5, 2.5), 0.0, z + rng.randf_range(-2.5, 2.5))
			z += step
			var d := Vector2(spot.x - centre.x, spot.z - centre.z).length()
			var ahead := (spot - end.origin).dot(forward)
			if d < radius + 2.0 or d > reach or ahead < -12.0 or not terrain.is_drawn(spot, 4.0):
				continue
			var tree: Array = trees[rng.randi_range(0, trees.size() - 1)]
			var size: Vector2 = tree[1]
			var near := d < radius + 22.0
			found.append({"scene": tree[0], "world": spot, "scale": rng.randf_range(size.x, size.y),
				"collision": "trunk" if near else "none", "radius": 0.3 if tree[0].contains("Quaternius") else 0.12,
				"snow": tree[0].contains("Quaternius"), "shadows": near, "fade": 0.0 if near else 320.0})
		x += step
	return found


## The triangles under the roof at each end of the cabin, in log brown.
func _add_gables(cabin: Node3D) -> void:
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	for x in [-1.5, 1.5]:
		var a := Vector3(x, 1.0, -0.5)
		var b := Vector3(x, 1.0, 1.5)
		var c := Vector3(x, 1.85, 0.5)
		var normal := Vector3(signf(x), 0, 0)
		for v in ([a, c, b] if x > 0 else [a, b, c]):
			tool.set_normal(normal)
			tool.add_vertex(v)
	var wood := StandardMaterial3D.new()
	wood.albedo_color = Color(0.42, 0.27, 0.17)
	wood.roughness = 0.9
	wood.cull_mode = BaseMaterial3D.CULL_DISABLED
	var view := MeshInstance3D.new()
	view.mesh = tool.commit()
	view.material_override = wood
	cabin.add_child(view)


## A frozen river across the course, under the jump.
func _add_frozen_river() -> void:
	var frame := track.world_frame_at(RIVER_AT)
	var terrain: Terrain = $Terrain
	var plane := PlaneMesh.new()
	plane.size = Vector2(14.0, 260.0)
	plane.material = load("res://Assets/Materials/ice_road.tres")
	var river := MeshInstance3D.new()
	river.name = "FrozenRiver"
	river.mesh = plane
	var heading := atan2(-frame.basis.z.x, -frame.basis.z.z)
	var ground := terrain.height_at(frame.origin)
	river.global_transform = Transform3D(Basis(Vector3.UP, heading + PI * 0.5), Vector3(frame.origin.x, ground + 0.08, frame.origin.z))
	add_child(river)


func _add_snowfall() -> void:
	_snow = CPUParticles3D.new()
	_snow.name = "Snowfall"
	_snow.amount = 900
	_snow.lifetime = 7.0
	_snow.preprocess = 7.0
	_snow.local_coords = false
	_snow.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_snow.emission_box_extents = Vector3(45, 1, 45)
	_snow.direction = Vector3(0.2, -1, 0.1)
	_snow.spread = 12.0
	_snow.gravity = Vector3.ZERO
	_snow.initial_velocity_min = 2.0
	_snow.initial_velocity_max = 3.5
	_snow.scale_amount_min = 0.6
	_snow.scale_amount_max = 1.4
	var flake := SphereMesh.new()
	flake.radius = 0.035
	flake.height = 0.07
	flake.radial_segments = 6
	flake.rings = 3
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(1, 1, 1)
	flake.material = material
	_snow.mesh = flake
	add_child(_snow)


func _process(_delta: float) -> void:
	if _snow == null:
		return
	if _camera == null or not is_instance_valid(_camera):
		_camera = get_viewport().get_camera_3d()
	if _camera:
		_snow.global_position = _camera.global_position + Vector3.UP * 14.0


func _sound(file: String) -> AudioStream:
	return load(SOUNDS + file) if ResourceLoader.exists(SOUNDS + file) else null


## Swinging weights across the track at (distance, phase) pairs.
func _add_swingers(spots: Array, setup: Callable) -> void:
	for spot: Vector2 in spots:
		var swinger := Swinger.new()
		swinger.name = "Swinger_%d" % int(spot.x)
		swinger.track = track
		swinger.terrain = $Terrain
		swinger.at_distance = spot.x
		swinger.phase = spot.y
		setup.call(swinger)
		add_child(swinger)
