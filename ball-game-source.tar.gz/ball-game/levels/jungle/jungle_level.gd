extends Level
## Forest: a mossy stone causeway weaving between tall trees whose crowns
## close over it, a very wiggly stretch, a jump between branches, then down on
## the forest floor through a fallen hollow log, ferns and overgrown ruins,
## up again into a banked wall ride and a loop, and through the ferns to the
## finish. Forested hills close in on every side.

const MODELS := "res://Assets/Models/"
const Q := "res://Assets/Models/Trees/Quaternius/"
const P := "res://Assets/Models/Plants/Quaternius/"
const SOUNDS := "res://Assets/Sounds/Jungle/"

## Where things are along the track (see tools/level_specs.py).
const FLOOR_FROM := 405.0
const HOLLOW_LOG_AT := 524.0
const POND_FROM := 412.0
const POND_TO := 492.0
const RUINS_FROM := 535.0
const FERNS_FROM := 1045.0
## Huge boulders blocking the ground beside the course (distance, metres right).
const BOULDERS: Array[Vector2] = [
	Vector2(90, -24), Vector2(130, 22), Vector2(250, -26), Vector2(300, 30), Vector2(360, -22),
	Vector2(640, 24), Vector2(700, -26), Vector2(760, 26), Vector2(860, -24), Vector2(930, 24),
	Vector2(990, -22), Vector2(1020, 26), Vector2(1130, -20), Vector2(1150, 22),
]


func _ready() -> void:
	$Supports.build()
	var props: PropScatter = $Props
	props.headroom = 5.5
	props.ground_lane = 4.0
	var tall_tree := func(scene: String, count: int, band: Vector2, scale: Vector2, spacing: float, fade := 0.0) -> Dictionary:
		return {"scene": Q + scene, "count": count, "band": band, "scale": scale, "collision": "trunk",
			"radius": 0.25, "canopy": Vector2(0.42, 2.0), "spacing": spacing, "bounce": 0.4, "fade": fade, "sink": 0.4}
	props.kinds = [
		# Tall trees right beside the track: their crowns hang over it.
		tall_tree.call("tree_a.glb", 45, Vector2(7.5, 14), Vector2(2.1, 2.6), 9.0),
		tall_tree.call("tree_b.glb", 45, Vector2(7.5, 14), Vector2(2.1, 2.6), 9.0),
		tall_tree.call("tree_e.glb", 35, Vector2(8, 18), Vector2(2.3, 2.8), 10.0),
		# The forest on the hills around.
		tall_tree.call("tree_a.glb", 70, Vector2(18, 240), Vector2(2.2, 3.2), 16.0, 220.0),
		tall_tree.call("tree_b.glb", 70, Vector2(18, 240), Vector2(2.2, 3.2), 16.0, 220.0),
		tall_tree.call("tree_a.glb", 60, Vector2(18, 240), Vector2(2.2, 3.2), 16.0, 220.0),
		tall_tree.call("tree_e.glb", 60, Vector2(18, 240), Vector2(2.2, 3.2), 16.0, 220.0),
		tall_tree.call("tree_e.glb", 70, Vector2(18, 240), Vector2(2.2, 3.2), 16.0, 220.0),
		{"scene": P + "fern.glb", "count": 120, "band": Vector2(5.5, 60), "scale": Vector2(0.45, 0.8), "spacing": 4.0},
		{"scene": P + "plant_big.glb", "count": 90, "band": Vector2(5.5, 50), "scale": Vector2(0.9, 1.6), "spacing": 3.0},
		{"scene": P + "plant.glb", "count": 120, "band": Vector2(5.0, 50), "scale": Vector2(1.0, 1.8), "spacing": 2.5},
		{"scene": P + "tall_grass.glb", "count": 100, "band": Vector2(5.0, 40), "scale": Vector2(1.2, 2.0), "spacing": 2.0},
		{"scene": P + "bush_flowers.glb", "count": 50, "band": Vector2(6.0, 60), "scale": Vector2(1.2, 2.0), "spacing": 4.0},
		{"scene": P + "mushroom_shelf.glb", "count": 30, "band": Vector2(5.5, 30), "scale": Vector2(1.0, 1.8), "spacing": 4.0},
		{"scene": MODELS + "Rocks/Quaternius/rock_b.glb", "count": 40, "band": Vector2(7, 120), "scale": Vector2(1.0, 2.2),
			"collision": "hull", "spacing": 8.0, "sink": 0.3},
		{"scene": MODELS + "Rocks/Quaternius/rock_c.glb", "count": 40, "band": Vector2(7, 120), "scale": Vector2(1.0, 2.2),
			"collision": "hull", "spacing": 8.0, "sink": 0.3},
	]
	# Forest-floor obstacles and ruins beside the racing line.
	props.placements = [
		# (The pond fills the start of the forest floor: its banks are kept clear.)
		{"scene": MODELS + "Props/Nature/statue_head.glb", "at": Vector2(RUINS_FROM + 12, -6.8), "scale": 6.0, "yaw": 70, "collision": "hull", "sink": 0.5},
		{"scene": MODELS + "Props/Nature/statue_column.glb", "at": Vector2(RUINS_FROM + 24, 5.5), "scale": 7.0, "collision": "hull"},
		{"scene": MODELS + "Props/Nature/statue_columnDamaged.glb", "at": Vector2(RUINS_FROM + 38, -5.2), "scale": 7.0, "collision": "hull"},
		{"scene": MODELS + "Props/Nature/statue_columnDamaged.glb", "at": Vector2(RUINS_FROM + 50, 5.4), "scale": 6.0, "yaw": 45, "collision": "hull"},
		{"scene": MODELS + "Props/Nature/statue_obelisk.glb", "at": Vector2(RUINS_FROM + 61, -6.5), "scale": 8.0, "collision": "hull"},
		{"scene": MODELS + "Props/Nature/statue_block.glb", "at": Vector2(RUINS_FROM + 70, 5.0), "scale": 4.0, "yaw": 15, "dynamic": true, "mass": 8.0},
		{"scene": MODELS + "Props/Nature/statue_block.glb", "at": Vector2(RUINS_FROM + 72, -4.8), "scale": 3.5, "yaw": 40, "dynamic": true, "mass": 6.0},
		{"scene": MODELS + "Trees/Nature/log_large.glb", "at": Vector2(FERNS_FROM + 15, -5.0), "scale": 4.5, "yaw": -30, "collision": "hull"},
		{"scene": MODELS + "Rocks/Quaternius/rock_b.glb", "at": Vector2(FERNS_FROM + 30, 5.5), "scale": 1.3, "collision": "hull", "sink": 0.2},
		{"scene": Q + "tree_d.glb", "at": Vector2(FERNS_FROM + 42, 6.0), "scale": 2.2, "collision": "trunk", "radius": 0.25},
	]
	# Huge boulders on the open forest floor, in the way of anyone who rolled
	# off the course and is trying to take a short cut along the ground.
	var boulders := ["stone_largeA", "stone_largeC", "stone_tallB"]
	var k := 0
	for spot: Vector2 in BOULDERS:
		props.placements.append({"scene": MODELS + "Rocks/Nature/%s.glb" % boulders[k % boulders.size()], "at": spot,
			"scale": 9.0 + (k % 3) * 2.0, "yaw": k * 53.0, "collision": "hull", "sink": 1.2})
		k += 1
	# The fallen hollow log the track runs through: nothing grows inside it.
	props.clear_spans = PackedVector3Array([Vector3(HOLLOW_LOG_AT - 18.0, HOLLOW_LOG_AT + 18.0, 8.5),
		Vector3(POND_FROM, POND_TO, 13.0)])
	props.build()
	var hollow := HollowLog.new()
	hollow.name = "HollowLog"
	hollow.track = track
	hollow.terrain = $Terrain
	hollow.at_distance = HOLLOW_LOG_AT
	hollow.bark_texture = load("res://Assets/Models/Quaternius/Textures/Bark_NormalTree.png")
	hollow.bark_normal = load("res://Assets/Models/Quaternius/Textures/Bark_NormalTree_Normal.png")
	hollow.fungus = load(P + "mushroom_shelf.glb")
	hollow.fern = load(P + "fern.glb")
	add_child(hollow)
	# A boulder swinging on a chain across the climb to the root break.
	# A round mossy boulder, unlike the jagged rocks lying about.
	_add_swingers([Vector2(645.0, 0.0)], func(swinger: Swinger) -> void:
		swinger.weight_material = load("res://Assets/Materials/mossy_rock_triplanar.tres")
		swinger.weight_radius = 1.6
		swinger.post_material = load("res://Assets/Materials/bark_triplanar.tres"))
	# A lily pond across the forest floor: hop along the springy pads, or
	# wade slowly through the water.
	var pond := LilyPond.new()
	pond.name = "LilyPond"
	pond.track = track
	pond.terrain = $Terrain
	pond.from_distance = POND_FROM
	pond.to_distance = POND_TO
	pond.flower = load(P + "bush_flowers.glb")
	# Murky, brown-green water you can't see into.
	pond.water_color = Color(0.27, 0.3, 0.16, 0.93)
	# Wading is slow: the way across is three big lily pads.
	pond.half_width = 9.0
	pond.drag = 7.0
	pond.wade_speed = 3.5
	pond.pad_count = 3
	pond.pad_radius = 3.6
	pond.pad_bounce = 0.2
	pond.pad_zigzag = 1.2
	add_child(pond)
	# Cobblestone walls along the forest floor: no rejoining from the ground.
	var walls := StoneWalls.new()
	walls.name = "StoneWalls"
	walls.track = track
	walls.terrain = $Terrain
	walls.material = load("res://Assets/Materials/cobblestone_wall.tres")
	add_child(walls)
	var ambience := LevelAmbience.new()
	ambience.name = "Ambience"
	ambience.bed = _sound("jungle_ambience.ogg")
	add_child(ambience)


func _sound(file: String) -> AudioStream:
	return load(SOUNDS + file) if ResourceLoader.exists(SOUNDS + file) else null


## Swinging weights across the track at (distance, phase) pairs.
func _add_swingers(spots: Array, setup: Callable) -> void:
	for spot: Vector2 in spots:
		var swinger := Swinger.new()
		swinger.name = "Swinger_%d" % int(spot.x)
		swinger.track = track
		swinger.terrain = $Terrain
		swinger.at_distance = spot.x
		swinger.phase = spot.y
		setup.call(swinger)
		add_child(swinger)
