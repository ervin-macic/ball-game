extends Level
## Beach Boardwalk: plank boardwalks over a pirate bay, a corkscrew over the
## water, a jump over an anchored pirate ship, down onto the sand through a
## ship wrecked in two, then waves roll in from the sea across the beach (ride
## their faces like a half-pipe), back up into a helix, a cannon jump and the
## finish pier. Sandstone cliffs behind the beach.

const SEA_LEVEL := -24.6
const MODELS := "res://Assets/Models/"
const PIRATE := "res://Assets/Models/Props/QuaterniusPirate/"
const SOUNDS := "res://Assets/Sounds/Summer/"

## Where things are along the track (see tools/level_specs.py).
const SHIP_JUMP_AT := 325.0
const BEACH_FROM := 411.0
const WRECK_AT := 438.0
const VENT_AT := 466.0
const WAVE_FROM := 475.0
const WAVE_TO := 560.0
const BEACH_TO := 611.0
const CANNONS_AT := 1184.0
## The stretch of the palm shortcut (metres along it) the barrels roll down.
const BARRELS_FROM := 96.0
const BARRELS_TO := 178.0

var _ball: RigidBody3D


func _ready() -> void:
	$Supports.build()
	var props: PropScatter = $Props
	props.kinds = [
		{"scene": MODELS + "Trees/Pirate/palm-straight.glb", "count": 40, "band": Vector2(12, 70), "scale": Vector2(2.0, 2.6),
			"collision": "trunk", "radius": 0.22, "canopy": Vector2(0.6, 1.3), "min_height": SEA_LEVEL + 0.8, "spacing": 7.0, "sink": 0.3},
		{"scene": MODELS + "Trees/Pirate/palm-bend.glb", "count": 35, "band": Vector2(12, 70), "scale": Vector2(2.0, 2.6),
			"collision": "trunk", "radius": 0.22, "canopy": Vector2(0.6, 1.5), "min_height": SEA_LEVEL + 0.8, "spacing": 7.0, "sink": 0.3},
		{"scene": PIRATE + "palm_a.glb", "count": 30, "band": Vector2(12, 90), "scale": Vector2(3.2, 4.2),
			"collision": "trunk", "radius": 0.12, "canopy": Vector2(0.6, 1.4), "min_height": SEA_LEVEL + 0.8, "spacing": 8.0, "sink": 0.3},
		{"scene": PIRATE + "palm_b.glb", "count": 30, "band": Vector2(12, 90), "scale": Vector2(3.2, 4.2),
			"collision": "trunk", "radius": 0.12, "canopy": Vector2(0.6, 1.4), "min_height": SEA_LEVEL + 0.8, "spacing": 8.0, "sink": 0.3},
		{"scene": PIRATE + "palm_c.glb", "count": 30, "band": Vector2(12, 90), "scale": Vector2(3.2, 4.2),
			"collision": "trunk", "radius": 0.12, "canopy": Vector2(0.6, 1.4), "min_height": SEA_LEVEL + 0.8, "spacing": 8.0, "sink": 0.3},
		{"scene": MODELS + "Rocks/Pirate/rocks-sand-a.glb", "count": 14, "band": Vector2(14, 90), "scale": Vector2(0.8, 1.5),
			"collision": "hull", "min_height": SEA_LEVEL - 1.5, "spacing": 10.0, "sink": 0.4},
		{"scene": PIRATE + "rocks_a.glb", "count": 12, "band": Vector2(20, 150), "scale": Vector2(1.5, 3.0),
			"collision": "hull", "max_height": SEA_LEVEL + 0.5, "spacing": 16.0, "sink": 1.0},
		{"scene": PIRATE + "barrel.glb", "count": 24, "band": Vector2(10, 40), "scale": Vector2(1.6, 2.0),
			"collision": "hull", "min_height": SEA_LEVEL + 0.8, "spacing": 6.0},
		{"scene": PIRATE + "skull.glb", "count": 10, "band": Vector2(10, 40), "scale": Vector2(1.5, 2.5),
			"min_height": SEA_LEVEL + 0.8, "spacing": 12.0},
		{"scene": PIRATE + "large_bone.glb", "count": 6, "band": Vector2(14, 50), "scale": Vector2(1.0, 1.4),
			"min_height": SEA_LEVEL + 0.8, "spacing": 12.0},
		{"scene": MODELS + "Plants/Quaternius/tall_grass.glb", "count": 140, "band": Vector2(14, 120), "scale": Vector2(1.0, 1.6),
			"min_height": SEA_LEVEL + 1.0, "spacing": 3.0},
	]
	var wave_mid := (WAVE_FROM + WAVE_TO) * 0.5
	props.placements = [
		# The pirate ship anchored under the jump, and its rowing boat.
		{"scene": PIRATE + "ship.glb", "at": Vector2(SHIP_JUMP_AT, -26.0), "scale": 1.7, "yaw": 15, "on_ground": false, "y": SEA_LEVEL + 1.0, "collision": "hull"},
		{"scene": PIRATE + "small_ship.glb", "at": Vector2(SHIP_JUMP_AT + 40, -26.0), "scale": 2.0, "yaw": 70, "on_ground": false, "y": SEA_LEVEL - 0.6},
		# Docks running out from the beach, with cargo.
		{"scene": PIRATE + "dock.glb", "at": Vector2(BEACH_FROM + 5, -16.0), "scale": 3.0, "yaw": 90, "sink": 0.5},
		{"scene": PIRATE + "dock_broken.glb", "at": Vector2(BEACH_FROM + 14, -18.0), "scale": 3.0, "yaw": 90, "sink": 0.5},
		{"scene": PIRATE + "anchor.glb", "at": Vector2(WRECK_AT + 14, -11.0), "scale": 3.0, "yaw": 30, "collision": "hull", "sink": 0.3},
		# Pirate stash beside the racing line on the sand: bump into it.
		{"scene": PIRATE + "barrel.glb", "at": Vector2(BEACH_FROM + 6, 6.5), "scale": 1.8, "dynamic": true, "mass": 3.0},
		{"scene": PIRATE + "barrel.glb", "at": Vector2(BEACH_FROM + 7, 8.0), "scale": 1.8, "dynamic": true, "mass": 3.0},
		{"scene": PIRATE + "barrel.glb", "at": Vector2(BEACH_FROM + 9, 7.0), "scale": 1.8, "dynamic": true, "mass": 3.0},
		{"scene": PIRATE + "chest_gold.glb", "at": Vector2(WRECK_AT + 20, 7.5), "scale": 1.4, "yaw": -70, "collision": "hull"},
		{"scene": PIRATE + "gold_bag.glb", "at": Vector2(WRECK_AT + 22, 9.5), "scale": 1.8, "collision": "hull"},
		{"scene": PIRATE + "coins.glb", "at": Vector2(WRECK_AT + 19, 9.8), "scale": 2.0},
		{"scene": PIRATE + "chest_closed.glb", "at": Vector2(WAVE_TO + 20, -7.0), "scale": 1.8, "yaw": 80, "dynamic": true, "mass": 6.0},
		{"scene": PIRATE + "bomb.glb", "at": Vector2(WAVE_TO + 26, 6.5), "scale": 2.0, "dynamic": true, "mass": 2.0},
		{"scene": PIRATE + "bucket.glb", "at": Vector2(WAVE_TO + 28, 7.5), "scale": 2.0, "dynamic": true, "mass": 1.0},
		{"scene": PIRATE + "pirate_house.glb", "at": Vector2(wave_mid, 26.0), "scale": 1.6, "yaw": -90, "collision": "hull"},
		{"scene": MODELS + "Props/Pirate/flag-pirate-high.glb", "at": Vector2(30, 10.0), "scale": 1.6, "collision": "trunk", "radius": 0.1},
		{"scene": MODELS + "Props/Pirate/flag-pirate-high.glb", "at": Vector2(BEACH_TO + 4, -9.0), "scale": 1.6, "collision": "trunk", "radius": 0.1},
		# Cannons guarding the cannon jump.
		{"scene": PIRATE + "cannon.glb", "at": Vector2(CANNONS_AT - 8, 12.0), "scale": 2.2, "yaw": 90, "collision": "hull"},
		{"scene": PIRATE + "cannon.glb", "at": Vector2(CANNONS_AT + 4, -12.0), "scale": 2.2, "yaw": -90, "collision": "hull"},
		{"scene": PIRATE + "barrel.glb", "at": Vector2(CANNONS_AT - 4, 14.0), "scale": 1.8, "collision": "hull"},
	]
	# The wreck the track runs through: no palms growing inside it.
	props.clear_spans = PackedVector3Array([Vector3(WRECK_AT - 24.0, WRECK_AT + 24.0, 12.0)])
	props.build()
	_add_sea()
	var wreck := WreckedShip.new()
	wreck.name = "Wreck"
	wreck.track = track
	wreck.terrain = $Terrain
	wreck.ship = load(PIRATE + "ship.glb")
	wreck.at_distance = WRECK_AT
	add_child(wreck)
	var wave := RideableWave.new()
	wave.name = "Wave"
	wave.track = track
	wave.from_distance = WAVE_FROM
	wave.to_distance = WAVE_TO
	wave.sea_side = -1.0
	wave.phase = 1.5
	wave.crash_sound = _sound("wave_crash.ogg")
	add_child(wave)
	# Giant cannonballs swinging on chains across the run-up to the cliff.
	var iron := StandardMaterial3D.new()
	iron.albedo_color = Color(0.13, 0.13, 0.14)
	iron.metallic = 0.7
	iron.roughness = 0.45
	_add_swingers([Vector2(652.0, 0.0), Vector2(676.0, 0.45)], func(swinger: Swinger) -> void:
		swinger.weight_radius = 1.6
		swinger.weight_material = iron
		swinger.post_material = load("res://Assets/Materials/planks_triplanar.tres"))
	# A steam vent on the sand: land on it and it blasts you into the sky.
	var vent := Vent.new()
	vent.name = "Vent"
	vent.track = track
	vent.terrain = $Terrain
	vent.at_distance = VENT_AT
	add_child(vent)
	# Barrels rolling down the raised boardwalk shortcut toward you: jump them.
	var shortcut := track.get_node_or_null("PalmShortcut") as TrackRoute
	if shortcut:
		var barrels := RollingBarrels.new()
		barrels.name = "RollingBarrels"
		barrels.track = shortcut
		barrels.from_distance = BARRELS_FROM
		barrels.to_distance = BARRELS_TO
		barrels.barrel = load(PIRATE + "barrel.glb")
		add_child(barrels)
	var ambience := LevelAmbience.new()
	ambience.name = "Ambience"
	ambience.bed = _sound("beach_ambience.ogg")
	add_child(ambience)


func bind_race(race: RaceManager) -> void:
	super(race)
	_ball = race.ball


## The sea holds the ball up: a beach ball floats where it falls in (press
## restart to get back to the course).
func _physics_process(_delta: float) -> void:
	if _ball == null:
		return
	var depth := SEA_LEVEL + 0.15 - _ball.global_position.y
	if depth > 0.0:
		var float_up := Vector3.UP * minf(depth, 1.0) * 30.0 * _ball.mass
		var drag := -_ball.linear_velocity * 1.6 * _ball.mass
		_ball.apply_central_force(float_up + drag)


func _add_sea() -> void:
	var plane := PlaneMesh.new()
	plane.size = Vector2(3000, 3000)
	plane.subdivide_width = 160
	plane.subdivide_depth = 160
	var water: ShaderMaterial = load("res://Assets/Materials/beach_water.tres").duplicate()
	var start := track.world_frame_at(BEACH_FROM).origin
	water.set_shader_parameter("shore_point", Vector2(start.x, start.z - 12.0))
	water.set_shader_parameter("offshore_direction", Vector2(0.0, -1.0))
	plane.material = water
	var sea := MeshInstance3D.new()
	sea.name = "Sea"
	sea.mesh = plane
	sea.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	sea.position = Vector3(start.x, SEA_LEVEL, start.z - 300.0)
	add_child(sea)


func _sound(file: String) -> AudioStream:
	return load(SOUNDS + file) if ResourceLoader.exists(SOUNDS + file) else null


## Swinging weights across the track at (distance, phase) pairs.
func _add_swingers(spots: Array, setup: Callable) -> void:
	for spot: Vector2 in spots:
		var swinger := Swinger.new()
		swinger.name = "Swinger_%d" % int(spot.x)
		swinger.track = track
		swinger.terrain = $Terrain
		swinger.at_distance = spot.x
		swinger.phase = spot.y
		setup.call(swinger)
		add_child(swinger)
